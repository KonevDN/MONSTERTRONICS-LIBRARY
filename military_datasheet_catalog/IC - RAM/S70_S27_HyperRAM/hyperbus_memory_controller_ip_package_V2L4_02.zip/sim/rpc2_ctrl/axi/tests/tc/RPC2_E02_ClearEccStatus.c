#ifdef SIMULATION
#include "sltapi_sim.h"
#include "svdpi.h"
#include "dpiheader.h"
#include <math.h>
#include "rpc2_vlld.h"
#include "rpc2_llops.h"
#else
#include <sltapi.h>
#endif
#include "rpc2.h"
#ifdef NCSC
extern int io_printf(const char *fmt, ...);
#define printf io_printf
#endif

char Script[] = "E02_ClearEccStatus";
char TestTitle[] = "Clear ECC Status";

/* Test Configuration */
int ERASE         = 1;
DWORD ECCUNITSIZE = 16; // bytes, will be moved to global var

PDEV pDevice;
STS t0, t1;
char s[81];

DWORD GetECCStatusReg(PDEV pDevice, DWORD EccUnitAddr, WORD *EccReg);
void DispEccReg(WORD reg);
DWORD test_exit(DWORD exit_val);

#ifdef SIMULATION
int c_test()
#else
int main(int argc, char* argv[])
#endif
{
    
    int i, tSector, errTot;
    DWORD errCode;
    DWORD SecAddr, SecSize;
    DWORD EccUnitAddr, EccUnitTot;
    WORD EccReg;
    int loop;

    printf("Test: %s\n", Script);
    printf("%s\n", TestTitle);

#ifndef SIMULATION
    LOOP_COUNT      = GetGlobalVar("LOOP_COUNT");
    SOE             = GetGlobalVar("SOE");
    BEGINSECTOR     = GetGlobalVar("BEGINSECTOR");
    ENDSECTOR       = GetGlobalVar("ENDSECTOR");
    SKIP            = GetGlobalVar("SKIP");
#else
    LOOP_COUNT      = 1;
    SOE             = SOE_SETTING;
    BEGINSECTOR     = 0;
    ENDSECTOR       = 1;
    SKIP            = 0;
#endif
    if (SKIP)
    {
        line_space(2);
        printf("Test is skipped\n");
        return __LINE__;
    }

    printf("ERASE    = %d\n", ERASE);
#ifdef SIMULATION
    pDevice = NewDeviceObject(0, RPC);
#endif
	pDevice = Find_Device(RPC);

    if (!pDevice)
    {
        line_space(2);
        printf("Error: RPC device not found\n");
        return __LINE__;
    }
    printf("Device: %s\n", (char *) SCRPGetFAPIInfo(pDevice, DEVICE_NAME));

    SYS_GetTimestamp(&t0);

    // ================================
    for (loop = 1; loop <= LOOP_COUNT; loop++)
    {
        line_space(2);
        printf("loop = %d\n", loop);

        for (tSector = BEGINSECTOR; tSector <= ENDSECTOR; tSector++)
        {
            if ((errCode = SYS_CheckUserBreak()))
            {
                return test_exit(0);
            }

            if (ERASE)
            {
                printf("Erase Sector %d to clear ECC status...", tSector);

                errCode = SCRPEraseSector(pDevice, tSector, TRUE);
                if (errCode != EC_NONE)
                {
                    printf("\nError: sector %04d %s\n", tSector, GetErrorText(errCode));
                    #ifndef SIMULATION
                    OutputLog(pDevice, LOG_DISP_NORM, 0, -100);
                    #endif
                    //if (SET_BAD)
                    //    SCRPSetBadSector(pDevice, tSector);
                    if (SOE)
                        return test_exit(__LINE__);
                    else
                        continue;
                } // if (errCode != EC_NONE)
                else
                    printf("OK\n");
            } // Erase sectors

            printf("Check sector %d ECC status... \n", tSector);
            SecAddr = SCRPGetFAPIGeometry(pDevice, ADDRESS_OF_SECTOR, tSector);
            SecSize = SCRPGetFAPIGeometry(pDevice, BYTE_COUNT_OF_SECTOR, tSector);
            EccUnitTot = SecSize / ECCUNITSIZE;
            errTot = 0;
            for (i = 0; i < EccUnitTot; i++)
            {

                //SYS_WaitUSec(50000);
                if ((errCode = SYS_CheckUserBreak()))
                {
                    return test_exit(0);
                }

                EccReg = 0xFF;
                EccUnitAddr = SecAddr + (i * ECCUNITSIZE);
                GetECCStatusReg(pDevice, EccUnitAddr, &EccReg);
                if (EccReg & 0x07)
                {
                    errTot++;
                    printf("Error: ECC Status Register = 0x%04X (unit %d, addr 0x%08lX)\n", EccReg, i, EccUnitAddr);
                    line_space(0);
                    DispEccReg(EccReg);
                    line_space(0);
                    if (SOE)
                        return test_exit(__LINE__);
                }
                if ((i % 100) == 0)
                    printf(".");
            } // for (i = 0; i < EccUnitTot; i++)
            if (errTot == 0)
                printf(" PASS \n");
        } // for (tSector = BEGINSECTOR; tSector <= ENDSECTOR; tSector++)
    } // for (loop = 1; loop <= LOOP_COUNT; loop++)
    // ================================

    line_space(2);
    printf("Test complete\n");
    return test_exit(0);

} //main

DWORD GetECCStatusReg(PDEV pDevice, DWORD EccUnitAddr, WORD *EccReg)
{
    DWORD addr;
    WORD EccStsArray[32];

    addr = EccUnitAddr & ~0x1F;
    SCRPCmd(pDevice, 0x555, 0xAA);
    SCRPCmd(pDevice, 0x2AA, 0x55);
    SCRPCmd(pDevice, 0x555, 0x75);
    SCRPCmd(pDevice, 0x555, 0xAA);
    *EccReg = SCRPRead(pDevice, addr);
    SCRPCmd(pDevice, 0x0, 0xF0);

    return EC_NONE;
} // GetECCStatusReg()

void DispEccReg(WORD reg)
{
    printf("Bit 15-8 (RFU)                         = %04X\n", (reg & 0xFF00));
    printf("Bit 7 (RFU)                            = %d\n", (reg & 0x0080) ? 1 : 0);
    printf("Bit 6 (RFU)                            = %d\n", (reg & 0x0040) ? 1 : 0);
    printf("Bit 5 (RFU)                            = %d\n", (reg & 0x0020) ? 1 : 0);
    printf("Bit 4 (2BD - 2b ECC Detection)         = %d\n", (reg & 0x0010) ? 1 : 0);
    printf("Bit 3 (CB - 1b ECC Correction)         = %d\n", (reg & 0x0008) ? 1 : 0);
    printf("Bit 2 (EECC - Error in ECC)            = %d\n", (reg & 0x0004) ? 1 : 0);
    printf("Bit 1 (EECCD - Error in ECC unit data) = %d\n", (reg & 0x0002) ? 1 : 0);
    printf("Bit 0 (ECCDI - ECC disabled)           = %d\n", (reg & 0x0001) ? 1 : 0);

    printf("\n");
    printf("RFU : reserved for future use\n");
    printf("2BD : 1 = 2b ECC detection occurred since last ECCSR read\n");
    printf("      0 = No 2b ECC detection occurred since last ECCSR read\n");
    printf("CB  : 1 = ECC correction performed since last ECCSR read\n");
    printf("      0 = No ECC correction performed since last ECCSR read\n");
    printf("EECC: 1 = single bit error found in the ECC unit error correct code\n");
    printf("      0 = no error\n");
    printf("EECCD 1 = single bit error corrrected in ECC unit data\n");
    printf("      0 = no error\n");
    printf("ECCDI 1 = ECC is disabled in the selected ECC unit\n");
    printf("      0 = ECC is enabled in the selected ECC unit\n");

} // DispEccReg();


DWORD test_exit(DWORD exit_val)
{

    SYS_GetTimestamp(&t1);
    FormatDeltaTime(s, &t0, &t1);
    line_space(2);
    printf("Test time: %s\n", s);

    if (exit_val)
    {
        SetGlobalVar("SKIP", 1);
	printf("<TC> Test =========================== Fail\n");
    }
    else {
      printf("<TC> Test =========================== Pass\n");
    }

    return(exit_val);
} // test_exit()


