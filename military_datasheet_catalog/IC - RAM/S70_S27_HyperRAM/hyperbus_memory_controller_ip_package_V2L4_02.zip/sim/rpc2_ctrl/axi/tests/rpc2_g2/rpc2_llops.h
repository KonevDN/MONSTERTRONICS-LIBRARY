/*******************************************************************************
 *
 *  Filename:       rpc_driver.h
 *
 *                  delare APIs of rpc driver 
 *
 *  Created:        Wei Huang (3/1/2012)
 *
 *  Modified:       $Author:
 *
 *******************************************************************************
 *  Copyright (C) 2012, Spansion Inc. All Rights Reserved.
 ******************************************************************************/
#ifndef __RPC_DRIVER_HEADER
#define __RPC_DRIVER_HEADER


#ifdef NCSC
extern int io_printf(const char *fmt, ...);
#define printf io_printf
#endif

/*******************************************************************************
 * constants
 ******************************************************************************/
#define RPC_DEVICE_CNT		1
//#define RPC_DEVICE_CNT		4
#define MAX_POLLING_NUM 100000

/* RPC Flash commands instruction value ------------- */
#define RPC_ID_ENTRY		0x90
#define RPC_SW_RESET		0xF0

#define RPC_RD_SR			0x70
#define RPC_CLR_SR			0x71
#define RPC_LD_VCR			0x38
#define RPC_RD_VCR			0xC7
#define RPC_PROG_NVCR		0x39
#define RPC_RD_NVCR			0xC6
#define RPC_WR_BUF			0x25
#define RPC_PROG_BUF		0x29
#define RPC_ERASE_SECTOR	0x80
#define RPC_BLANK_CHECK		0x33

//RPC2 new commands
#define RPC_PROG_WD         0xA0
#define RPC_PROG_PORTR      0x34
#define RPC_RD_PORTR        0x3A
#define RPC_LD_ICR          0x36
#define RPC_RD_ICR          0xC4
#define RPC_LD_ISR          0x37
#define RPC_RD_ISR          0xC5
#define RPC_PROG_PORTR      0x34
#define RPC_ERASE_NVCR      0xC8
#define RPC_PROG_FIDR       0x3A
#define RPC_RD_FIDR         0x3B
#define RPC_CHIP_ERASE      0x10
#define RPC_EVAL_ES         0xD0
#define RPC_ERASE_SUSPEND   0xB0
#define RPC_ERASE_RESUME    0x30
#define RPC_PROG_SUSPEND    0x51
#define RPC_PROG_RESUME     0x50
#define RPC_SSR_ENTRY       0x88
#define RPC_SSR_EXIT        0x90
#define RPC_ASP_ENTRY       0x40
#define RPC_ASP_PROG        0xA0
#define RPC_ASP_EXIT        0x90
#define RPC_PASSWD_ENTRY    0x60
#define RPC_PASSWD_EXIT     0x90
#define RPC_PPB_ENTRY       0xC0
#define RPC_PPB_ERASE       0x30
#define RPC_PPB_PROG        0xA0
#define RPC_PPB_RD_SAPS     0x60
#define RPC_PPB_EXIT        0x90
#define RPC_PPB_LOCK_ENTRY  0x50
#define RPC_DYB_ENTRY       0xE0
#define RPC_DYB_SET_CLR     0xA0
#define RPC_DYB_RD_SAPS     0x60
#define RPC_DYB_EXIT        0x90
#define RPC_ECC_ENTRY       0x75
#define RPC_CRC_ENTRY       0x78
#define RPC_CRC_LD_START_ADDR   0xC3
#define RPC_CRC_LD_END_ADDR     0x3C


#ifdef SIMULATION
#define CS0_BASE_ADDR		0x00000000		//Base address for rpc controller SLT mode r\w
#define CS1_BASE_ADDR		0x08000000		//Base address for rpc controller SLT mode r\w
#else
#define CS0_BASE_ADDR		0x08000000		//Base address for rpc controller SLT mode r\w
#define CS1_BASE_ADDR		0x18000000		//Base address for rpc controller SLT mode r\w
#endif
#define RDDPRAM_BASE_ADDR	0x00002000		//Base address of RDDPRAM in rpc controller
#define WRDPRAM_BASE_ADDR	0x00001000		//Base address of WRDPRAM in rpc controller

//Fixed Mapping of WRDPRAM for Memory Operation in SLT (normal and loopback mode)
#define RDOP_WL				3
#define SROP_WL				4
#define BUFOP_WL			4	
#define BCOP_WL				4
#define SRSOP_WL			7	
#define ASOP_WL				12
#define RVCROP_WL			15
#define RNVCROP_WL			15
#define STSCLROP_WL			16	
#define LVCROP_WL			16	
#define PNVCROP_WL			16	
#define SEOP_WL				24
#define WBUFOP_WL			20	
		
#define RDOP_ADDR			0
#define SROP_ADDR			4
#define BUFOP_ADDR			8	
#define BCOP_ADDR			12
#define SRSOP_ADDR			16	
#define ASOP_ADDR			24
#define RVCROP_ADDR			36	
#define RNVCROP_ADDR		52
#define STSCLROP_ADDR		68	
#define LVCROP_ADDR			84	
#define PNVCROP_ADDR		100
#define SEOP_ADDR			116
#define WBUFOP_ADDR			140

//Fixed Mapping of RDDPRAM for Memory Operation in SLT (normal and loopback mode)
#define RDOP_RL				1
#define SROP_RL				0
#define BUFOP_RL			0	
#define BCOP_RL				0
#define SRSOP_RL			1	
#define ASOP_RL				0
#define RVCROP_RL			1
#define RNVCROP_RL			1
#define STSCLROP_RL			0	
#define LVCROP_RL			0	
#define PNVCROP_RL			0	
#define SEOP_RL				0
#define WBUFOP_RL			0	
		
#define RDOP_RDADDR			0
#define SROP_RDADDR			0
#define BUFOP_RDADDR		0	
#define BCOP_RDADDR			0
#define SRSOP_RDADDR		0	
#define ASOP_RDADDR			0
#define RVCROP_RDADDR		0
#define RNVCROP_RDADDR		0	
#define STSCLROP_RDADDR		0	
#define LVCROP_RDADDR		0	
#define PNVCROP_RDADDR		0
#define SEOP_RDADDR			0
#define WBUFOP_RDADDR		0

/*******************************************************************************
 * types and structures
 ******************************************************************************/
/* basic types -------------------------------- */

#ifndef UINT8
typedef unsigned char		UINT8;
#endif
#ifndef UINT16
typedef unsigned short		UINT16;
#endif
#ifndef UINT32
typedef unsigned int		UINT32;
#endif
#ifndef UINT64
typedef unsigned long long	UINT64;
#endif
/*
#ifndef BOOL
typedef enum { FALSE=0, TRUE=1 } BOOL;
#endif
*/
typedef float				float32;
typedef double				float64;

/* rpc flash register ------------------------------- */
typedef union {
	struct {
		UINT16 RESERVED3	:4;
		UINT16 PSB				:1;
		UINT16 ESB				:1;
		UINT16 RESERVED2	:1;
		UINT16 DRB				:1;
		UINT16 RESERVED1	:8;
	};
	UINT16 val;
} __attribute__((packed)) rpc_sr_t;
#define RPC_SR_EER		0x0020
#define RPC_SR_PER		0x0010

#define RPC_SR_ERRBIT	(RPC_SR_EER|RPC_SR_PER)

/*
#define APU_ST_IS_ALLOK(reg0)		((reg0.val&APU_REG0_ERRBIT)==0)
#define APU_ST_ISNOT_ALLOK(reg0)	((reg0.val&APU_REG0_ERRBIT))
#define APU_ST_IS_DONE(reg0)		(reg0.DB==0)
#define APU_ST_IS_BUSY(reg0)		(reg0.DB==1)
#define APU_ST_IS_DATA_READY(reg0)	(reg0.NRR==1)

typedef UINT8             apu_reg1_t;
*/

typedef union {
	struct {
		UINT16 BURST_LEN	:2;
		UINT16 DR_STRENGTH:2;
		UINT16 RD_LC			:4;
		UINT16 RESERVED1	:8;
	};
	UINT16 val;
} __attribute__((packed)) rpc_cr_t;

typedef UINT32 faddr_t;
/* flash device info -------------------------- */
typedef struct {
	unsigned int rd_addr_algn;		// x16/x32, number of byte

	unsigned int sz_page;			// bytes in each page
	unsigned int nr_page;			// pages in each sector
	unsigned int sz_sec;			// bytes in each sector
	unsigned int nr_sec;			// total number of sector

	unsigned int total_size;		// total bytes

	unsigned int tmout_wrr_us;		// timeout for WRR, us
	unsigned int tmout_wrcfg_us;	// timeout for WRAPUCFG0/1, us
	unsigned int tmout_pp_us;		// timeout for PP, us
	unsigned int tmout_se_ms;		// timeout for SE, ms
	unsigned int tmout_be_ms;		// timeout for BE, ms
} fdev_info_t;

/* rpc protocol format ------------------------ */
typedef union {
	struct {
		UINT64 RESEVERD2		:16;
		UINT64 WORD_ADDR		:4;
		UINT64 RESERVED			:9;
		UINT64 RFU2				:2;
		UINT64 BURST_TYPE		:1;
		UINT64 PAGE_ADDR  		:25;
		UINT64 RFU1				:5;
		UINT64 TARGET			:1;
		UINT64 R_W				:1;
	};
	UINT16 rpc_ca[4];
} __attribute__((packed)) rpc_ca_t;

/* rpc controller register -------------------------- */
#define RPC_RRR					0x0000
#define RPC_MCR					0x0002
#define RPC_RPCSR				0x0004
#define RPC_WDSAR				0x0006
#define RPC_WDLR				0x0008
#define RPC_RDAMR				0x000A
#define RPC_WDRSR				0x000C
#define RPC_RDDAR				0x000E
#define RPC_RDLR				0x0010
#define RPC_RDRSR				0x0012
#define RPC_WRRDR				0x0014
#define RPC_RSTGR				0x0016
#define RPC_CLKSR				0x0018
#define RPC_LPBKSR			0x001A
#define RPC_CHSR				0x001C
#define RPC_IWSR			0x001E
#define RPC_EMWSR			0x0020
#define RPC_HIAR				0x0022
#define RPC_CHWER				0x0024
#define RPC_RCMCR				0x0026
#define RPC_LEDPIO				0x0028
#define RPC_OSCI2C				0x002A
#define RPC_CS2CSD				0x002C
#define RPC_OMSR				0x002E
#define RPC_TMR					0x0030
#define RPC_BMR					0x0032
#define RPC_WRDPRAM				0x1000
#define RPC_RDDPRAM				0x2000


/* rpc ctrl prarmeter ----------------------------- */
#define MAX_RD_BUF_SIZE 	2048

#define RPC_CS0				0x0001
#define RPC_CS1				0x0002
#define RPC_CS2				0x0004
#define RPC_CS3				0x0008

#define WR_WS_LN0			0x1000
#define WR_WS_LN1			0x2000
#define WR_WS_LN2			0x4000
#define WR_WS_LN3			0x8000

#define RR_RS_LN0			0x0100
#define RR_RS_LN1			0x0200
#define RR_RS_LN2			0x0400
#define RR_RS_LN3			0x0800

#define WR_RS_LN0			0x1000
#define WR_RS_LN1			0x2000
#define WR_RS_LN2			0x4000
#define WR_RS_LN3			0x8000

#define RR_WS_LN0			0x0100
#define RR_WS_LN1			0x0200
#define RR_WS_LN2			0x0400
#define RR_WS_LN3			0x0800

#define RPC_WE0_N			0x0001
#define RPC_WE1_N			0x0002
#define RPC_WE2_N			0x0004
#define RPC_WE3_N			0x0008

typedef union {
	struct {
		UINT32 READ_TRANS	:5;
		UINT32 RFU1	        :11;
        UINT32 WRITE_TRANS	:5;
		UINT32 RFU2	        :11;
	};
	UINT32 val;
} __attribute__((packed)) trinity_ctrl_tcsr_t;

typedef union {
	struct {
		UINT16 REV_MINOR	:8;
		UINT16 REV_MAJOR	:8;
	};
	UINT16 val;
} __attribute__((packed)) rpc_ctrl_rrr_t;

typedef union {
	struct {	
		UINT16 RFU			:13;
		UINT16 AUTO_REPEAT	:1;
		UINT16 REPEAT		:1;
		UINT16 STRT_CMD		:1;
	};
	UINT16 val;
} __attribute__((packed)) rpc_ctrl_mcr_t;

typedef union {
	struct {
		UINT16 RESERVED		:10;
		UINT16 CLK_STATE	:1;
		UINT16 CMD_DONE		:1;
		UINT16 RX_DONE		:1;
		UINT16 TX_DONE		:1;
		UINT16 CMD_ACCEPTED	:1;
		UINT16 IDLE			:1;
	};
	UINT16 val;
} __attribute__((packed)) rpc_ctrl_rpcsr_t;

typedef union {
	struct {
		UINT16 INIT_LAT			:8;
		UINT16 RFU				:7;
		UINT16 RPC_BURST_MODE	:1;
	};
	UINT16 val;
} __attribute__((packed)) rpc_ctrl_rdamr_t;

typedef union {
	struct {
		UINT16 RFU			:13;
		UINT16 RO			:1;
		UINT16 WRRD			:1;
		UINT16 WO			:1;
	};
	UINT16 val;
} __attribute__((packed)) rpc_ctrl_wrrdr_t;

typedef union {
	struct {
		UINT16 RST_PUL_WD	:11;
		UINT16 RST_CLK_GEN	:1;
		UINT16 RST_RDFIFO	:1;
		UINT16 RST_WRFIFO	:1;
		UINT16 RST_RPC		:1;
		UINT16 RST_DEV		:1;
	};
	UINT16 val;
} __attribute__((packed)) rpc_ctrl_rstgr_t;

typedef union {
	struct {
		UINT16 RFU			:7;
		UINT16 RPC_CLK_MULT :1;
		UINT16 CLK_FREQ		:8;
	};
	UINT16 val;
} __attribute__((packed)) rpc_ctrl_clksr_t;

typedef union {
	struct {
		UINT16 RFU			:15;
		UINT16 LBK_MODE		:1;
	};
	UINT16 val;
} __attribute__((packed)) rpc_ctrl_lpbkr_t;

typedef union {
	struct {
		UINT16 RFU				:8;
		UINT16 ADDR				:8;
	};
	UINT16 val;
} __attribute__((packed)) rpc_ctrl_hiar_t;

typedef union {
	struct {
		UINT16 BURST_LEN		:13;
		UINT16 RFU				:2;
		UINT16 ASYN_BURST_SEL	:1;
	};
	UINT16 val;
} __attribute__((packed)) rpc_ctrl_rcmcr_t;

typedef union {
	struct {
		UINT16 RFU				:14;
		UINT16 I2C_SCL			:1;
		UINT16 I2C_SDA			:1;
	};
	UINT16 val;
} __attribute__((packed)) rpc_ctrl_osci2c_t;

typedef union {
	struct {
		UINT16 RFU				:10;
		UINT16 CS2CS_DELAY		:6;
	};
	UINT16 val;
} __attribute__((packed)) rpc_ctrl_cs2csd_t;

typedef struct {
	rpc_ctrl_rrr_t 		RRR;						// RPC Revision Register
	rpc_ctrl_mcr_t 		MCR;						// Main Control Register
	rpc_ctrl_rpcsr_t	RPCSR;					// RPC Controller Status Register
	UINT16						WDSAR;					// Write Data Source Address Register in byte
	UINT16						WDLR;						// Write Data Length Register in byte
	rpc_ctrl_rdamr_t	RDAMR;					// RPC Device Access Mode register
	UINT16						WDRSR;					// Write Data RAM Size Register in byte
	UINT16						RDDAR;					// Read Data Destination Address Register in byte
	UINT16						RDLR;						// Read Data Length Register in byte
	UINT16						RDRSR;					// Read Data RAM Size Register in byte
	rpc_ctrl_wrrdr_t	WRRDR;					// Write Read Operation Register
	rpc_ctrl_rstgr_t	RSTGR;					// Reset Generating Register
	rpc_ctrl_clksr_t	CLKSR;					// Clock Setting Register
	rpc_ctrl_lpbkr_t	LPBKR;					// Loop Back Register
	UINT16						CHSR;						// Chip Select Register
	UINT16						IWSR;			// Internal Data Bus Byte Select Register
	UINT16						EMWSR;
	rpc_ctrl_hiar_t		HIAR;						// High Address Bit Register
	UINT16						CHWER;					// Chip Write Enable Register
	rpc_ctrl_rcmcr_t	RCMCR;					// RPC Controller Mode Control Register
	UINT16						LEDPIO;			//LED ON/OFF of 226 Board
	rpc_ctrl_osci2c_t	OSCI2C;					//I2C register Oscillator and power supply of 226 Board
	rpc_ctrl_cs2csd_t	CS2CSD;					//Chip Select to Chip Select Delay
	UINT16					 *WRDPRAM;				// Write Dual Port RAM, 0x1000-0x1FFF 4KB
	UINT16					 *RDDPRAM;				// Read Dual Port RAM, 0x2000-0x2FFF 4KB
}__attribute__((packed)) rpc_ctrl_reg_def_t;

typedef union {
	rpc_ctrl_reg_def_t reg;
	UINT16 val[25];
} __attribute__((packed)) rpc_ctrl_reg_t;

/*******************************************************************************
 * APIs
 ******************************************************************************/
 
 #ifndef SIMULATION
// R/W memory bus
void gpmc_write16(DWORD address, WORD* data);
void gpmc_read16(DWORD address, WORD* data);
BOOL GPMC_Write(DWORD address, WORD* pData, DWORD write_count);
BOOL GPMC_Read(DWORD address, WORD* pData, DWORD read_count);
#endif


/* Flash -------------------------------------- */
//BOOL rpc_get_flash_info(fdev_info_t *pFDevIF);
BOOL RPC_Read_Data(DWORD read_address, DWORD read_length, WORD* pData);
BOOL RPC_Prog_Data(DWORD prog_address, DWORD prog_length, WORD* pData);
BOOL RPC_Buffer_Write_Load(DWORD prog_address, DWORD prog_length);
BOOL RPC_Buffer_Write_Store(DWORD prog_address, DWORD prog_length, WORD* pData);
BOOL RPC_Buffer_Write_Commit(DWORD prog_address);
BOOL RPC_Erase(DWORD sector_address);
BOOL RPC_Read_Reg(DWORD reg_type, WORD* pReg);
BOOL RPC_Prog_Reg(DWORD reg_type, WORD* pReg);
BOOL RPC_Read_CFI(WORD* pCFI);
BOOL RPC_ID_ASO_Exit(void);
void RPC_Reset(void);
BOOL RPC_Clear_SR(void);
BOOL RPC_Blank_Chenk(DWORD sector_address);
void RPC_Write_Protect(DWORD bWP_EN);

/* RPC ---------------------------------------- */
BOOL RPC_Write(DWORD write_address, WORD* data, DWORD length);
BOOL RPC_Read(DWORD read_address, WORD* data, DWORD length);
BOOL RPC_CTRL_Reg_Read(DWORD read_address, DWORD* data);
BOOL RPC_CTRL_Reg_Write(DWORD write_address, DWORD* data);
//BOOL RPC_Read_4DIE(rpc_ca_t* command_address, WORD* data, DWORD length);

/* system ------------------------------------- */
//void sys_get_time_stamp(unsigned long long *p_time_ns);
//void sys_delay(unsigned long long delay_ns);
//void sys_set_rpc_freq(unsigned int freq_mhz);
//unsigned int sys_get_rpc_freq(void);

/* driver ------------------------------------- */
BOOL rpc_driver_init(void);
void rpc_driver_exit(void);
#ifndef SIMULATION
 DWORD rpc_ctrl_init(DWORD type);
#endif

#endif /* ifndef RPC_DRIVER_HEADER */
///////////////////////////////////////////////////////2012-02-28
