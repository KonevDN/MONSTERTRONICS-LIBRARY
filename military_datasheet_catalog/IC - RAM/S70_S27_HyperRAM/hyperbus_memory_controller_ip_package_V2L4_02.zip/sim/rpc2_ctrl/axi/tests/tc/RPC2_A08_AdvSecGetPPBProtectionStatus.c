#ifdef SIMULATION
#include "sltapi_sim.h"
#include "svdpi.h"
#include "dpiheader.h"
#include <math.h>
#include "rpc2_vlld.h"
#include "rpc2_llops.h"
#else
#include <sltapi.h>
#endif
#include "rpc2.h"
#ifdef NCSC
extern int io_printf(const char *fmt, ...);
#define printf io_printf
#endif

//----------------------------------------------------------------------------------
// 	Script: Advanced Sector Persistent Protection Bit test
//  Before running this script, the Include.scp needs to be downloaded first.
//----------------------------------------------------------------------------------

enum
{
	CLEARPPBL,
	SETPPBL,
	SCRPPAGESIZE = 8
};

PDEV pDevice;

DWORD GetPPBProtectionStatus(PDEV dev, DWORD tSecAddr)
{
    DWORD PPB_Status;

    //PPB Entry
    SCRPCmd(dev, 0x555, 0xAA);
    SCRPCmd(dev, 0x2AA, 0x55);
    SCRPCmd(dev, 0x555, 0xC0);
    //SA Protection Status
    SCRPCmd(dev, 0x000, 0x60);
    PPB_Status = SCRPRead(dev, tSecAddr);
    //Command Set Exit
    SCRPCmd(dev, 0x000, 0x90);
    SCRPCmd(dev, 0x000, 0x00);
    PPB_Status = !(PPB_Status & 0x0001);
    return PPB_Status;
}

DWORD tVerifyProtectionOff(PDEV dev, DWORD totalSectors, DWORD chkPPBL)
{
	DWORD errCode, i;
	DWORD secAddr, ASPBit;
	
	errCode = EC_NONE;
	for (i = 0; i < totalSectors; i++)
	{
		secAddr = SCRPGetFAPIGeometry(dev, ADDRESS_OF_SECTOR, i);
		SCRPGetASPFunc(dev, ASP_DYB, secAddr, &ASPBit);
		if (ASPBit)
		{
			printf("DYB ON in sector %d\n", i);
			errCode = EC_DYBSTATE;
			break;
		}
	}
	if (errCode) return errCode;
	for (i = 0; i < totalSectors; i++)
	{
		secAddr = SCRPGetFAPIGeometry(dev, ADDRESS_OF_SECTOR, i);
		//SCRPGetASPFunc(dev, ASP_PPB, secAddr, &ASPBit);
        ASPBit = GetPPBProtectionStatus(dev, secAddr);
		if (ASPBit)
		{
			printf("PPB ON in sector %d\n", i);
			errCode = EC_PPBERASEVERIFY;
			break;
		}
	}
	if (errCode) return errCode;
	if (chkPPBL)
	{
		SCRPGetASPFunc(dev, ASP_PPBL, 0, &ASPBit);
		if (ASPBit)
			errCode = EC_PPBLSET;
	}
	return errCode;
}

DWORD VerifyProtectedSector(PDEV dev, DWORD vSec, DWORD vSecAddr, DWORD sectorTestAddr)
{
	DWORD i;
	WORD rdData;
	
	if (SCRPSProg(dev, vSecAddr+sectorTestAddr, 0) == EC_NONE)
	{
        printf("Error: [0x%x] Protected Sector Program succeeded\n", vSecAddr+sectorTestAddr);
        return EC_PROGSUCCEEDED;
    }
    else
        SCRPClrDeviceStatus(dev, vSecAddr+sectorTestAddr);
    if (SCRPEraseSector(dev, vSec, TRUE) == EC_NONE)
    {
        printf("Error: [0x%x] Protected Sector Erase succeeded\n", vSecAddr);
		return EC_ERASESUCCEEDED;
	}
	else
		SCRPClrDeviceStatus(dev, vSec);
	return EC_NONE;
}

DWORD VerifyUnprotectedSector(PDEV dev, DWORD vSecAddr, DWORD sectorTestAddr)
{
	DWORD errCode, ASPBit;
	WORD rdData;
	
	errCode = EC_NONE;
	//SCRPGetASPFunc(dev, ASP_PPB, vSecAddr, &ASPBit);
    ASPBit = GetPPBProtectionStatus(dev, vSecAddr);
	if (ASPBit)
	{
        printf("Error: [0x%x] PPB is SET (and should NOT be)\n", vSecAddr);
        return EC_PPBSET;
    }
    if (errCode = SCRPSProg(dev, vSecAddr+sectorTestAddr, 0x55AA))
    {
        rdData = SCRPRead(dev, vSecAddr+sectorTestAddr);
        printf("Error: [0x%x] 0x%x, W:0x55AA: Program error\n", vSecAddr+sectorTestAddr, rdData);
    }
    return errCode;
}



DWORD test_exit(DWORD exit_val)
{
    if (exit_val)
    {
        SetGlobalVar("SKIP", 1);
	printf("<TC> Test =========================== Fail\n");
    }
    else {
      printf("<TC> Test =========================== Pass\n");
    }
    return (exit_val);
}

#ifdef SIMULATION
int c_test()
#else
int main(int argc, char* argv[])
#endif
{
	DWORD tSector, tSecAddr, vSecAddr, sectorTestAddr, sec;
	DWORD errCode, totalSectors, i, j, bitPPBL, logStat, ASPBit;
	DWORD ProtectedSecErrCount, UnprotectedSecErrCount, ErrSetASPCount, ErrGetASPCount;
	
#ifndef SIMULATION
    SKIP = GetGlobalVar("SKIP");
#endif
    if (SKIP)
    {
        line_space(2);
        printf("Test is skipped\n");
        return test_exit(__LINE__);
    }

#ifdef SIMULATION
    pDevice = NewDeviceObject(0, RPC);
#endif
	pDevice = Find_Device(RPC);
	
	//if (!(FS_PERSISTENTSECTOR & SCRPSupport(pDevice)))
    if (!(FS_SECTORPROTECT & SCRPSupport(pDevice)))
    {
        printf("Error: Advanced Sector Protection not supported\n");
        return test_exit(__LINE__);
    }

    //Setup persistent protection mode in advance for RPC2 model, HUANG WEI, 20130625
    if (errCode = SCRPSetASPFunc(pDevice, ASP_PWD, 0, PROT_PERSISTENT))
    {
        printf("Error: Enable PERSISTENT fail%s\n", GetErrorText(errCode));
        return test_exit(__LINE__);
    }
    
    if (errCode = SCRPASPUnlock(pDevice))
    {
        printf("Error: %s\n", GetErrorText(errCode));
        return test_exit(__LINE__);
    }

	errCode = EC_NONE;
	// Start at address 1, address 0 is reserved for erase test.
	sectorTestAddr = 1;
	totalSectors = SCRPGetFAPIInfo(pDevice, SECTOR_COUNT);
	printf("Advanced Sector Persistent Protection Bit Test\n");
	SCRPGetASPFunc(pDevice, ASP_PPBL, 0, &bitPPBL);
	if (bitPPBL == 0)
		printf("PPB Lock Bit is OFF\n");
	else
	{
        printf("Error: PPB Lock Bit is ON\n");
        printf("The system needs to do power cycle to clear the PPB Lock Bit\n");
        return test_exit(__LINE__);
    }

    // Clear All PPB
    if (errCode = SCRPSetASPFunc(pDevice, ASP_PPBERASEALL, 0, FALSE))
    {
        printf("Error: PPB Erase: %s\n", GetErrorText(errCode));
        return test_exit(__LINE__);
    }
    //
    if (errCode = tVerifyProtectionOff(pDevice, totalSectors, TRUE))
    {
            printf("Error: Verify DYB/PPB OFF: %s\n", GetErrorText(errCode));
            return test_exit(__LINE__);
	}
#ifndef SIMULATION
	logStat = SaveDevLogState(pDevice);
	//SetLogDevice(pDevice, LOG_NONE);
#endif
	printf("Erasing Sectors ...\n");
    for (tSector = 0; tSector < totalSectors; tSector++)
    {
        if ((errCode = SCRPEraseSector(pDevice, tSector, TRUE)) != EC_NONE)
        {
            printf("Error: Failed to Erase Sector %d\n", tSector);
            return test_exit(__LINE__);
		}
		else
			printf("Sector %d Erased\n", tSector);
	}
#ifndef SIMULATION
	RestoreDevLogState(pDevice, logStat);
#endif
	ErrSetASPCount = 0;
	ErrGetASPCount = 0;

	for (tSector = 0; (tSector < totalSectors) && (errCode == EC_NONE); tSector++)
    {
        tSecAddr  = SCRPGetFAPIGeometry(pDevice, ADDRESS_OF_SECTOR, tSector );
        printf("\nTesting Sector %d ...\n", tSector);
        //
        //SCRPGetASPFunc(pDevice, ASP_PPB, tSecAddr, &ASPBit);
        ASPBit = GetPPBProtectionStatus(pDevice, tSecAddr);
        if (ASPBit)
        {
            errCode = EC_PPBERASEVERIFY;
            printf("Error: Verify PPB OFF [0x%08lX]: %s\n", tSecAddr, GetErrorText(errCode));
            break;
        }
        // Do not program at the beginning of the test sector
        if ((errCode = SCRPSProg(pDevice, tSecAddr+0x700, 0x4321)) != EC_NONE)
        {
            printf("Error: Program [0x%08lX] ERROR\n", tSecAddr);
			break;
		}
		if ((errCode = SCRPSProg(pDevice, tSecAddr+0x555, 0xAA57)) != EC_NONE)
		{
            printf("Error: Program [0x%08lX] ERROR\n", tSecAddr);
            break;
        }
        if ((errCode = SCRPSetASPFunc(pDevice, ASP_PPB, tSecAddr, TRUE)) != EC_NONE)
        {
                printf("Error: [0x%08lX] Timeout Setting PPB: %s\n", tSecAddr, GetErrorText(errCode));
                ErrSetASPCount++;
			break;
		}
		//SCRPGetASPFunc(pDevice, ASP_PPB, tSecAddr, &ASPBit);
        ASPBit = GetPPBProtectionStatus(pDevice, tSecAddr);
		if (!ASPBit)
		{
			errCode = EC_PPBVERIFY;
            printf("Error: Verify PPB SET [0x%08lX]: %s\n", tSecAddr, GetErrorText(errCode));
            ErrGetASPCount++;
            break;
        }
        UnprotectedSecErrCount = 0;
        ProtectedSecErrCount = 0;
        for (i = 0; i < totalSectors; i++)
        {
            vSecAddr  = SCRPGetFAPIGeometry(pDevice, ADDRESS_OF_SECTOR, i );
            if (i == tSector)
            {
                if ((errCode = VerifyProtectedSector(pDevice, i, vSecAddr, sectorTestAddr)) != EC_NONE)
                {
                    printf("Error: [0x%08lX] Sector %d should be PPB protected %s\n", vSecAddr, i, GetErrorText(errCode));
                    ProtectedSecErrCount++;
				}
			}
			else
			{
				if ((errCode = VerifyUnprotectedSector(pDevice, vSecAddr, sectorTestAddr)) != EC_NONE)
                {
                    printf("Error: [0x%08lX] Sector %d should not be PPB protected %s\n", vSecAddr, i, GetErrorText(errCode));
                    UnprotectedSecErrCount++;
				}
			}
			if (SYS_CheckUserBreak())
			{
				errCode = EC_USERBREAK;
                printf("User break!\n");
				break;
			}
		}
		
		printf("ErrSetASPCount = %d, ErrGetASPCount = %d\n", ErrSetASPCount, ErrGetASPCount);
		printf("ProtectedSecErrCount = %d, UnprotectedSecErrCount = %d\n", ProtectedSecErrCount, UnprotectedSecErrCount);
		if (errCode == EC_USERBREAK) break;
        printf("Removing PPB protection\n");
        if (errCode = SCRPSetASPFunc(pDevice, ASP_PPBERASEALL, 0, FALSE))
        {
            printf("Error: PPB Erasing: %s\n", GetErrorText(errCode));
			break;
		}
		else
		{
			//SCRPGetASPFunc(pDevice, ASP_PPB, tSecAddr, &ASPBit);
            ASPBit = GetPPBProtectionStatus(pDevice, tSecAddr);
			if (ASPBit)
			{
				errCode = EC_PPBERASEVERIFY;
                printf("Error: [0x%08lX] PPB not cleared after Erase: %s\n", tSecAddr, GetErrorText(errCode));
				break;
			}
		}
		printf("Persistent Protection Bit SET/CLEAR OK on sector %d\n", tSector);
		sectorTestAddr += SCRPPAGESIZE;
		if (SYS_CheckUserBreak())
		{
			errCode = EC_USERBREAK;
			break;
		}
	}

	if (errCode)
    {
        if (errCode == EC_USERBREAK)
            printf("%s\n", GetErrorText(errCode));
        return test_exit(__LINE__);
    }

    printf("Test complete\n");
    return test_exit(0);
} // main()

