//===========================================================================
//
//  rpc2_api_sv_api.h
//
//   @author  Yuichi Ise (yuichi.ise@spansion.com)
//   @version 0.1
//   @since   06/21/2013
//
//===========================================================================
#ifndef __RPC2_API_SV_API_H__
#define __RPC2_API_SV_API_H__
#include "rpc2_type.h"

//=============================================================================
//  DEFINITIONS
//=============================================================================
#ifndef MAX_LEN
#define MAX_LEN     (256)
#endif
#ifndef FIXED_MAX_LEN
#define FIXED_MAX_LEN   (16)
#endif
#ifndef WRAP_MAX_LEN
#define WRAP_MAX_LEN    (16)
#endif
#ifndef MAX_OUTSTANDING_TRANS
#define MAX_OUTSTANDING_TRANS	(17)
#endif
#ifndef AXI_ID_WIDTH
#define AXI_ID_WIDTH    (4)
#endif

#ifndef INVALID
#define INVALID (0)
#endif
#ifndef VALID
#define VALID   (1)
#endif

#define MEM_WRITE_FIXED     (INVALID)
#define MEM_READ_FIXED      (INVALID)
#define MEM_WRITE_INCR      (VALID)
#define MEM_READ_INCR       (VALID)
#define MEM_WRITE_WRAP      (INVALID)
#define MEM_READ_WRAP       (VALID)

#define REG_WRITE_FIXED     (VALID)
#define REG_READ_FIXED      (VALID)
#define REG_WRITE_INCR      (VALID)
#define REG_READ_INCR       (VALID)
#define REG_WRITE_WRAP      (INVALID)
#define REG_READ_WRAP       (INVALID)

// WRAP SIZE
#define WRAP_2B         (2)
#define WRAP_4B         (4)
#define WRAP_8B         (8)
#define WRAP_16B        (16)
#define WRAP_32B        (32)
#define WRAP_64B        (64)
#define WRAP_128B       (128)
#define WRAP_256B       (256)

#define WRAP_LEN_2      (2)
#define WRAP_LEN_4      (4)
#define WRAP_LEN_8      (8)
#define WRAP_LEN_16     (16)

//=============================================================================
//  ENUMS
//=============================================================================
// Burst Type
enum {
  FIXED =  0,
  INCR,
  WRAP,
  RESERVED
} EBurstType;

// Burst size
enum {
  BYTE_1 = 0,
  BYTE_2,
  BYTE_4,
  BYTE_8,
  BYTE_16
} EBurstSize;

// Response
enum {
  OKAY = 0,
  EXOKAY,
  SLVERR,
  DECERR
} EResponse;

// Target
enum {
  MEM = 0,
  REG
} ETarget;

//=============================================================================
//  PROTOTYPES
//=============================================================================
void waitNs(DWORD num_ns);
void waitUs(DWORD num_us);
DWORD genRndAddr (void);
DWORD genRndAddr4 (void);
DWORD genRndLen (void);
void genRndData (void* genData, DWORD len8);
DWORD genRndDataLimit(DWORD maxData);
void getRpcClkPeriod(DWORD* rpc_clk);
void getAxiClkPeriod(DWORD* axi_clk);
void setRndDelay(int target, int maxBurst, int maxWait);
void startCScnt(int cs);
void endCScnt(int cs);
void getCScnt(int cs, DWORD* cs_neg_cnt);

void start2CScntArbitration(int cs);
void end2CScntArbitration(void);
void get2CScntArbitration(int arbitration, DWORD* cs_neg_cnt_write, DWORD* cs_neg_cnt_read);

void AXIREG_reset(void);
void AXIMEM_reset(void);
int AXIREG_writeData(DWORD address, DWORD* wdata);
int AXIMEM_writeData32(DWORD address, DWORD len, DWORD* wdata);
int AXIMEM_writeData16(DWORD address, DWORD len16, WORD* wdata);
int AXIMEM_writeData8(DWORD address, DWORD len8, BYTE* wdata);
void AXIMEM_writeAddress8(DWORD address, DWORD burstLen, DWORD wrid, DWORD* wrPtr);
void AXIMEM_writeAddress16(DWORD address, DWORD burstLen, DWORD wrid, DWORD* wrPtr);
void AXIMEM_writeAddress32(DWORD address, DWORD burstLen, DWORD wrid, DWORD* wrPtr);
void AXIMEM_writeBurstData8(DWORD address, DWORD burstLen, DWORD wrid, BYTE* wdata, DWORD wrPtr);
void AXIMEM_writeBurstData16(DWORD address, DWORD burstLen, DWORD wrid, WORD* wdata, DWORD wrPtr);
void AXIMEM_writeBurstData32(DWORD address, DWORD burstLen, DWORD wrid, DWORD* wdata, DWORD wrPtr);
int AXIREG_readData(DWORD address, DWORD* rdata);
int AXIMEM_readData(DWORD address, DWORD len, DWORD* rdata);
int AXIMEM_readData16(DWORD address, DWORD len16, WORD* rdata);
int AXIMEM_readData8(DWORD address, DWORD len8, BYTE* rdata);

void AXIMEM_writeBurst16(DWORD address, DWORD burstLen, WORD* wdata);
void AXIMEM_writeBurst8(DWORD address, DWORD burstLen, BYTE* wdata);
void AXIMEM_writeBurst32(DWORD address, DWORD burstLen, DWORD* wdata);
int AXIMEM_getWriteResp(void);
int AXIMEM_getWriteRespIndex(DWORD wrPtr);
void AXIMEM_readBurst(DWORD address, DWORD burstLen, DWORD burstType);
void AXIMEM_readBurst8(DWORD address, DWORD burstLen, DWORD burstType);
void AXIMEM_readBurst32(DWORD address, DWORD burstLen, DWORD burstType);
int AXIMEM_getData(DWORD burstLen, WORD* buf);
int AXIMEM_getData8(DWORD burstLen, BYTE* buf);
int AXIMEM_getData32(DWORD burstLen, DWORD* buf);

void AXIMEM_idleReadDataUs(DWORD us);

void writeBurst (int target,
		 unsigned int addr,
		 unsigned int burstLen,
		 unsigned int burstType,
		 unsigned int burstSize,
		 void* buf);
void getWriteResp (int target,
		   unsigned char* resp);
void readBurst (int target,
		unsigned int addr,
		unsigned int burstLen,
		unsigned int burstType,
		unsigned int burstSize);
#ifdef STRESS_TEST
void getReadDataRespStress(int target,
             unsigned int addr,
		     unsigned int burstLen,
		     unsigned int burstSize,
		     void* buf,
		     unsigned char resp[]);
#else
void getReadDataResp(int target,
		     unsigned int burstLen,
		     unsigned int burstSize,
		     void* buf,
		     unsigned char resp[]);
#endif
void writeBurstStrobe(int target,
        unsigned int addr,
        unsigned int burstLen,
        unsigned int burstType,
        unsigned int burstSize,
        void* buf,
        void* strb);
void writeAddress (int target,
                   unsigned int wrid,
		   unsigned int addr,
		   unsigned int burstLen,
		   unsigned int burstType,
		   unsigned int burstSize,
                   unsigned int *wrPtr);
void writeBurstData (int target,
                     unsigned int wrid,
                     unsigned int addr,
                     unsigned int burstLen,
                     unsigned int burstType,
                     unsigned int burstSize,
                     void* buf,
                     unsigned int wrPtr);
void getWriteRespIndex(int target,
		       unsigned char* resp,
                       unsigned int wrPtr);
#endif //__RPC2_API_SV_API_H__
