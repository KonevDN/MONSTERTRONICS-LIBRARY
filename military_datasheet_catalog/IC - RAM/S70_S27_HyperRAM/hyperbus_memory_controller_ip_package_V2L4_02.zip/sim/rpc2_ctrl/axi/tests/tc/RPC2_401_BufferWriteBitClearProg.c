#ifdef SIMULATION
#include "sltapi_sim.h"
#include "svdpi.h"
#include "dpiheader.h"
#include <math.h>
#include "rpc2_vlld.h"
#include "rpc2_llops.h"

#else
#include <sltapi.h>
#endif

#include "rpc2.h"

#ifdef NCSC
extern int io_printf(const char *fmt, ...);
#define printf io_printf
#endif

//
//----------------------------------------------------------------------------------
//  Script: Bit Clear Pattern Buffer Write Program test
//----------------------------------------------------------------------------------
char Script[] = "401_BufferWriteBitClearProg";
char TestTitle[] = "Bit Clear Pattern Buffer Write Program test";
                 
// Command line arguments and their default values
DWORD help_only = NO;                 // display help only (NO), execute test (YES)
DWORD PreRead = NO;         // Blank check before buffer write: enabled(YES), disabled(NO)

// Test Configuration
SOE       = SOE_SETTING;        // Stop on Error flag
SKIP = 0;
LOOP_COUNT = 1;//LOOPS;
DWORD ERASE = 1;
burst_mode = 1;


PDEV pDevice;
// Global variables
WORD *pSrcData = (WORD *)NULL;
WORD *pDestData = (WORD *)NULL;
STS t0, t1;
char s[81];


void help(void);
void linespace(DWORD n);
DWORD BitClearPatternFill(DWORD instance, WORD *dest, DWORD count, BOOL wDir, BOOL bDir);
DWORD BitClearPattern(DWORD instance, WORD *dest, DWORD count, BOOL wDir, BOOL bDir);
DWORD BufferWriteProgram(PDEV, DWORD, DWORD, WORD *, DWORD);
DWORD test_exit(DWORD exit_val);
DWORD EraseSector(PDEV dev, DWORD sector);
DWORD GetBwSize(DWORD MaxSize, DWORD *bwsize);
void print_buf(WORD * buff, DWORD count);
DWORD rpc_ctrl_init(void);

//----------------------------------------------------------------------------------
//RPC Test script begin
//----------------------------------------------------------------------------------
#ifdef SIMULATION
int c_test()
#else
int main(int argc, char* argv[])
#endif
{
    DWORD tSector, tSecAddr, tSecSize;
    DWORD logStat, errCode;
    DWORD totalSectors, bufSize, largeSecSize;
    DWORD i;
    DWORD loop;
    int voltage, temperature;
    //PDEV pDevice;
    DWORD bwsize=256;
    DWORD d_lsb=1, d_begin=1;
    DWORD instance;
          

    printf("<TC> Test: %s\n", Script);
    printf("%s\n", TestTitle);

	#ifndef SIMULATION
    SKIP = GetGlobalVar("SKIP");
    #endif
    
	if (SKIP)
	{
		line_space(2);
		printf("<TC> Test is skipped\n");
		return __LINE__;
	}
	
#ifndef SIMULATION   
    GetArgEnum("help", &help_only, "YES_NO");
    if (help_only == YES)
    {
        help();
        return 0;
    }
#endif

	#ifdef SIMULATION    
    pDevice = NewDeviceObject(0, RPC);
	#endif	 	  
	  
    pDevice = Find_Device(RPC);
    if (!pDevice)
    {
        printf("<TC> Error: RPC device not found\n");
        return __LINE__;
    }
    printf("Device: %s\n", SCRPGetFAPIInfo(pDevice, DEVICE_NAME));
    
    	    

    SYS_GetTimestamp(&t0);
    SCRPCmdResetFlash(pDevice);
    //SCRPASPUnlock(pDevice);

    totalSectors = SCRPGetFAPIInfo(pDevice, SECTOR_COUNT);
    bufSize = SCRPGetFAPIInfo(pDevice, WRITE_BUFFER_SIZE);
    largeSecSize = SCRPGetFAPIInfo(pDevice, LARGEST_SECTOR);
    pSrcData = (WORD *) malloc(sizeof(WORD) * largeSecSize);
    pDestData = (WORD *) malloc(sizeof(WORD) * largeSecSize * 4);
    if (!pSrcData || !pDestData)
    {
        printf("<TC> malloc error!\n");
        return test_exit(__LINE__);
    }

//    linespace(2);
#ifndef SIMULATION
        GetBwSize(bufSize, &bwsize);
        GetArg("lsb", &d_lsb);
        GetArg("begin", &d_begin);
#endif         

#ifdef SIMULATION
    #ifdef DEF_BUFSIZE
    if(DEF_BUFSIZE==0)
        bwsize = bufSize;
    else
    bwsize = DEF_BUFSIZE;
    #endif
#endif

    linespace(2);
    if (d_lsb)
        printf("\n\n<TC> Start clear from LSB\n");
    else
        printf("\n\n<TC> Start clear from MSB\n");
    if (d_begin)
        printf("<TC> Start clear from begin of buf\n");
    else
        printf("<TC> Start clear from end of buf\n");

    printf("<TC> Word size of buffer write = %d words\n", bwsize);


    linespace(2);    
    for (loop = 0; loop < LOOP_COUNT; loop++)
    {
	#ifndef SIMULATION         
        ClearDevLog(pDevice);
	#endif
        for (tSector = 0; tSector < totalSectors; tSector++)
        {
            printf("\n<TC> Erasing Sector %d ... ", tSector);
            if (SYS_CheckUserBreak())
            {
                printf("\n\n<TC> User Break\n");
                return test_exit(0);
            }

            //if (SCRPGetBadSector(pDevice, tSector))
            //    continue;
            errCode = EraseSector(pDevice, tSector);
            if (errCode != EC_NONE)
            {
                if (SOE)
                {
                    printf("\n\n<TC> Stop on Error\n");
                    return test_exit(__LINE__);
                }
                continue;   // move on to next sector
            }
	#ifndef SIMULATION 
            ClearDevLog(pDevice);
            logStat = SaveDevLogState(pDevice);
            SetLogDevice(pDevice, LOG_RW_ALL);
            SetLogDevice(pDevice, LOG_RW_ALL);
 	#endif               
            tSecAddr = SCRPGetFAPIGeometry(pDevice, ADDRESS_OF_SECTOR, tSector);
            tSecSize = SCRPGetFAPIGeometry(pDevice, WORD_COUNT_OF_SECTOR, tSector); 

                    for (instance=1; instance<513; instance++)
                        {
                                printf("<TC> Buffer Write on sector %d\n", tSector);
                                printf("<TC> Sector %d bit clear pattern = %d\n", tSector, instance);
                                errCode = BitClearPatternFill(instance, pSrcData, tSecSize, d_lsb, d_begin);
                    if (errCode != EC_NONE)
                    {
                        printf("<TC> Error: Preparing Bit Clear Pattern\n");
                        return test_exit(__LINE__);
                    }
                    if (1) // display first 32 words data pattern
                    {
                        linespace(1);
                        printf("<TC> Data pattern\n");
                        for (i = 0; i < 32; i++)
                        {
                            if ((i % 8) == 0)
                                printf("\n%04X ", i);
                            printf("%04X ", pSrcData[i]);
                        }
                        printf("\n");
                        printf("...\n...\n");

                        // continue;
                    }

                    errCode = BufferWriteProgram(pDevice, tSecAddr, tSecSize, pSrcData, bwsize);
                    if (errCode != EC_NONE)
                    {
                        printf("Error: %s", GetErrorText(errCode));
                        if (SOE)
                        {
                            printf("\n\n<TC> Stop on Error\n");
                            return test_exit(__LINE__);
                        }
                                        instance = 513;
                        continue;   // move on to next sector
                    }

                    errCode = EC_NONE;
                    memset(pDestData, 0, tSecSize*sizeof(WORD) * 4);
                    printf("<TC> Read Verify on address 0x%08X with length of %d words\n\n", tSecAddr, tSecSize);

                    errCode = SCRPReadArray(pDevice, pDestData, tSecAddr, tSecSize);
                    if (errCode != EC_NONE)
                    {
                        printf("<TC> Error: %s", GetErrorText(errCode));
                        if (SOE)
                        {
                            printf("\n\n<TC> Stop on Error\n");
                            return test_exit(__LINE__);
                        }
                        instance = 513;
                        continue;   // move on to next sector
                    }
	#ifndef SIMULATION
                    RestoreDevLogState(pDevice, logStat);
     	#endif                       
                    for (i = 0; i < tSecSize; i++)
                    {
                        if (pSrcData[i] != pDestData[i])
                        {
                            printf("<TC> Written: 0x%04X, Read: 0x%04X, Offset: 0x%04X\n", pSrcData[i], pDestData[i], i);
                            if (SOE)
                            {
                                printf("\n\n<TC> Stop on Error\n");
                                return test_exit(__LINE__);
                            }
                            break;
                        }
                    }

                    if (errCode = SYS_CheckUserBreak())
                    {
                        linespace(2);
                        printf("<TC> User break\n");
                        return test_exit(0);
                    }

                        } //for (instance=0; instance<512; instance++)
        } // for (tSector = 0; tSector < totalSectors; tSector++)
    } // for (loop = 0; loop < LOOP_COUNT; loop++)

    printf("<TC> Test complete\n");
#ifndef SIMULATION        
    if (TASK_DELAY)
        SYS_OSTickDelay(TASK_DELAY);
#endif
    return test_exit(0);
} // main()


DWORD BitClearPatternFill(DWORD instance, WORD *dest, DWORD count, BOOL wDir, BOOL bDir)
{
        DWORD i, j;
        WORD *pSrcData = dest;
        for (i=0; i<count/32; i++)
        {
                BitClearPattern(instance, pSrcData, 32, wDir, bDir);
                pSrcData += 32;
        }
        return EC_NONE;
}

DWORD BitClearPattern(DWORD instance, WORD *dest, DWORD count, BOOL wDir, BOOL bDir)
{
    DWORD index, offset, value, i, j;
    if (!dest || !count) return EC_PARAMETER;
    if (instance > count * 16) return EC_PARAMETER;
    index = instance / 16;
    offset = instance % 16;
    if (wDir)
        value = ~((1 << offset) - 1);
    else
        value = (1 << (16 - offset)) - 1;
    j = count - 1;
    if (bDir)
    {
        // handle clear from beginning
        for (i = 0; i < index; i++)
            dest[i] = 0;
        if (i < count)
            dest[i] = value;
        for (++i ; i < count; i++)
            dest[i] = 0xFFFF;
    }
    else
    {
        // handle clear from end
        for (i = 0; i < index; i++)
            dest[j - i] = 0;
        if (i < count)
            dest[j - i] = value;
        for (++i ; i < count; i++)
            dest[j - i] = 0xFFFF;
    }

    return EC_NONE;
}


DWORD BufferWriteProgram(PDEV pDevice, DWORD secAddr, DWORD progSize, WORD *pData,
                         DWORD bwsize)
{
    DWORD errCode;
    DWORD i, j;
    DWORD bw_loop;

    errCode = EC_NONE;
    bw_loop = progSize / bwsize;
    j = 0;
    for (i = 0; i < bw_loop; i++)
    {
 #ifndef SIMULATION   
        ClearDevLog(pDevice);
#endif          
        if (PreRead == YES)
            errCode = SCRPBufferWriteBlankCheck(pDevice, &pData[j], secAddr, bwsize, TRUE);
        else
            errCode = SCRPBufferWrite(pDevice, &pData[j], secAddr, bwsize, TRUE);
        if (errCode != EC_NONE)
            return errCode;
        j += bwsize;
        secAddr += bwsize;
    }
    return(errCode);
} // BufferWriteProgram()

DWORD test_exit(DWORD exit_val)
{
    if (pSrcData) free(pSrcData);
    if (pDestData) free(pDestData);

    SYS_GetTimestamp(&t1);
    FormatDeltaTime(s, &t0, &t1);
    printf("<TC> Test time: %s\n", s);

    if (exit_val)
    {
        SetGlobalVar("SKIP", 1);
	printf("<TC> Test =========================== Fail\n");
    }
    else {
      printf("<TC> Test =========================== Pass\n");
    }
    return exit_val;
} // test_exit()

DWORD EraseSector(PDEV dev, DWORD sector)
{
    DWORD errCode;
    DWORD logStat;
    DWORD secSize;
    DWORD secAddr;
    DWORD i;

    secSize = SCRPGetFAPIGeometry(dev, WORD_COUNT_OF_SECTOR, sector);
    secAddr  = SCRPGetFAPIGeometry(dev, ADDRESS_OF_SECTOR, sector);

    errCode = SCRPEraseSector(dev, sector, TRUE);
    if (errCode != EC_NONE)
    {
        printf("<TC> Error: %s\n", GetErrorText(errCode));
        return errCode;
    }

    errCode = EC_NONE;
    memset(pDestData, 0, secSize*sizeof(WORD) * 4);
#ifndef SIMULATION      
    logStat = SaveDevLogState(dev);
    SetLogDevice(dev, LOG_RW_ALL);
#endif     
    SCRPReadArray(dev, pDestData, secAddr, secSize);
#ifndef SIMULATION     
    RestoreDevLogState(dev, logStat);
#endif      
    for (i = 0; i < secSize; i++)
    {
        if (pDestData[i] != 0xFFFF)
        {
            printf("<TC> Error: Blank Check\n");
            return EC_ERASEVERIFY;
        }
    }

    printf("OK\n");
    return EC_NONE;
} // EraseSector()

void linespace(DWORD n)
{
    DWORD i;

    for (i = 0; i < n; i++)
        printf("\n");
    printf("<TC> ****************************\n");
} // linespace()

//DWORD GetBwSize(DWORD MaxSize, DWORD *bwsize)
//{
//    DWORD status;
//    DWORD i;
//
//    status = GetArg("bs", bwsize);
//
//    if (status != TRUE)
//    {
//        printf("Warning: bs argument missing or wrong\n");
//        printf("Use default buffer write size: %d words\n", MaxSize);
//        *bwsize = MaxSize;
//        return EC_NONE;
//    }
//
//    if (*bwsize > MaxSize)
//    {
//       printf("Warning: Exceeding Max Buffer Size %d words\n", MaxSize);
//       printf("Use max buffer size %d words\n", MaxSize);
//       *bwsize = MaxSize;
//       return EC_PARAMETER;
//    }
//
//    if (*bwsize == 0)
//    {
//       printf("Warning: 0 word Buffer Size\n");
//       printf("Use max buffer size %d words\n", MaxSize);
//       *bwsize = MaxSize;
//       return EC_PARAMETER;
//    }
//
//    printf("buffer-write size: %d\n", *bwsize);
//    for (i = 0; i < 16; i++)
//    {
//        if ((*bwsize | (1 << i)) == (DWORD)(1 << i))
//            return EC_NONE;
//    }
//
//    printf("Warning: Buffer write word size %d is not power of 2\n", *bwsize);
//    if (0)  // adjust buffer write word size: enable(1), disable(0)
//    {
//        printf("Use max buffer size %d words\n", MaxSize);
//        *bwsize = MaxSize;
//        return EC_PARAMETER;
//    }
//    else
//        return EC_NONE;
//
//} // GetBwSize()
//
void help(void)
{
    linespace(2);
    printf("<TC> %s command line arguments:\n", Script);
    printf("<TC> lsb: clear from lsb\n");
    printf("<TC> begin: clear from the begining of write buffer\n");
    printf("<TC> example:\n");
    printf("<TC> - bs=32 lsb=0 begin=0\n");
    linespace(0);
} // help()

