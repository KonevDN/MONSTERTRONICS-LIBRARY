#ifdef SIMULATION
#include "sltapi_sim.h"
#include "svdpi.h"
#include "dpiheader.h"
#include <math.h>
#include "rpc2_vlld.h"
#include "rpc2_llops.h"
#else
#include <sltapi.h>
#endif
#include "rpc2.h"
#ifdef NCSC
extern int io_printf(const char *fmt, ...);
#define printf io_printf
#endif

//----------------------------------------------------------------------------------
// 	Script: Advanced Sector Persistent Protection with password test
//  Before running this script, the Include.scp needs to be downloaded first.
//----------------------------------------------------------------------------------

enum
{
	CLEARDYBL,
	SETDYBL,
	SCRPPAGESIZE = 8,
	PASSVALUE = 0x5555
};

enum
{
	CLEARPPBL,
	SETPPBL
};

PDEV pDevice;

DWORD SendTestPassword ( WORD *testPwd )
{
	DWORD   errCode, i, bitPPBL;

	if ((errCode = SCRPSendPassword( pDevice, testPwd )) == EC_NONE)
	{
       	// If PPB Lock bit still set, the password did not work.
		SCRPGetASPFunc( pDevice, ASP_PPBL, 0, &bitPPBL );
        printf("bitPPBL = %d", bitPPBL);
		if ( bitPPBL )
			errCode = EC_PPBLSET;
	}

	return( errCode );
}

//andy
DWORD PasswordTest ( WORD *pwdValue )
{
	DWORD i;

	// Password command set entry code.
	SCRPCmd( pDevice, 0x555, 0xAA );
	SCRPCmd( pDevice, 0x2AA, 0x55 );
	SCRPCmd( pDevice, 0x555, 0x60 );	

	// Send BAD password unlock command and password values.
	SCRPCmd( pDevice, 0, 0x25 );
	SCRPCmd( pDevice, 0, 0x3 );
	for ( i = 0; i < 4; i++ )
		SCRPCmd( pDevice, i, ~pwdValue[i] );
	SCRPCmd( pDevice, 0, 0x29 );

	// Send PASSED password unlock command and password values.
	SCRPCmd( pDevice, 0, 0x25 );
	SCRPCmd( pDevice, 0, 0x3 );
	for ( i = 0; i < 4; i++ )
		SCRPCmd( pDevice, i, (DWORD)pwdValue[i] );
	SCRPCmd( pDevice, 0, 0x29 );

	// Send common Exit sequence.
	SCRPCmd( pDevice, 0, 0x90 );
	SCRPCmd( pDevice, 0, 0 );

	SYS_WaitUSec( 10 ); // Let it settle down before attempting PPBL read.
	return EC_NONE;
}

/*andy
DWORD PasswordTest ( WORD *pwdValue )
{
	DWORD i;

	// Password command set entry code.
	SCRPSendCmdArray(pDevice, CB_PWDENTRY);

	// Send BAD password unlock command and password values.
	SCRPCmd( pDevice, 0, FC_WBLOAD );
	SCRPCmd( pDevice, 0, FC_WBPWDCNT );
	for ( i = 0; i < 4; i++ )
		SCRPCmd( pDevice, i, ~pwdValue[i] );
	SCRPCmd( pDevice, 0, FC_WBCOMMIT );

	// Send PASSED password unlock command and password values.
	SCRPCmd( pDevice, 0, FC_WBLOAD );
	SCRPCmd( pDevice, 0, FC_WBPWDCNT );
	for ( i = 0; i < 4; i++ )
		SCRPCmd( pDevice, i, (DWORD)pwdValue[i] );
	SCRPCmd( pDevice, 0, FC_WBCOMMIT );

	// Send common Exit sequence.
	SCRPSendCmdArray(pDevice, CB_GENERICEXIT);

	SYS_WaitUSec( 10 ); // Let it settle down before attempting PPBL read.
	return EC_NONE;
}


DWORD PasswordTest ( WORD *pwdValue )
{
	struct pctrl_struct List[17];
	SINGLEDATA lcmd[16];
	DWORD stArray[2], i;
	
	stArray[0] = EC_NONE;
	stArray[1] = 0xFF;
	for (i = 0; i < 16; i++)
	{
		lcmd[i].pDevice = pDevice;
		lcmd[i].SecAddr = 0;
		List[i].func = pDevice->pCmd;
		List[i].pArg = (PARGS) &lcmd[i];
		List[i].statusList = &stArray[0];
	}
	List[i].func = (PFUN) NULL;
	lcmd[0].Offset = CB_PWDENTRY;
	List[0].func = pDevice->pSendCmdArray;
	lcmd[1].Data = FC_WBLOAD;
	lcmd[2].Data = FC_WBPWDCNT;
	for (i = 3; i < 7; i++)
	{
		lcmd[i].SecAddr = i - 3;
		lcmd[i].Data = ~pwdValue[i-3];
	}
	lcmd[7].Data = FC_WBCOMMIT;
	lcmd[8].Data = FC_WBLOAD;
	lcmd[9].Data = FC_WBPWDCNT;
	for (i = 10; i < 14; i++)
	{
		lcmd[i].SecAddr = i - 10;
		lcmd[i].Data = pwdValue[i-10];
	}
	lcmd[14].Data = FC_WBCOMMIT;
	lcmd[15].Offset = CB_GENERICEXIT;
	List[15].func = pDevice->pSendCmdArray;
	return SCRPPrimProcessCtrl(pTest, pDevice, &List[0]);
}
*/

DWORD test_exit(DWORD exit_val)
{
    if (exit_val)
    {
        SetGlobalVar("SKIP", 1);
	printf("<TC> Test =========================== Fail\n");
    }
    else {
      printf("<TC> Test =========================== Pass\n");
    }
    return (exit_val);
}

#ifdef SIMULATION
int c_test()
#else
int main(int argc, char* argv[])
#endif
{
	DWORD errCode, i, j, Data;
	DWORD bitPWDD, bitPWDE, logStat;
	WORD  password[4];
	WORD  pwdValue[4];
	WORD  badPwd[4];
	WORD  goodPwd[4];
	
#ifndef SIMULATION
    SKIP = GetGlobalVar("SKIP");
#endif
    if (SKIP)
    {
        line_space(2);
        printf("Test is skipped\n");
        return test_exit(__LINE__);
    }

#ifdef SIMULATION
    pDevice = NewDeviceObject(0, RPC);
#endif
	pDevice = Find_Device(RPC);
	
	//if (!(FS_PERSISTENTSECTOR & SCRPSupport(pDevice)))
    if (!(FS_SECTORPROTECT & SCRPSupport(pDevice)))
    {
        printf("Error: Advanced Sector Protection not supported\n");
        return test_exit(__LINE__);
    }

    for (i = 0; i < 4; i++)
    {
        badPwd[i] = 1;
        goodPwd[i] = 0;
    }
	password[0] = 0x1111;
	password[1] = 0x2222;
	password[2] = 0x3333;
	password[3] = 0x4444;
	//FTHardwareResetFlash(TRUE);
	errCode = EC_NONE;
    printf("Advanced Sector Password Protection Enable Mode Test\n");

    //SCRPGetASPFunc(pDevice, ASP_PPBL, 0, &Data);
    //if (Data)
    //  printf("PPB Lock Bit is ON\n");
    //else
    //  printf("PPB Lock Bit is OFF\n");

    SCRPGetASPFunc( pDevice, ASP_PWD, 0, &Data );
    switch (Data)
    {
        case PROT_PERSISTENT:
            printf("Error: This device has been set to PPB mode\n");
            #ifndef SIMULATION
            OutputLog(pDevice, LOG_DISP_NORM, 0, -50);
            #endif
            return test_exit(__LINE__);
        case PROT_NONE:
            printf("No Password and no Persistent mode setting\n");

            for (i = 0; i < 4; i++)
            {
                errCode = SCRPProgPassword( pDevice, i, (DWORD)password[i] );
                if (errCode != EC_NONE)
                {
                    printf("Error: Program Password: %s\n", GetErrorText(errCode));
                    #ifndef SIMULATION
                    OutputLog(pDevice, LOG_DISP_NORM, 0, -50);
                    #endif
                    return test_exit(__LINE__);
                }
            }

			SCRPReadPassword( pDevice, pwdValue );
   			for (i = 0; i < 4; i++)
   				printf("read = 0x%04X  expect = 0x%04X\n", pwdValue[i], password[i]);
   			
			for (i = 0; i < 4; i++)
            {
				if (pwdValue[i] != password[i])
				{
                    printf("Error: Verify Programmed Password\n");
                    #ifndef SIMULATION
                    OutputLog(pDevice, LOG_DISP_NORM, 0, -50);
                    #endif
                    return test_exit(__LINE__);
				}
            }

            // Do not program the lock register
            // Attempt to set both PWDE and PWDD at the same time.  Should timeout.
            printf("Try to set PPB and PASSWORD protection mode at the same time\n");
            if (( errCode = SCRPSetASPFunc( pDevice, ASP_PWDED, 0, TRUE )) != EC_PWDETIMEOUT )
            {
                printf("Error: PPB and PASSWORD protection modes can be set at the same time\n");
                #ifndef SIMULATION
                OutputLog(pDevice, LOG_DISP_NORM, 0, -50);
                #endif
                return test_exit(__LINE__);
            }
            else
                printf("PPB and PASSWORD protection mode can not be set at the same time (good)\n");

            //Add to clear failure status in SR, HUANG WEI, 20130619
            SCRPClrDeviceStatus(pDevice, 0);
            
            // Attempt to set the PWDE bit to enable password mode.
            if (( errCode = SCRPSetASPFunc( pDevice, ASP_PWD, 0, PROT_PASSWORD )) != EC_NONE )
            {
                printf("Error: Set password protection mode failed\n");
                #ifndef SIMULATION
                OutputLog(pDevice, LOG_DISP_NORM, 0, -50);
                #endif
                return test_exit(__LINE__);
            }

            // Set PPB Lock Bit without power cycle
            if (errCode = SCRPSetASPFunc(pDevice, ASP_PPBL, 0, TRUE))
            {
                printf("Error: PPB Lock Failure: %s\n", GetErrorText(errCode));
                #ifndef SIMULATION
                OutputLog(pDevice, LOG_DISP_NORM, 0, -50);
                #endif
                return test_exit(__LINE__);
            }
            break;
        case PROT_PASSWORD:
        default:
            printf("Password Protection Enable Mode is already SET\n");
			break;
	}
   	// At this point, the password should be programmed and the PWDE bit set.
   	// Verify that the PWDE bit is set, then try to write the PWDD bit, which
   	// should fail.  Finally, try to read/verify the passord registers.

	// If PWDE not set, it's fatal at this point in the test.
	SCRPGetASPFunc( pDevice, ASP_PWD, 0, &Data );
	if (Data == 0)
   	{
        printf("Error: %s\n", GetErrorText(EC_PWDENOTSET));
        #ifndef SIMULATION
        OutputLog(pDevice, LOG_DISP_NORM, 0, -50);
        #endif
        return test_exit(__LINE__);
    }
    else
        printf("Password Protection Enable Mode is SET\n");


    // Attempt to set the PWDD bit to enable persistent mode. Should FAIL!
    if ( SCRPSetASPFunc( pDevice, ASP_PWD, 0, PROT_PERSISTENT ) == EC_NONE )
    {
        printf("Error: %s\n", GetErrorText(EC_PWDDSUCCEEDED));
        #ifndef SIMULATION
        OutputLog(pDevice, LOG_DISP_NORM, 0, -50);
        #endif
        return test_exit(__LINE__);
    }
    else
        printf("Persistent Protection can NOT be enabled ... OK\n");

    //Add to clear failure status in SR, HUANG WEI, 20130619
    SCRPClrDeviceStatus(pDevice, 0);

    // Attempt to read and verify password.  Should fail.
    SCRPReadPassword( pDevice, pwdValue );
    for (i = 0; i < 4; i++)
    {
        if (pwdValue[i] != 0xFFFF)
        {
            printf("Error: %s\n", GetErrorText(errCode));
            #ifndef SIMULATION
            OutputLog(pDevice, LOG_DISP_NORM, 0, -50);
            #endif
            return test_exit(__LINE__);
        }
    }
	
    printf("Password can not be read... OK\n");
	
    // Attempt to program password registers.  should fail.
	for (i = 0; i < 4; i++)
    {
		if (SCRPProgPassword( pDevice, i, 0 ) == EC_NONE)
		{
            printf("Error: %s\n", GetErrorText(errCode));
            #ifndef SIMULATION
            OutputLog(pDevice, LOG_DISP_NORM, 0, -50);
            #endif
            return test_exit(__LINE__);
		}
    }
    printf("Password can not be programmed again ... OK\n");

    //Add to clear failure status in SR, HUANG WEI, 20130619
    SCRPClrDeviceStatus(pDevice, 0);
    
    SCRPGetASPFunc( pDevice, ASP_PPBL, 0, &Data );
    if ( !Data )
    {
        printf("Error: PPB lock is not enabled\n");
        #ifndef SIMULATION
        OutputLog(pDevice, LOG_DISP_NORM, 0, -50);
        #endif
        return test_exit(__LINE__);
    }
    else
        printf("PPB lock is enabled on a password mode device... OK\n");

    // Try an invalid password by itself.
    printf("Disable PPB Lock by a wrong password\n");
    if (SCRPSendPassword( pDevice, badPwd ) == EC_NONE)
    {
        SCRPGetASPFunc( pDevice, ASP_PPBL, 0, &Data );
        if ( !Data )
        {
            printf("Error: PPB Lock can be disabled by a wrong password\n");
            #ifndef SIMULATION
            OutputLog(pDevice, LOG_DISP_NORM, 0, -50);
            #endif
            return test_exit(__LINE__);
    		}
		else
            printf("PPB Lock can not be disabled by a wrong password\n");
	}


	// Enter a bad and good password in quick succession.  The 'good'
	// password should not work because it was entered too soon after
	// the 'bad' password.
#ifndef SIMULATION
	logStat = SaveDevLogState(pDevice);
	SetLogDevice(pDevice, LOG_NONE);
//	PasswordTest(password);
	RestoreDevLogState(pDevice, logStat);
#endif
//	SCRPGetASPFunc( pDevice, ASP_PPBL, 0, &Data );
//	if ( !Data )
// 	{
//		printf("%s\n", GetErrorText(EC_PWDGOODGOOD));
//		return 0;    	
//	}
//	else
//		printf("BAD password followed by GOOD password too soon. Can NOT unlock the device.\n");
    //Huang Wei, clear SR prog error bit.
    SCRPClrDeviceStatus(pDevice, 0);
	errCode = SendTestPassword(password);

	if (errCode)
    {
        printf("Error: %s\n", GetErrorText(errCode));
        return test_exit(__LINE__);
    }
    else
        printf("Send Password, PPB Lock is CLEARED\n");


    printf("Test complete\n");
    return test_exit(0);
}

