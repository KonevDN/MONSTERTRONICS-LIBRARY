#ifdef SIMULATION
#include "sltapi_sim.h"
#include "svdpi.h"
#include "dpiheader.h"
#include <math.h>
#include "rpc2_vlld.h"
#include "rpc2_llops.h"
#else
#include <sltapi.h>
#endif
#include "rpc2.h"
#ifdef NCSC
extern int io_printf(const char *fmt, ...);
#define printf io_printf
#endif
//----------------------------------------------------------------------------------
// 	Script: Advanced Sector Persistent Protection Lock Bit test
//  Before running this script, the Include.scp needs to be downloaded first.
//----------------------------------------------------------------------------------

enum
{
	CLEARDYBL,
	SETDYBL,
	SCRPPAGESIZE = 8
};

enum
{
	CLEARPPBL,
	SETPPBL
};

PDEV pDevice;

DWORD tVerifyProtectionOff(PDEV dev, DWORD totalSectors, DWORD chkPPBL)
{
	DWORD errCode, i;
	DWORD secAddr, Data;
	
	errCode = EC_NONE;
	for (i = 0; i < totalSectors; i++)
	{
		secAddr = SCRPGetFAPIGeometry(dev, ADDRESS_OF_SECTOR, i);
		SCRPGetASPFunc(dev, ASP_DYB, secAddr, &Data);
		if (Data)
		{
            printf("DYB ON in sector %d\n", i);
            errCode = EC_DYBSTATE;
            break;
        }
    }
    if (errCode) return errCode;
    printf("All sectors are DYB cleared (OFF)\n");

    for (i = 0; i < totalSectors; i++)
    {
        secAddr = SCRPGetFAPIGeometry(dev, ADDRESS_OF_SECTOR, i);
        SCRPGetASPFunc(dev, ASP_PPB, secAddr, &Data);
        if (Data)
        {
            printf("PPB ON in sector %d\n", i);
			errCode = EC_PPBERASEVERIFY;
			break;
		}
	}
	if (errCode) return errCode;
	printf("All sectors are PPB cleared (OFF)\n");
	if (chkPPBL)
	{
		SCRPGetASPFunc(dev, ASP_PPBL, 0, &Data);
		if (Data)
			errCode = EC_PPBLSET;
	}
	return errCode;
}

DWORD test_exit(DWORD exit_val)
{
    if (exit_val)
    {
        SetGlobalVar("SKIP", 1);
	printf("<TC> Test =========================== Fail\n");
    }
    else {
      printf("<TC> Test =========================== Pass\n");
    }
    return (exit_val);
}

#ifdef SIMULATION
int c_test()
#else
int main(int argc, char* argv[])
#endif
{
	DWORD tSector, tSecAddr, Data;
	DWORD errCode, totalSectors, i, bitPPBL;
	
#ifndef SIMULATION
    SKIP = GetGlobalVar("SKIP");
#endif
    if (SKIP)
    {
        line_space(2);
        printf("Test is skipped\n");
        return test_exit(__LINE__);
    }

#ifdef SIMULATION
    pDevice = NewDeviceObject(0, RPC);
#endif
	pDevice = Find_Device(RPC);

	//if (!(FS_PERSISTENTSECTOR & SCRPSupport(pDevice)))
    if (!(FS_SECTORPROTECT & SCRPSupport(pDevice)))
    {
        printf("Error: Advanced Sector Protection not supported\n");
        return test_exit(__LINE__);
    }
    if (errCode = SCRPASPUnlock(pDevice))
    {
        printf("Error: %s\n", GetErrorText(errCode));
        return test_exit(__LINE__);
    }

	errCode = EC_NONE;
	// Start at address 1, address 0 is reserved for erase test.
	totalSectors = SCRPGetFAPIInfo(pDevice, SECTOR_COUNT);
	printf("Advanced Sector Persistent Protection Lock Bit Test\n");
	
	SCRPGetASPFunc(pDevice, ASP_PPBL, 0, &Data);
	if (Data == 0)
		printf("PPB Lock Bit is OFF\n");
	else
	{
        printf("Error: PPB Lock Bit is ON\n");
        printf("The system needs to do power cycle to clear the PPB Lock Bit\n");
        return test_exit(__LINE__);
    }
    if (errCode = SCRPSetASPFunc(pDevice, ASP_PPBERASEALL, 0, FALSE))
    {
        printf("Error: PPB Erase: %s\n", GetErrorText(errCode));
        return test_exit(__LINE__);
    }
    printf("Erased all PPB bits\n");
    if (errCode = tVerifyProtectionOff(pDevice, totalSectors, TRUE))
    {
        printf("Error: Verify DYB/PPB OFF: %s\n", GetErrorText(errCode));
        return test_exit(__LINE__);
    }

    if (errCode = SCRPSetASPFunc(pDevice, ASP_PPBL, 0, TRUE))
    {
        printf("Error: PPB Lock Failure: %s\n", GetErrorText(errCode));
        return test_exit(__LINE__);
    }

    SCRPGetASPFunc(pDevice, ASP_PPBL, 0, &Data);
    if (Data == 0)
    {
        printf("Error: PPB Not set: %s\n", GetErrorText(EC_PPBLNOTSET));
        return test_exit(__LINE__);
	}
	printf("PPB Lock Bit SET, Testing PPB program...\n");
    errCode = EC_NONE;
	for (tSector = 0; (tSector < totalSectors) && (errCode == EC_NONE); tSector++)
	{
		tSecAddr  = SCRPGetFAPIGeometry(pDevice, ADDRESS_OF_SECTOR, tSector );
		if (SCRPSetASPFunc(pDevice, ASP_PPB, tSecAddr, TRUE) == EC_NONE)
		{
			errCode = EC_PPBSET;
            printf("Error: [0x%08lX] PPB can be set: %s\n", tSecAddr, GetErrorText(errCode));
            return test_exit(__LINE__);
		}
		else
            printf("OK, Not able to set PPB on sector %d\n", tSector);

		if (SYS_CheckUserBreak())
		{
            printf("User break!\n");
			return test_exit(0);
		}
	}
		
    if (errCode = tVerifyProtectionOff(pDevice, totalSectors, FALSE))
    {
        printf("Error: Verify DYB/PPB OFF: %s\n", GetErrorText(errCode));
        return test_exit(__LINE__);
	}
	if (errCode == EC_NONE)
		printf("All sectors of PPBs are LOCKed (UNABLE TO SET), and Testing DYB Program ... \n");
	for (tSector = 0; (tSector < totalSectors) && (errCode == EC_NONE); tSector++)
	{
		tSecAddr  = SCRPGetFAPIGeometry(pDevice, ADDRESS_OF_SECTOR, tSector );
        if (errCode = SCRPSetASPFunc(pDevice, ASP_DYB, tSecAddr, TRUE))
        {
            printf("Error: Setting sector %lu DYB: %s\n", tSector, GetErrorText(errCode));
            return test_exit(__LINE__);
        }
        else
            printf("Set DYB on sector %d ... OK\n", tSector);

        if (errCode = SCRPSetASPFunc(pDevice, ASP_DYB, tSecAddr, FALSE))
        {
            printf("Error: Clearing sector %lu DYB: %s\n", tSector, GetErrorText(errCode));
			return test_exit(__LINE__);
		}
		else
            printf("Clear DYB on sector %d ... OK\n", tSector);

		if (SYS_CheckUserBreak())
		{
            printf("User break!\n");
			return test_exit(0);
		}
	}

    printf("All sectors of DYB SET and CLEAR test OK\n");

    printf("Test complete\n");
    return test_exit(0);
}

