#include <stdio.h>
#ifdef SIMULATION
#include "sltapi_sim.h"
#else
#include "sltapi.h"
#endif
#include "rpc2_llops.h"
#include "rpc2_vlld.h"

extern PDEV pDevice;
extern rpc_ctrl_reg_t rpc_ctrl;
extern DWORD rpc_reg_baseaddr;
//extern int slt_mode;
//extern int direct_mode;
//extern int loopbk_mode;
//extern int burst_mode;
DWORD test_config(void)
{
    DWORD errCode = EC_NONE;
    #ifdef NVCR
    DWORD NVCR_val;
    NVCR_val = SCRPGetConfigReg(pDevice, 1);    // 0 - VCR, 1 - NVCR
    printf("Read reg success! NVCR = 0x%04X\n",NVCR_val);
    
    errCode = SCRPSetConfigReg(pDevice, 1, NVCR);
    if (errCode == EC_NONE)
    {
        printf("Write reg success! NVCR = 0x%04X\n",NVCR);
    }
    else
    {        
        printf("Write reg error: errCode = %d \n", errCode);

        return -1;
    }
    printf("Reset RPC2 Flash.\n");
    SCRPCmdResetFlash(pDevice);
    #endif
    
    #ifdef VCR
    DWORD VCR_val;
    VCR_val = SCRPGetConfigReg(pDevice, 0);    // 0 - VCR, 1 - NVCR
    printf("Read reg success! VCR = 0x%04X\n",VCR_val);
    
    errCode = SCRPSetConfigReg(pDevice, 0, VCR);
    if (errCode == EC_NONE)
    {
        printf("Write reg success! VCR = 0x%04X\n",VCR);
    }
    else
    {        
        printf("Write reg error: errCode = %d \n", errCode);

        return -1;
    }
    #endif
    
    #ifdef WP_ENABLE
        if(WP_ENABLE==1)
        {
            SCRPQSPISetWP(pDevice, TRUE);
            printf("<TC> Write protect enable!\n");
        }
        else if(WP_ENABLE==0)
        {
            SCRPQSPISetWP(pDevice, FALSE);
            printf("<TC> Write protect disable.\n");
        }
        SYS_WaitUSec(1);
    #endif
    return errCode;
}


DWORD rpc_mode_init(int slt_mode, int direct_mode, int loopbk_mode, int burst_mode)
{
	DWORD ret = TRUE;
	if(loopbk_mode==TRUE) 
		{
			//Set RPC controller in Loopback mode
			printf("Set RPC controller in Loopback mode\n");
			rpc_ctrl.reg.LPBKR.LBK_MODE = 1;
			pDevice->RPC_LOOPBACK_MODE = 1;
			SCRPQSPIFPGARegWr(pDevice, RPC_LPBKSR, rpc_ctrl.reg.LPBKR.val);
		}
	else
		{
			//Set RPC controller in Normal mode
			printf("Set RPC controller in Normal mode\n");
			rpc_ctrl.reg.LPBKR.LBK_MODE = 0;
			pDevice->RPC_LOOPBACK_MODE = 0;
			SCRPQSPIFPGARegWr(pDevice, RPC_LPBKSR, rpc_ctrl.reg.LPBKR.val);
		}

	if(slt_mode && !direct_mode)
		{
			pDevice->RPC_CTRL_MODE = 1;
			printf("RPC controller work in SLT mode.\n");
		}
	else if(!slt_mode && direct_mode)
		{
			pDevice->RPC_CTRL_MODE = 0;
			printf("RPC controller work in Direct mode.\n");
		}
	else
		{
			printf("Unknown work mode.\n");
			//test_exit(0);
			return FALSE;
		}
	printf("RPC Flash Burst mode : ");
	if(burst_mode)
		{
			pDevice->RPC_FLASH_MODE = 1;
			printf("Continuous Burst\n");
		}
	else
		{
			pDevice->RPC_FLASH_MODE = 0;
			printf("Wrapper Burst\n");
		}

	return ret;
}

/**<rpc_flash_init>***********************************************
DESCRIPTION:  Set config reg of RPC flash
INPUTS:
    PARAMETERS:
    	WORD latency				5 ~ 20 clock latency can be setup
    	
    	WORD rpc_flash_burst_len	2 : 16bytes burst len
    								3 : 32bytes burst len
    								
    	WORD drive_strength			0 : Legacy(Default)
    								1 : Full
    								2 : Half
    								3 : Quarter
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Type:   DWORD           operation status
        Values:
            TRUE	             no error
            FALSE			     setup error or input value invalid
**********************************************************************/
DWORD rpc_flash_init(int latency, int rpc_flash_burst_len, int drive_strength)
{
	rpc_cr_t rpc_cr;
	DWORD ret = TRUE;
	rpc_cr.val = 0;			//Clear rpc_cr content
	
	rpc_cr.DR_STRENGTH = drive_strength;

	//printf("RD_LC = %d, DR_STRENGTH = %d, BURST_LEN = %d\n",rpc_cr.RD_LC,rpc_cr.DR_STRENGTH,rpc_cr.BURST_LEN);
	//printf("rpc_cr = %04X\n",rpc_cr.val);
	if(latency>=5 && latency<=20) 
		{
			//Latency valid
			printf("RPC Flash Latency : %d\n",latency);
			rpc_cr.RD_LC = latency - 5;
		}
	else
		{
			//Latency invalid
			printf("Invalid RPC Flash Latency.\n");
			ret = FALSE;
			goto exit;
		}

	if(rpc_flash_burst_len==16 || rpc_flash_burst_len==32) 
		{
			//Burst length valid
			
			if(rpc_flash_burst_len==16) {
				rpc_cr.BURST_LEN = 2;
				printf("RPC Flash Burst Length : %d bytes\n",rpc_flash_burst_len);
				}
			if(rpc_flash_burst_len==32) {
				rpc_cr.BURST_LEN = 3;
				printf("RPC Flash Burst Length : %d bytes\n",rpc_flash_burst_len);
				}
		}
	else
		{
			//Burst length valid
			printf("Invalid RPC Flash Burst Length.\n");
			ret = FALSE;
			goto exit;
		}
	
	if(drive_strength>=0 && drive_strength<=3) 
		{
			rpc_cr.DR_STRENGTH = drive_strength;
			//Drive strength valid
			if(rpc_cr.DR_STRENGTH==0)
			printf("RPC Flash Drive strength : Legacy\n");

			if(rpc_cr.DR_STRENGTH==1)
			printf("RPC Flash Drive strength : Full\n");

			if(rpc_cr.DR_STRENGTH==2)
			printf("RPC Flash Drive strength : Half\n");

			if(rpc_cr.DR_STRENGTH==3)
			printf("RPC Flash Drive strength : Quarter\n");
		}
	else
		{
			//Drive strength valid
			printf("Invalid RPC Flash Drive strength.\n");
			ret = FALSE;
			goto exit;			
		}
/*
	if(rpc_clk>0 && rpc_clk<=68) 
		{
			//RPC CLK valid
			printf("RPC CLK : %d MHz\n",rpc_clk);
			#ifdef SIMULATION
			printf("(In simulation env RPC CLK is fixed at 66MHz)\n");
			#endif
		}
	else
		{
			//RPC CLK invalid
			printf("Invalid RPC CLK freq.\n");
			ret = FALSE;
			goto exit;
		}
*/	
	//printf("RD_LC = %d, DR_STRENGTH = %d, BURST_LEN = %d\n",rpc_cr.RD_LC,rpc_cr.DR_STRENGTH,rpc_cr.BURST_LEN);
	//printf("rpc_cr = %04X\n",rpc_cr.val);
	printf("Set RPC Flash volatile config register ----------- ");
	if(SCRPSetConfigReg(pDevice, 1, (DWORD)rpc_cr.val)==EC_NONE) {printf("PASS\n");}
	else {printf("FAIL\n"); ret = FALSE; goto exit;}
/*
	#ifndef SIMULATION
	printf("Set RPC CLK to %2d MHz --------------------------- ");
	if(SCRPQSPISetClock(pDevice, rpc_clk)==EC_NONE){printf("PASS\n");}
	else printf("FAIL\n");
	#endif
*/	

exit: return ret;
}

DWORD rpc_ctrl_init(void)
{
	DWORD ret = TRUE;
    /*
	DWORD polling_num = 0;

	SCRPQSPIFPGARegRd(pDevice, RPC_CLKSR, &rpc_ctrl.reg.CLKSR.val);
	printf("Default RPC_CLKSR = %04X, CLK_FREQ = %3d, RPC_CLK_MULT = %d\n",rpc_ctrl.reg.CLKSR.val,rpc_ctrl.reg.CLKSR.CLK_FREQ,rpc_ctrl.reg.CLKSR.RPC_CLK_MULT);
	
	rpc_ctrl.reg.MCR.val= 0x0000;
	rpc_ctrl.reg.WDSAR = 0x0000;
	rpc_ctrl.reg.WDLR = 0x0000;				// Write Data Length Register in word
	rpc_ctrl.reg.RDAMR.RPC_BURST_MODE = 1;	//Continue burst RPC Device Access Mode register
	rpc_ctrl.reg.RDAMR.INIT_LAT = 20;		//LC 20 RPC Device Access Mode register
	rpc_ctrl.reg.RDDAR = 0x0000;					// Read Data Destination Address Register in word
	rpc_ctrl.reg.RDLR = 0x0000;			// Read Data Length Register in word
	rpc_ctrl.reg.WRRDR.WO = 1;					// Write Read Operation Register
	#ifdef SIMULATION
	#ifdef CLK_HALFPERIOD_NS
	rpc_ctrl.reg.RSTGR.val = 0;					// Reset Generating Register	rpc_ctrl.reg.CLKSR.RPC_CLK_MULT = 1;
	rpc_ctrl.reg.CLKSR.CLK_FREQ = (WORD)(500/CLK_HALFPERIOD_NS);		//xxMHz Clock Setting Register
	if(CLK_HALFPERIOD_NS >= 7.35 && CLK_HALFPERIOD_NS < 14.7)
			rpc_ctrl.reg.CLKSR.RPC_CLK_MULT = 1;
	else 
			rpc_ctrl.reg.CLKSR.RPC_CLK_MULT = 0;
	#else
	rpc_ctrl.reg.CLKSR.CLK_FREQ = 5;
	rpc_ctrl.reg.CLKSR.RPC_CLK_MULT = 0;
	#endif
	
	#endif
	rpc_ctrl.reg.LPBKR.LBK_MODE = 0;		//Normal mode Loop Back Register
	#ifdef SELECT_DIE
    switch(SELECT_DIE) {
    case 0:rpc_ctrl.reg.CHSR = RPC_CS0;
	       rpc_ctrl.reg.IWSR = RR_RS_LN0 | WR_WS_LN0;
	       rpc_ctrl.reg.EMWSR =RR_WS_LN0 | WR_RS_LN0;
           break;
    case 1:rpc_ctrl.reg.CHSR = RPC_CS0;
	       rpc_ctrl.reg.IWSR = RR_RS_LN1 | WR_WS_LN1;
	       rpc_ctrl.reg.EMWSR =RR_WS_LN1 | WR_RS_LN1;
           break;
    case 2:rpc_ctrl.reg.CHSR = RPC_CS1;
	       rpc_ctrl.reg.IWSR = RR_RS_LN2 | WR_WS_LN2;
	       rpc_ctrl.reg.EMWSR =RR_WS_LN2 | WR_RS_LN2;
           break;
    case 3:rpc_ctrl.reg.CHSR = RPC_CS1;
	       rpc_ctrl.reg.IWSR = RR_RS_LN3 | WR_WS_LN3;
	       rpc_ctrl.reg.EMWSR =RR_WS_LN3 | WR_RS_LN3;
           break;
    case 4:rpc_ctrl.reg.CHSR = RPC_CS2;
	       rpc_ctrl.reg.IWSR = RR_RS_LN0 | WR_WS_LN0;
	       rpc_ctrl.reg.EMWSR =RR_WS_LN0 | WR_RS_LN0;
           break;
    case 5:rpc_ctrl.reg.CHSR = RPC_CS2;
	       rpc_ctrl.reg.IWSR = RR_RS_LN1 | WR_WS_LN1;
	       rpc_ctrl.reg.EMWSR =RR_WS_LN1 | WR_RS_LN1;
           break;
    case 6:rpc_ctrl.reg.CHSR = RPC_CS3;
	       rpc_ctrl.reg.IWSR = RR_RS_LN2 | WR_WS_LN2;
	       rpc_ctrl.reg.EMWSR =RR_WS_LN2 | WR_RS_LN2;
           break;
    case 7:rpc_ctrl.reg.CHSR = RPC_CS3;
	       rpc_ctrl.reg.IWSR = RR_RS_LN3 | WR_WS_LN3;
	       rpc_ctrl.reg.EMWSR =RR_WS_LN3 | WR_RS_LN3;
           break;
    case 8:rpc_ctrl.reg.CHSR = RPC_CS0|RPC_CS1;
	       rpc_ctrl.reg.IWSR = 0xFF00;
	       rpc_ctrl.reg.EMWSR =0xFF00;
           break;
    case 9:rpc_ctrl.reg.CHSR = RPC_CS2|RPC_CS3;
	       rpc_ctrl.reg.IWSR = 0xFF00;
	       rpc_ctrl.reg.EMWSR =0xFF00;
           break;
    default:rpc_ctrl.reg.CHSR = RPC_CS0;
	       rpc_ctrl.reg.IWSR = RR_RS_LN0 | WR_WS_LN0;
	       rpc_ctrl.reg.EMWSR =RR_WS_LN0 | WR_RS_LN0;
           break;
        }
    if(SELECT_DIE>0 && SELECT_DIE<8)
    printf("DIE %d is selected.\n",SELECT_DIE);
    else if(SELECT_DIE==8)
    printf("DIE 0-3 are selected.\n");
    else if(SELECT_DIE==9)
    printf("DIE 4-7 are selected.\n");
    #else
	rpc_ctrl.reg.CHSR = RPC_CS0;				// Chip Select Register
	rpc_ctrl.reg.IWSR = RR_RS_LN0 | WR_WS_LN0;			// Internal Data Bus Byte Select Register
	rpc_ctrl.reg.EMWSR =RR_WS_LN0 | WR_RS_LN0;
    #endif
	rpc_ctrl.reg.HIAR.ADDR = 0x00;						// High Address Bit Register
	rpc_ctrl.reg.CHWER = 0x0000;					// Chip Write Enable Register
    #ifdef ZYNQ_ASYNC
    rpc_ctrl.reg.RCMCR.ASYN_BURST_SEL = 0;					// RPC Controller Mode Control Register for Aynchronous mode
	rpc_ctrl.reg.RCMCR.BURST_LEN = 0;		//Aynchronous mode
	#else
    rpc_ctrl.reg.RCMCR.ASYN_BURST_SEL = 1;					// RPC Controller Mode Control Register
	rpc_ctrl.reg.RCMCR.BURST_LEN = 16;		//Burst len = 16 word
	#endif
	rpc_ctrl.reg.LEDPIO = 0x0000;			//LED ON/OFF of 226 Board
	rpc_ctrl.reg.OSCI2C.val = 0x0003;					//I2C register Oscillator and power supply of 226 Board
	rpc_ctrl.reg.CS2CSD.val = 0x0000;					//Chip Select to Chip Select Delay

	SCRPQSPIFPGARegWr(pDevice, RPC_MCR, rpc_ctrl.reg.MCR.val);
	
	SCRPQSPIFPGARegWr(pDevice, RPC_WDSAR, rpc_ctrl.reg.WDSAR);

	SCRPQSPIFPGARegWr(pDevice, RPC_WDLR, rpc_ctrl.reg.WDLR);

	SCRPQSPIFPGARegWr(pDevice, RPC_RDAMR, rpc_ctrl.reg.RDAMR.val);

	SCRPQSPIFPGARegWr(pDevice, RPC_RDDAR, rpc_ctrl.reg.RDDAR);

	SCRPQSPIFPGARegWr(pDevice, RPC_RDLR, rpc_ctrl.reg.RDLR);

	SCRPQSPIFPGARegWr(pDevice, RPC_WRRDR, rpc_ctrl.reg.WRRDR.val);

	printf("Setup RPC clock to %2dMHz\n",rpc_ctrl.reg.CLKSR.CLK_FREQ);
	SCRPQSPIFPGARegWr(pDevice, RPC_CLKSR, rpc_ctrl.reg.CLKSR.val);
	
	rpc_ctrl.reg.RSTGR.RST_CLK_GEN = 1;
	SCRPQSPIFPGARegWr(pDevice, RPC_RSTGR, rpc_ctrl.reg.RSTGR.val);
	//SYS_WaitUSec(5000);
	rpc_ctrl.reg.RPCSR.val=0;
	rpc_ctrl.reg.RSTGR.val=0;
	
	printf(" Polling for RST_CLK_GEN=0\n");
	while(1)
		{
			SCRPQSPIFPGARegRd(pDevice, RPC_RSTGR, &rpc_ctrl.reg.RSTGR.val);
			polling_num++;
			if(rpc_ctrl.reg.RSTGR.RST_CLK_GEN==0) 
			{
				printf("  Done. Polling %d times. RSTGR = %04X, RST_CLK_GEN = %d\n",polling_num,rpc_ctrl.reg.RSTGR.val,rpc_ctrl.reg.RSTGR.RST_CLK_GEN);
				break;
			}
			else 
			{
				if(polling_num%1000==0) printf("  Polling %d times. RSTGR = %04X, RST_CLK_GEN = %d\n",polling_num,rpc_ctrl.reg.RSTGR.val,rpc_ctrl.reg.RSTGR.RST_CLK_GEN);
			}
		}	
	
	printf(" Polling for CLK_STATE=1\n");
	polling_num = 0;
	while(1)
		{
			SCRPQSPIFPGARegRd(pDevice, RPC_RPCSR, &rpc_ctrl.reg.RPCSR.val);
			polling_num++;
			if(rpc_ctrl.reg.RPCSR.CLK_STATE==1) 
			{
				printf("  Done. Polling %d times. RPCSR = %04X, CLK_STATE = %d\n",polling_num,rpc_ctrl.reg.RPCSR.val,rpc_ctrl.reg.RPCSR.CLK_STATE);
				break;
			}
			else 
			{
				if(polling_num%1000==0) printf("  Polling %d times. RSTGR = %04X, RST_CLK_GEN = %d\n",polling_num,rpc_ctrl.reg.RSTGR.val,rpc_ctrl.reg.RSTGR.RST_CLK_GEN);
			}
		}

	SCRPQSPIFPGARegRd(pDevice, RPC_CLKSR, &rpc_ctrl.reg.CLKSR.val);
	printf("Setup complete. RPC_CLKSR = %04X, CLK_FREQ = %3d, RPC_CLK_MULT = %d\n",rpc_ctrl.reg.CLKSR.val,rpc_ctrl.reg.CLKSR.CLK_FREQ,rpc_ctrl.reg.CLKSR.RPC_CLK_MULT);
	

	SCRPQSPIFPGARegWr(pDevice, RPC_CHSR, rpc_ctrl.reg.CHSR);

	SCRPQSPIFPGARegWr(pDevice, RPC_IWSR, rpc_ctrl.reg.IWSR);

	SCRPQSPIFPGARegWr(pDevice, RPC_EMWSR, rpc_ctrl.reg.EMWSR);

	SCRPQSPIFPGARegWr(pDevice, RPC_HIAR, rpc_ctrl.reg.HIAR.val);
	
	SCRPQSPIFPGARegWr(pDevice, RPC_CHWER, rpc_ctrl.reg.CHWER);

	SCRPQSPIFPGARegWr(pDevice, RPC_RCMCR, rpc_ctrl.reg.RCMCR.val);

	SCRPQSPIFPGARegWr(pDevice, RPC_LEDPIO, rpc_ctrl.reg.LEDPIO);
	
	SCRPQSPIFPGARegWr(pDevice, RPC_OSCI2C, rpc_ctrl.reg.OSCI2C.val);
	
	SCRPQSPIFPGARegWr(pDevice, RPC_CS2CSD, rpc_ctrl.reg.CS2CSD.val);
	
	
	*/
	return ret;
}

DWORD rpc_ctrl_init_4die(void)
{
	DWORD ret = TRUE;
    /*
	DWORD polling_num = 0;

	SCRPQSPIFPGARegRd(pDevice, RPC_CLKSR, &rpc_ctrl.reg.CLKSR.val);
	printf("Default RPC_CLKSR = %04X, CLK_FREQ = %3d, RPC_CLK_MULT = %d\n",rpc_ctrl.reg.CLKSR.val,rpc_ctrl.reg.CLKSR.CLK_FREQ,rpc_ctrl.reg.CLKSR.RPC_CLK_MULT);
	
	rpc_ctrl.reg.MCR.val= 0x0000;
	rpc_ctrl.reg.WDSAR = 0x0000;
	rpc_ctrl.reg.WDLR = 0x0000;				// Write Data Length Register in word
	rpc_ctrl.reg.RDAMR.RPC_BURST_MODE = 1;	//Continue burst RPC Device Access Mode register
	rpc_ctrl.reg.RDAMR.INIT_LAT = 20;		//LC 20 RPC Device Access Mode register
	rpc_ctrl.reg.RDDAR = 0x0000;					// Read Data Destination Address Register in word
	rpc_ctrl.reg.RDLR = 0x0000;			// Read Data Length Register in word
	rpc_ctrl.reg.WRRDR.WO = 1;					// Write Read Operation Register
	#ifdef SIMULATION
	#ifdef CLK_HALFPERIOD_NS
	//rpc_ctrl.reg.RSTGR.val = 0;					// Reset Generating Register	rpc_ctrl.reg.CLKSR.RPC_CLK_MULT = 1;
	rpc_ctrl.reg.CLKSR.CLK_FREQ = (WORD)(500/CLK_HALFPERIOD_NS);		//xxMHz Clock Setting Register
	if(CLK_HALFPERIOD_NS >= 7.35 && CLK_HALFPERIOD_NS < 14.7)
			rpc_ctrl.reg.CLKSR.RPC_CLK_MULT = 1;
	else 
			rpc_ctrl.reg.CLKSR.RPC_CLK_MULT = 0;
	#else
	rpc_ctrl.reg.CLKSR.CLK_FREQ = 5;
	rpc_ctrl.reg.CLKSR.RPC_CLK_MULT = 0;
	#endif
	
	#endif
	rpc_ctrl.reg.LPBKR.LBK_MODE = 0;		//Normal mode Loop Back Register
	rpc_ctrl.reg.CHSR = RPC_CS0 | RPC_CS1;				// Chip Select Register
	rpc_ctrl.reg.IWSR = WR_WS_LN0 | WR_WS_LN1 | WR_WS_LN2 | WR_WS_LN3 | RR_RS_LN0 | RR_RS_LN1 | RR_RS_LN2 | RR_RS_LN3;			// Internal Data Bus Byte Select Register
	rpc_ctrl.reg.EMWSR = WR_RS_LN0 | RR_WS_LN0 | WR_RS_LN1 | RR_WS_LN1 | WR_WS_LN2 | RR_RS_LN2 | WR_WS_LN3 | RR_RS_LN3; 
	rpc_ctrl.reg.HIAR.ADDR = 0x00;						// High Address Bit Register
	rpc_ctrl.reg.CHWER = 0x0000;					// Chip Write Enable Register
	#ifdef ZYNQ_ASYNC
    rpc_ctrl.reg.RCMCR.ASYN_BURST_SEL = 0;					// RPC Controller Mode Control Register for Aynchronous mode
	rpc_ctrl.reg.RCMCR.BURST_LEN = 0;		//Aynchronous mode
	#else
    rpc_ctrl.reg.RCMCR.ASYN_BURST_SEL = 1;					// RPC Controller Mode Control Register
	rpc_ctrl.reg.RCMCR.BURST_LEN = 16;		//Burst len = 16 word
	#endif
	rpc_ctrl.reg.LEDPIO = 0x0000;			//LED ON/OFF of 226 Board
	rpc_ctrl.reg.OSCI2C.val = 0x0003;					//I2C register Oscillator and power supply of 226 Board
	rpc_ctrl.reg.CS2CSD.val = 0x0000;					//Chip Select to Chip Select Delay

	SCRPQSPIFPGARegWr(pDevice, RPC_MCR, rpc_ctrl.reg.MCR.val);
	
	SCRPQSPIFPGARegWr(pDevice, RPC_WDSAR, rpc_ctrl.reg.WDSAR);

	SCRPQSPIFPGARegWr(pDevice, RPC_WDLR, rpc_ctrl.reg.WDLR);

	SCRPQSPIFPGARegWr(pDevice, RPC_RDAMR, rpc_ctrl.reg.RDAMR.val);

	SCRPQSPIFPGARegWr(pDevice, RPC_RDDAR, rpc_ctrl.reg.RDDAR);

	SCRPQSPIFPGARegWr(pDevice, RPC_RDLR, rpc_ctrl.reg.RDLR);

	SCRPQSPIFPGARegWr(pDevice, RPC_WRRDR, rpc_ctrl.reg.WRRDR.val);

	printf("Setup RPC clock to %2dMHz\n",rpc_ctrl.reg.CLKSR.CLK_FREQ);
	SCRPQSPIFPGARegWr(pDevice, RPC_CLKSR, rpc_ctrl.reg.CLKSR.val);
	
	rpc_ctrl.reg.RSTGR.RST_CLK_GEN = 1;
	SCRPQSPIFPGARegWr(pDevice, RPC_RSTGR, rpc_ctrl.reg.RSTGR.val);
	//SYS_WaitUSec(5000);
	rpc_ctrl.reg.RPCSR.val=0;
	rpc_ctrl.reg.RSTGR.val=0;
	
	printf(" Polling for RST_CLK_GEN=0\n");
	while(1)
		{
			SCRPQSPIFPGARegRd(pDevice, RPC_RSTGR, &rpc_ctrl.reg.RSTGR.val);
			polling_num++;
			if(rpc_ctrl.reg.RSTGR.RST_CLK_GEN==0) 
			{
				printf("  Done. Polling %d times. RSTGR = %04X, RST_CLK_GEN = %d\n",polling_num,rpc_ctrl.reg.RSTGR.val,rpc_ctrl.reg.RSTGR.RST_CLK_GEN);
				break;
			}
			else 
			{
				if(polling_num%1000==0) printf("  Polling %d times. RSTGR = %04X, RST_CLK_GEN = %d\n",polling_num,rpc_ctrl.reg.RSTGR.val,rpc_ctrl.reg.RSTGR.RST_CLK_GEN);
			}
		}	
	
	printf(" Polling for CLK_STATE=1\n");
	polling_num = 0;
	while(1)
		{
			SCRPQSPIFPGARegRd(pDevice, RPC_RPCSR, &rpc_ctrl.reg.RPCSR.val);
			polling_num++;
			if(rpc_ctrl.reg.RPCSR.CLK_STATE==1) 
			{
				printf("  Done. Polling %d times. RPCSR = %04X, CLK_STATE = %d\n",polling_num,rpc_ctrl.reg.RPCSR.val,rpc_ctrl.reg.RPCSR.CLK_STATE);
				break;
			}
			else 
			{
				if(polling_num%1000==0) printf("  Polling %d times. RSTGR = %04X, RST_CLK_GEN = %d\n",polling_num,rpc_ctrl.reg.RSTGR.val,rpc_ctrl.reg.RSTGR.RST_CLK_GEN);
			}
		}
	SCRPQSPIFPGARegRd(pDevice, RPC_CLKSR, &rpc_ctrl.reg.CLKSR.val);
	printf("Setup complete. RPC_CLKSR = %04X, CLK_FREQ = %3d, RPC_CLK_MULT = %d\n",rpc_ctrl.reg.CLKSR.val,rpc_ctrl.reg.CLKSR.CLK_FREQ,rpc_ctrl.reg.CLKSR.RPC_CLK_MULT);
	
	SCRPQSPIFPGARegWr(pDevice, RPC_CHSR, rpc_ctrl.reg.CHSR);

	SCRPQSPIFPGARegWr(pDevice, RPC_IWSR, rpc_ctrl.reg.IWSR);

	SCRPQSPIFPGARegWr(pDevice, RPC_EMWSR, rpc_ctrl.reg.EMWSR);

	SCRPQSPIFPGARegWr(pDevice, RPC_HIAR, rpc_ctrl.reg.HIAR.val);
	
	SCRPQSPIFPGARegWr(pDevice, RPC_CHWER, rpc_ctrl.reg.CHWER);

	SCRPQSPIFPGARegWr(pDevice, RPC_RCMCR, rpc_ctrl.reg.RCMCR.val);

	SCRPQSPIFPGARegWr(pDevice, RPC_LEDPIO, rpc_ctrl.reg.LEDPIO);
	
	SCRPQSPIFPGARegWr(pDevice, RPC_OSCI2C, rpc_ctrl.reg.OSCI2C.val);
	
	SCRPQSPIFPGARegWr(pDevice, RPC_CS2CSD, rpc_ctrl.reg.CS2CSD.val);
	
	
	*/
	return ret;
}
