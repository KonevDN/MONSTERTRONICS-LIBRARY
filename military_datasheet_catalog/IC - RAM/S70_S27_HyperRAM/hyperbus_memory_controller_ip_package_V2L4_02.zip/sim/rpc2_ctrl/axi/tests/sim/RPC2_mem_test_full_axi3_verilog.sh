FF="rpc2_ctrl_slt3_sysw.f "
OP1="-end -DDEF_2_SECTORS -DDEF_SECTORSIZE=32"
OP2="-end -DDEF_2_SECTORS -DDEF_SECTORSIZE=32 -DTEST_CONFIG"
OP3="-end -DDEF_2_SECTORS -DDEF_SECTORSIZE=512"
CLK="-define CLK_PERIOD=6"
WP="-DWP_ENABLE=1"

for cmd_arg in $@; do
	case $cmd_arg in
	-cdn)
		FF="rpc2_ctrl_slt3_cdn.f"
		;;
	-all)
		OP1="-end -DDEF_2_SECTORS"
		OP2="-end -DDEF_2_SECTORS -DTEST_CONFIG"
		OP3="-end -DDEF_2_SECTORS"
		;;
	esac
done

LOG="sim/log"
for LOG_FILE in ../$LOG/RPC2_*.log; do
rm -f $LOG_FILE 
done

irun -f $FF ../tc/RPC2_B02_CheckCFI_xxx.c $OP1 $CLK -l ../$LOG/RPC2_B02_CheckCFI_xxx.log
irun -f $FF ../tc/RPC2_419_SingleWordProg_Random.c $OP1 -DDEF_SECTORSIZE=32 $CLK -l ../$LOG/RPC2_419_SingleWordProg_Random.log 
irun -f $FF ../tc/RPC2_420_SingleWordProg_addr_1.c $OP1 -DDEF_SECTORSIZE=32 $CLK -l ../$LOG/RPC2_420_SingleWordProg_addr_1.log 
irun -f $FF ../tc/RPC2_420_SingleWordProg_AA55.c $OP1 -DDEF_SECTORSIZE=32 $CLK -l ../$LOG/RPC2_420_SingleWordProg_AA55.log
irun -f $FF ../tc/RPC2_104_EraseProgRead_random.c $OP1 $CLK -l ../$LOG/RPC2_104_EraseProgRead_Random.log

CLK="-define CLK_PERIOD=20"
# VCR TEST, burst len = 16B, latency = 5~16, RPC_CK = 50MHz
for VCR in 0x0202 0x0212 0x0222 0x0232 0x0242 0x0252 0x0262 0x0272 0x0282 0x0292 0x02A2 0x02B2; do
irun -f $FF ../tc/RPC2_104_EraseProgRead_random.c $OP2 -DVCR=$VCR $CLK -l ../$LOG/RPC2_104_EraseProgRead_random_VCR_16B_$VCR.log 
done

# VCR TEST, burst len = 32B, latency = 5~16, RPC_CK = 50MHz
for VCR in 0x0203 0x0213 0x0223 0x0233 0x0243 0x0253 0x0263 0x0273 0x0283 0x0293 0x02A3 0x02B3; do
irun -f $FF ../tc/RPC2_104_EraseProgRead_random.c $OP2 -DVCR=$VCR $CLK -l ../$LOG/RPC2_104_EraseProgRead_random_VCR_32B_$VCR.log 
done

# VCR TEST, burst len = 64B, latency = 5~16, RPC_CK = 50MHz
for VCR in 0x0201 0x0211 0x0221 0x0231 0x0241 0x0251 0x0261 0x0271 0x0281 0x0291 0x02A1 0x02B1; do
irun -f $FF ../tc/RPC2_104_EraseProgRead_random.c $OP2 -DVCR=$VCR $CLK -l ../$LOG/RPC2_104_EraseProgRead_random_VCR_64B_$VCR.log 
done

# NVCR TEST, burst len = 16B, latency = 5~16, RPC_CK = 50MHz
for NVCR in 0x0202 0x0212 0x0222 0x0232 0x0242 0x0252 0x0262 0x0272 0x0282 0x0292 0x02A2 0x02B2; do
irun -f $FF ../tc/RPC2_104_EraseProgRead_random.c $OP2 -DNVCR=$NVCR $CLK -l ../$LOG/RPC2_104_EraseProgRead_random_NVCR_16B_$NVCR.log 
done

# NVCR TEST, burst len = 32B, latency = 5~16, RPC_CK = 50MHz
for NVCR in 0x0203 0x0213 0x0223 0x0233 0x0243 0x0253 0x0263 0x0273 0x0283 0x0293 0x02A3 0x02B3; do
irun -f $FF ../tc/RPC2_104_EraseProgRead_random.c $OP2 -DNVCR=$NVCR $CLK -l ../$LOG/RPC2_104_EraseProgRead_random_NVCR_32B_$NVCR.log 
done

# NVCR TEST, burst len = 64B, latency = 5~16, RPC_CK = 50MHz
for NVCR in 0x0201 0x0211 0x0221 0x0231 0x0241 0x0251 0x0261 0x0271 0x0281 0x0291 0x02A1 0x02B1; do
irun -f $FF ../tc/RPC2_104_EraseProgRead_random.c $OP2 -DNVCR=$NVCR $CLK -l ../$LOG/RPC2_104_EraseProgRead_random_NVCR_64B_$NVCR.log 
done

CLK="-define CLK_PERIOD=6"
irun -f $FF ../tc/RPC2_104_EraseProgRead_random_WP.c $OP2 $WP $CLK -l ../$LOG/RPC2_104_EraseProgRead_Random_WP.log
irun -f $FF ../tc/RPC2_104_EraseProgRead_random_EraseSectors_read_FFFF.c $OP1 $CLK -l ../$LOG/RPC2_104_EraseProgRead_Random_EraseSectors_read_FFFF.log
irun -f $FF ../tc/RPC2_105_EraseProgRead_addr_1.c $OP1 $CLK -l ../$LOG/RPC2_105_EraseProgRead_Addr_1.log
irun -f $FF ../tc/RPC2_105_EraseProgRead_addr_1_EraseSectors_read_FFFF.c $OP1 $CLK -l ../$LOG/RPC2_105_EraseProgRead_Addr_1_EraseSectors_read_FFFF.log
irun -f $FF ../tc/RPC2_106_EraseProgRead_FFFF.c $OP1 $CLK -l ../$LOG/RPC2_106_EraseProgRead_FFFF.log
irun -f $FF ../tc/RPC2_305_EraseSectors_BlankcheckCmd.c $OP1 $CLK -l ../$LOG/RPC2_305_EraseSectors_BlankcheckCmd.log
irun -f $FF ../tc/RPC2_107_EraseProgRead_FFFE.c $OP1 $CLK -l ../$LOG/RPC2_107_EraseProgRead_FFFE.log
irun -f $FF ../tc/RPC2_107_EraseProgRead_FFFE_NonBlankcheckCmd.c $OP1 $CLK -l ../$LOG/RPC2_107_EraseProgRead_FFFE_NonBlankcheckCmd.log
irun -f $FF ../tc/RPC2_108_EraseProgRead_EFFF.c $OP1 $CLK -l ../$LOG/RPC2_108_EraseProgRead_EFFF.log
irun -f $FF ../tc/RPC2_108_EraseProgRead_EFFF_NonBlankcheckCmd.c $OP1 $CLK -l ../$LOG/RPC2_108_EraseProgRead_EFFF_NonBlankcheckCmd.log
irun -f $FF ../tc/RPC2_401_BufferWriteBitClearProg.c $OP3 -DDEF_BUFSIZE=256 $CLK -l ../$LOG/RPC2_401_BufferWriteBitClearProg.log
irun -f $FF ../tc/RPC2_406_BufferWriteWordClearProg.c $OP3 -DDEF_BUFSIZE=256 $CLK -l ../$LOG/RPC2_406_BufferWriteWordClearProg.log

# Write buffer TEST, buffer size = 32, 64, 128, 256, RPC_CK = 166MHz
for BUF_SIZE in 32 64 128 256; do
irun -f $FF ../tc/RPC2_407_BufferWriteXXWordProg.c $OP3 -DDEF_BUFSIZE=$BUF_SIZE -DDEF_DATA_PATTERN=1 $CLK -l ../$LOG/RPC2_407_BufferWriteXXWordProg_random_$BUF_SIZE.log 
done

# RPC_CK TEST, CLK_PERIOD = 100, 50, 33, 25, 20, 16, 14, 12.5, 11, 10, 9, 8, 7.7, 7.1, 6.6, 6 
for CK in 100 50 33 25 20 16 14 12.5 11 10 9 8 7.7 7.1 6.6 6; do
irun -f $FF ../tc/RPC2_104_EraseProgRead_random.c $OP1  -define CLK_PERIOD=$CK -l ../$LOG/RPC2_104_EraseProgRead_random_$CK.log 
done

irun -f $FF ../tc/RPC2_407_BufferWriteXXWordProg.c $OP3 -DDEF_BUFSIZE=256 -DDEF_DATA_PATTERN=2 $CLK -l ../$LOG/RPC2_407_BufferWriteXXWordProg_addr_1_256.log 
irun -f $FF ../tc/RPC2_407_BufferWriteXXWordProg.c $OP3 -DDEF_BUFSIZE=256 -DDEF_DATA_PATTERN=3 $CLK -l ../$LOG/RPC2_407_BufferWriteXXWordProg_AA55_256.log 

irun -f $FF ../tc/RPC2_408_BufferWriteXXYYWordProg.c $OP3 -DDEF_BUFSIZE=256 $CLK -l ../$LOG/RPC2_408_BufferWriteXXYYWordProg.log
irun -f $FF ../tc/RPC2_508_Erase_sus_res_rand.c $OP1 $CLK -l ../$LOG/RPC2_508_Erase_sus_res_rand.log
irun -f $FF ../tc/RPC2_604_Prog_sus_res_rand.c $OP3 $CLK -l ../$LOG/RPC2_604_Prog_sus_res_rand.log
irun -f $FF ../tc/RPC2_A01_AdvSecDynamicProtectBit.c $OP1 $CLK -l ../$LOG/RPC2_A01_AdvSecDynamicProtectBit.log
irun -f $FF ../tc/RPC2_A02_AdvSecPersistenProtectLockBit.c $OP1 $CLK -l ../$LOG/RPC2_A02_AdvSecPersistenProtectLockBit.log
irun -f $FF ../tc/RPC2_A03_AdvSecPersistentNoPassword.c $OP1 $CLK -l ../$LOG/RPC2_A03_AdvSecPersistentNoPassword.log
irun -f $FF ../tc/RPC2_A04_AdvSecPersistentPassword.c $OP1 $CLK -l ../$LOG/RPC2_A04_AdvSecPersistentPassword.log
irun -f $FF ../tc/RPC2_A05_AdvSecPersistentPasswordReadMode.c $OP1 $CLK -l ../$LOG/RPC2_A05_AdvSecPersistentPasswordReadMode.log
irun -f $FF ../tc/RPC2_A06_AdvSecPersistentProtectBit.c $OP1 $CLK -l ../$LOG/RPC2_A06_AdvSecPersistentProtectBit.log
irun -f $FF ../tc/RPC2_A07_AdvSecPersistentStatus.c $OP1 $CLK -l ../$LOG/RPC2_A07_AdvSecPersistentStatus.log
irun -f $FF ../tc/RPC2_C01_ReadOtp.c $OP1 $CLK -l ../$LOG/RPC2_C01_ReadOtp.log
irun -f $FF ../tc/RPC2_C02_WordProgOtp.c $OP1 $CLK -l ../$LOG/RPC2_C02_WordProgOtp.log
irun -f $FF ../tc/RPC2_C03_OtpBlankCheck.c $OP1 $CLK -l ../$LOG/RPC2_C03_OtpBlankCheck.log
irun -f $FF ../tc/RPC2_C04_ProgBitClearOtp.c $OP1 $CLK -l ../$LOG/RPC2_C04_ProgBitClearOtp.log
irun -f $FF ../tc/RPC2_C05_PageProgOtp.c $OP1 $CLK -l ../$LOG/RPC2_C05_PageProgOtp.log
irun -f $FF ../tc/RPC2_E01_EccOneWordProg.c $OP1 $CLK -l ../$LOG/RPC2_E01_EccOneWordProg.log
irun -f $FF ../tc/RPC2_E02_ClearEccStatus.c $OP1 $CLK -l ../$LOG/RPC2_E02_ClearEccStatus.log
irun -f $FF ../tc/RPC2_CRCTest.c $OP1 $CLK -l ../$LOG/RPC2_CRCTest.log

CLK="-define CLK_PERIOD=20"
irun -f $FF ../tc/RPC2_BurstWriteTest.c $OP3 $CLK -l ../$LOG/RPC2_BurstWriteTest.log

CLK="-define CLK_PERIOD=6"
irun -f $FF ../tc/RPC2_INTSignalTest.c $OP1 $CLK -l ../$LOG/RPC2_INTSignalTest.log

