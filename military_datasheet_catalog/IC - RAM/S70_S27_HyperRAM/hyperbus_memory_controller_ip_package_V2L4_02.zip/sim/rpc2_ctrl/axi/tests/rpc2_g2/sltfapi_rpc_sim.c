#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#ifdef SIMULATION
#include "sltapi_sim.h"
#include "rpc2_llops.h"
#include "rpc2_vlld.h"
#else
#include "genlib.h"
#include "sp00082.h"
#include "sp00082hw.h"
#include "sp00081hw.h"
#include "arm.h"
#include "omap24xx.h"
#include "slttypes.h"
#include "slterr.h"
#include "sltfapi.h"
//#include "sltapi.h"
#include "sysio.h"
#include "rpc2_llops.h"

#endif

// ***************************************************************************
//  external variables
// ***************************************************************************
extern rpc_ctrl_reg_t rpc_ctrl;

#ifndef SIMULATION
extern void SysISRHandler(void);
#endif

// ***************************************************************************
//  definitions
// ***************************************************************************
//#define WRDISABLE
#define PRINT_INTERVAL	1000

// boot type - region count table
BTRC BootTable[] =
{
    {BT_UNIFORM_NONE,     1},
    {BT_SMALL_TOP_BOTTOM, 3},
    {BT_SMALL_BOTTOM,     2},
    {BT_SMALL_TOP,        2},
    {BT_UNIFORM_BOTTOM,   1},
    {BT_UNIFORM_TOP,      1},
    {BT_UNIFORM_WP_ALL,   1},
    {BT_UNIFORM_WP_TOP_BOTTOM,   2},
    {BT_LIMIT,            0}
};

// default column address bits
#define FAPI_COLUMN_BITS 7

// ***************************************************************************
//  QSPI Library Definitions
// ***************************************************************************
enum
{
    // API result codes
    QSPI_OK          =  0,      // Success
    QSPI_ERR_INIT    = -1,      // Library not initialized
    QSPI_ERR_PARAM   = -2,      // Parameter error
    QSPI_ERR_FPGA    = -3,      // Problem communicating with FPGA design
    QSPI_ERR_DCM     = -4,      // DCM not locked
    QSPI_ERR_TIMEOUT = -5,      // Communication timeout
    QSPI_ERR_FPGA_RST= -6,

    // SPI clock modes
    QSPI_SPI_MODE_0 = 0,        // Mode 0 (CPOL=0, CPHA=0)
    QSPI_SPI_MODE_1 = 1,        // Mode 1 (CPOL=0, CPHA=1)
    QSPI_SPI_MODE_2 = 2,        // Mode 2 (CPOL=1, CPHA=0)
    QSPI_SPI_MODE_3 = 3,        // Mode 3 (CPOL=1, CPHA=1)

    // SPI bit modes
    QSPI_1BIT = 0,              // single-bit, MSB first
    QSPI_2BIT = 1,              // dual-bit, MSB first
    QSPI_4BIT = 2,              // quad-bit, MSB first
    QSPI_8BIT_PM = 3,           // 8 bit parallel mode

    // SPI banks
    QSPI_BANK_NONE = -1,        // Deselect all FS_CS[3:0]
    QSPI_BANK_CS0  = 0,         // Select FS_CS[0]
    QSPI_BANK_CS1  = 1,         // Select FS_CS[1]
    QSPI_BANK_CS2  = 2,         // Select FS_CS[2]
    QSPI_BANK_CS3  = 3,         // Select FS_CS[3]

    //SPI status
    QSPI_WIP    = 0x01,
    QSPI_WEL    = 0x02,
    QSPI_BP0    = 0x04,
    QSPI_BP1    = 0x08,
    QSPI_BP2    = 0x10,
    QSPI_E_ERR  = 0x20,         //only FL-P support, FL-R don't
    QSPI_P_ERR  = 0x40,         //only FL-P support, FL-R don't
    QSPI_SRWD   = 0x80,
    QSPI_PSSB   = 0x01,
    QSPI_ESSB   = 0x02,

    //SPI config
    QSPI_FREEZE = 0x01,
    QSPI_QUAD   = 0x02,
    QSPI_TBPARM = 0x04,
    QSPI_BPNV   = 0x08,
    QSPI_LOCK   = 0x10,
    QSPI_TBPROT = 0x20,
    QSPI_LC0    = 0x40,
    QSPI_LC1    = 0x80,

    //Op or Data
    QSPI_OP = 0x01,
    QSPI_DATA = 0x02,
    QSPI_ADDR = 0x03,

    // Flags (e.g. for write protect...)
    QSPI_ON = 1,
    QSPI_OFF = 0
};


// ***************************************************************************
//  data
// ***************************************************************************
PDEV pDevice;   // global flash device
char flashName[64];
DWORD rpc_reg_baseaddr = CS1_BASE_ADDR;


// ***************************************************************************
//  implementation
// ***************************************************************************

#ifndef SIMULATION
void GPMC_Init(void)
{
    // config SM0 --- CS1
    OMAP24XX_REG32(GPMC_CONFIG1_1) = 0x61411001;
    OMAP24XX_REG32(GPMC_CONFIG2_1) = 0x00060c00;
    OMAP24XX_REG32(GPMC_CONFIG3_1) = 0x00010100;
    OMAP24XX_REG32(GPMC_CONFIG4_1) = 0x06020c02;
    OMAP24XX_REG32(GPMC_CONFIG5_1) = 0x0203060d;
    OMAP24XX_REG32(GPMC_CONFIG6_1) = 0;
    OMAP24XX_REG32(GPMC_CONFIG7_1) = 0x00000848;
    // config SM1 --- CS3
    OMAP24XX_REG32(GPMC_CONFIG1_3) = 0x61411001;
    OMAP24XX_REG32(GPMC_CONFIG2_3) = 0x00060c00;
    OMAP24XX_REG32(GPMC_CONFIG3_3) = 0x00010100;
    OMAP24XX_REG32(GPMC_CONFIG4_3) = 0x06020c02;
    OMAP24XX_REG32(GPMC_CONFIG5_3) = 0x0203060d;
    OMAP24XX_REG32(GPMC_CONFIG6_3) = 0;
    OMAP24XX_REG32(GPMC_CONFIG7_3) = 0x00000858;
}

int RPCGetClock(unsigned int* pnHertz)
{
    unsigned short nReg;
    unsigned short nOCT;
    unsigned short nDAC;

    // Check parameters
    if (pnHertz == 0)
        return QSPI_ERR_PARAM;

    /*****************************/
    // add code to get val from I2C
    

    if (nOCT<15)
         *pnHertz = ((2<<nOCT)*2078*30)/(2*60-(nDAC*60/1024));  // for sck<=136MHz
//andy         *pnHertz = ((2<<(nOCT-1))*2078*60)/(2*60-(nDAC*60/1024));  // for sck<=136MHz
    else
         *pnHertz = ((2<<nOCT)*2078*15)/(2*30-(nDAC*30/1024));  // for sck>136MHz
//andy         *pnHertz = ((2<<(nOCT-1))*2078*30)/(2*30-(nDAC*30/1024));  // for sck>136MHz

    // Get SPI freq
    *pnHertz =(*pnHertz) * 8 / 2;

    return QSPI_OK;
}

// QspiSetSpiClock
//*****************************************************************//
// SPI Clock x 2                OSC output                  DCM
// 1.064Mhz~34.01Mhz        OCT=10~14                   x1
// 34.048Mhz~272.08Mhz  OCT=12~14(4.256M~34.01M)    x8
//
//*****************************************************************//
extern short set_sp00226_osc2(unsigned char OCT, unsigned short DAC);
int RPCSetClock(PDEV dev, unsigned int nHertz)// nHertz = SPI clock, FPGA output clock = 2 * nHertz
{
    unsigned int nVal;
    unsigned short nOCT;
    unsigned short nDAC;
    unsigned short nOSC=0x0000; // OSC reg value
    short err_i2c = 0;

    nVal = (nHertz >= 3000000) ? (2 * nHertz / 8) : 3000000;//FPGA use 2 x SPI clock as output clock; minimum Frequrency of DCM input is 1Mhz

    // Get OCT
    if  ((nVal>=    1039) && (nVal<    2076))
        nOCT = 0;
    else if ((nVal>=    2078) && (nVal<    4152))
        nOCT = 1;
    else if ((nVal>=    4156) && (nVal<    8304))
        nOCT = 2;
    else if ((nVal>=    8312) && (nVal<   16610))
        nOCT = 3;
    else if ((nVal>=   16620) && (nVal<   33220))
        nOCT = 4;
    else if ((nVal>=   33250) && (nVal<   66430))
        nOCT = 5;
    else if ((nVal>=   66500) && (nVal<  132900))
        nOCT = 6;
    else if ((nVal>=  133000) && (nVal<  265700))
        nOCT = 7;
    else if ((nVal>=  266000) && (nVal<  531400))
        nOCT = 8;
    else if ((nVal>=  532000) && (nVal< 1063000))
        nOCT = 9;
    else if ((nVal>= 1064000) && (nVal< 2126000))
        nOCT = 10;
    else if ((nVal>= 2128000) && (nVal< 4252000))
        nOCT = 11;
    else if ((nVal>= 4256000) && (nVal< 8503000))
        nOCT = 12;
    else if ((nVal>= 8511000) && (nVal<17010000))
        nOCT = 13;
    else if ((nVal>=17020000) && (nVal<34010000))
        nOCT = 14;
    else if ((nVal>=34050000) && (nVal<68030000))
        nOCT = 15;
    else
        return QSPI_ERR_PARAM;
//andy    nDAC = 2048 - (2078 * (16*(2<<(nOCT-1)))/(nVal/64));// Get DAC
    nDAC = 2048 - (2078 * (8*(2<<nOCT))/(nVal/64));// Get DAC
    printf("set clock oct = 0x%x, dac = 0x%x\n", nOCT, nDAC);
    if (err_i2c = set_sp00226_osc2(nOCT, nDAC)) {
        printf("set clock failed, error code %d\n", err_i2c);
        return QSPI_ERR_DCM;
    }

    return QSPI_OK;
}
#endif

WORD RPC2EMU_EXT_FLASH_CFI[MAX_CFI] =
{
    0x0001, 0x227E, 0x0000, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
    0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0x0001, 0x0000, 0x2266, 0x2201,
    0x0051, 0x0052, 0x0059, 0x0002, 0x0000, 0x0040, 0x0000, 0x0000,
    0x0000, 0x0000, 0x0000, 0x0027, 0x0036, 0x0000, 0x0000, 0x0008,
    0x0009, 0x0008, 0x0015, 0x0001, 0x0002, 0x0003, 0x0003, 0x001C,
    0x0001, 0x0000, 0x0009, 0x0000, 0x0001, 0x00FF, 0x0003, 0x0000,
    0x0004, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000,
    0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000,
    0x0050, 0x0052, 0x0049, 0x0031, 0x0035, 0x001C, 0x0000, 0x0000,
    0x0000, 0x0008, 0x0000, 0x0001, 0x0003, 0x0000, 0x0000, 0x0006,
    0x0000, 0x0000, 0x0009, 0x0019, 0x0005, 0x0006, 0x0006, 0xFFFF,
    0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
    0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
    0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
    0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
    0x0006, 0x0009, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
};

WORD RPC2EMU_INT_BRAM_CFI[MAX_CFI] =
{
    0x0001, 0x227E, 0x0000, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
    0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0x0001, 0x0000, 0x2266, 0x2201,
    0x0051, 0x0052, 0x0059, 0x0002, 0x0000, 0x0040, 0x0000, 0x0000,
    0x0000, 0x0000, 0x0000, 0x0027, 0x0036, 0x0000, 0x0000, 0x0008,
    0x0009, 0x0008, 0x0015, 0x0001, 0x0002, 0x0003, 0x0003, 0x001A,
    0x0001, 0x0000, 0x0009, 0x0000, 0x0001, 0x00FF, 0x0000, 0x0000,
    0x0004, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000,
    0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000,
    0x0050, 0x0052, 0x0049, 0x0031, 0x0035, 0x001C, 0x0000, 0x0000,
    0x0000, 0x0008, 0x0000, 0x0001, 0x0003, 0x0000, 0x0000, 0x0006,
    0x0000, 0x0000, 0x0009, 0x0019, 0x0005, 0x0006, 0x0006, 0xFFFF,
    0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
    0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
    0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
    0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
    0x0006, 0x0009, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
};

void FAPI_NORCmdAlternateModeProg(PDARGS pArg)
{
    PDEV dev = pArg->pDevice;

    pArg->fl_addr = 0x000;
    pArg->fl_data = 0xA0;
    dev->pWriteNORData(pArg);

    pArg->fl_addr = pArg->st_addr;
    pArg->fl_data = pArg->dwValue;
    dev->pWriteNORData(pArg);
}

void FAPI_NORCmdAnymodeExit(PDARGS pArg)
{
    PDEV dev = pArg->pDevice;

    pArg->fl_addr = 0x000;
    pArg->fl_data = 0x90;
    dev->pWriteNORData(pArg);

    pArg->fl_addr = 0x000;
    pArg->fl_data = 0x00;
    dev->pWriteNORData(pArg);
}

void FAPI_NORCmdLockRegisterEnter(PDARGS pArg)
{
    PDEV dev = pArg->pDevice;

    pArg->fl_addr = 0x555;
    pArg->fl_data = 0xAA;
    dev->pWriteNORData(pArg);

    pArg->fl_addr = 0x2AA;
    pArg->fl_data = 0x55;
    dev->pWriteNORData(pArg);

    pArg->fl_addr = 0x555;
    pArg->fl_data = 0x40;
    dev->pWriteNORData(pArg);
}

void FAPI_NORCmdPasswordEnter(PDARGS pArg)
{
    PDEV dev = pArg->pDevice;

    pArg->fl_addr = 0x555;
    pArg->fl_data = 0xAA;
    dev->pWriteNORData(pArg);

    pArg->fl_addr = 0x2AA;
    pArg->fl_data = 0x55;
    dev->pWriteNORData(pArg);

    pArg->fl_addr = 0x555;
    pArg->fl_data = 0x60;
    dev->pWriteNORData(pArg);
}

void FAPI_NORCmdPasswordUnlock(PDARGS pArg)
{
    PDEV dev = pArg->pDevice;

    pArg->fl_addr = 0x000;
    pArg->fl_data = 0x25;
    dev->pWriteNORData(pArg);

    pArg->fl_addr = 0x000;
    pArg->fl_data = 0x03;
    dev->pWriteNORData(pArg);
}

void FAPI_NORCmdPasswordConfirm(PDARGS pArg)
{
    PDEV dev = pArg->pDevice;

    pArg->fl_addr = 0x000;
    pArg->fl_data = 0x29;
    dev->pWriteNORData(pArg);
}

void FAPI_NORCmdPPBEnter(PDARGS pArg)
{
    PDEV dev = pArg->pDevice;

    pArg->fl_addr = 0x555;
    pArg->fl_data = 0xAA;
    dev->pWriteNORData(pArg);

    pArg->fl_addr = 0x2AA;
    pArg->fl_data = 0x55;
    dev->pWriteNORData(pArg);

    pArg->fl_addr = 0x555;
    pArg->fl_data = 0xC0;
    dev->pWriteNORData(pArg);
}

void FAPI_NORCmdPPBLockEnter(PDARGS pArg)
{
    PDEV dev = pArg->pDevice;

    pArg->fl_addr = 0x555;
    pArg->fl_data = 0xAA;
    dev->pWriteNORData(pArg);

    pArg->fl_addr = 0x2AA;
    pArg->fl_data = 0x55;
    dev->pWriteNORData(pArg);

    pArg->fl_addr = 0x555;
    pArg->fl_data = 0x50;
    dev->pWriteNORData(pArg);
}

void FAPI_NORCmdPPBEraseAll(PDARGS pArg)
{
    PDEV dev = pArg->pDevice;

    pArg->fl_addr = 0x000;
    pArg->fl_data = 0x80;
    dev->pWriteNORData(pArg);

    pArg->fl_addr = 0x000;
    pArg->fl_data = 0x30;
    dev->pWriteNORData(pArg);
}

void FAPI_NORCmdDYBEnter(PDARGS pArg)
{
    PDEV dev = pArg->pDevice;

    pArg->fl_addr = 0x555;
    pArg->fl_data = 0xAA;
    dev->pWriteNORData(pArg);

    pArg->fl_addr = 0x2AA;
    pArg->fl_data = 0x55;
    dev->pWriteNORData(pArg);

    pArg->fl_addr = 0x555;
    pArg->fl_data = 0xE0;
    dev->pWriteNORData(pArg);
}

void FAPI_NORCmdStatusClear(PDARGS pArg)
{
    PDEV dev = pArg->pDevice;

    pArg->fl_addr = 0x555;
    pArg->fl_data = 0x71;
    dev->pWriteNORData(pArg);
}

void FAPI_NORCmdSSREnter(PDARGS pArg)
{
    PDEV dev = pArg->pDevice;

    pArg->fl_addr = 0x555;
    pArg->fl_data = 0xAA;
    dev->pWriteNORData(pArg);

    pArg->fl_addr = 0x2AA;
    pArg->fl_data = 0x55;
    dev->pWriteNORData(pArg);

    pArg->fl_addr = 0x555;
    pArg->fl_data = 0x88;
    dev->pWriteNORData(pArg);
}

void FAPI_NORCmdSSRExit(PDARGS pArg)
{
    PDEV dev = pArg->pDevice;

    pArg->fl_addr = 0x555;
    pArg->fl_data = 0xAA;
    dev->pWriteNORData(pArg);

    pArg->fl_addr = 0x2AA;
    pArg->fl_data = 0x55;
    dev->pWriteNORData(pArg);
    
    pArg->fl_addr = 0x555;
    pArg->fl_data = 0x90;
    dev->pWriteNORData(pArg);

    pArg->fl_addr = 0x000;
    pArg->fl_data = 0x00;
    dev->pWriteNORData(pArg);
}
/** FAPIInitArgs ************************************************************/
/*                                                                          */
/*  Initialize FAPI argument block.                                         */
/*  Enter: PDARGS args = argument block to initialize                       */
/*         PDEV dev = pointer to target device object                       */
/*  Exit:  PDARGS = pointer to target device object                         */
/*                                                                          */
/****************************************************************************/

PDARGS FAPIInitArgs(PDARGS pArg, PDEV dev)
{
    if (!pArg) return NULL;
    memset((char*)pArg, 0, sizeof(DARGS));
    pArg->pDevice = dev;
    return pArg;
}

/** FAPI_GetFAPIInfo ********************************************************/
/*                                                                          */
/*  Get configuration information for the target device.                    */
/*  Enter: PDARGS pArg = pointer to argument block                          */
/*         pArg->pDevice = pointer to target device object                  */
/*         pArg->dwType = type of information to return                     */
/*  Exit:  DWORD = operation status                                         */
/*         pArg->dwResult = device information                              */
/*                                                                          */
/****************************************************************************/

DWORD FAPI_GetFAPIInfo(PDARGS pArg)
{
    PDEV dev = pArg->pDevice;
    DWORD info;
    pArg->dwResult = 0;
    if (!dev) return EC_PARAMETER;
    switch (pArg->dwType)
    {
    case INFO_COUNT:            info = MAX_PARAMETER; break;
    case FLASH_TYPE:            info = dev->DevType; break;
    case FLASH_BASE:            info = (DWORD)dev->FlashBase; break;
    case TECHNOLOGY:            info = dev->Technology; break;
    case WRITE_BUFFER_SIZE:     info = dev->BufferWriteSize ? dev->BufferWriteSize : 1; break;
    case MEMORY_WIDTH:          info = dev->DataWidth; break;
    case MEMORY_SIZE:           info = dev->MemSize; break;
    case WORD_COUNT:            info = dev->MemSize / (dev->DataWidth / 8); break;
    case BANK_COUNT:            info = dev->BankCount; break;
    case SECTOR_COUNT:          info = dev->SectorCount; break;
    case REGION_COUNT:          info = dev->RegionCount; break;
    case PROG_WORD_TIMEOUT:     info = dev->ProgWordTimeout; break;
    case PROG_BUFFER_TIMEOUT:   info = dev->ProgBufferTimeout; break;
    case SEC_ERASE_TIMEOUT:     info = dev->SecEraseTimeout; break;
    case CHIP_ERASE_TIMEOUT:    info = dev->ChipEraseTimeout; break;
    case SUSPEND_TIMEOUT:       info = dev->SuspendTimeout; break;
    case LARGEST_SECTOR:        info = dev->LargestSectorSize; break;
    case CFI_DATA:              info = (DWORD)dev->cfiData; break;
    case AUTOSELECT_DATA:       info = (DWORD)dev->ASData; break;
    case REGION_OFFSETS:        info = (DWORD)dev->RegionOffsets; break;
    case REGION_SECTOR_SIZES:   info = (DWORD)dev->RegionSecSize; break;
    case REGION_SECTOR_COUNTS:  info = (DWORD)dev->RegionSecCount; break;
    case BANK_OFFSETS:          info = (DWORD)dev->BankOffsets; break;
    case BANK_SECTOR_COUNTS:    info = (DWORD)dev->BankSecCount; break;
    case PAGE_SIZE:             info = dev->PageSize; break;
/*
    case BLOCK_SIZE:            info = dev->BlockSize; break;
    case SPARE_SIZE:            info = dev->SpareAreaSize; break;
    case PAGES_PER_BLOCK:       info = dev->BlockSize / dev->PageSize; break;
    case BLOCK_COUNT:           info = dev->BlockCount; break;
    case ID_LENGTH:             info = dev->IDLength; break;
    case SYS_CONFIG:            info = (DWORD)dev->SysConfig; break;
    case ROW_ADD_COUNT:         info = dev->RowCount; break;
    case PAGE_SEGMENT_SIZE:     info = dev->PageSegmentSize; break;
    case SPARE_SEGMENT_SIZE:    info = dev->SpareSegmentSize; break;
    case CS_CONTROL:            info = (DWORD)dev->SysConfig; break;
*/
    case MAX_FREQUENCY:         info = dev->SpeedOption; break;
//    case FUNCTION_COUNT:        info = FN_MAX; break;
    case OBJECT_SIZE:           info = sizeof(struct device); break;
    case VOLUME_TYPE:           info = dev->VolType; break;
    case VOLUME_NAME:           info = (DWORD)dev->VolName; break;
    case READ_MODE_TABLE:       info = (DWORD)dev->pRMTable; break;
    case COLUMN_BITS:           info = dev->ColumnBits; break;
    case PRIME_ADDRESS_BIT:     info = dev->PrimeAddressBit; break;
    case SPEC_CFI_DATA:         info = (DWORD)dev->specCfiData; break;
    case ARG_BLOCK_SIZE:        info = sizeof(struct pdev_struct); break;
//    case DEVICE_TYPE_COUNT:     info = MAX_DEVICE; break;
    case BOOT_TYPE:             info = dev->BootType; break;
    case FEATURES:              info = dev->Features; break;
    case DEVICE_NAME:           info = (DWORD)flashName; break;
/*
    case CFG_COUNT:             info = CFG_END; break;
    case LUN_COUNT:             info = dev->LUNCount; break;
    case PLANE_COUNT:           info = dev->PlaneCount; break;
    case BLOCKS_PER_LUN:        info = dev->BlockPerLUN; break;
*/
    default:                    pArg->dwResult = 0; return EC_PARAMETER;
    }
    pArg->dwResult = info;
    return EC_NONE;
}

/** FAPI_GetFAPIGeometry ****************************************************/
/*                                                                          */
/*  Get geometry information for the target device.                         */
/*  Enter: PDARGS pArg = pointer to argument block                          */
/*         pArg->pDevice = pointer to target device object                  */
/*         pArg->dwType = type of geometry information to return            */
/*         pArg->dwSelect = subtype selection                               */
/*  Exit:  DWORD = operation status                                         */
/*         pArg->dwResult = device information                              */
/*                                                                          */
/****************************************************************************/

DWORD FAPI_GetFAPIGeometry(PDARGS pArg)
{
    DWORD bank, region, sectorCount = 0, i, j;
    PDEV dev = pArg->pDevice;
    DWORD geo, opt = pArg->dwSelect;
    pArg->dwResult = 0;
    if (!dev) return EC_PARAMETER;

    switch (pArg->dwType)
    {
    case SECTOR_COUNT_OF_BANK:
        geo = opt > dev->BankCount ? 0 : dev->BankSecCount[opt];
        break;
    case ADDRESS_OF_BANK:
        #ifndef SIMULATION
        geo = opt >= dev->BankCount ? 0 : dev->BankOffsets[opt];
        #else
        geo = 0;
        #endif
        break;
    case ADDRESS_OF_REGION:
        geo = opt >= dev->RegionCount ? 0 : dev->RegionOffsets[opt];
        break;
    case BANK_FROM_SECTOR:
        for (bank = 0; bank < dev->BankCount; bank++)
        {
            sectorCount += dev->BankSecCount[bank];
            if (opt < sectorCount)
                break;
        }
        geo = bank;
        break;
    case REGION_FROM_SECTOR:
        for (region = 0; region < dev->RegionCount; region++)
        {
            sectorCount += dev->RegionSecCount[region];
            if (opt < sectorCount)
                break;
        }
        geo = region;
        break;
    case SECTOR_SIZE_OF_REGION:
        if (opt >= dev->RegionCount) return EC_PARAMETER;
        geo = (DWORD)dev->RegionSecSize[opt];
        break;
    case SECTOR_COUNT_OF_REGION:
        if (opt >= dev->RegionCount) return EC_PARAMETER;
        geo = (DWORD)dev->RegionSecCount[opt];
        break;
    case START_SECTOR_OF_REGION:
        j = opt >= dev->RegionCount ? 0 : dev->RegionOffsets[opt];
        for (i = 0; i < dev->SectorCount; i++)
            if (j < dev->pAddrSize[i].SecAddr + dev->pAddrSize[i].SecSize - 1)
                break;
        geo = i;
        break;
    case ADDRESS_OF_SECTOR:
        if (opt >= dev->SectorCount) return EC_PARAMETER;
        geo = dev->pAddrSize[opt].SecAddr;
        break;
    case SECTOR_FROM_ADDRESS:
        for (i = 0; i <dev->SectorCount ; i++)
            if (opt < dev->pAddrSize[i].SecAddr + dev->pAddrSize[i].SecSize)
                break;
        geo = i;
        break;
    case WORD_COUNT_OF_SECTOR:
        if (opt >= dev->SectorCount) return EC_PARAMETER;
        geo = dev->pAddrSize[opt].SecSize;
        break;
    case BYTE_COUNT_OF_SECTOR:
        if (opt >= dev->SectorCount) return EC_PARAMETER;
        geo = dev->pAddrSize[opt].SecSize * sizeof(WORD);
        break;
    case WORD_COUNT_OF_BANK:
        if (opt >= dev->BankCount) return EC_PARAMETER;
        i = dev->BankOffsets[opt];
        if (opt < dev->BankCount - 1) j = dev->BankOffsets[opt + 1];
        else j = dev->MemSize;
        geo = (j - i) / sizeof(WORD);
        break;
    case BYTE_COUNT_OF_BANK:
        if (opt >= dev->BankCount) return EC_PARAMETER;
        i = dev->BankOffsets[opt];
        if (opt < dev->BankCount - 1) j = dev->BankOffsets[opt + 1];
        else j = dev->MemSize;
        geo = j - i;
        break;
    default: pArg->dwResult = 0;
        return EC_PARAMETER;
    }
    pArg->dwResult = geo;
    return EC_NONE;
}

/** FAPI_NORConfigure *******************************************************/
/*                                                                          */
/*  NOR flash configuration. Sets the base read and write pointers for      */
/*  the selected mode, various timeout values, sector, region, and bank     */
/*  information.                                                            */
/*  Enter: PDARGS pArg = pointer to argument block                          */
/*         pArg->pDevice = pointer to target device object                  */
/*         pArg->pSrc = pointer to CFI data                                 */
/*  Exit:  DWORD = operation status                                         */
/*  Notes: Only called during device enumeration. Will fail otherwise.      */
/*                                                                          */
/****************************************************************************/
#if 1
DWORD FAPI_NORConfigure(PDARGS pArg)
{
    DWORD i, offset, j, k, region, sector, sectorCount, sectorSize = 0;
    DWORD maskCount, minRegSize = 0xFFFFFFFF, regSize, addrMask = 0;
    DWORD regions, bType;
    PDEV dev = pArg->pDevice;
    #ifndef SIMULATION
    WORD *cfi = pArg->pSrc;
    #else
    WORD cfi[MAX_CFI];

    memcpy(&cfi[0] ,&RPC2EMU_INT_BRAM_CFI[0], sizeof(WORD)*MAX_CFI);

    #endif
//    if (MODE_RUN == sysMode) return EC_NOTSUPPORTED;

    /* Verify CFI Query strings before continuing.  */
    // *** note that we are checking for both standard and extended tables
    // this could be split up if we want to handle older or other vendor
    // devices ***
    if ((cfi[0x10] != 'Q') || (cfi[0x11] != 'R') || (cfi[0x12] != 'Y') ||
        (cfi[0x40] != 'P') || (cfi[0x41] != 'R') || (cfi[0x42] != 'I'))
        return EC_CFIINVALID;

    // get boot type
    bType = cfi[CFI_BOOTFLAG];
    if (bType >= BT_LIMIT) return EC_INVALIDBOOTTYPE;
    dev->BootType = bType;
    // Do basic check for 8 bit values in each entry, some CFIs will be
    // out of spec. Also, skip the bank sector counts since they may
    // exceed 0x80 soon.
    // continue processing CFI - if inconsistencies are found report them
    /* Region information.  */
    regions = BootTable[bType].regions;

    if (cfi[CFI_REGIONCOUNT] != regions)
        printf("\nCFI region count does not match boot type. Corrected.");
    dev->RegionCount = regions;
    /* Get support information */
    if (cfi[CFI_ERASESUSPEND])
        dev->Features |= FS_ERASESUSPEND;
    if (cfi[CFI_MULTIBYTEWRITE])
        dev->Features |= FS_BUFFERWRITE;
    if (cfi[CFI_SIMULOP])
        dev->Features |= FS_SIMULOP;
    if (cfi[CFI_BURSTMODE])
        dev->Features |= FS_BURSTMODE;
//  if (cfi[CFI_SECTORPROTECT])
//      dev->Features |= FS_SECTORPROTECT;
    if (0x08 & cfi[CFI_ADVSECPROTECT])
        dev->Features |= FS_SECTORPROTECT;
    if (0x01 & cfi[CFI_ADVSECPROTECT])
        dev->Features |= FS_SECTORLOCK | FS_SECTORLOCKRANGE;
    if (cfi[CFI_PROGSUSPEND])
        dev->Features |= FS_PROGSUSPEND;
    if (cfi[CFI_SECSISIZE])
        dev->Features |= FS_SECURESILICON;
    if (cfi[CFI_UNLOCKBYPASS])
        dev->Features |= FS_UNLOCKBYPASS;

    /* Get page size */
    if (cfi[CFI_PAGEMODE])
    {
        if (cfi[CFI_PAGEMODE] == 1)
            dev->PageSize = 4;
        else if (cfi[CFI_PAGEMODE] == 2)
            dev->PageSize = 8;
        else if (cfi[CFI_PAGEMODE] == 3)
            dev->PageSize = 16;
        else if (cfi[CFI_PAGEMODE] == 4)
            dev->PageSize = 512;
        dev->Features |= FS_PAGEMODE;
    }

    /* Memory size in bytes.    */
    dev->MemSize = (1 << cfi[CFI_DEVSIZE]);

    /* Determine write buffer size in words.    */
    dev->BufferWriteSize = (1 << cfi[CFI_MULTIBYTEWRITE]);
    dev->BufferWriteSize /= sizeof(WORD);   // 16-bit device ONLY

    /* Device bank information. */
    dev->BankCount = cfi[CFI_BANKCOUNT];
    if ((dev->BankCount == 0xFFFF) || (dev->BankCount == 0xFF))
        dev->BankCount = 0;

    if (dev->BankCount > MAX_BANKS)
    {
        dev->BankCount = MAX_BANKS;
        printf("\nBank count exceeded. Corrected.");
    }

    // Note that some CFIs (incorrectly) place the full sector count
    // in 0x2D even if it is more than 8 bits (such as 0x1FF) so we do
    // not mask for 8 bit values.
    for (i = 0; i < dev->RegionCount; i++)
    {
        dev->RegionSecCount[i] = ((cfi[0x2E + (i * 4)] << 8) + (cfi[0x2D + (i * 4)])) + 1;
        dev->RegionSecSize[i] = ((cfi[0x30 + (i * 4)] << 16) + (cfi[0x2F + (i * 4)] << 8));
        if (0 == dev->RegionSecSize[i])
            printf("\nCFI region size error, enumeration will fail.");
    }

    // Note - will skip if bank count is zero
    for (i = 0; i < dev->BankCount; i++)
        dev->BankSecCount[i] = cfi[0x58 + i];

    /* Calculate region boundaries. */
    offset = 0;
    dev->SectorCount = 0;
    for (i = 0; i < dev->RegionCount; i++)
    {
        dev->RegionOffsets[i] = offset;
        offset += dev->RegionSecCount[i] * dev->RegionSecSize[i];
        dev->SectorCount += dev->RegionSecCount[i];
    }

    /* Single-bank devices report no banks, so fake one big bank.   */
    if (dev->BankCount == 0)
    {
        dev->BankCount = 1;
        dev->BankSecCount[0] = dev->SectorCount;
    }

    /* create sector address and size table */
    if (!(dev->pAddrSize = (PASBK)malloc(sizeof(ASBK) * dev->SectorCount)))
        return printf("\nSector count failure."), EC_MALLOC;

    // create bad sector table
    if (!(dev->BadSectorArray = (BYTE*)malloc(sizeof(BYTE) * dev->SectorCount)))
        return printf("\nBad sector array failure."), EC_MALLOC;

    memset((char*)dev->BadSectorArray, 0, sizeof(BYTE) * dev->SectorCount);

    k = 0;
    offset = 0;
    for (i = 0; i < dev->RegionCount; i++)
    {
        for (j = 0; j < dev->RegionSecCount[i]; j++, k++)
        {
            dev->pAddrSize[k].SecAddr = offset;
            dev->pAddrSize[k].SecSize = dev->RegionSecSize[i] / sizeof(WORD);
            offset += dev->RegionSecSize[i] / sizeof(WORD);
            printf("dev->pAddrSize[%d].SecAddr = 0x%08X, dev->pAddrSize[%d].SecSize = 0x%08X\n",k,dev->pAddrSize[k].SecAddr,k,dev->pAddrSize[k].SecSize);
        }
    }

    /* Use the region information and the bank information  */
    /* to determine the bank boundaries.                    */
    region = 0;
    offset = 0;
    sector = 0;
    sectorCount = dev->RegionSecCount[0];

    for (i = 0; i < dev->BankCount; i++)
    {
        dev->BankOffsets[i] = offset;

        /* Cycle through each region, adding the sector lengths,    */
        /* until we reach the number of sectors in each bank, using */
        /* the value to determine the bank boundary address.        */
        for (j = 0; j < dev->BankSecCount[i]; j++)
        {
            offset += dev->RegionSecSize[region];
            sector++;

            /* Switch to next region?   */
            if (sector >= sectorCount)
            {
                region++;
                sectorCount += dev->RegionSecCount[region];
            }
        }
    }

    // determine largest sector size and minimum region size
    for (i = 0; i < dev->RegionCount; i++)
    {
        if (dev->RegionSecSize[i] > sectorSize)
            sectorSize = dev->RegionSecSize[i];
        regSize = dev->RegionSecCount[i] * dev->RegionSecSize[i];
        if (regSize < minRegSize)
            minRegSize = regSize;
    }
    dev->LargestSectorSize = sectorSize / sizeof(WORD);
    dev->MinRegionSize = minRegSize;

    // create sector address masks
    maskCount = dev->MemSize / minRegSize;
    //printf("maskCount = %08X, dev->memSize = %08X, minRegSize = %08X\n",maskCount, dev->MemSize, minRegSize);
    if (!(dev->BankSecMask = (DWORD*)malloc(sizeof(DWORD) * maskCount)))
        return printf("\nMask count failure."), EC_MALLOC;
    dev->MaskCount = maskCount;
    for (i = j = offset = 0; i < maskCount; i++)
    {
        if (offset == dev->RegionOffsets[j])
            addrMask =  ~(dev->RegionSecSize[j++] / 2 - 1);
        dev->BankSecMask[i] = addrMask;
        offset += minRegSize;
    }
    dev->AddressMask = dev->MemSize / 2 - 1;
    for (i = 0, j = minRegSize / 4; j; i++, j >>= 1) ;
    dev->AddressShift = i;

    // get timeout data (convert to microseconds where needed)
    if (0 == cfi[0x1F] || 0 == cfi[0x23])
        dev->ProgWordTimeout = 0;
    else
    {
        dev->ProgWordTimeout = (1 << cfi[0x1F]) * (1 << cfi[0x23]);
        dev->Features |= FS_SINGLEWRITE;
    }

    // enforce timeout of zero for devices with no buffer write support
    if (0 == cfi[0x20] || 0 == cfi[0x24])
        dev->ProgBufferTimeout = 0;
    else
        dev->ProgBufferTimeout = (1 << cfi[0x20]) * (1 << cfi[0x24]);

    dev->SecEraseTimeout = (1 << cfi[0x21]) * (1 << cfi[0x25]) * 1000;

    // handle missing chip erase timeout (let device override set features)
    if (0 == cfi[0x22] || 0 == cfi[0x26])
        dev->ChipEraseTimeout = dev->SecEraseTimeout * dev->SectorCount;
    else
    {
        dev->ChipEraseTimeout = (1 << cfi[0x22]) * (1 << cfi[0x26]) * 1000;
        dev->Features |= FS_ERASECHIP;
    }

    if (cfi[CFI_ERASESUSPTO])
        dev->SuspendTimeout = 1 << cfi[CFI_ERASESUSPTO];
#ifdef SIMULATION
	#ifdef DEF_2_SECTORS
	dev->SectorCount = 2;
    dev->RegionSecCount[0] = 2;
    dev->BankSecCount[0] = 2;
    printf("Re-define sector count to 2 for simulation!\n");
	#endif
    #ifdef DEF_SECTORSIZE
    k = 0;
    for (i = 0; i < dev->RegionCount; i++)
    {
        for (j = 0; j < dev->RegionSecCount[i]; j++, k++)
        {
			dev->pAddrSize[k].SecSize = DEF_SECTORSIZE;
			
        }
    }
    dev->LargestSectorSize = DEF_SECTORSIZE;
    printf("Re-define sector size to %d Bytes for simulation!\n",DEF_SECTORSIZE);
#endif  
#endif
    return EC_NONE;
}
#else
DWORD FAPI_NORConfigure(PDARGS pArg)
{
//    DWORD i, offset, j, k, region, sector, sectorCount, sectorSize = 0;
    DWORD i, offset, j, k/*, sectorCount, sectorSize = 0*/;
//    DWORD maskCount, minRegSize = 0xFFFFFFFF, regSize, addrMask = 0;
//    DWORD regions, bType;
    PDEV dev = pArg->pDevice;
//    WORD *cfi = pArg->pSrc;
	DWORD page_num;
	DWORD page_size = 256; 		//Page size 256(words)
    /*
//    if (MODE_RUN == sysMode) return EC_NOTSUPPORTED;

    // Verify CFI Query strings before continuing.  
    // *** note that we are checking for both standard and extended tables
    // this could be split up if we want to handle older or other vendor
    // devices ***
    if ((cfi[0x10] != 'Q') || (cfi[0x11] != 'R') || (cfi[0x12] != 'Y') ||
        (cfi[0x40] != 'P') || (cfi[0x41] != 'R') || (cfi[0x42] != 'I'))
        return EC_CFIINVALID;

    // get boot type
    bType = cfi[CFI_BOOTFLAG];
    if (bType >= BT_LIMIT) return EC_INVALIDBOOTTYPE;
    dev->BootType = bType;

    // Do basic check for 8 bit values in each entry, some CFIs will be
    // out of spec. Also, skip the bank sector counts since they may
    // exceed 0x80 soon.
    // continue processing CFI - if inconsistencies are found report them
    // Region information.  
    regions = BootTable[bType].regions;
    if (cfi[CFI_REGIONCOUNT] != regions)
        printf("\nCFI region count does not match boot type. Corrected.");
    dev->RegionCount = regions;
    // Get support information 
    if (cfi[CFI_ERASESUSPEND])
        dev->Features |= FS_ERASESUSPEND;
    if (cfi[CFI_MULTIBYTEWRITE])
        dev->Features |= FS_BUFFERWRITE;
    if (cfi[CFI_SIMULOP])
        dev->Features |= FS_SIMULOP;
    if (cfi[CFI_BURSTMODE])
        dev->Features |= FS_BURSTMODE;
//  if (cfi[CFI_SECTORPROTECT])
//      dev->Features |= FS_SECTORPROTECT;
    if (0x08 & cfi[CFI_ADVSECPROTECT])
        dev->Features |= FS_SECTORPROTECT;
    if (0x01 & cfi[CFI_ADVSECPROTECT])
        dev->Features |= FS_SECTORLOCK | FS_SECTORLOCKRANGE;
    if (cfi[CFI_PROGSUSPEND])
        dev->Features |= FS_PROGSUSPEND;
    if (cfi[CFI_SECSISIZE])
        dev->Features |= FS_SECURESILICON;
    if (cfi[CFI_UNLOCKBYPASS])
        dev->Features |= FS_UNLOCKBYPASS;

    // Get page size 
    if (cfi[CFI_PAGEMODE])
    {
        if (cfi[CFI_PAGEMODE] == 1)
            dev->PageSize = 4;
        else if (cfi[CFI_PAGEMODE] == 2)
            dev->PageSize = 8;
        else if (cfi[CFI_PAGEMODE] == 3)
            dev->PageSize = 16;
        else if (cfi[CFI_PAGEMODE] == 4)
            dev->PageSize = 512;
        dev->Features |= FS_PAGEMODE;
    }

    // Memory size in bytes.    
    dev->MemSize = (1 << cfi[CFI_DEVSIZE]);

    // Determine write buffer size in bytes.    
    dev->BufferWriteSize = (1 << cfi[CFI_MULTIBYTEWRITE]);

    // Device bank information. 
    dev->BankCount = dev->MemSize/0x1000000;
    for (i = 0; i < dev->BankCount; i++)
        dev->BankOffsets[i] = 0x1000000*i;

    // Note that some CFIs (incorrectly) place the full sector count
    // in 0x2D even if it is more than 8 bits (such as 0x1FF) so we do
    // not mask for 8 bit values.
    for (i = 0; i < dev->RegionCount; i++)
    {
        dev->RegionSecCount[i] = ((cfi[0x2E + (i * 4)] << 8) + (cfi[0x2D + (i * 4)])) + 1;
        dev->RegionSecSize[i] = ((cfi[0x30 + (i * 4)] << 16) + (cfi[0x2F + (i * 4)] << 8));
        if (0 == dev->RegionSecSize[i])
            printf("\nCFI region size error, enumeration will fail.");
    }

    // Calculate region boundaries. 
    offset = 0;
    dev->SectorCount = 0;
    for (i = 0; i < dev->RegionCount; i++)
    {
        dev->RegionOffsets[i] = offset;
        offset += dev->RegionSecCount[i] * dev->RegionSecSize[i];
        dev->SectorCount += dev->RegionSecCount[i];
    }

    // create sector address and size table 
    if (!(dev->pAddrSize = (PASBK)malloc(sizeof(ASBK) * dev->SectorCount)))
        return printf("\nSector count failure."), EC_MALLOC;

    // create bad sector table
    if (!(dev->BadSectorArray = (BYTE*)malloc(sizeof(BYTE) * dev->SectorCount)))
        return printf("\nBad sector array failure."), EC_MALLOC;
    memset((char*)dev->BadSectorArray, 0, sizeof(BYTE) * dev->SectorCount);

    k = 0;
    offset = 0;
    for (i = 0; i < dev->RegionCount; i++)
    {
        for (j = 0; j < dev->RegionSecCount[i]; j++, k++)
        {
            dev->pAddrSize[k].SecAddr = offset;
            dev->pAddrSize[k].SecSize = dev->RegionSecSize[i] ;
            offset += dev->RegionSecSize[i];
        }
    }

    // determine the sector count of each bank
    k = 0;
    for (i = 0; i < dev->BankCount; i++)
    {
        offset = 0;
        sectorCount = 0;
        do
        {
            offset += dev->pAddrSize[k++].SecSize;
            sectorCount++;
        }while (offset != 0x1000000);
        dev->BankSecCount[i] = sectorCount;
    }

    // determine largest sector size and minimum region size
    for (i = 0; i < dev->RegionCount; i++)
    {
        if (dev->RegionSecSize[i] > sectorSize)
            sectorSize = dev->RegionSecSize[i];
        regSize = dev->RegionSecCount[i] * dev->RegionSecSize[i];
        if (regSize < minRegSize)
            minRegSize = regSize;
    }
    dev->LargestSectorSize = sectorSize;
    dev->MinRegionSize = minRegSize;

    // create sector address masks
    maskCount = dev->MemSize / minRegSize;
    if (!(dev->BankSecMask = (DWORD*)malloc(sizeof(DWORD) * maskCount)))
        return printf("\nMask count failure."), EC_MALLOC;
    dev->MaskCount = maskCount;
    for (i = j = offset = 0; i < maskCount; i++)
    {
        if (offset == dev->RegionOffsets[j])
            addrMask =  ~(dev->RegionSecSize[j++] / 2 - 1);
        dev->BankSecMask[i] = addrMask;
        offset += minRegSize;
    }
    dev->AddressMask = dev->MemSize / 2 - 1;
    for (i = 0, j = minRegSize / 4; j; i++, j >>= 1) ;
    dev->AddressShift = i;

    // get timeout data (convert to microseconds where needed)
    if (0 == cfi[0x1F] || 0 == cfi[0x23])
        dev->ProgWordTimeout = 0;
    else
    {
        dev->ProgWordTimeout = (1 << cfi[0x1F]) * (1 << cfi[0x23]);
        dev->Features |= FS_SINGLEWRITE;
    }

    // enforce timeout of zero for devices with no buffer write support
    if (0 == cfi[0x20] || 0 == cfi[0x24])
        dev->ProgBufferTimeout = 0;
    else
        dev->ProgBufferTimeout = (1 << cfi[0x20]) * (1 << cfi[0x24]);

    dev->SecEraseTimeout = (1 << cfi[0x21]) * (1 << cfi[0x25]) * 1000;

    // handle missing chip erase timeout (let device override set features)
    if (0 == cfi[0x22] || 0 == cfi[0x26])
        dev->ChipEraseTimeout = dev->SecEraseTimeout * dev->SectorCount;
    else
    {
        dev->ChipEraseTimeout = (1 << cfi[0x22]) * (1 << cfi[0x26]) * 1000;
        dev->Features |= FS_ERASECHIP;
    }

    if (cfi[CFI_ERASESUSPTO])
        dev->SuspendTimeout = 1 << cfi[CFI_ERASESUSPTO];
    */

//#ifdef SEC_256
	page_num = 512; 
//#else
//	page_num = 1024;	//Default page num 1024
//#endif

//printf("page_num = %d\n",page_num);
	
#ifndef SIMULATION
	dev->SectorCount = 4;
	dev->LargestSectorSize = page_size * page_num;
	dev->PageSize = page_size;
	dev->BufferWriteSize = page_size;

	dev->BankCount = 1;
	dev->RegionCount = 1;
	dev->RegionSecCount = (DWORD *)malloc(sizeof(DWORD)*dev->RegionCount);
	dev->BankSecCount = (DWORD *)malloc(sizeof(DWORD)*dev->BankCount);
	dev->RegionSecSize = (DWORD *)malloc(sizeof(DWORD)*1);
	dev->RegionSecCount[0] = 4;
	dev->RegionSecSize[0] = page_size * page_num;
	dev->BankSecCount[0] = dev->SectorCount;
#else
	#ifdef DEF_2_SECTORS
	dev->SectorCount = 2;
	#else
	dev->SectorCount = 256;
	#endif
	dev->LargestSectorSize = page_size * page_num;
	dev->PageSize = page_size;
	dev->BufferWriteSize = page_size;

	dev->BankCount = 1;
	dev->RegionCount = 1;
	dev->RegionSecCount = (DWORD *)malloc(sizeof(DWORD)*dev->RegionCount);
	dev->BankSecCount = (DWORD *)malloc(sizeof(DWORD)*dev->BankCount);
	dev->RegionSecSize = (DWORD *)malloc(sizeof(DWORD)*1);
	#ifdef DEF_2_SECTORS
	dev->RegionSecCount[0] = 2;
	#else
	dev->RegionSecCount[0] = 256;
	#endif
	dev->RegionSecSize[0] = page_size * page_num;
	dev->BankSecCount[0] = dev->SectorCount;
#endif
	// create sector address and size table 
    if (!(dev->pAddrSize = (PASBK)malloc(sizeof(ASBK) * dev->SectorCount)))
        return printf("\nSector count failure."), EC_MALLOC;
	 k = 0;
    offset = 0;
    for (i = 0; i < dev->RegionCount; i++)
    {
        for (j = 0; j < dev->RegionSecCount[i]; j++, k++)
        {
            dev->pAddrSize[k].SecAddr = offset;
			//#ifdef SIMULATION
            //dev->pAddrSize[k].SecSize = 8192;
			//dev->LargestSectorSize = 4096;
			//#else
			dev->pAddrSize[k].SecSize = dev->RegionSecSize[i];
			//#endif
			offset += dev->RegionSecSize[i];
			printf("dev->pAddrSize[%d].SecAddr = 0x%08X, dev->pAddrSize[%d].SecSize = 0x%08X\n",k,dev->pAddrSize[k].SecAddr,k,dev->pAddrSize[k].SecSize);
        }
    }
#ifdef DEF_SECTORSIZE
    k = 0;
    for (i = 0; i < dev->RegionCount; i++)
    {
        for (j = 0; j < dev->RegionSecCount[i]; j++, k++)
        {
			dev->pAddrSize[k].SecSize = DEF_SECTORSIZE;
			
        }
    }
    dev->LargestSectorSize = DEF_SECTORSIZE;
    printf("Re-define sector size to %d Bytes for simulation!\n",DEF_SECTORSIZE);
#endif    
	//Fill the support feature
    dev->Features |= FS_BUFFERWRITE;	//Support buffer write
	dev->Features |= FS_BURSTMODE;		//Support burst mode

	//Fill timeout parameters
	dev->ProgWordTimeout = 5000 * 1000;
	dev->ProgBufferTimeout = 5000 * 1000;
	dev->SecEraseTimeout = 5000 * 1000;
	
    return EC_NONE;
}
#endif
/** FAPI_ProgNORBuffer ******************************************************/
/*                                                                          */
/*  Program a quantity of WORDs to the target device from a buffer.         */
/*  Normally uses single WORD programming. Can use buffered write           */
/*  for faster transfer.                                                    */
/*  Enter: PDARGS pArg = pointer to argument block                          */
/*         pArg->pDevice = pointer to target device object                  */
/*         pArg->pSrc = pointer to source buffer                            */
/*         pArg->dwCount = number of WORDS to write                         */
/*         pArg->st_addr = starting WORD address on device                  */
/*         pArg->dwOptNOR = option settings:                                */
/*               | NOR_WRITE_BUFFER = use buffered write if available       */
/*               | NOR_PBUFF_ERROR_GO = continue writing past errors        */
/*               | NOR_WRITE_FAST = use fast write for buffered write       */
/*  Exit:  DWORD = operation status                                         */
/*                                                                          */
/****************************************************************************/

DWORD FAPI_ProgNORBuffer(PDARGS pArg)
{
    DWORD status = EC_NONE;
    DWORD i, count = pArg->dwCount, size, bufs, rem;
    DWORD addr = pArg->st_addr;
    PDEV dev = pArg->pDevice;
    WORD *data = pArg->pSrc;

    // handle buffer write
    size = dev->BufferWriteSize;
    if (NOR_WRITE_BUFFER & pArg->dwOptNOR && size)
    {
        pArg->dwCount = size;
        pArg->dwOptNOR |= NOR_BW_WAIT;
        bufs = count / size, rem = count % size;
        for (i = 0; i < bufs; i++)
        {
            status = dev->pBufferWrite(pArg);
            // check for exit on error
            if (EC_NONE != status && !(NOR_PBUFF_ERROR_GO & pArg->dwOptNOR))
                return status;
            addr += size;
            data += size;
            pArg->st_addr = addr;
            pArg->pSrc = data;
        }
        if (rem)
        {
            pArg->dwCount = rem;
            return dev->pBufferWrite(pArg);
        }
    }
    // handle single word program
    else
    {
        for (i = 0; i < count; i++)
        {
            pArg->st_addr = addr++;
            pArg->dwValue = data[i];
            status = dev->pSingleProg(pArg);
            if (EC_NONE != status) return status;
        }
    }
    return EC_NONE;
}

/** FAPINotSupported ********************************************************/
/*                                                                          */
/*  Generic "not supported" function.                                       */
/*  Enter: PDARGS pArg = pointer to argument block                          */
/*  Exit:  DWORD = EC_NOTSUPPORTED                                          */
/*  Notes: Point to this function if an operation is not supported.         */
/*                                                                          */
/****************************************************************************/

DWORD FAPINotSupported(PDARGS pArg)
{
    return EC_NOTSUPPORTED;
}

PDEV FAPIGetDevice(DWORD index){return pDevice;}

DWORD FAPIGetDeviceCount(void) {return 1;}


DWORD FAPI_ReadNORStatus(PDARGS pArg)
{
    return EC_NONE;
}

DWORD FAPI_GetNORStatus(PDARGS pArg)
{
    DWORD ret = EC_NONE;
    unsigned short val = 0;
    DWORD polling_nr = 0;

	
    while(val==0) {
	if(RPC_Read_Reg(RPC_RD_SR, &val)) 
		{
			pArg->dwStatus = (DWORD)val;
			//printf("ok, status value = %04X", pArg->dwStatus);
			//printf("ok, status value = %04X\n", val);
        	ret = EC_NONE;
		}
	else 
		{
        	//printf("error, status value = %04X\n",val);
			ret = EC_DEVICEERROR;
    	}
    polling_nr++;
    if(polling_nr > 1000000) 
        {
            ret= EC_DEVICEERROR;
            break;
        }
    }
    pArg->dwStatus = 0;
    if((val&0x0080)==0x0080)
    pArg->dwStatus = NOR_DS_READ_ARRAY;
    if((val&0x0040)==0x0040)
    pArg->dwStatus |= NOR_DS_ERASE_SUSPENDED;
    if((val&0x0020)==0x0020)
    pArg->dwStatus |= NOR_DS_ERASE_FAIL;
    if((val&0x0010)==0x0010)
    pArg->dwStatus |= NOR_DS_PGM_FAIL;
    if((val&0x0004)==0x0004)
    pArg->dwStatus |= NOR_DS_PGM_SUSPENDED;
    if((val&0x0002)==0x0002)
    pArg->dwStatus |= NOR_DS_SEC_LOCK_ERROR;
    
 	return ret;
}

DWORD FAPI_ClearNORStatus(PDARGS pArg)
{
//    DWORD cpuStat = SYS_EnterCritical();
    pArg->st_addr = pArg->fl_addr;
    FAPI_NORCmdStatusClear(pArg);
//    SYS_ExitCritical(cpuStat);
    return EC_NONE;
}

char FlashDevice[0x16]="RPC";

//  FL_CheckTBParm
DWORD FL_CheckTBParm(PDARGS pArg)
{
    int status = EC_NONE;

    return status;
}

// FL_Configure
// Chekc TBParm bit in config register
DWORD FAPI_Configure(PDARGS pArg)
{
    DWORD status = EC_NONE;
    SYS_WaitUSec(10000);
    status = FAPI_NORConfigure(pArg);
    if (status) return status;
    SYS_WaitUSec(10000);

    status = FL_CheckTBParm(pArg); // check TBParm

    return status;
}

DWORD FAPI_GetStatusReg(PDARGS pArg);
//  FL_EraseSector
DWORD FAPI_EraseSector(PDARGS pArg)
{
    int nRc = QSPI_OK;
    DWORD status = EC_NONE;
    PDEV dev = pArg->pDevice;
    unsigned int addr;
    WORD stat = 0;
    unsigned int polling_nr = 0;
/*
    if (dev->SectorCount <= pArg->fl_sect) return EC_PARAMETER;
    if (NOR_ERASE_VER & pArg->dwOptNOR)
        if (!pArg->pDest) return EC_PARAMETER;
*/
    addr = (unsigned int)dev->pAddrSize[pArg->fl_sect].SecAddr;
    //size = (unsigned int)dev->pAddrSize[pArg->fl_sect].SecSize;
    //addr = pArg->fl_sect;
    //cpuStat = SYS_EnterCritical();
    
	if(RPC_Erase(addr)==FALSE) { status = EC_DEVICEERROR;}
    if((pArg->dwOptNOR & NOR_ERASE_WAIT)==NOR_ERASE_WAIT)
        {
            while(stat==0x0000) 
                {
                    status = FAPI_GetStatusReg(pArg);
                    stat = pArg->dwStatus;
                    polling_nr++;
                    if(polling_nr>100000) return EC_ERASETIMEOUT;
                    #ifdef SIMULATION
                    waitUs(100);    //wait 100us in SV simulator
                    #endif
                }
            //printf("     SR = %08X\n",stat);
            if(stat!=0x0080) return EC_ERASEFAILURE;
        }
    if (nRc != QSPI_OK)
    {
        //SYS_ExitCritical(cpuStat);
        return EC_DEVICEERROR;
    }


    return status;
}

void FAPI_EraseSuspend(PDARGS pArg)
{
    PDEV dev = pArg->pDevice;

    pArg->fl_addr = 0x000;
    pArg->fl_data = 0xB0;
    dev->pWriteNORData(pArg);
}

void FAPI_EraseResume(PDARGS pArg)
{
    PDEV dev = pArg->pDevice;
    DWORD sa;

    sa = (DWORD)(pArg->st_addr &
        dev->BankSecMask[(pArg->st_addr & dev->AddressMask) >> dev->AddressShift]);

    pArg->fl_addr = sa + 0x000;
    pArg->fl_data = 0x30;
    dev->pWriteNORData(pArg);
}

// RPC_BlankCheck
DWORD RPC_BlankCheck(PDARGS pArg)
{
    PDEV dev = pArg->pDevice;
	unsigned int sector;
    int nRc = QSPI_OK;
	
	sector = (unsigned int)dev->pAddrSize[pArg->fl_sect].SecAddr;
	if(!RPC_Blank_Check(sector)) nRc = QSPI_ERR_INIT;
    if (nRc != QSPI_OK)
        return EC_DEVICEERROR;
    else
        return EC_NONE;
}

//  RPC_WriteData
DWORD RPC_WriteData(PDARGS pArg)
{
    DWORD status = EC_NONE;
//    DWORD total_count = pArg->dwCount; // total read data byte count
    DWORD addr = pArg->fl_addr; // address
//    PDEV dev = pArg->pDevice; //device pointer
    WORD dat = (WORD)pArg->fl_data;
    //WORD *buf = pArg->pSrc; // write data

	printf("addr=%08X, data=%08X\n",addr,dat);
	if(RPC_Buffer_Write_Store(addr, 1, &dat)==FALSE) { status = EC_BWABORT;}
    //else printf("RPC send OK.\n");
    	
    return status;
}

//  RPC_SingleProg
DWORD RPC_SingleProg(PDARGS pArg)
{
    DWORD status = EC_NONE, dstat;
//    DWORD total_count = pArg->dwCount; // total read data byte count
    DWORD addr = pArg->st_addr; // address
    PDEV dev = pArg->pDevice; //device pointer
    WORD dat = (WORD)pArg->dwValue;
    //WORD *buf = pArg->pSrc; // write data

	if(RPC_Prog_Data(addr, 1, &dat)==FALSE) { status = EC_BWABORT;}
    status = dev->pGetNORStatus(pArg);
    dstat = pArg->dwStatus;

    if ((NOR_DS_TIMEOUT | NOR_DS_PGM_FAIL) & dstat)
        return EC_PROGFAILURE;
    //else printf("RPC Single Prog OK.\n");
    	
    return status;
}

//  RPC_BufferWriteLoad
DWORD RPC_BufferWriteLoad(PDARGS pArg)
{
    DWORD status = EC_NONE;
    DWORD total_count = pArg->dwCount; // total read data byte count
    DWORD addr = pArg->st_addr; // address
//    PDEV dev = pArg->pDevice; //device pointer
    //WORD *buf = pArg->pSrc; // write data

	if(RPC_Buffer_Write_Load(addr, total_count)==FALSE) { status = EC_BWABORT;}
    else printf("RPC Buffer write load OK.\n");
    	
    return status;
}

//  RPC_BufferWriteStore
DWORD RPC_BufferWriteStore(PDARGS pArg)
{
    DWORD status = EC_NONE;
    DWORD total_count = pArg->dwCount; // total read data byte count
    DWORD addr = pArg->st_addr; // address
//    PDEV dev = pArg->pDevice; //device pointer
    WORD *buf = pArg->pSrc; // write data

	if(RPC_Buffer_Write_Store(addr, total_count, buf)==FALSE) { status = EC_BWABORT;}
    else printf("RPC Buffer write store OK.\n");
    	
    return status;
}

//  RPC_BufferWriteCommit
DWORD RPC_BufferWriteCommit(PDARGS pArg)
{
    DWORD status = EC_NONE;
//    DWORD total_count = pArg->dwCount; // total read data byte count
    DWORD addr = pArg->st_addr; // address
//    PDEV dev = pArg->pDevice; //device pointer
    //WORD *buf = pArg->pSrc; // write data

	if(RPC_Buffer_Write_Commit(addr)==FALSE) { status = EC_BWABORT;}
    else printf("RPC Buffer write commit OK.\n");
    	
    return status;
}

//  FL_BufferWrite
DWORD FAPI_BufferWrite(PDARGS pArg)
{
    int nRc = QSPI_OK;
    DWORD /*cpuStat,*/ i, status/*, dstat*/;
    DWORD startAddr = pArg->st_addr;    // write address
    DWORD bufLen = pArg->dwCount;       // write count
    WORD *pDataArray = pArg->pSrc;      // write source data
    DWORD opt = pArg->dwOptNOR;         // write mode: normal or quad
    PDEV dev = pArg->pDevice;
    WORD pDataVer[1024];                 // data arrar for Blank Check and Data Check
    WORD wait = NOR_BW_WAIT & opt;      // wait: 1--read verify, 0--no read verify

    WORD stat = 0;
    unsigned int polling_nr = 0;
    // check for valid write count
    if (bufLen > dev->BufferWriteSize) return EC_PARAMETER;

    // *** could catch this with log "scan args" feature ***
    if (pDataArray == NULL)
        return EC_PARAMETER;
	#ifndef SIMULATION
    cpuStat = SYS_EnterCritical();
	#endif
    // Handle blank verify
    // given bytes count
    
    if (NOR_PGM_BLANK_CHECK & opt)
    {
    	printf("NOR_PGM_BLANK_CHECK starting...\n");
        pArg->pDest = pDataVer;
        dev->pReadNORBuffer(pArg);
		printf("NOR_PGM_BLANK_CHECK complete.\n");
		printf("dwCount = %d\n",pArg->dwCount);
        for (i = 0; i < pArg->dwCount; i++)
        {
            if (0xFFFF != pDataVer[i]){
				printf("error  ");
				#ifndef SIMULATION
                return SYS_ExitCritical(cpuStat), EC_READDATANOTBLANK;
				#else
				printf("     -------- EC_READDATANOTBLANK --------- \n");
				printf("     -------- %d, read %04X expect FFFF --- \n",i,pDataVer[i]);
				return EC_READDATANOTBLANK;
				#endif
            	}
			//printf("pDataVer[%d] = %04X\n",pDataVer[i]);
        }
    }
	printf("   start addr = %08X, len = %d\n",startAddr,bufLen);
	if(RPC_Prog_Data(startAddr, bufLen, pDataArray)==FALSE) { status = EC_BWABORT;}
//#define BMOD_BURSTWRITE_DEBUG
#ifdef BMOD_BURSTWRITE_DEBUG
	if(wait)
    {
        stat = 0;
        while(stat!=0x0080) 
            {
                status = FAPI_GetStatusReg(pArg);
                stat = pArg->dwStatus;
                printf("    SR = %08X\n",stat);
                polling_nr++;
                if(polling_nr>100) return EC_PROGTIMEOUT;

            }
        //printf("    SR = %08X\n",stat);
        if(stat!=0x0080)    return EC_PROGFAILURE;
    }
#else
    if(wait)
    {
        stat = 0;
        while(stat==0x0000) 
            {
                status = FAPI_GetStatusReg(pArg);
                stat = pArg->dwStatus;
                polling_nr++;
                if(polling_nr>100000) return EC_PROGTIMEOUT;

            }
        //printf("    SR = %08X\n",stat);
        if(stat!=0x0080)    return EC_PROGFAILURE;
    }
#endif
    
    if (nRc != QSPI_OK)
		{
				#ifndef SIMULATION
                return SYS_ExitCritical(cpuStat), EC_DEVICEERROR;
				#else
				return EC_DEVICEERROR;
				#endif
            	}


	#ifndef SIMULATION
    SYS_ExitCritical(cpuStat);
	#endif
    return EC_NONE;
}

void FAPI_ProgSuspend(PDARGS pArg)
{
    PDEV dev = pArg->pDevice;

    pArg->fl_addr = 0x000;
    pArg->fl_data = 0x51;
    dev->pWriteNORData(pArg);
}

void FAPI_ProgResume(PDARGS pArg)
{
    PDEV dev = pArg->pDevice;
    DWORD sa;

    sa = (DWORD)(pArg->st_addr &
        dev->BankSecMask[(pArg->st_addr & dev->AddressMask) >> dev->AddressShift]);

    pArg->fl_addr = sa;
    pArg->fl_data = 0x50;
    dev->pWriteNORData(pArg);
}

// FL_ClearStatus
DWORD FAPI_ClearStatus(PDARGS pArg)
{
//    PDEV dev = pArg->pDevice;
    int nRc = QSPI_OK;

	if(!RPC_Clear_SR()) nRc = QSPI_ERR_INIT;
    if (nRc != QSPI_OK)
        return EC_DEVICEERROR;
    else
        return EC_NONE;
}

//  FL_ReadData
DWORD FAPI_ReadData(PDARGS pArg)
{
    DWORD status = EC_NONE;
    //DWORD total_count = pArg->dwCount; // total read data byte count
    DWORD addr = pArg->fl_addr; // address
//    PDEV dev = pArg->pDevice; //device pointer
    //WORD buf = pArg->fl_data; // read data
	WORD buf;
	if(RPC_Read_Data(addr, 1, &buf)==FALSE) { status = EC_READDATA;}
    else {
		pArg->fl_data = buf;
		printf("RPC_Read_data OK.\n");
		}
    	
    return status;
}

//  FL_ReadArray
DWORD FAPI_ReadArray(PDARGS pArg)
{
    DWORD status = EC_NONE;
    DWORD total_count = pArg->dwCount; // total read data byte count
    DWORD addr = pArg->st_addr; // address
//    PDEV dev = pArg->pDevice; //device pointer
    WORD *buf = pArg->pDest; // read data

	if(RPC_Read_Data(addr, total_count, buf)==FALSE) { status = EC_READDATA;}
    else printf("RPC_Read_Array OK.\n");
    	

    return status;
}

//  FL_ReadCFI, FL-R and FL-P are different
DWORD FAPI_ReadCFI(PDARGS pArg)
{
    //int nRc = QSPI_OK;
//    PDEV dev = pArg->pDevice;
    WORD *data = pArg->pDest;


	if(!RPC_Read_CFI(data)) return EC_DEVICEERROR;
	else return EC_NONE;
}

// FL_Reset
DWORD FAPI_Reset(PDARGS pArg)
{
//    PDEV dev = pArg->pDevice;
//	rpc_ctrl_rstgr_t rstgr;
    int nRc = QSPI_OK;
//	DWORD polling_nr = 0;
    //DWORD cpuStat = SYS_EnterCritical();
    pArg->dwValue +=3;

    if (pArg->dwValue == 0)	//RPC flash Software reset
    {
    	if(RPC_ID_ASO_Exit()==FALSE) {return EC_DEVICEERROR;}
    }
    else if (pArg->dwValue == 1)	//RPC flash Hardware reset
    {
		resetRPCmem();
    }
    else if (pArg->dwValue == 2)	//RPC controller reset
    {
        resetRPCreg();
    }
    else if (pArg->dwValue == 3 || pArg->dwValue == 6)	//RPC flash Software reset
    {
        	if(RPC_ID_ASO_Exit()==FALSE) {return EC_DEVICEERROR;}
    }
	else if (pArg->dwValue == 4)	//RPC flash Hardware reset
    {
        resetRPCmem();
    }
    else
        //return SYS_ExitCritical(cpuStat), EC_PARAMETER;
		return EC_PARAMETER;
    //SYS_ExitCritical(cpuStat);
    if (nRc != QSPI_OK)
        return EC_DEVICEERROR;
    else
        return EC_NONE;
}

// FL_GetStatusReg
DWORD FAPI_GetStatusReg(PDARGS pArg)
{
 //   PDEV dev = pArg->pDevice;
    DWORD ret = EC_NONE;
    unsigned short val;

	

	if(RPC_Read_Reg(RPC_RD_SR, &val)) 
		{
			pArg->dwStatus = (DWORD)val;
			//printf("ok, status value = %04X", pArg->dwStatus);
			//printf("ok, status value = %04X\n", val);
        	ret = EC_NONE;
		}
	else 
		{
        	//printf("error, status value = %04X\n",val);
			ret = EC_DEVICEERROR;
    	}


 	return ret;
}

//  FL_SetConfigReg
DWORD FAPI_SetConfigReg(PDARGS pArg)
{
    int nRc = QSPI_OK;
    unsigned short nSta;// read status reg
    unsigned short nCfg[4];// read config reg
    unsigned short nC ; // config reg
    PDEV dev = pArg->pDevice;
	DWORD reg_idx = pArg->st_addr;
	DWORD type = 0;
	DWORD type2;
    DWORD status;
	DWORD lpbk_stat;


	//RPC_Read_Reg(type, &nCfg);	
	if(reg_idx==1) {type = RPC_PROG_NVCR; type2 = RPC_RD_NVCR;}
	else if(reg_idx==0) {type = RPC_LD_VCR; type2 = RPC_RD_VCR;}
    else if(reg_idx==2) {type = RPC_LD_ICR; type2 = RPC_RD_ICR;}
    else if(reg_idx==3) {type = RPC_LD_ISR; type2 = RPC_RD_ISR;}
    nC = (WORD)pArg->dwValue;
	if(RPC_Prog_Reg(type, &nC)==FALSE) nRc = QSPI_ERR_INIT;

//andy
//    SYS_WaitUSec(10);    //delay for WIP set
    rdRPC2_REG(reg_lbr_adr, &lpbk_stat);
	if(lpbk_stat==0x0000){
    pArg->dwTimeout = dev->WRRTimeout;
    status = 0x01;
	nSta = 0;
    while ((nSta & 0x0080) == 0x0080)  // make sure status reg bit[1] = 0
    {
          status = dev->pGetStatusReg(pArg);
		  nSta = pArg->dwStatus;
    }

    // Read verify config register
    if(RPC_Read_Reg(type2, &nCfg[0])==FALSE) nRc = QSPI_ERR_INIT;
    if (nRc != QSPI_OK)
        return EC_DEVICEERROR;


    if (nCfg[0] == nC)
        return EC_NONE;
    else
    	{
    	printf("CMD %04X %04X, write %04X, read %04X\n",type,type2,nC,nCfg);
        return EC_CFGREGNOTSET;
    	}
	 
	}
	return EC_NONE;
}


//  FL_GetConfigReg
DWORD FAPI_GetConfigReg(PDARGS pArg)
{
//    PDEV dev = pArg->pDevice;
    DWORD ret = EC_NONE;
	DWORD reg_idx = pArg->st_addr;
	DWORD type = 0;
    unsigned short nCfg;


	if(reg_idx==1) type = RPC_RD_NVCR;
	else if(reg_idx==0) type = RPC_RD_VCR;
	else if(reg_idx==2) type = RPC_RD_ICR;
    else if(reg_idx==3) type = RPC_RD_ISR;


    if(RPC_Read_Reg(type, &nCfg)) 
		{
			pArg->dwResult = (DWORD)nCfg;
			//printf("ok, status value = %04X", pArg->dwStatus);
			//printf("ok, status value = %04X\n", val);
        	ret = EC_NONE;
		}
	else 
		{
        	//printf("error, status value = %04X\n",val);
			ret = EC_DEVICEERROR;
    	}
	


	return ret;
}

//  FL_SetWP
// Set Hardware Protect Mode by WP# pin
DWORD FAPI_SetWP(PDARGS pArg)
{
    int nRc = QSPI_OK;
    unsigned int nOnOff = 0; // TRUE of FALSE

	if(pArg->dwSelect) nOnOff = 1; //Write disable 
	else nOnOff = 0;				//Write enable

    wrRPC2_REG(reg_wpr_adr, &nOnOff);    //Set write protecet into rpc2 controller WPR
    if (nRc == QSPI_OK)
        return EC_NONE;
    else
        return EC_DEVICEERROR;
}

/** FAPI_SendPassword *******************************************************/
/*                                                                          */
/*  Sends the passed four array values to the password registers to unlock  */
/*  the PPBL bit on the target device.                                      */
/*  Enter: PDARGS pArg = pointer to argument block                          */
/*         pArg->pDevice = pointer to target device object                  */
/*         pArg->pSrc = pointer to WORD buffer providing password data      */
/*  Exit:  DWORD = operation status                                         */
/*                                                                          */
/****************************************************************************/

DWORD FAPI_SendPassword(PDARGS pArg)
{
    DWORD status = EC_NONE, errCode = EC_NONE, i;
    PDEV dev = pArg->pDevice;
    WORD *data = pArg->pSrc;
//    DWORD cpuStat = SYS_EnterCritical();
    FAPI_NORCmdPasswordEnter(pArg);

    /* Send password unlock command and password values.    */
    FAPI_NORCmdPasswordUnlock(pArg);
    for (i = 0; i < 4; i++)
    {
        pArg->fl_addr = i;
        pArg->fl_data = data[i];
        dev->pWriteNORData(pArg);
//        SYS_WaitUSec(200);		//kshouji
    }

    FAPI_NORCmdPasswordConfirm(pArg);
//    SYS_ExitCritical(cpuStat);

    /* Wait for password 'program' operation to complete.   */
    /* Use the word program timeout value as the gating     */
    /* factor even though it probably should be *much*      */
    /* shorter.                                             */
    pArg->dwTimeout = dev->ProgWordTimeout;
    /* Poll status bit until it is set to the desired state.    */
    status = dev->pGetNORStatus(pArg);
    if (status) return status;
    if (NOR_DS_READ_ARRAY != pArg->dwStatus)
        errCode = EC_PWDACCEPTTIMEOUT;

    FAPI_NORCmdAnymodeExit(pArg);
    if (errCode) return errCode;
    return status;
}

/** FAPI_ReadPassword *******************************************************/
/*                                                                          */
/*  Reads the target device and fills a buffer with four password register  */
/*  values.                                                                 */
/*  Enter: PDARGS pArg = pointer to argument block                          */
/*         pArg->pDevice = pointer to target device object                  */
/*         pArg->pDest = pointer to WORD buffer to receive password data    */
/*  Exit:  DWORD = operation status                                         */
/*         pArg->pDest[1..4] = password data                                */
/*                                                                          */
/****************************************************************************/

DWORD FAPI_ReadPassword(PDARGS pArg)
{
    DWORD status = EC_NONE, i;
    PDEV dev = pArg->pDevice;
    WORD *data = pArg->pDest;
//    DWORD cpuStat = SYS_EnterCritical();

    FAPI_NORCmdPasswordEnter(pArg);

    for (i = 0; i < 4; i++)
    {
        pArg->fl_addr = i;
        dev->pReadNORData(pArg);
        data[i] = pArg->fl_data;
    }

    FAPI_NORCmdAnymodeExit(pArg);
//    SYS_ExitCritical(cpuStat);
    return status;
}

/** FAPI_ProgPassword *******************************************************/
/*                                                                          */
/*  Program specified password register of target device with passed value. */
/*  Enter: PDARGS pArg = pointer to argument block                          */
/*         pArg->pDevice = pointer to target device object                  */
/*         pArg->st_addr = register address                                 */
/*         pArg->dwValue = value to program                                 */
/*  Exit:  DWORD = operation status                                         */
/*  Notes: Later may pass in all four values and program in one sequence.   */
/*                                                                          */
/****************************************************************************/

DWORD FAPI_ProgPassword(PDARGS pArg)
{
    DWORD errCode = EC_NONE, status = EC_NONE;
    PDEV dev = pArg->pDevice;
    DWORD /*cpuStat, */addr;

    if (pArg->st_addr > 3)
        return EC_BADPWDINDEX;

    addr = pArg->st_addr;
//    cpuStat = SYS_EnterCritical();
    /* Enter password protection command set mode.  */
    FAPI_NORCmdPasswordEnter(pArg);

    /* Send program command and passed value.   */
    FAPI_NORCmdAlternateModeProg(pArg);

    pArg->dwTimeout = dev->ProgWordTimeout;
    /* Poll status bit until it is set to the desired state.    */
    status = dev->pGetNORStatus(pArg);
    if (status)
    {
        FAPI_NORCmdAnymodeExit(pArg);
//        SYS_ExitCritical(cpuStat);
        return status;
    }

    if (NOR_DS_READ_ARRAY != pArg->dwStatus)
        errCode = EC_PWDTIMEOUT;
    else
    {
        /* Final verify.    */
        pArg->fl_addr = addr;
        dev->pReadNORData(pArg);
        if (pArg->fl_data != (WORD)(pArg->dwValue&0xffff))
            errCode = EC_READDATA;
    }

    /* Send sequence.   */
    FAPI_NORCmdAnymodeExit(pArg);
//    SYS_ExitCritical(cpuStat);
    if (errCode) return errCode;
    return status;
}

/** FAPI_ReadLockRegister ***************************************************/
/*                                                                          */
/*  Read the Lock register of the target device.                            */
/*  Enter: PDARGS pArg = pointer to argument block                          */
/*         pArg->pDevice = pointer to target device object                  */
/*         pArg->dwValue = value to program                                 */
/*  Exit:  DWORD = operation status                                         */
/*         pArg->dwResult = lock register contents                          */
/*                                                                          */
/****************************************************************************/

DWORD FAPI_ReadLockRegister(PDARGS pArg)
{
    DWORD status = EC_NONE;
    PDEV dev = pArg->pDevice;
//    DWORD cpuStat = SYS_EnterCritical();
    /* Send common unlock sequence. */
    FAPI_NORCmdLockRegisterEnter(pArg);

    pArg->fl_addr = dev->LkRegAdd;
    dev->pReadNORData(pArg);
    pArg->dwResult = pArg->fl_data;
    /* Lock up */
    FAPI_NORCmdAnymodeExit(pArg);
//    SYS_ExitCritical(cpuStat);
    return status;
}

/** FAPI_ProgLockRegister ***************************************************/
/*                                                                          */
/*  Set the Lock register of the target device.                             */
/*  Enter: PDARGS pArg = pointer to argument block                          */
/*         pArg->pDevice = pointer to target device object                  */
/*         pArg->dwValue = value to program                                 */
/*  Exit:  DWORD = operation status                                         */
/*                                                                          */
/****************************************************************************/

DWORD FAPI_ProgLockRegister(PDARGS pArg)
{
    DWORD errCode = EC_NONE, status = EC_NONE;
    PDEV dev = pArg->pDevice;
//    DWORD cpuStat = SYS_EnterCritical();

    /* Write it out. Assume that caller has done a read-modify  */
    /* operation so that we won't be attempting to program a    */
    /* '0' back to a '1'.                                       */
    FAPI_NORCmdLockRegisterEnter(pArg);

    pArg->st_addr = dev->LkRegAdd;
    FAPI_NORCmdAlternateModeProg(pArg);

    /* Poll status bit until it is set to the desired state.    */
    pArg->dwTimeout = dev->ProgWordTimeout;
    status = dev->pGetNORStatus(pArg);
    if (status)
    {
        FAPI_NORCmdAnymodeExit(pArg);
 //       SYS_ExitCritical(cpuStat);
        return status;
    }

    if (NOR_DS_READ_ARRAY != pArg->dwStatus)
        errCode = EC_PROGTIMEOUT;
    else
    {
        /* Final verify.    */
        dev->pReadNORData(pArg);
        if (pArg->fl_data != pArg->dwValue)
            errCode = EC_READDATA;
    }
    FAPI_NORCmdAnymodeExit(pArg);
//    SYS_ExitCritical(cpuStat);
    if (errCode) return errCode;
    return status;
}

/** FAPI_GetASPState ********************************************************/
/*                                                                          */
/*  Read Advanced Sector Protection register state from target device.      */
/*  Enter: PDARGS pArg = pointer to argument block                          */
/*         pArg->pDevice = pointer to target device object                  */
/*         pArg->st_addr = PPB, DYB sector address, PPBL bank address       */
/*         pArg->dwSelect = type of ASP to read:                            */
/*                          ASP_PPB = persistent protection                 */
/*                          ASP_DYB = dynamic protection                    */
/*                          ASP_PPBL = PPB lock                             */
/*                          ASP_PWD = lock register                         */
/*                          ASP_SECSI_CUST = customer lock bit              */
/*  Exit:  DWORD = operation status                                         */
/*         pArg->dwResult = status of bit(s):                               */
/*                          TRUE if set, FALSE if clear for PPB, DYB, PPBL  */
/*                          Setting status for lock register bits:          */
/*                               PROT_NONE = no protection                  */
/*                               PROT_PERSISTENT = persistent               */
/*                               PROT_PASSWORD = password                   */
/*                               PROT_RDPASSWORD = read password            */
/*  Notes: 'Set' and 'Clear' are different values on different devices.     */
/*                                                                          */
/****************************************************************************/

DWORD FAPI_GetASPState(PDARGS pArg)
{
    PDEV dev = pArg->pDevice;
    DWORD status = EC_NONE/*, cpuStat = SYS_EnterCritical()*/;
    DWORD i, SectorAddr;

    /* Send commands specific to requested register.    */
    switch (pArg->dwSelect)
    {
    case ASP_PPB:
        FAPI_NORCmdPPBEnter(pArg);
        pArg->fl_addr = pArg->st_addr;
        dev->pReadNORData(pArg);
        pArg->dwResult = pArg->fl_data;
        FAPI_NORCmdAnymodeExit(pArg);
        break;

    case ASP_DYB:
        SectorAddr = pArg->st_addr;
        for (i=0; i<dev->BankCount; i++)
        {
            if (pArg->st_addr < dev->BankOffsets[i]/ sizeof(WORD))
                break;
        }
        pArg->st_addr = dev->BankOffsets[i-1] / sizeof(WORD);
        FAPI_NORCmdDYBEnter(pArg);
        pArg->st_addr = SectorAddr;
        pArg->fl_addr = pArg->st_addr;
//        printf("    GetASP DYB addr %08X\n",pArg->fl_addr);
        dev->pReadNORData(pArg);
        pArg->dwResult = pArg->fl_data;
//        printf("    GetASP DYB data %04X\n",pArg->fl_data);
        FAPI_NORCmdAnymodeExit(pArg);
        break;

    case ASP_PPBL:
        FAPI_NORCmdPPBLockEnter(pArg);
        pArg->fl_addr = pArg->st_addr;
        dev->pReadNORData(pArg);
        pArg->dwResult = pArg->fl_data;
        FAPI_NORCmdAnymodeExit(pArg);
        break;

    case ASP_PWD:      // Lock register bit DQ1 & DQ2
        #ifndef SIMULATION
        SYS_ExitCritical(cpuStat);
        #endif
        status = dev->pReadLockRegister(pArg);
        if (status) return status;
        switch ((~pArg->dwResult) & (DQ2_MASK | DQ1_MASK))
        {
        case DQ2_MASK:
            if ((~pArg->dwResult) & DQ5_MASK)
                pArg->dwResult = PROT_RDPASSWORD;
            else
                pArg->dwResult = PROT_PASSWORD;
            break;
        case DQ1_MASK: pArg->dwResult = PROT_PERSISTENT; break;
        case 0: pArg->dwResult = PROT_NONE; break;
        default:
            if ((~pArg->dwResult) & DQ0_MASK)
                return PROT_PPBENABLE;
            else
                return EC_BADPWDPROTECT;
        }
        return EC_NONE;

    case ASP_SECSI_CUST:
        #ifndef SIMULATION
        SYS_ExitCritical(cpuStat);
        #endif
        status = dev->pReadLockRegister(pArg);
        if (status) return status;
        pArg->dwResult = pArg->dwResult & DQ0_MASK ? SECSI_UNLOCKED : SECSI_LOCKED;
        return EC_NONE;

    default:
        status = EC_PARAMETER;
        break;
    }

    #ifndef SIMULATION
    SYS_ExitCritical(cpuStat);
    #endif
    if (status) return status;
    pArg->dwResult = !(pArg->dwResult & 0x0001);

    return EC_NONE;
}

/** FAPI_SetASPState ********************************************************/
/*                                                                          */
/*  Set Advanced Sector Protection state on target device.                  */
/*  Enter: PDARGS pArg = pointer to argument block                          */
/*         pArg->pDevice = pointer to target device object                  */
/*         pArg->st_addr = PPB (set), DYB sector address                    */
/*         pArg->dwSelect = type of ASP to set:                             */
/*                          ASP_PPB = persistent protection                 */
/*                          ASP_PPBERASEALL = erase all PPB                 */
/*                          ASP_DYB = dynamic protection                    */
/*                          ASP_PPBL = PPB lock                             */
/*                          ASP_PWD = lock register                         */
/*                          ASP_SECSI_CUST = customer lock bit              */
/*         pArg->dwValue = state to set:                                    */
/*                         TRUE if set, FALSE if clear for DYB, PPBL        */
/*                         TRUE to set PPB (use erase all to clear)         */
/*                         State to set for lock register bits:             */
/*                               PROT_NONE = no protection                  */
/*                               PROT_PERSISTENT = persistent               */
/*                               PROT_PASSWORD = password                   */
/*                               PROT_RDPASSWORD = read password            */
/*  Exit:  DWORD = operation status                                         */
/*  Notes: 'Set' - (setBit == TRUE), 'Clear' - (setBit == FALSE)            */
/*         'Set' and 'Clear' are different values on different devices;     */
/*         this function sets the state appropriate to the device.          */
/*                                                                          */
/****************************************************************************/

DWORD FAPI_SetASPState(PDARGS pArg)
{
    DWORD status = EC_NONE, errCode = EC_NONE;
    WORD setValue = pArg->dwValue ? 0 : DQ0_MASK;
    PDEV dev = pArg->pDevice;
//    DWORD cpuStat = SYS_EnterCritical();
    DWORD i, SectorAddr;

    /* Send commands specific to requested register. */
    switch (pArg->dwSelect)
    {
    case ASP_PPB:
        FAPI_NORCmdPPBEnter(pArg);
        pArg->dwValue = setValue;
        FAPI_NORCmdAlternateModeProg(pArg);

        pArg->dwTimeout = dev->ProgWordTimeout;
        status = dev->pGetNORStatus(pArg);
        if (status) return /*SYS_ExitCritical(cpuStat), */status;
        if (NOR_DS_READ_ARRAY != pArg->dwStatus)
            errCode = EC_PPBTIMEOUT;
        else
        {
            SYS_WaitUSec(500); // Specified in the datasheet.
            /* Final verify.    */
            pArg->fl_addr = pArg->st_addr;
            dev->pReadNORData(pArg);
            if ((pArg->fl_data & 0x01) != setValue)
                errCode = EC_READDATA;
        }

        FAPI_NORCmdAnymodeExit(pArg);
        break;

    case ASP_PPBERASEALL:
        FAPI_NORCmdPPBEnter(pArg);
        FAPI_NORCmdPPBEraseAll(pArg);

        /* Poll status bit until it is set to the desired state.    */
        pArg->dwTimeout = pArg->pDevice->SecEraseTimeout;
        status = dev->pGetNORStatus(pArg);
        // *** may want to exit PPB mode here ***
        if (status) return /*SYS_ExitCritical(cpuStat), */status;
        if (NOR_DS_READ_ARRAY != pArg->dwStatus)
            errCode = EC_ERASETIMEOUT;
        else
        {
            /* Final verify.    */
            dev->pReadNORData(pArg);
            if ((pArg->fl_data & 0x01) != 0x01)
                errCode = EC_READDATA;
        }
        FAPI_NORCmdAnymodeExit(pArg);
        break;

    case ASP_DYB:
        SectorAddr = pArg->st_addr;
        for (i=0; i<dev->BankCount; i++)
        {
            if (pArg->st_addr < dev->BankOffsets[i]/ sizeof(WORD))
                break;
        }
        pArg->st_addr = dev->BankOffsets[i-1] / sizeof(WORD);
        FAPI_NORCmdDYBEnter(pArg);
        pArg->st_addr = SectorAddr;
        pArg->dwValue = setValue;
        printf("   Write DYB   addr = %08X data = %d\n",pArg->st_addr,pArg->dwValue);
        FAPI_NORCmdAlternateModeProg(pArg);
        FAPI_NORCmdAnymodeExit(pArg);
        break;

    case ASP_PPBL:
        FAPI_NORCmdPPBLockEnter(pArg);
        pArg->st_addr = 0x0000;
        pArg->dwValue = setValue;
        FAPI_NORCmdAlternateModeProg(pArg);
        FAPI_NORCmdAnymodeExit(pArg);
        break;

    case ASP_PWD:
        switch (pArg->dwValue)
        {
        case PROT_NONE: setValue = 0; break;
        case PROT_PERSISTENT: setValue = DQ1_MASK; break;
        case PROT_PASSWORD: setValue = DQ2_MASK; break;
        case PROT_RDPASSWORD: setValue = (DQ2_MASK | DQ5_MASK); break;
        case PROT_PPBENABLE: setValue = DQ0_MASK; break;
        default: /*SYS_ExitCritical(cpuStat); */return EC_PARAMETER;
        }
        dev->pReadLockRegister(pArg);

        /* Write it out.    */
        pArg->dwValue = pArg->dwResult & (~setValue);
        status = dev->pProgLockRegister(pArg);
        break;

    case ASP_PWDED: // Test Only: Set DQ1 && DQ2 at the same time.
//        pArg->dwValue = DQ2_MASK | DQ1_MASK;
        pArg->dwValue = 0;
        status = dev->pProgLockRegister(pArg);
        if (status)
            errCode = EC_PWDETIMEOUT;
        break;

    case ASP_SECSI_CUST:
        status = dev->pReadLockRegister(pArg);
        if (status) return /*SYS_ExitCritical(cpuStat), */status;
        pArg->dwValue = pArg->dwResult & ~DQ0_MASK;
        /* Write it out.    */
        pArg->dwValue |= setValue;
        status = dev->pProgLockRegister(pArg);
        break;

    default:
        status = EC_PARAMETER;
        break;
    }

    //SYS_ExitCritical(cpuStat);
    if (errCode) return errCode;

    return status;
}

/** FAPI_ASPUnlock **********************************************************/
/*                                                                          */
/*  Unlock all possible protection on target device.                        */
/*  Enter: PDARGS pArg = pointer to argument block                          */
/*         pArg->pDevice = pointer to target device object                  */
/*  Exit:  DWORD = operation status                                         */
/*                                                                          */
/****************************************************************************/

DWORD FAPI_ASPUnlock(PDARGS pArg)
{
    PDEV dev = pArg->pDevice;
    WORD testPwd[4] = {0};
    BOOL bitPWDE, bitPPBL;
    DWORD status = EC_NONE, i;

    pArg->dwSelect = ASP_PWD;
    if ((status = dev->pGetASPState(pArg))) return status;
    bitPWDE = pArg->dwResult;
    pArg->dwSelect = ASP_PPBL;
    pArg->st_addr = 0;
    if ((status = dev->pGetASPState(pArg))) return status;
    bitPPBL = pArg->dwResult;
    /* Make no judgements about whether or not the bits should be   */
    /* set; if they are set, send the password of all 0's.          */
    if (bitPWDE && bitPPBL)
    {
        testPwd[0] = 0x1111;
        testPwd[1] = 0x2222;
        testPwd[2] = 0x3333;
        testPwd[3] = 0x4444;
        pArg->pSrc = testPwd;
        if ((status = dev->pSendPassword(pArg))) return status;
        pArg->dwSelect = ASP_PPBL;
        pArg->st_addr = 0;
        if ((status = dev->pGetASPState(pArg))) return status;
        /* If PPB Lock bit still set, the password did not work.    */
        if (pArg->dwResult) return EC_PPBLSET;
    }
    else if (bitPPBL)
        return EC_PPBLSET;
    /* Check to see if DYBs are set on powerup (device option). */
    /* If so, clear them all.  We will assume that if one DYB   */
    /* is set immediately after powerup, they all must be set.  */
    // debug
    pArg->dwSelect = ASP_DYB;
    pArg->st_addr = 0;
    if ((status = dev->pGetASPState(pArg))) return status;
    if (pArg->dwResult)
    {
        for (i = 0; i < dev->SectorCount; i++)
        {
            pArg->dwSelect = ASP_DYB;
            pArg->st_addr = dev->pAddrSize[i].SecAddr;
            pArg->dwValue = FALSE;
            if ((status = dev->pSetASPState(pArg))) return status;
        }
    }
    pArg->dwSelect = ASP_PPBERASEALL;
    pArg->st_addr = 0;
    if ((status = dev->pSetASPState(pArg))) return status;
    return EC_NONE;
}

//  FAPI_ProgOTP
DWORD FAPI_ProgOTP(PDARGS pArg)
{
    DWORD /*cpuStat,*/ status = EC_NONE;
    DWORD count = pArg->dwCount;
    WORD *buf = pArg->pSrc;
    unsigned int nAddress = (unsigned int)pArg->st_addr;
    WORD stat = 0;
    DWORD polling_nr = 0;
//    PDEV dev = pArg->pDevice;
//    DWORD i;

    FAPI_NORCmdSSREnter(pArg);
#if 1
    if(RPC_Prog_Data((nAddress>>1), count, buf)==FALSE) { status = EC_BWABORT;}
    while(stat!=0x0080) 
        {
            status = FAPI_GetStatusReg(pArg);
            stat = pArg->dwStatus;
            polling_nr++;
            if(polling_nr>100000) return EC_PROGTIMEOUT;

        }    
#else
    for(i=0;i<count;i++) {
    pArg->fl_addr = 0x555;
    pArg->fl_data = 0xAA;
    dev->pWriteNORData(pArg);

    pArg->fl_addr = 0x2AA;
    pArg->fl_data = 0x55;
    dev->pWriteNORData(pArg);

    pArg->fl_addr = 0x555;
    pArg->fl_data = 0xA0;
    dev->pWriteNORData(pArg);

    pArg->fl_addr = nAddress;
    pArg->fl_data = *buf;
    dev->pWriteNORData(pArg);
    buf++;
    nAddress++;
    }
#endif
    FAPI_NORCmdSSRExit(pArg);
/*
    cpuStat = SYS_EnterCritical();
    if (SelDevice == FLS)
        status = OTPWrite(pArg, nAddress, (void*)buf, count);
    else
    {
        unsigned int i;
        for (i=0; i<count; i++)
        {
            status = OTPWrite(pArg, nAddress+i, (void*)(buf+i), 1);
            if (status) break;
        }
    }

    SYS_ExitCritical(cpuStat);
*/
    return status;
}
// FAPI_ReadOTP
DWORD FAPI_ReadOTP(PDARGS pArg)
{
    int nRc = QSPI_OK;
//    DWORD cpuStat;
    DWORD count = pArg->dwCount;
//    PDEV dev = pArg->pDevice;
    WORD *buf = pArg->pDest;
    unsigned int nAddress = (unsigned int)pArg->st_addr;

//    cpuStat = SYS_EnterCritical();
    FAPI_NORCmdSSREnter(pArg);
    RPC_Read_Data((nAddress>>1), (count/2 + count%2), buf);
    FAPI_NORCmdSSRExit(pArg);
//    nRc = QspiCmdRead(dev, OTPRead, nAddress, NO_MB, (void*)buf, count);

//    SYS_ExitCritical(cpuStat);
    if (nRc == QSPI_OK)
        return EC_NONE;
    else
        return EC_DEVICEERROR;
}

// FL_SetClock
DWORD FAPI_SetClock(PDARGS pArg)
{
//    PDEV dev = pArg->pDevice;	
    int nRc = QSPI_OK;
    unsigned int polling_nr = 0;
//    unsigned int nMhz = (unsigned int)pArg->dwValue;
//    DWORD cpuStat;
    WORD nReg = 0;

	#ifndef SIMULATION
	cpuStat = SYS_EnterCritical();
    nRc = RPCSetClock(dev, nMhz*1000*1000);
	#endif
    while(1){
        //GPMC_Read(rpc_reg_baseaddr | RPC_RPCSR, &nReg, 1);		//Read rpcsr
        if((nReg & 0x0400)==0x0400) {
            //printf("DONE. polling %d times, RPCSR: %04X\n",polling_nr,nReg);
            break;
        }
        polling_nr++;
        if(polling_nr>MAX_POLLING_NUM*200) {
            printf("polling %d times, RPCSR: %04X\n",polling_nr,nReg);
            nRc=QSPI_ERR_INIT; 
            break;
        }
    }
	
	#ifndef SIMULATION
    SYS_ExitCritical(cpuStat);
    #endif
	
    if (nRc == QSPI_OK)
        return EC_NONE;
    else
        return EC_DEVICEERROR;
}

// FL_GetClock
DWORD FAPI_GetClock(PDARGS pArg)
{
    int nRc = QSPI_OK;
    unsigned int nClock = 0;
    unsigned int* pKhz = (unsigned int*)pArg->pDest;
//    DWORD cpuStat;

	#ifndef SIMULATION
    cpuStat = SYS_EnterCritical();
    nRc = RPCGetClock(&nClock);
    SYS_ExitCritical(cpuStat);
	#endif
	
    if (nRc == QSPI_OK)
    {
        nClock = (nClock+1000000)/1000000;
        *pKhz = (DWORD)(nClock); // output MHz
        return EC_NONE;
    }
    else
        return EC_DEVICEERROR;
}


// ****************************
// Debug API
//*****************************
DWORD FAPI_FPGARegRd(PDARGS pArg)
{
    unsigned int nReg = (unsigned int)pArg->dwSelect;
    unsigned int* pVal = (unsigned short*)pArg->pDest;
    //*pVal = QspiRegRd(nReg);
	//GPMC_Read(rpc_reg_baseaddr | nReg, pVal, 1);
	RPC_CTRL_Reg_Read(nReg, pVal);
    return EC_NONE;
}

DWORD FAPI_FPGARegWr(PDARGS pArg)
{
    unsigned int nReg = (unsigned int)pArg->dwSelect;
    unsigned int nVal = (unsigned short)pArg->dwValue;
    //QspiRegWr(nReg, nVal);
	//GPMC_Write(rpc_reg_baseaddr | nReg, &nVal, 1);
	RPC_CTRL_Reg_Write(nReg, &nVal);
    return EC_NONE;
}

#ifndef SIMULATION

/** DeleteDeviceObject ******************************************************/
/*                                                                          */
/*  Destroy a device object.                                                */
/*  Enter: PDEV dev = device object                                         */
/*  Exit:  None                                                             */
/*                                                                          */
/****************************************************************************/

void DeleteDeviceObject(PDEV dev)
{
    if (!dev) return;
    // free current log
//    DeleteLog(dev);
    // free any internal arrays
    if (dev->RegionSecCount)    free((char*)dev->RegionSecCount);
    if (dev->RegionSecSize)     free((char*)dev->RegionSecSize);
    if (dev->RegionOffsets)     free((char*)dev->RegionOffsets);
    if (dev->BankSecCount)      free((char*)dev->BankSecCount);
    if (dev->BankOffsets)       free((char*)dev->BankOffsets);
    if (dev->BankSecMask)       free((char*)dev->BankSecMask);
    if (dev->pAddrSize)         free((char*)dev->pAddrSize);
    if (dev->ASData)            free((char*)dev->ASData);
    if (dev->cfiData)           free((char*)dev->cfiData);
//    if (dev->idData)            free((char*)dev->idData);
//    if (dev->BadBlockArray)     free((char*)dev->BadBlockArray);
    if (dev->BadSectorArray)    free((char*)dev->BadSectorArray);
/*
    if (dev->pNorVol)
        free((char*)dev->pNorVol->pTable), free((char*)dev->pNorVol);
    if (dev->pNandVol)
        free((char*)dev->pNandVol->FFSSpare), free((char*)dev->pNandVol);
*/
    // free device
    free((char*)dev);
}

#endif

PDEV NewDeviceObject(DWORD flashBase, DWORD tech)
{
    DWORD i;
    BOOL memOK = TRUE;
    PDEV dev;
    PFUN *ptr;

    if (!(dev = (PDEV)malloc(sizeof(struct device)))) return (PDEV)NULL;
    // zero internal variables
    memset((char*)dev, 0, sizeof(struct device));
    // point to first function (note functions are in pairs)
    ptr = &dev->pGetFAPIInfo;   // *** could just point to start of struct ***
    // initialize all function pointers to function not supported
    for (i = 0; i < FN_MAX; i++) ptr[2 * i] = FAPINotSupported;

    // assign members
    dev->FlashBase = (PVOID)flashBase;
    dev->Technology = tech;
//    dev->DevType = MAX_DEVICE;      // initially indicate unknown
//    dev->SysConfig = config;
//    dev->parms.pLog = dev->logf;    // point to default device log
//    dev->parms.logSize = LOG_DEFAULT;
		strcpy(flashName, "RPC");
    // handle technology
    switch (tech)
    {
    case NOR:
    case RPC:
    		
        // internal operation
        dev->pGetFAPIInfo           = FAPI_GetFAPIInfo;
        
        dev->pGetFAPIGeometry       = FAPI_GetFAPIGeometry;
        // initialization
        dev->pConfigure             = FAPI_Configure;
        /*
        // assign proper read and write functions
//        switch (CardType)
//        {
//        case 0:  dev->pReadNORData = FAPI_ReadNORData16;  dev->pWriteNORData = FAPI_WriteNORData16;  break;
//        case 1:  dev->pReadNORData = FAPI_ReadNORData32U; dev->pWriteNORData = FAPI_WriteNORData32U; break;
//        case 2:  dev->pReadNORData = FAPI_ReadNORData32L; dev->pWriteNORData = FAPI_WriteNORData32L; break;
//        default: dev->pReadNORData = FAPI_ReadNORData16;  dev->pWriteNORData = FAPI_WriteNORData16;  break;
//        }
*/
        dev->pReadNORData = FAPI_ReadData;  
        dev->pWriteNORData = RPC_WriteData;
        
        dev->pReadNORBuffer         = FAPI_ReadArray;
        /*
        dev->pReadNORRandom         = FL_ReadRandom;
//        dev->pVerifyNORBuffer       = FAPI_VerifyNORBuffer;
		*/
        dev->pProgNORBuffer         = FAPI_ProgNORBuffer;
        dev->pCmdResetFlash         = FAPI_Reset;
		/*
        dev->pSetReadMode           = FAPINotSupported;
        dev->pWriteAutoSelectCmd    = FAPINotSupported;
        dev->pReadAutoSelect        = FAPINotSupported;
//        dev->pGetAutoSelectReg      = FAPI_GetAutoSelectReg;
		*/
        dev->pReadCFI               = FAPI_ReadCFI;
        // erasure
        
        dev->pEraseSector           = FAPI_EraseSector;
		/*
//        dev->pEraseSectors          = FAPI_EraseSectors;
*/
        dev->pVerifySectorBlank     = RPC_BlankCheck;
/*
        dev->pWaitForSectorErase    = FL_WaitForSectorErase;
        dev->pEraseChip             = FL_EraseChip;
//        dev->pQueueEraseSector      = FAPI_QueueEraseSector;
*/
        dev->pBlankCheck            = RPC_BlankCheck;

		// async access
        dev->pSingleProg            = RPC_SingleProg;
/*
        dev->pSingleProgWait        = FAPINotSupported;
        // *** let individual files do this one ***
//        dev->pUnlockBypassProg      = FAPI_UnlockBypassProg;
*/
        // buffered access
        dev->pBProgAbortReset       = FAPI_Reset;
        dev->pBufferWriteLoad       = RPC_BufferWriteLoad;
        dev->pBufferWriteStore      = RPC_BufferWriteStore;
        dev->pBufferWriteCommit     = RPC_BufferWriteCommit;
        dev->pBufferWrite           = FAPI_BufferWrite;
		
        // suspend/resume
        dev->pProgSuspend           = FAPI_ProgSuspend;
        dev->pProgResume            = FAPI_ProgResume;
        dev->pEraseSuspend          = FAPI_EraseSuspend;
        dev->pEraseResume           = FAPI_EraseResume;
        
        // status
        dev->pGetNORStatus          = FAPI_GetNORStatus;
        dev->pClearNORStatus        = FAPI_ClearStatus;
        
        // special functionality
        dev->pGetStatusReg          = FAPI_GetStatusReg;
		/*
        dev->pGetECCStatusReg       = FL_GetECCStatusReg;
        */
        dev->pSetConfigReg          = FAPI_SetConfigReg;
        dev->pGetConfigReg          = FAPI_GetConfigReg;

		dev->pReadPassword          = FAPI_ReadPassword;
        dev->pSendPassword          = FAPI_SendPassword;
        dev->pProgPassword          = FAPI_ProgPassword;
        dev->pReadLockRegister      = FAPI_ReadLockRegister;
        dev->pProgLockRegister      = FAPI_ProgLockRegister;
        dev->pGetASPState           = FAPI_GetASPState;
        dev->pSetASPState           = FAPI_SetASPState;
        /*
//        dev->pSecSi                 = FAPI_SecSi;
//        dev->pProgramSecSi          = FAPI_ProgramSecSi;
//        dev->pReadSecSiBits         = FAPI_ReadSecSiBits;
        dev->pBadSectorInfo         = FAPI_BadSectorInfo;
        */
        dev->pASPUnlock             = FAPI_ASPUnlock;
        /*
        dev->pSectorLockUnlock      = FAPINotSupported;
        dev->pSectorLockRange       = FAPINotSupported;
        // QSPI
        dev->pReadID                = FL_ReadID;
        dev->pEnableQuad            = FL_EnableQuad;
        dev->pDisableQuad           = FL_DisableQuad;
        dev->pEnableParallel        = FL_EnableParallel;
        dev->pDisableParallel       = FL_DisableParallel;
        */
        dev->pSetClock              = FAPINotSupported;
        dev->pGetClock              = FAPINotSupported;
		/*
		dev->pSetVoltage            = FL_SetVoltage;
        dev->pGetVoltage            = FL_GetVoltage;
        */
        dev->pSetWP                 = FAPI_SetWP;
		/*
        dev->pSetBlockProtect       = FL_SetBlockProtect;
        dev->pDisableStatusRegWrite = FL_DisableStatusRegWrite;
        dev->pClearWELBit           = FL_ClearWELBit;
        dev->pFreezeBPsTBs          = FL_FreezeBPsTBs;
        dev->pConfigTBParm          = FL_ConfigTBParm;
        dev->pConfigBPNV            = FL_ConfigBPNV;
        dev->pConfigTBProt          = FL_ConfigTBProt;
        dev->pLockBPsCBs            = FL_LockBPsCBs;
        */
        dev->pProgOTP               = FAPI_ProgOTP;
        dev->pReadOTP               = FAPI_ReadOTP;
        /*
        dev->pAutoBootRegWrite      = FAPINotSupported;
        dev->pAutoBootRegRead       = FAPINotSupported;
        dev->pAutoBootReadData      = FAPINotSupported;
        dev->pAutoBootUpdateRT      = FAPINotSupported;
        dev->pWriteOpcode           = FL_WriteOpcode;
        dev->pWriteAddr             = FL_WriteAddr;
        dev->pWriteCount            = FL_WriteCount;
        dev->pWriteModeBit          = FL_WriteModeBit;
        dev->pWriteDataBit          = FL_WriteDataBit;
        dev->pReadDataBit           = FL_ReadDataBit;
        dev->pEnterDP               = FL_EnterDP;
        dev->pExitDP                = FL_ExitDP;
        dev->pEnableHold            = FL_EnableHold;
        dev->pDisableHold           = FL_DisableHold;
        dev->pHold                  = FL_Hold;
 */
        dev->pFPGARegRd             = FAPI_FPGARegRd;
        dev->pFPGARegWr             = FAPI_FPGARegWr;
/*
        dev->pFPGARamRd             = FL_FPGARamRd;
        dev->pFPGAReset             = FL_FPGAReset;
        dev->pFPGAIdle              = FL_FPGAIdle;
        dev->pSetReadCmdMode        = FL_SetReadCmdMode;
        dev->pSetProgCmdMode        = FL_SetProgCmdMode;
        dev->pSetAddrMode           = FL_SetAddrMode;
        dev->pGetReadCmdMode        = FL_GetReadCmdMode;
        dev->pGetProgCmdMode        = FL_GetProgCmdMode;
        dev->pGetAddrMode           = FL_GetAddrMode;
        // assign non-zero member variables
        dev->DataWidth = 8;                             // set data width = 8 bit (1 byte)
        dev->ProgWordTimeout        = 1024;
        dev->ProgBufferTimeout      = 1024 * 32;
        dev->SecEraseTimeout        = 1000000;
        dev->ChipEraseTimeout       = 1000000 * 250;
        dev->SuspendTimeout         = 25;
        dev->pRMTable               = drmTable;
//        dev->LkRegAdd               = 0;
*/
        dev->ColumnBits             = FAPI_COLUMN_BITS; // default
/*
        dev->readMode               = DEV_ASYNC;
        // set most common fields here, device overrides will clear as required
        dev->Features               = FS_SETCONFIGREG | FS_READCONFIGREG;

        // command control blocks
        dev->CCB_Reset              = FAPI_RESET;
        dev->CCB_AutoSelEnter       = FAPI_LC_AUTOSEL_ENTER;
        dev->CCB_ReadCfgReg         = FAPI_LC_CFG_RD;
        dev->CCB_WriteCfgReg        = FAPI_LC_CFG_WT;
        dev->CCB_EraseChip          = FAPI_LC_ERASE_CHIP;
        dev->CCB_EraseSector        = FAPI_LC_ERASE_SECTOR;
        dev->CCB_EraseSuspend       = FAPI_LC_ERASE_SUSPEND;
        dev->CCB_EraseResume        = FAPI_LC_ERASE_RESUME;
        dev->CCB_UnBypassEnter      = FAPI_LC_UNLOCKBYPASS_ENTER;
        dev->CCB_UnBypassExit       = FAPI_LC_ANYMODE_EXIT;
        dev->CCB_ReadStatReg        = FAPI_STATUS_READ;
        dev->CCB_ClearStatReg       = FAPI_STATUS_CLEAR;
        dev->CCB_SingleWordPgm      = FAPI_LC_SINGLE_WORD_PROGRAM;
        dev->CCB_WriteBufLoad       = FAPI_LC_WRITE_BUFFER_LOAD;
        dev->CCB_WriteBufConfirm    = FAPI_LC_WRITE_BUFFER_CONFIRM;
        dev->CCB_WriteBufReset      = FAPI_LC_WRITE_BUFFER_RESET;
        dev->CCB_ProgramSuspend     = FAPI_LC_PROGRAM_SUSPEND;
        dev->CCB_ProgramResume      = FAPI_LC_PROGRAM_RESUME;
        dev->CCB_SecSiEnter         = FAPI_LC_SEC_SI_ENTER;
        dev->CCB_SecSiExit          = FAPI_LC_SEC_SI_EXIT;
        dev->CCB_PasswordEnter      = FAPI_LC_PASSWORD_ENTER;
        dev->CCB_PasswordExit       = FAPI_LC_ANYMODE_EXIT;
        dev->CCB_PPBEnter           = FAPI_LC_PPB_ENTER;
        dev->CCB_PPBExit            = FAPI_LC_ANYMODE_EXIT;
        dev->CCB_PPBLockEnter       = FAPI_LC_PPB_LOCK_ENTER;
        dev->CCB_PPBLockExit        = FAPI_LC_ANYMODE_EXIT;
        dev->CCB_DYBEnter           = FAPI_LC_DYB_ENTER;
        dev->CCB_DYBExit            = FAPI_LC_ANYMODE_EXIT;
        dev->CCB_LockRegisterEnter  = FAPI_LC_LOCK_REG_ENTER;
        dev->CCB_LockRegisterExit   = FAPI_LC_ANYMODE_EXIT;
*/

        // memory allocation
        if ((dev->RegionSecCount = (DWORD*)malloc(sizeof(DWORD) * MAX_REGIONS)))  // Number of sectors in each region.
            memset((char*)dev->RegionSecCount, 0, sizeof(DWORD) * MAX_REGIONS);
        else memOK = FALSE;
        if ((dev->RegionSecSize = (DWORD*)malloc(sizeof(DWORD) * MAX_REGIONS)))   // Size of sectors in each region.
            memset((char*)dev->RegionSecSize, 0, sizeof(DWORD) * MAX_REGIONS);
        else memOK = FALSE;
        if ((dev->RegionOffsets = (DWORD*)malloc(sizeof(DWORD) * MAX_REGIONS)))   // BYTE address of each region on device
            memset((char*)dev->RegionOffsets, 0, sizeof(DWORD) * MAX_REGIONS);
        else memOK = FALSE;
        if ((dev->BankSecCount = (DWORD*)malloc(sizeof(DWORD) * MAX_BANKS)))  // Number of sectors in each bank
            memset((char*)dev->BankSecCount, 0, sizeof(DWORD) * MAX_BANKS);
        else memOK = FALSE;
        if ((dev->BankOffsets = (DWORD*)malloc(sizeof(DWORD) * MAX_BANKS)))   // BYTE address of each bank on device
            memset((char*)dev->BankOffsets, 0, sizeof(DWORD) * MAX_BANKS);
        else memOK = FALSE;
        if ((dev->ASData = (WORD*)malloc(sizeof(WORD) * MAX_AUTOSELECT)))
            memset((char*)dev->ASData, 0, sizeof(WORD) * MAX_AUTOSELECT);
        else memOK = FALSE;
        if ((dev->cfiData = (WORD*)malloc(sizeof(WORD) * MAX_CFI)))
            memset((char*)dev->cfiData, 0, sizeof(WORD) * MAX_CFI);
        else memOK = FALSE;
/*
        if (dev->pNorVol = (PNORV)malloc(sizeof(norvol)))
            if (dev->pNorVol->pTable = (PENTRY)malloc(sizeof(fentry) * VSECT_MAX))
                dev->pNorVol->dev = dev;
            else memOK = FALSE;
        else memOK = FALSE;
*/
        break;
        default: break;
/*
    case NAND:
    default:    // for now
        // internal operation
        dev->pGetFAPIInfo           = FAPI_GetFAPIInfo;
        // basic operation
        dev->pConfigure             = FAPI_NANDConfigure;
        dev->pReadNANDData          = FAPI_ReadNANDData_08;
        dev->pWriteNANDCmd          = FAPI_WriteNANDCmd_08;
        dev->pWriteNANDAdd          = FAPI_WriteNANDAdd_08;
        dev->pWriteNANDData         = FAPI_WriteNANDData_08;
        dev->pGetID                 = FAPI_GetID;
        dev->pCmdResetFlash         = FAPI_NANDCmdResetFlash;
        // status
        dev->pGetNANDStatus         = FAPI_GetNANDStatus;
        // special functionality
        dev->pBadBlockInfo          = FAPI_BadBlockInfo;
        // assign non-zero member variables
        dev->DataWidth = 8;         // assume minimum
        dev->RowCount = 2;          // large dev <= 128MB, small dev <= 256Mb
        dev->IDLength = NAND_ID_MAX;
        if (dev->idData = malloc(NAND_ID_MAX))
            memset(dev->idData, 0, NAND_ID_MAX);
        else memOK = FALSE;
        if (dev->pNandVol = (PNANDV)malloc(sizeof(nandvol)))
            if (dev->pNandVol->FFSSpare = (BYTE *)malloc(SPARE_MAX))
                dev->pNandVol->dev = dev;
            else memOK = FALSE;
        else memOK = FALSE;
        // assign NAND register addresses
        dev->HoldCS = SYS_GetCSParam(dev->SysConfig, CS_CTRL);
        dev->NAND_cmd = SYS_GetCSParam(dev->SysConfig, NAND_CMD);
        dev->NAND_add = SYS_GetCSParam(dev->SysConfig, NAND_ADD);
        dev->NAND_data = SYS_GetCSParam(dev->SysConfig, NAND_DATA);
        // assign BadBlockArray in Configure
        break;
*/
    }
	#ifndef SIMULATION
    // check for malloc failure
    if (!memOK) return DeleteDeviceObject(dev), (PDEV)NULL;
    // init device for logging
    InitLogDevice(dev);
    // request normal sized log
    if (!NewLog(dev, LOG_SIZE))
        return (PDEV)NULL;;
    #endif
    return dev;
}

#ifndef SIMULATION

static int SLTInitDone = 0;
void SLTInit()
{
    DWORD flashBase;
    DARGS Arg;

    InitTimer2();
    //setup timer 1 isr
    assign_handler(VEC_IRQ, (unsigned long) SysISRHandler, 0);

    if (SLTInitDone == 1) return;

    InitTimer1();
    InitErrorTable();
    InitFunctionNames();
    Sp00082GetCsParam(SYSIO_CS_PISMO_SM0, SYSIO_PHYS_ADDR, (int*)&flashBase);
    Sp00082GetCsParam(SYSIO_CS_PISMO_SM1, SYSIO_PHYS_ADDR, (int*)&rpc_reg_baseaddr);
    pDevice = NewDeviceObject(flashBase, RPC);
    SetLogDevice(pDevice, LOG_READ | LOG_WRITE | LOG_FUNCTION | LOG_FAST_READ | LOG_FAST_WRITE | LOG_USER_TEXT);

    FAPIInitArgs(&Arg, pDevice);
    

// add by pzhu
// initialize interface
    GPMC_Init();
    rpc_ctrl_init(1);
    printf("RPC flash used........\n");

    pDevice->pConfigure(&Arg);
    printf("after configure\n");
    ClearLog(pDevice);
    printf("after clear log\n");
    SLTInitDone = 1;
}

void ShowFlash(PDEV dev)
{
    char *s;
    if (!dev)
    {
        printf("Invalid device object.");
        return;
    }
//    if (dev->DevType >= MAX_DEVICE)
//        printf("Unknown type");
//    else
    {
        switch (dev->Technology)
        {
        case NAND: s = "NAND"; break;
        case NOR:  s = "NOR"; break;
        case SPI:  s = "SPI"; break;
        case RPC: s= "RPC"; break;
        default:   s = "Unknown technology"; break;
        }
        printf("%s %s", s, flashName);
    }
}

void
ShowSLTVersion(void)
{
    printf("SLT core release: %d.%d, cpu board version %d, ap board version %d, flash device: %s\n\n",
        SLT_MAJOR_VERSION,SLT_MINOR_VERSION,CPU_BOARD_VERSION,AP_BOARD_VERSION,FlashDevice);
}

#endif
