//===========================================================================
//
//  rpc2_basic.c
//
//   @author  Yuichi Ise (yuichi.ise@spansion.com)
//   @version 0.1
//   @since   06/21/2013
//
//===========================================================================
#include <stdlib.h>
#include "rpc2_common.h"
#include "dpiheader.h"

//=============================================================================
//  DEFINITIONS
//=============================================================================
#define CT_MSG(fmt, args ...)     printf("[BT]"); printf(fmt, ## args)
#define CT_ERR_MSG(fmt, args ...) printf("[BT]<ERR>"); printf(fmt, ## args)

#define MAX_RDAT_FIFO_SIZE  256  // length in 32-bit
#define MAX_RX_FIFO_SIZE    128  // length in 32-bit
#if (MAX_LEN == 16)
#define MAX_WDAT_FIFO_SIZE  256  // length in 32-bit
#else
#define MAX_WDAT_FIFO_SIZE  512  // length in 32-bit
#endif
#if (RPC2_CTRL_IP_VER >= 240)
#define MAX_ADR_FIFO_SIZE   1    // length in 32-bit
#else
#define MAX_ADR_FIFO_SIZE   32   // length in 32-bit
#endif

#define MAX_ADDR_LOOP   6

#if (RPC2_CTRL_IP_VER >= 240)
#define PSRAM_IR0_OFFSET        0x0000
#define PSRAM_IR1_OFFSET        0x0001
#define PSRAM_CR0_OFFSET        0x1000
#define PSRAM_CR1_OFFSET        0x1001
#endif

#if (RPC2_CTRL_IP_VER >= 230)
#define PSRAM_CS_INIT   0x8F13
//#define PSRAM_CS_INIT   0x8F1F
#else
#define PSRAM_CS_INIT   0x8F17
#endif
#define FLSH_CS_INIT    0x8FB7

#define BURST_16B       (0x2)
#define BURST_32B       (0x3)
#define BURST_64B       (0x1)
#define PSRAM_BURST_64B	(0x0)

#define WRAP2INCR_ON    (0x0)
#define WRAP2INCR_OFF   (0x1)

#define PSRAM_TCSM      4000000

typedef struct {
  DWORD addr;
  DWORD len;
  DWORD burst;
  DWORD size;
  DWORD pattern;
} TBurstParam;

enum {
  WRITE_AHEAD = 0,
  READ_AHEAD
} AHEAD_TRANSACTION;

DWORD PSRAM_LTCY[] = {LTCY_3,LTCY_4,LTCY_5,LTCY_6};
DWORD WRAP_BURST[][2] = {{16,BURST_16B}, \
                         {32,BURST_32B}, \
                         {64,BURST_64B}};

#if (RPC2_CTRL_IP_VER >= 230)
DWORD WMAXEN_RMAXEN[][2] = {{MAXEN_ENABLED,MAXEN_DISABLED}, \
                            {MAXEN_DISABLED,MAXEN_ENABLED}, \
                            {MAXEN_ENABLED,MAXEN_ENABLED}};
#endif

//=============================================================================
//  FUCNTIONS
//=============================================================================
#if 0
static int wr_rd (DWORD initAddr, DWORD incAddr, DWORD len16, WORD* wbuf, DWORD cs)
{
  int ret = NO_ERROR;
  DWORD i;
  DWORD addr;
  WORD* rbuf;
  DWORD mbrReg;
  
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_wr_rd;
  }

  rbuf = (WORD*)malloc(sizeof(WORD)*len16);
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_wr_rd;
  }

  CT_MSG("Addr 0x%08X: %dB x %d-req Write -> Read\n", initAddr, sizeof(WORD), len16);
  for (i = 0; i < len16; i++) {
    addr = initAddr + i*incAddr + mbrReg;
    ret = RPC2_WRITE(addr, 1, &wbuf[i]);
    if (ret != NO_ERROR) {
      CT_ERR_MSG("RPC2_WRITE: i=%d, %d\n", i, ret);
      goto end_wr_rd;
    }
  }
  for (i = 0; i < len16; i++) {
    addr = initAddr + i*incAddr + mbrReg;
    ret = RPC2_READ(addr, 1, &rbuf[i]);
    if (ret != NO_ERROR) {
	CT_ERR_MSG("RPC2_READ: i=%d, %d\n", i, ret);
	goto end_wr_rd;
    }
  }
  if (verifyData(rbuf, wbuf, len16)) {
    ret = VERIFY_ERROR;
    CT_ERR_MSG("VerifyData\n");
  }
 end_wr_rd:
  if (rbuf) {
    free(rbuf);
  }
  return ret;
}
#endif

static int wr8_rd8 (DWORD initAddr, DWORD incAddr, DWORD len8, BYTE* wbuf, DWORD cs)
{
  int ret = NO_ERROR;
  DWORD i;
  DWORD addr;
  BYTE* rbuf;
  DWORD mbrReg;
  
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_wr_rd;
  }

  rbuf = (BYTE*)malloc(sizeof(BYTE)*len8);
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_wr_rd;
  }

  CT_MSG("Addr 0x%08X: %dB x %d-req Write -> Read\n", initAddr, sizeof(BYTE), len8);
  for (i = 0; i < len8; i++) {
    addr = initAddr + i*incAddr + mbrReg;
    ret = RPC2_WRITE8(addr, 1, &wbuf[i]);
    if (ret != NO_ERROR) {
      CT_ERR_MSG("RPC2_WRITE8: i=%d, %d\n", i, ret);
      goto end_wr_rd;
    }
  }
  for (i = 0; i < len8; i++) {
    addr = initAddr + i*incAddr + mbrReg;
    ret = RPC2_READ8(addr, 1, &rbuf[i]);
    if (ret != NO_ERROR) {
	CT_ERR_MSG("RPC2_READ8: i=%d, %d\n", i, ret);
	goto end_wr_rd;
    }
  }
  if (verifyData8(rbuf, wbuf, len8)) {
    ret = VERIFY_ERROR;
    CT_ERR_MSG("VerifyData\n");
  }
 end_wr_rd:
  if (rbuf) {
    free(rbuf);
  }
  return ret;
}

static int wr_rd_burst (DWORD initAddr, DWORD len16, WORD* wbuf, DWORD cs)
{
  int ret = NO_ERROR;
  DWORD addr;
  WORD* rbuf;
  DWORD mbrReg;
  DWORD len8 = (sizeof(WORD)*len16) - initAddr%sizeof(WORD);

  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_wr_rd;
  }
  
  rbuf = (WORD*)malloc(sizeof(WORD)*len16);
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_wr_rd;
  }
  
  addr = initAddr + mbrReg;
  CT_MSG("Addr 0x%08X: %d len Write -> Read\n", addr, len16);
  ret = RPC2_WRITE(addr, len16, wbuf);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("RPC2_WRITE: %d\n", ret);
    goto end_wr_rd;
  }
  ret = RPC2_READ(addr, len16, rbuf);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("RPC2_READ: %d\n", ret);
    goto end_wr_rd;
  }
  if (verifyData8((BYTE*)rbuf, (BYTE*)wbuf, len8)) {
    ret = VERIFY_ERROR;
    CT_ERR_MSG("VerifyData\n");
  }
 end_wr_rd:
  if (rbuf) {
    free(rbuf);
  }
  return ret;
}

static int wr_rd32_burst (DWORD initAddr, DWORD len16, WORD* wbuf, DWORD cs)
{
  int ret = NO_ERROR;
  DWORD addr;
  DWORD* rbuf;
  DWORD len32;
  DWORD mbrReg;
  
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_wr_rd;
  }

  len32 = (len16+1)/2;
  rbuf = (DWORD*)malloc(sizeof(DWORD)*len32);
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_wr_rd;
  }
  
  addr = initAddr + mbrReg;
  CT_MSG("Addr 0x%08X: %d-len Write -> %d-len Read32\n", addr, len16, len32);
  ret = RPC2_WRITE(addr, len16, wbuf);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("RPC2_WRITE: %d\n", ret);
    goto end_wr_rd;
  }
  ret = RPC2_READ32(addr, len32, rbuf);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("RPC2_READ: %d\n", ret);
    goto end_wr_rd;
  }
  if (verifyData((WORD*)rbuf, wbuf, len16)) {
    ret = VERIFY_ERROR;
    CT_ERR_MSG("VerifyData\n");
    goto end_wr_rd;
  }
 end_wr_rd:
  if (rbuf) {
    free(rbuf);
  }
  return ret;
}

static int wr8_rd8_burst (DWORD initAddr, DWORD len8, BYTE* wbuf, DWORD cs)
{
  int ret = NO_ERROR;
  DWORD addr;
  BYTE* rbuf;
  DWORD mbrReg;
  
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_wr_rd;
  }

  rbuf = (BYTE*)malloc(len8);
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_wr_rd;
  }
  
  addr = initAddr + mbrReg;
  CT_MSG("Addr 0x%08X: %d-len Write8 -> Read8\n", addr, len8);
  ret = RPC2_WRITE8(addr, len8, wbuf);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("RPC2_WRITE8: %d\n", ret);
    goto end_wr_rd;
  }
  ret = RPC2_READ8(addr, len8, rbuf);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("RPC2_READ8: %d\n", ret);
    goto end_wr_rd;
  }
  if (verifyData8(rbuf, wbuf, len8)) {
    ret = VERIFY_ERROR;
    CT_ERR_MSG("VerifyData8\n");
  }
 end_wr_rd:
  if (rbuf) {
    free(rbuf);
  }
  return ret;
}

#if 0
static int wr32_rd32_burst (DWORD initAddr, DWORD len32, DWORD* wbuf, DWORD cs)
{
  int ret = NO_ERROR;
  DWORD addr;
  DWORD* rbuf;
  DWORD mbrReg;
  DWORD len8 = (sizeof(DWORD)*len32) - initAddr%sizeof(DWORD);

  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_wr_rd;
  }
  
  rbuf = (DWORD*)malloc(sizeof(DWORD)*len32);
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_wr_rd;
  }
  
  addr = initAddr + mbrReg;
  CT_MSG("Addr 0x%08X: %d len Write -> Read\n", addr, len32);
  ret = RPC2_WRITE32(addr, len32, wbuf);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("RPC2_WRITE32: %d\n", ret);
    goto end_wr_rd;
  }
  ret = RPC2_READ32(addr, len32, rbuf);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("RPC2_READ32: %d\n", ret);
    goto end_wr_rd;
  }
  if (verifyData8((BYTE*)rbuf, (BYTE*)wbuf, len8)) {
    ret = VERIFY_ERROR;
    CT_ERR_MSG("VerifyData\n");
  }
 end_wr_rd:
  if (rbuf) {
    free(rbuf);
  }
  return ret;
}
#endif

static int sequential_wr16 (DWORD initAddr, DWORD len16, int transNum, WORD* wbuf)
{
  int ret = NO_ERROR;
  int i;

  CT_MSG("Sequential Write addr 0x%08X, len16 0x%x x%d\n", initAddr, len16, transNum);
  for (i = 0; i < transNum; i++) {
    RPC_WRITE_BURST(initAddr + sizeof(WORD)*len16*i, len16, &wbuf[len16*i]);
  }
  for (i = 0; i < transNum; i++) {
    ret = RPC_GET_WRESP();
    if (ret != NO_ERROR) {
      CT_MSG("RPC2_WRITE_BURST: %d\n", ret);
      return ret;
    }
  }
  return ret;
}

static int sequential_wr_incaddr (DWORD initAddr, DWORD incAddr, DWORD len16, int transNum, WORD* wbuf)
{
  int ret = NO_ERROR;
  int i;

  CT_MSG("Sequential Write addr 0x%08X, len16 0x%x x%d\n", initAddr, len16, transNum);
  for (i = 0; i < transNum; i++) {
    RPC_WRITE_BURST(initAddr + (sizeof(WORD)*len16 + incAddr)*i, len16, &wbuf[len16*i]);
  }
  for (i = 0; i < transNum; i++) {
    ret = RPC_GET_WRESP();
    if (ret != NO_ERROR) {
      CT_MSG("RPC2_WRITE_BURST: %d\n", ret);
      return ret;
    }
  }
  return ret;
}

static int sequential_wr8 (DWORD initAddr, DWORD len8, int transNum, BYTE* wbuf)
{
  int ret = NO_ERROR;
  int i;

  CT_MSG("Sequential Write addr 0x%08X, len8 0x%x x%d\n", initAddr, len8, transNum);
  for (i = 0; i < transNum; i++) {
    RPC_WRITE_BURST8(initAddr + sizeof(BYTE)*len8*i, len8, &wbuf[len8*i]);
  }
  for (i = 0; i < transNum; i++) {
    ret = RPC_GET_WRESP();
    if (ret != NO_ERROR) {
      CT_MSG("RPC2_WRITE_BURST8: %d\n", ret);
      return ret;
    }
  }
  return ret;
}

static int sequential_wr32 (DWORD initAddr, DWORD len, int transNum, DWORD* wbuf)
{
  int ret = NO_ERROR;
  int i;

  CT_MSG("Sequential Write addr 0x%08X, len32 0x%x x%d\n", initAddr, len, transNum);
  for (i = 0; i < transNum; i++) {
    RPC_WRITE_BURST32(initAddr + sizeof(DWORD)*len*i, len, &wbuf[len*i]);
  }
  for (i = 0; i < transNum; i++) {
    ret = RPC_GET_WRESP();
    if (ret != NO_ERROR) {
      CT_MSG("RPC2_WRITE_BURST32: %d\n", ret);
      return ret;
    }
  }
  return ret;
}

// @param burst 0: wrap, 1: incr
static int sequential_rd16 (DWORD initAddr, DWORD len16, int transNum, WORD* rbuf, int burst)
{
  int ret = NO_ERROR;
  int i;

  CT_MSG("Sequential Read addr 0x%08X, len16 0x%x x%d\n", initAddr, len16, transNum);
  for (i = 0; i < transNum; i++) {
    if (burst == 0) {
      RPC_READ_WRAP_BURST(initAddr + sizeof(WORD)*len16*i, len16);
    }
    else {
      RPC_READ_BURST(initAddr + sizeof(WORD)*len16*i, len16);
    }
  }
  for (i = 0; i < transNum; i++) {
    ret = RPC2_GET_DATA(len16, &rbuf[len16*i]);
    if (ret != NO_ERROR) {
      CT_MSG("RPC2_READ_BURST: %d\n", ret);
      return ret;
    }
  }

  return ret;
}

static int sequential_rd_incaddr (DWORD initAddr, DWORD incAddr, DWORD len16, int transNum, WORD* rbuf, int burst)
{
  int ret = NO_ERROR;
  int i;

  CT_MSG("Sequential Read addr 0x%08X, len16 0x%x x%d\n", initAddr, len16, transNum);
  for (i = 0; i < transNum; i++) {
    if (burst == 0) {
      RPC_READ_WRAP_BURST(initAddr + (sizeof(WORD)*len16 + incAddr)*i, len16);
    }
    else {
      RPC_READ_BURST(initAddr + (sizeof(WORD)*len16 + incAddr)*i, len16);
    }
  }
  for (i = 0; i < transNum; i++) {
    ret = RPC2_GET_DATA(len16, &rbuf[len16*i]);
    if (ret != NO_ERROR) {
      CT_MSG("RPC2_READ_BURST: %d\n", ret);
      return ret;
    }
  }

  return ret;
}

static int sequential_rd8 (DWORD initAddr, DWORD len8, int transNum, BYTE* rbuf, int burst)
{
  int ret = NO_ERROR;
  int i;

  CT_MSG("Sequential Read addr 0x%08X, len8 0x%x x%d\n", initAddr, len8, transNum);
  for (i = 0; i < transNum; i++) {
    if (burst == 0) {
      RPC_READ_WRAP_BURST8(initAddr + len8*i, len8);
    }
    else {
      RPC_READ_BURST8(initAddr + len8*i, len8);
    }
  }
  for (i = 0; i < transNum; i++) {
    ret = RPC2_GET_DATA8(len8, &rbuf[len8*i]);
    if (ret != NO_ERROR) {
      CT_MSG("RPC2_READ_BURST8: %d\n", ret);
      return ret;
    }
  }

  return ret;
}

// @param burst 0: wrap, 1: incr
static int sequential_rd32 (DWORD initAddr, DWORD len, int transNum, DWORD* rbuf, int burst)
{
  int ret = NO_ERROR;
  int i;

  CT_MSG("Sequential Read addr 0x%08X, len32 0x%x x%d\n", initAddr, len, transNum);
  for (i = 0; i < transNum; i++) {
    if (burst == 0) {
      RPC_READ_WRAP_BURST32(initAddr + sizeof(DWORD)*len*i, len);
    }
    else {
      RPC_READ_BURST32(initAddr + sizeof(DWORD)*len*i, len);
    }
  }
  for (i = 0; i < transNum; i++) {
    ret = RPC2_GET_DATA32(len, &rbuf[len*i]);
    if (ret != NO_ERROR) {
      CT_MSG("RPC2_READ_BURST32: %d\n", ret);
      return ret;
    }
  }

  return ret;
}

static int sequential_rd (DWORD initAddr, DWORD size, DWORD len, int transNum, void* rbuf, int burst)
{
  int ret = NO_ERROR;

  switch (size) {
  case BYTE_1:
    ret = sequential_rd8(initAddr, len, transNum, (BYTE*)rbuf, burst);
    break;
  case BYTE_2:
    ret = sequential_rd16(initAddr, len, transNum, (WORD*)rbuf, burst);
    break;
  case BYTE_4:
    ret = sequential_rd32(initAddr, len, transNum, (DWORD*)rbuf, burst);
  default:
    break;
  }
  return ret;
}

static int sequential_wr (DWORD initAddr, DWORD size, DWORD len, int transNum, void* wbuf)
{
  int ret = NO_ERROR;

  switch (size) {
  case BYTE_1:
    ret = sequential_wr8(initAddr, len, transNum, (BYTE*)wbuf);
    break;
  case BYTE_2:
    ret = sequential_wr16(initAddr, len, transNum, (WORD*)wbuf);
    break;
  case BYTE_4:
    ret = sequential_wr32(initAddr, len, transNum, (DWORD*)wbuf);
  default:
    break;
  }
  return ret;
}

#if 0
static int sequential_wr_rd (DWORD initAddr, DWORD size, DWORD len, int transNum, void* wbuf, void* rbuf, int rburst)
{
  int ret = NO_ERROR;

  switch (size) {
  case BYTE_1:
    ret = sequential_wr8(initAddr, len, transNum, (BYTE*)wbuf);
    if (ret != NO_ERROR) break;
    ret = sequential_rd8(initAddr, len, transNum, (BYTE*)rbuf, rburst);
    break;
  case BYTE_2:
    ret = sequential_wr16(initAddr, len, transNum, (WORD*)wbuf);
    if (ret != NO_ERROR) break;
    ret = sequential_rd16(initAddr, len, transNum, (WORD*)rbuf, rburst);
    break;
  case BYTE_4:
    ret = sequential_wr32(initAddr, len, transNum, (DWORD*)wbuf);
    if (ret != NO_ERROR) break;
    ret = sequential_rd32(initAddr, len, transNum, (DWORD*)rbuf, rburst);
  default:
    break;
  }
  return ret;
}
#endif

// @param burst 0: wrap, 1: incr
static int sequential_wr_2cs (TBurstParam *pTBurstParam0, int transNum0, WORD *wbuf0, \
                              TBurstParam *pTBurstParam1, int transNum1, WORD *wbuf1)
{
  int ret = NO_ERROR;
  int i;

  CT_MSG("Sequential Write addr0 0x%08X, len 0x%x x%d => addr1 0x%08X, len 0x%x x%d\n", \
                                    pTBurstParam0->addr, pTBurstParam0->len, transNum0, \
                                    pTBurstParam1->addr, pTBurstParam1->len, transNum1);
  for (i = 0; i < transNum0; i++) {
    RPC_WRITE_BURST(pTBurstParam0->addr + sizeof(WORD)*pTBurstParam0->len*i, pTBurstParam0->len, &wbuf0[pTBurstParam0->len*i]);
  }
  for (i = 0; i < transNum1; i++) {
    RPC_WRITE_BURST(pTBurstParam1->addr + sizeof(WORD)*pTBurstParam1->len*i, pTBurstParam1->len, &wbuf1[pTBurstParam1->len*i]);
  }
  for (i = 0; i < transNum0; i++) {
    ret = RPC_GET_WRESP();
    if (ret != NO_ERROR) {
      CT_MSG("RPC_GET_WRESP addr0: %d\n", ret);
      return ret;
    }
  }
  for (i = 0; i < transNum1; i++) {
    ret = RPC_GET_WRESP();
    if (ret != NO_ERROR) {
      CT_MSG("RPC_GET_WRESP addr1: %d\n", ret);
      return ret;
    }
  }

  return ret;
}

// @param burst 0: wrap, 1: incr
static int sequential_rd_2cs (TBurstParam *pTBurstParam0, int transNum0, WORD *rbuf0, \
                              TBurstParam *pTBurstParam1, int transNum1, WORD *rbuf1)
{
  int ret = NO_ERROR;
  int i;

  CT_MSG("Sequential Read addr0 0x%08X, len 0x%x x%d => addr1 0x%08X, len 0x%x x%d\n", \
                                   pTBurstParam0->addr, pTBurstParam0->len, transNum0, \
                                   pTBurstParam1->addr, pTBurstParam1->len, transNum1);
  for (i = 0; i < transNum0; i++) {
    if (pTBurstParam0->burst == 0) {
      RPC_READ_WRAP_BURST(pTBurstParam0->addr + sizeof(WORD)*pTBurstParam0->len*i, pTBurstParam0->len);
    }
    else {
      RPC_READ_BURST(pTBurstParam0->addr + sizeof(WORD)*pTBurstParam0->len*i, pTBurstParam0->len);
    }
  }
  for (i = 0; i < transNum1; i++) {
    if (pTBurstParam1->burst == 0) {
      RPC_READ_WRAP_BURST(pTBurstParam1->addr + sizeof(WORD)*pTBurstParam1->len*i, pTBurstParam1->len);
    }
    else {
      RPC_READ_BURST(pTBurstParam1->addr + sizeof(WORD)*pTBurstParam1->len*i, pTBurstParam1->len);
    }
  }
  for (i = 0; i < transNum0; i++) {
    ret = RPC2_GET_DATA(pTBurstParam0->len, &rbuf0[pTBurstParam0->len*i]);
    if (ret != NO_ERROR) {
      CT_MSG("RPC2_READ_BURST addr0: %d\n", ret);
      return ret;
    }
  }
  for (i = 0; i < transNum1; i++) {
    ret = RPC2_GET_DATA(pTBurstParam1->len, &rbuf1[pTBurstParam1->len*i]);
    if (ret != NO_ERROR) {
      CT_MSG("RPC2_READ_BURST addr1: %d\n", ret);
      return ret;
    }
  }

  return ret;
}

static int sub_concurrent_wr_rd_2cs (DWORD turn, TBurstParam **ppTBurstParam)
{
  int i;
  int ret = NO_ERROR;

  BYTE wresp[2];
  BYTE rresp[2][MAX_LEN];
  DWORD addr[0];
  DWORD len[2];
  DWORD len8[2];
  DWORD len16[2];
  DWORD burst[2];
  DWORD size[2];
  WORD *wbuf[2], *rbuf[2];

  int XferByte[2];

  for (i = 0; i < 2; i++) {
    addr[i]  = ppTBurstParam[i]->addr;
    len[i]   = ppTBurstParam[i]->len;
    burst[i] = ppTBurstParam[i]->burst;
    size[i]  = ppTBurstParam[i]->size;

    if (len[i] > MAX_LEN) {
      CT_ERR_MSG("Can't support Addr 0x%08X %d-req length\n", addr[i], len[i]);
      ret = NOT_SUPPORT;
      goto end_wr_rd;
    }

    XferByte[i] = 1 << size[i];
    len8[i]  = (XferByte[i]*len[i])-addr[i]%XferByte[i];
    len16[i] = (XferByte[i]*len8[i]+(sizeof(WORD)-1))/sizeof(WORD);

    wbuf[i] = (WORD*)malloc(XferByte[i]*len8[i]);
    if (!wbuf[i]) {
      CT_ERR_MSG("Can't allocate memory for Addr 0x%08X write data\n", addr[i]);
      ret = ALLOC_ERROR;
      goto end_wr_rd;
    }
    rbuf[i] = (WORD*)malloc(XferByte[i]*len8[i]);
    if (!rbuf[i]) {
      CT_ERR_MSG("Can't allocate memory for Addr 0x%08X read data\n", addr[i]);
      ret = ALLOC_ERROR;
      goto end_wr_rd;
    }

    fillBuffer(ppTBurstParam[i]->pattern, wbuf[i], len16[i]);
    CT_MSG("Data Pattern for Addr 0x%08X\n", addr[i]);
    printBuffer(wbuf[i], len16[i]);
  }

  // Write wbuf[1] before concurrent_wr_rd
  CT_MSG("Write: Addr=0x%08X len=0x%03X burst=%1d size=%1d\n", addr[1], len[1], burst[1], size[1]);
  writeBurst(MEM, addr[1], len[1], burst[1], size[1], wbuf[1]);
  getWriteResp(MEM, &wresp[1]);
  if (wresp[1]) {
    CT_ERR_MSG("Write Response 0x%x\n", wresp[1]);
    ret = RESP_ERROR;
    goto end_wr_rd;
  }

  if (turn == WRITE_AHEAD) {
    // 2CS Concurrent Write -> Read
    CT_MSG("2CS Concurrent Write: Addr=0x%08X len=0x%03X burst=%1d size=%1d\n", addr[0], len[0], burst[0], size[0]);
    CT_MSG("               Read : Addr=0x%08X len=0x%03X burst=%1d size=%1d\n", addr[1], len[1], burst[1], size[1]);
    writeBurst(MEM, addr[0], len[0], burst[0], size[0], wbuf[0]);
    readBurst(MEM, addr[1], len[1], burst[1], size[1]);
    getWriteResp(MEM, &wresp[0]);
    getReadDataResp(MEM, len[1], size[1], rbuf[1], rresp[1]);
  } else if (turn == READ_AHEAD) {
    // 2CS Concurrent Read -> Write
    CT_MSG("2CS Concurrent Read : Addr=0x%08X len=0x%03X burst=%1d size=%1d\n", addr[1], len[1], burst[1], size[1]);
    CT_MSG("               Write: Addr=0x%08X len=0x%03X burst=%1d size=%1d\n", addr[0], len[0], burst[0], size[0]);
    readBurst(MEM, addr[1], len[1], burst[1], size[1]);
    writeBurst(MEM, addr[0], len[0], burst[0], size[0], wbuf[0]);
    getReadDataResp(MEM, len[1], size[1], rbuf[1], rresp[1]);
    getWriteResp(MEM, &wresp[0]);
  } else {
    CT_ERR_MSG("Parameter error. Select lead transaction of WRITE_AHEAD(0) or READ_AHEAD(1)\n");
    ret = NOT_SUPPORT;
    goto end_wr_rd;
  }

  // addr0 write response check
  if (wresp[0]) {
    CT_ERR_MSG("Write Response 0x%x\n", wresp[0]);
    ret = RESP_ERROR;
    goto end_wr_rd;
  }

  // addr1 read response check
  for (i = 0; i < len[1]; i++) {
    if (rresp[1][i]) {
      CT_ERR_MSG("Read Response %d: 0x%x\n", i, rresp[1][i]);
      ret = RESP_ERROR;
      goto end_wr_rd;
    }
  }
  // addr1 verify check
  if (verifyData8((BYTE*)(rbuf[1]), (BYTE*)(wbuf[1]), len8[1])) {
    ret = VERIFY_ERROR;
    CT_ERR_MSG("Addr=0x%08X VerifyData\n",addr[1]);
    goto end_wr_rd;
  }

  // Read addr0 for verify write data
  CT_MSG("Read: Addr=0x%08X len=0x%03X burst=%1d size=%1d\n", addr[0], len[0], burst[0], size[0]);
  readBurst(MEM, addr[0], len[0], burst[0], size[0]);
  getReadDataResp(MEM, len[0], size[0], rbuf[0], rresp[0]);
  // addr0 read response check
  for (i = 0; i < len[0]; i++) {
    if (rresp[0][i]) {
      CT_ERR_MSG("Read Response %d: 0x%x\n", i, rresp[0][i]);
      ret = RESP_ERROR;
      goto end_wr_rd;
    }
  }
  // addr0 verify check
  if (verifyData8((BYTE*)(rbuf[0]), (BYTE*)(wbuf[0]), len8[0])) {
    ret = VERIFY_ERROR;
    CT_ERR_MSG("Addr=0x%08X VerifyData\n",addr[0]);
    goto end_wr_rd;
  }

 end_wr_rd:
  for (i=0; i<2; i++) {
    if (wbuf[i]) {
      free(wbuf[i]);
    }
    if (rbuf[i]) {
      free(rbuf[i]);
    }
  }
  return ret;
}

#if (RPC2_CTRL_IP_VER >= 240)
static int sub_concurrent_wr_rd_outstanding_2cs (TBurstParam **wppTBurstParam, \
                                                 DWORD w_outstanding_cnt,      \
                                                 TBurstParam **rppTBurstParam, \
                                                 DWORD r_outstanding_cnt,      \
                                                 DWORD check_arbitration)
{
  int i, j;
  int ret = NO_ERROR;

  DWORD rest_outstanding_cnt;
  BYTE *wresp, *rwresp;
  BYTE **wrresp,**rresp;
  WORD **wbuf,  **wrbuf;
  WORD **rwbuf, **rbuf;
  DWORD *waddr, *wlen, *wburst, *wsize, *wlen8, *wlen16;
  DWORD *raddr, *rlen, *rburst, *rsize, *rlen8, *rlen16;
  DWORD *cs_neg_cnt_write, *cs_neg_cnt_read;
  DWORD expected_wta, expected_rta;
  DWORD write_cs;
  int *wXferByte, *rXferByte;

  wresp     = (BYTE*)malloc(w_outstanding_cnt);
  wrresp    = (BYTE**)malloc((sizeof (BYTE*))*w_outstanding_cnt);
  wbuf      = (WORD**)malloc((sizeof (WORD*))*w_outstanding_cnt);
  wrbuf     = (WORD**)malloc((sizeof (WORD*))*w_outstanding_cnt);
  waddr     = (DWORD*)malloc(w_outstanding_cnt*sizeof(DWORD));
  wlen      = (DWORD*)malloc(w_outstanding_cnt*sizeof(DWORD));
  wburst    = (DWORD*)malloc(w_outstanding_cnt*sizeof(DWORD));
  wsize     = (DWORD*)malloc(w_outstanding_cnt*sizeof(DWORD));
  wlen8     = (DWORD*)malloc(w_outstanding_cnt*sizeof(DWORD));
  wlen16    = (DWORD*)malloc(w_outstanding_cnt*sizeof(DWORD));
  wXferByte = (int*)malloc(w_outstanding_cnt*sizeof(DWORD));

  rwresp    = (BYTE*)malloc(r_outstanding_cnt);
  rresp     = (BYTE**)malloc((sizeof (BYTE*))*r_outstanding_cnt);
  rwbuf     = (WORD**)malloc((sizeof (WORD*))*r_outstanding_cnt);
  rbuf      = (WORD**)malloc((sizeof (WORD*))*r_outstanding_cnt);
  raddr     = (DWORD*)malloc(r_outstanding_cnt*sizeof(DWORD));
  rlen      = (DWORD*)malloc(r_outstanding_cnt*sizeof(DWORD));
  rburst    = (DWORD*)malloc(r_outstanding_cnt*sizeof(DWORD));
  rsize     = (DWORD*)malloc(r_outstanding_cnt*sizeof(DWORD));
  rlen8     = (DWORD*)malloc(r_outstanding_cnt*sizeof(DWORD));
  rlen16    = (DWORD*)malloc(r_outstanding_cnt*sizeof(DWORD));
  rXferByte = (int*)malloc(r_outstanding_cnt*sizeof(DWORD));

  for (i = 0; i < w_outstanding_cnt; i++) {
    waddr[i]  = wppTBurstParam[i]->addr;
    wlen[i]   = wppTBurstParam[i]->len;
    wburst[i] = wppTBurstParam[i]->burst;
    wsize[i]  = wppTBurstParam[i]->size;

    if (wlen[i] > MAX_LEN) {
      CT_ERR_MSG("Can't support Write Addr 0x%08X %d-req length\n", waddr[i], wlen[i]);
      ret = NOT_SUPPORT;
      goto end_wr_rd;
    }
    wXferByte[i] = 1 << wsize[i];
    wlen8[i]  = (wXferByte[i]*wlen[i])-waddr[i]%wXferByte[i];
    wlen16[i] = (wXferByte[i]*wlen8[i]+(sizeof(WORD)-1))/sizeof(WORD);

    wbuf[i] = (WORD*)malloc(wXferByte[i]*wlen8[i]);
    if (!wbuf[i]) {
      CT_ERR_MSG("Can't allocate memory for Addr 0x%08X write data\n", waddr[i]);
      ret = ALLOC_ERROR;
      goto end_wr_rd;
    }
    fillBuffer(wppTBurstParam[i]->pattern, wbuf[i], wlen16[i]);
    CT_MSG("Data Pattern for Addr 0x%08X\n", waddr[i]);
    printBuffer(wbuf[i], wlen16[i]);
    wrbuf[i]  = (WORD*)malloc(wXferByte[i]*wlen8[i]);
    wrresp[i] = (BYTE*)malloc(MAX_LEN);
    if (!wrbuf[i]) {
      CT_ERR_MSG("Can't allocate memory for Addr 0x%08X read data\n", waddr[i]);
      ret = ALLOC_ERROR;
      goto end_wr_rd;
    }
  }

  for (i = 0; i < r_outstanding_cnt; i++) {
    raddr[i]  = rppTBurstParam[i]->addr;
    rlen[i]   = rppTBurstParam[i]->len;
    rburst[i] = rppTBurstParam[i]->burst;
    rsize[i]  = rppTBurstParam[i]->size;

    if (rlen[i] > MAX_LEN) {
      CT_ERR_MSG("Can't support Read Addr 0x%08X %d-req length\n", raddr[i], rlen[i]);
      ret = NOT_SUPPORT;
      goto end_wr_rd;
    }
    rXferByte[i] = 1 << rsize[i];
    rlen8[i]  = (rXferByte[i]*rlen[i])-raddr[i]%rXferByte[i];
    rlen16[i] = (rXferByte[i]*rlen8[i]+(sizeof(WORD)-1))/sizeof(WORD);

    rbuf[i]  = (WORD*)malloc(rXferByte[i]*rlen8[i]);
    rresp[i] = (BYTE*)malloc(MAX_LEN);
    if (!rbuf[i]) {
      CT_ERR_MSG("Can't allocate memory for Addr 0x%08X read data\n", raddr[i]);
      ret = ALLOC_ERROR;
      goto end_wr_rd;
    }
    rwbuf[i] = (WORD*)malloc(rXferByte[i]*rlen8[i]);
    if (!rwbuf[i]) {
      CT_ERR_MSG("Can't allocate memory for Addr 0x%08X write data\n", raddr[i]);
      ret = ALLOC_ERROR;
      goto end_wr_rd;
    }
    fillBuffer(rppTBurstParam[i]->pattern, rwbuf[i], rlen16[i]);
    CT_MSG("Data Pattern for Addr 0x%08X\n", raddr[i]);
    printBuffer(rwbuf[i], rlen16[i]);
  }

  // Write rbuf x r_outstanding_cnt before concurrent write/read
  for (i = 0; i < r_outstanding_cnt; i++) {
    CT_MSG("Write #%2d: raddr=0x%08X rlen=0x%03X rburst=%1d rsize=%1d\n", i, raddr[i], rlen[i], rburst[i], rsize[i]);
    writeBurst(MEM, raddr[i], rlen[i], rburst[i], rsize[i], rwbuf[i]);
  }
  for (i = 0; i < r_outstanding_cnt; i++) {
    getWriteResp(MEM, &rwresp[i]);
    if (rwresp[i]) {
      CT_ERR_MSG("Write Response 0x%x\n", rwresp[i]);
      ret = RESP_ERROR;
      goto end_wr_rd;
    }
  }

  if (check_arbitration) {
    cs_neg_cnt_write = (DWORD*)malloc(check_arbitration*sizeof(DWORD));
    cs_neg_cnt_read  = (DWORD*)malloc(check_arbitration*sizeof(DWORD));
    getWTA (&expected_wta);
    getRTA (&expected_rta);
    getCsNum (waddr[0], &write_cs);
    start2CScntArbitration(write_cs);
  }

  // 2CS concurrent outstanding write/read
  if (w_outstanding_cnt < r_outstanding_cnt) {
    rest_outstanding_cnt = w_outstanding_cnt;
    for (i = 0; i < r_outstanding_cnt; i++) {
      if (rest_outstanding_cnt) {
        CT_MSG("2CS Concurrent Write: Addr=0x%08X len=0x%03X burst=%1d size=%1d\n", waddr[i], wlen[i], wburst[i], wsize[i]);
      }
      CT_MSG("               Read : Addr=0x%08X len=0x%03X burst=%1d size=%1d\n", raddr[i], rlen[i], rburst[i], rsize[i]);
      if (rest_outstanding_cnt) {
        writeBurst(MEM, waddr[i], wlen[i], wburst[i], wsize[i], wbuf[i]);
      }
      readBurst(MEM, raddr[i], rlen[i], rburst[i], rsize[i]);
      if (rest_outstanding_cnt) rest_outstanding_cnt--;
    }
    rest_outstanding_cnt = w_outstanding_cnt;
    for (i = 0; i < r_outstanding_cnt; i++) {
      if (rest_outstanding_cnt) {
        getWriteResp(MEM, &wresp[i]);
        if (wresp[i]) {
          CT_ERR_MSG("Write Response 0x%x\n", wresp[i]);
          ret = RESP_ERROR;
          goto end_wr_rd;
        }
      }
      getReadDataResp(MEM, rlen[i], rsize[i], rbuf[i], rresp[i]);
      for (j = 0; j < rlen[j]; j++) {
        if (rresp[i][j]) {
          CT_ERR_MSG("Read Response %d: 0x%x\n", i, rresp[i][j]);
          ret = RESP_ERROR;
          goto end_wr_rd;
        }
      }
      if (rest_outstanding_cnt) rest_outstanding_cnt--;
    }
  } else {
    rest_outstanding_cnt = r_outstanding_cnt;
    for (i = 0; i < w_outstanding_cnt; i++) {
      CT_MSG("2CS Concurrent Write: Addr=0x%08X len=0x%03X burst=%1d size=%1d\n", waddr[i], wlen[i], wburst[i], wsize[i]);
      if (rest_outstanding_cnt) {
        CT_MSG("               Read : Addr=0x%08X len=0x%03X burst=%1d size=%1d\n", raddr[i], rlen[i], rburst[i], rsize[i]);
      }
      writeBurst(MEM, waddr[i], wlen[i], wburst[i], wsize[i], wbuf[i]);
      if (rest_outstanding_cnt) {
        readBurst(MEM, raddr[i], rlen[i], rburst[i], rsize[i]);
        rest_outstanding_cnt--;
      }
    }
    rest_outstanding_cnt = r_outstanding_cnt;
    for (i = 0; i < w_outstanding_cnt; i++) {
      getWriteResp(MEM, &wresp[i]);
      if (wresp[i]) {
        CT_ERR_MSG("Write Response 0x%x\n", wresp[i]);
        ret = RESP_ERROR;
        goto end_wr_rd;
      }
      if (rest_outstanding_cnt) {
        getReadDataResp(MEM, rlen[i], rsize[i], rbuf[i], rresp[i]);
        for (j = 0; j < rlen[j]; j++) {
          if (rresp[i][j]) {
            CT_ERR_MSG("Read Response %d: 0x%x\n", i, rresp[i][j]);
            ret = RESP_ERROR;
            goto end_wr_rd;
          }
        }
        rest_outstanding_cnt--;
      }
    }
  }

  if (check_arbitration) {
    end2CScntArbitration();
    get2CScntArbitration(check_arbitration,cs_neg_cnt_write,cs_neg_cnt_read);
    rest_outstanding_cnt = w_outstanding_cnt;
    CT_MSG("Arbitration Check %d count: Write %d tran, Read %d trans\n", check_arbitration, expected_wta+1, expected_rta+1);
    for (i=0; i<check_arbitration;i++){
      CT_MSG("Write %d: %d trans.\n", i, cs_neg_cnt_write[i]);
      CT_MSG("Read %d:  %d trans.\n", i, cs_neg_cnt_read[i]);

      if (rest_outstanding_cnt < (expected_wta+1)) {
        expected_wta = rest_outstanding_cnt - 1;
      }

      if (cs_neg_cnt_write[i] != expected_wta+1) {
        ret = VERIFY_ERROR;
        CT_ERR_MSG("Write transaction count mismatch\n");
        goto end_wr_rd;
      }
      if ((i < check_arbitration-1) && (cs_neg_cnt_read[i] != expected_rta+1)) {
        ret = VERIFY_ERROR;
        CT_ERR_MSG("Read transaction count mismatch\n");
        goto end_wr_rd;
      }
      rest_outstanding_cnt -= (expected_wta+1);
    }
  }

  // Read Data verify check
  for (i = 0; i < r_outstanding_cnt; i++) {
    if (verifyData8((BYTE*)(rbuf[i]), (BYTE*)(rwbuf[i]), rlen8[i])) {
      ret = VERIFY_ERROR;
      CT_ERR_MSG("Addr=0x%08X VerifyData\n",raddr[i]);
      goto end_wr_rd;
    }
  }
  // Read for verify write data
  for (i = 0; i < w_outstanding_cnt; i++) {
    CT_MSG("Read #%2d: waddr=0x%08X wlen=0x%03X wburst=%1d wsize=%1d\n", i, waddr[i], wlen[i], wburst[i], wsize[i]);
    readBurst(MEM, waddr[i], wlen[i], wburst[i], wsize[i]);
    getReadDataResp(MEM, wlen[i], wsize[i], wrbuf[i], wrresp[i]);
    // addr0 read response check
    for (j = 0; j < wlen[i]; j++) {
      if (wrresp[i][j]) {
        CT_ERR_MSG("Read Response %d: 0x%x\n", i, wrresp[i][j]);
        ret = RESP_ERROR;
        goto end_wr_rd;
      }
    }
    // addr0 verify check
    if (verifyData8((BYTE*)(wrbuf[i]), (BYTE*)(wbuf[i]), wlen8[i])) {
      ret = VERIFY_ERROR;
      CT_ERR_MSG("Addr=0x%08X VerifyData\n",waddr[i]);
      goto end_wr_rd;
    }
  }
 end_wr_rd:
  if (check_arbitration) {
    if (cs_neg_cnt_write)   free(cs_neg_cnt_write);
    if (cs_neg_cnt_read)    free(cs_neg_cnt_read);
  }
  if (wresp)      free(wresp);
  if (waddr)      free(waddr);
  if (wlen)       free(wlen);
  if (wburst)     free(wburst);
  if (wsize)      free(wsize);
  if (wlen8)      free(wlen16);
  if (wXferByte)  free(wXferByte);
  if (wrresp) {
    for (i = 0; i < w_outstanding_cnt; i++) {
      if (wrresp[i])  free (wrresp[i]);
    }
    free(wrresp);
  }
  if (wbuf) {
    for (i = 0; i < w_outstanding_cnt; i++) {
      if (wbuf[i])  free (wbuf[i]);
    }
    free(wbuf);
  }
  if (wrbuf) {
    for (i = 0; i < w_outstanding_cnt; i++) {
      if (wrbuf[i])  free (wrbuf[i]);
    }
    free(wrbuf);
  }

  if (rwresp)     free(rwresp);
  if (raddr)      free(raddr);
  if (rlen)       free(rlen);
  if (rburst)     free(rburst);
  if (rsize)      free(rsize);
  if (rlen8)      free(rlen16);
  if (rXferByte)  free(rXferByte);

  if (rresp) {
    for (i = 0; i < r_outstanding_cnt; i++) {
      if (rresp[i])  free (rresp[i]);
    }
    free(rresp);
  }
  if (rbuf) {
    for (i = 0; i < r_outstanding_cnt; i++) {
      if (rbuf[i])  free (rbuf[i]);
    }
    free(rbuf);
  }
  if (rwbuf) {
    for (i = 0; i < r_outstanding_cnt; i++) {
      if (rwbuf[i])  free (rwbuf[i]);
    }
    free(rwbuf);
  }
  return ret;
}
#endif

static int sub_alternative_wr_rd_2cs (TBurstParam **ppTBurstParam)
{
  int i, j;
  int ret = NO_ERROR;

  BYTE wresp[2];
  BYTE rresp[2][MAX_LEN];
  DWORD addr[0];
  DWORD len[2];
  DWORD len8[2];
  DWORD len16[2];
  DWORD burst[2];
  DWORD size[2];
  WORD *wbuf[2], *rbuf[2];

  int XferByte[2];

  for (i = 0; i < 2; i++) {
    addr[i]  = ppTBurstParam[i]->addr;
    len[i]   = ppTBurstParam[i]->len;
    burst[i] = ppTBurstParam[i]->burst;
    size[i]  = ppTBurstParam[i]->size;

    if (len[i] > MAX_LEN) {
      CT_ERR_MSG("Can't support Addr 0x%08X %d-req length\n", addr[i], len[i]);
      ret = NOT_SUPPORT;
      goto end_wr_rd;
    }

    XferByte[i] = 1 << size[i];
    len8[i]  = (XferByte[i]*len[i])-addr[i]%XferByte[i];
    len16[i] = (XferByte[i]*len8[i]+(sizeof(WORD)-1))/sizeof(WORD);

    wbuf[i] = (WORD*)malloc(XferByte[i]*len8[i]);
    if (!wbuf[i]) {
      CT_ERR_MSG("Can't allocate memory for Addr 0x%08X write data\n", addr[i]);
      ret = ALLOC_ERROR;
      goto end_wr_rd;
    }
    rbuf[i] = (WORD*)malloc(XferByte[i]*len8[i]);
    if (!rbuf[i]) {
      CT_ERR_MSG("Can't allocate memory for Addr 0x%08X read data\n", addr[i]);
      ret = ALLOC_ERROR;
      goto end_wr_rd;
    }

    fillBuffer(ppTBurstParam[i]->pattern, wbuf[i], len16[i]);
    CT_MSG("Data Pattern for Addr 0x%08X\n", addr[i]);
    printBuffer(wbuf[i], len16[i]);
  }

  // 2CS Alternative Write
  CT_MSG("2CS Alternative Write0: addr0=0x%08X len=0x%03X burst=%1d size=%1d\n", addr[0], len[0], burst[0], size[0]);
  CT_MSG("                Write1: addr1=0x%08X len=0x%03X burst=%1d size=%1d\n", addr[1], len[1], burst[1], size[1]);
  writeBurst(MEM, addr[0], len[0], burst[0], size[0], wbuf[0]);
  writeBurst(MEM, addr[1], len[1], burst[1], size[1], wbuf[1]);

  // 2CS write response check
  getWriteResp(MEM, &wresp[0]);
  getWriteResp(MEM, &wresp[1]);
  for (i = 0; i < 2; i++) {
    if (wresp[i]) {
      CT_ERR_MSG("Write %1d Response 0x%x\n", wresp[i]);
      ret = RESP_ERROR;
      goto end_wr_rd;
    }
  }

  // 2CS Alternative Read
  CT_MSG("2CS Alternative Read0: addr0=0x%08X len=0x%03X burst=%1d size=%1d\n", addr[0], len[0], burst[0], size[0]);
  CT_MSG("                Read1: addr1=0x%08X len=0x%03X burst=%1d size=%1d\n", addr[1], len[1], burst[1], size[1]);
  readBurst(MEM, addr[0], len[0], burst[0], size[0]);
  readBurst(MEM, addr[1], len[1], burst[1], size[1]);

  // 2CS read response & verify check
  getReadDataResp(MEM, len[0], size[0], rbuf[0], rresp[0]);
  getReadDataResp(MEM, len[1], size[1], rbuf[1], rresp[1]);
  for (i = 0; i < 2; i++) {
    for (j = 0; j < len[i]; j++) {
      if (rresp[i][j]) {
        CT_ERR_MSG("Read %1d Response %d: 0x%x\n", i, j, rresp[i][j]);
        ret = RESP_ERROR;
        goto end_wr_rd;
      }
    }

    if (verifyData8((BYTE*)(rbuf[i]), (BYTE*)(wbuf[i]), len8[i])) {
      CT_ERR_MSG("addr %1d VerifyData\n", i);
      ret = VERIFY_ERROR;
      goto end_wr_rd;
    }
  }

 end_wr_rd:
  for (i=0; i<2; i++) {
    if (wbuf[i]) {
      free(wbuf[i]);
    }
    if (rbuf[i]) {
      free(rbuf[i]);
    }
  }

  return ret;
}

static int rd_slave_error(int target, DWORD addr, DWORD rlen, DWORD rburst,
			      DWORD rsize, WORD* rbuf)
{
  int i;
  int ret = NO_ERROR;
  BYTE rresp[MAX_LEN];

  CT_MSG("Read : len=%3d burst=%1d size=%1d\n", rlen, rburst, rsize);
  readBurst(target, addr, rlen, rburst, rsize);
  getReadDataResp(target, rlen, rsize, rbuf, rresp);
  for (i = 0; i < rlen; i++) {
    if (rresp[i] != SLVERR) {
      ret = RESP_ERROR;
      CT_ERR_MSG("Unexpected Read response %d\n", rresp[i]);
      break;
    }
  }
  return ret;
}

static int rd_decode_error(int target, DWORD addr, DWORD rlen, DWORD rburst,
			       DWORD rsize, WORD* rbuf)
{
  int i;
  int ret = NO_ERROR;
  BYTE rresp[MAX_LEN];

  CT_MSG("Read : len=%3d burst=%1d size=%1d\n", rlen, rburst, rsize);
  readBurst(target, addr, rlen, rburst, rsize);
  getReadDataResp(target, rlen, rsize, rbuf, rresp);
  for (i = 0; i < rlen; i++) {
    if (rresp[i] != DECERR) {
      ret = RESP_ERROR;
      CT_ERR_MSG("Unexpected Read response %d\n", rresp[i]);
      break;
    }
  }
  return ret;
}

static int wr_slave_error(int target, DWORD addr, DWORD wlen, DWORD wburst,
			      DWORD wsize, WORD* wbuf)
{
  int ret = NO_ERROR;
  BYTE wresp;

  CT_MSG("Write: len=%3d burst=%1d size=%1d\n", wlen, wburst, wsize);
  writeBurst(target, addr, wlen, wburst, wsize, wbuf);
  getWriteResp(target, &wresp);
  if (wresp != SLVERR) {
    ret = RESP_ERROR;
    CT_ERR_MSG("Unexpected Write response %d\n", wresp);
  }
  return ret;
}

static int wr_decode_error(int target, DWORD addr, DWORD wlen, DWORD wburst,
			       DWORD wsize, WORD* wbuf)
{
  int ret = NO_ERROR;
  BYTE wresp;

  CT_MSG("Write: len=%3d burst=%1d size=%1d\n", wlen, wburst, wsize);
  writeBurst(target, addr, wlen, wburst, wsize, wbuf);
  getWriteResp(target, &wresp);
  if (wresp != DECERR) {
    ret = RESP_ERROR;
    CT_ERR_MSG("Unexpected Write response %d\n", wresp);
  }
  return ret;
}

static int set_cr_wrapsize (DWORD wrapSize, DWORD wrap2incr, DWORD cs)
{
  int ret = NO_ERROR;
#if (RPC2_CTRL_IP_VER >= 240)
  DWORD addr = PSRAM_CR0_OFFSET;
#else
  DWORD addr = 0x0;
#endif
  DWORD len16 = 1;
  DWORD mbrReg;
  DWORD devtype;
  WORD  crData, crwData, cr2;

  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    return ret;
  }
  getDevType(&devtype, cs);

  CT_MSG("Set CRT=1 --------------------------------\n");
  setConfigRegTarget(1, cs);
#if (RPC2_CTRL_IP_VER >= 240)
  sequential_rd16 (mbrReg+PSRAM_CR0_OFFSET, len16, BYTE_2, &crData, INCR);
#else
  sequential_rd16 (mbrReg, len16, BYTE_2, &crData, INCR);
#endif
  if (ret != NO_ERROR) {
    return ret;
  }

#if (RPC2_CTRL_IP_VER >= 230)
  if (devtype == PSRAM) {
    if (wrapSize == BURST_64B) {
      wrapSize = PSRAM_BURST_64B;
    }
  }
  cr2 = wrap2incr & 0x00000001;
#else
  if (devtype == PSRAM) {
    if (wrapSize == BURST_64B) {
      wrapSize = PSRAM_BURST_64B;
    }
    cr2 = 1;
  } else {
    cr2 = wrap2incr & 0x00000001;
  }
#endif
  crwData = ((crData & 0xFFF8) | (wrapSize & 0x0007) | (cr2 << 2));

  MSG("Write CR Reg = 0x%04X\n", crwData);
  ret = wr_rd_burst(addr, len16, &crwData, cs);
  if (ret != NO_ERROR) {
    return ret;
  }
  CT_MSG("Set CRT=0 --------------------------------\n");
  setConfigRegTarget(0, cs);
  return ret;
}

static int set_cr_reg (WORD crData, DWORD cs)
{
  int ret = NO_ERROR;
#if (RPC2_CTRL_IP_VER >= 240)
  DWORD addr = PSRAM_CR0_OFFSET;
#else
  DWORD addr = 0x0;
#endif
  DWORD len16 = 1;
  DWORD mbrReg;

  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    return ret;
  }

  CT_MSG("Set CRT=1 --------------------------------\n");
  setConfigRegTarget(1, cs);

  MSG("Write CR Reg = 0x%04X\n", crData);
  ret = wr_rd_burst(addr, len16, &crData, cs);
  if (ret != NO_ERROR) {
    return ret;
  }

  CT_MSG("Set CRT=0 --------------------------------\n");
  setConfigRegTarget(0, cs);
  return ret;
}

static int read_cr_reg (WORD* crData, DWORD cs)
{
  int ret = NO_ERROR;
  DWORD len16 = 1;
  DWORD mbrReg;

  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    return ret;
  }

  CT_MSG("Set CRT=1 --------------------------------\n");
  setConfigRegTarget(1, cs);
#if (RPC2_CTRL_IP_VER >= 240)
  ret = sequential_rd16 (mbrReg+PSRAM_CR0_OFFSET, len16, BYTE_2, crData, INCR);
#else
  ret = sequential_rd16 (mbrReg, len16, BYTE_2, crData, INCR);
#endif

  CT_MSG("Set CRT=0 --------------------------------\n");
  setConfigRegTarget(0, cs);
  return ret;
}

#if (RPC2_CTRL_IP_VER >= 220)
static int csr_reg_rd_verify (DWORD expcsrReg)
{
  int ret = NO_ERROR;
  DWORD csrReg;

  if (RPC2_READ_REG(REG_CSR_ADDR,  &csrReg)) {
    CT_ERR_MSG("Can't read CSR register\n");
    ret = ERROR;
    return ret;
  }
  CT_MSG(" CSR   : 0x%08X\n", csrReg);
  if (verifyData32(&csrReg, &expcsrReg, 1)) {
    CT_ERR_MSG("VerifyData32\n");
    ret = VERIFY_ERROR;
  }

  CT_MSG("WRSTOERR=%1d, WSLVERR=%1d, WDECERR=%1d, WACT=%1d\n", \
          GET_WRSTOERR(csrReg), GET_WTRSERR(csrReg), GET_WDECERR(csrReg), GET_WACT(csrReg));
  CT_MSG("RDSSTALL=%1d, RRSTOERR=%1d, RSLVERR=%1d, RDECERR=%1d, RACT=%1d\n", \
          GET_RDSSTALL(csrReg), GET_RRSTOERR(csrReg), GET_RTRSERR(csrReg), GET_RDECERR(csrReg), GET_RACT(csrReg));

  return ret;
}
#endif

static int getexp_wcsNeg_cnt(DWORD initAddr, DWORD size, DWORD len, int trans_cnt,
                             DWORD maxen, DWORD maxlen, DWORD *exp_wcs_neg_cnt)
{
  int i;
  int ret = NO_ERROR;
  DWORD len16;
  DWORD addr = initAddr;
  int xferByte;

  xferByte = 1 << size;
  *exp_wcs_neg_cnt = 0;

  for (i=0; i<trans_cnt; i++) {
    switch (size) {
    case BYTE_1:
      len16 = ((xferByte * len) + (addr%sizeof(WORD)) + 1)/sizeof(WORD);
      break;
    case BYTE_2:
      len16 = (xferByte * len)/sizeof(WORD);
      break;
    case BYTE_4:
      len16 = (xferByte * len)/sizeof(WORD) - ((addr&sizeof(WORD))/sizeof(WORD));
      CT_MSG(" len16   : 0x%08X\n", len16);
    default:
      break;
    }

    if ((maxen == MAXEN_ENABLED) && (len16 > maxlen + 1)) {
      *exp_wcs_neg_cnt += ((len16+maxlen) / (maxlen + 1));
    } else {
      *exp_wcs_neg_cnt += 1;
    }
    addr += (xferByte * len - addr%xferByte);
  }
  return ret;
}

static int getexp_rcsNeg_cnt(DWORD initAddr, DWORD size, DWORD len, int trans_cnt, int rburst, 
                             DWORD maxen, DWORD maxlen, DWORD *exp_rcs_neg_cnt)
{
  int i;
  int ret = NO_ERROR;
  DWORD len16;
  DWORD tc_len16 = 0;
  DWORD addr = initAddr;
  DWORD cs;
  DWORD devtype;
  int xferByte;

  xferByte = 1 << size;
  *exp_rcs_neg_cnt = 0;
  getCsNum (addr, &cs);
  getDevType(&devtype, cs);

  if (rburst == WRAP) {
    len16 = (xferByte * len)/sizeof(WORD);
    if ((xferByte * len)%sizeof(WORD)) {
      ret = NOT_SUPPORT;
      goto end_wr_rd;
    }

    for (i=0; i<trans_cnt; i++) {
      if (maxen == MAXEN_ENABLED) {
        if (len16 > maxlen) {
          if (!(len16 % (maxlen+1))) {
            *exp_rcs_neg_cnt += ((len16+maxlen) / (maxlen + 1)) + (addr%sizeof(WORD));
          } else {
            *exp_rcs_neg_cnt += ((len16+maxlen) / (maxlen + 1));
          }
#if (RPC2_CTRL_IP_VER >= 240)
        } else if (addr%(xferByte * len)) {
#else
        } else if ((devtype == PSRAM) || (addr%(xferByte * len))) {
#endif
          *exp_rcs_neg_cnt += 1;
           tc_len16 = len16;
        } else {
          if ((tc_len16 + len16) > maxlen + 1) {
            *exp_rcs_neg_cnt += 1;
            tc_len16 = len16;
          } else {
            if (!*exp_rcs_neg_cnt) *exp_rcs_neg_cnt += 1;
            tc_len16 += len16;
          }
        }
      } else {
#if (RPC2_CTRL_IP_VER >= 240)
        if ((addr%(xferByte * len)) || (!*exp_rcs_neg_cnt))
#else
        if ((devtype == PSRAM) || (addr%(xferByte * len)) || (!*exp_rcs_neg_cnt))
#endif
          *exp_rcs_neg_cnt += 1;
      }
    }
  } else {
    for (i=0; i<trans_cnt; i++) {
      switch (size) {
      case BYTE_1:
        len16 = ((xferByte * len) + (addr%sizeof(WORD)) + 1)/sizeof(WORD);
        break;
      case BYTE_2:
        len16 = (xferByte * len)/sizeof(WORD);
        break;
      case BYTE_4:
        len16 = (xferByte * len)/sizeof(WORD) - ((addr&sizeof(WORD))/sizeof(WORD));
      default:
        break;
      }

      if (maxen == MAXEN_ENABLED) {
        if (len16 > maxlen + 1) {
          *exp_rcs_neg_cnt += ((len16+maxlen) / (maxlen + 1));
#if (RPC2_CTRL_IP_VER >= 240)
        } else if (addr%sizeof(WORD)) {
#else
        } else if ((devtype == PSRAM) || (addr%sizeof(WORD))) {
#endif
          *exp_rcs_neg_cnt += 1;
          tc_len16 = len16;
        } else {
          if ((tc_len16 + len16) > maxlen + 1) {
            *exp_rcs_neg_cnt += 1;
            tc_len16 = len16;
          } else {
            if (!*exp_rcs_neg_cnt) *exp_rcs_neg_cnt += 1;
            tc_len16 += len16;
          }
        }
      } else {
#if (RPC2_CTRL_IP_VER >= 240)
        if ((addr%sizeof(WORD)) || (!*exp_rcs_neg_cnt)) {
#else
        if ((devtype == PSRAM) || (addr%sizeof(WORD)) || (!*exp_rcs_neg_cnt)) {
#endif
          *exp_rcs_neg_cnt += 1;
        }
      }
      addr += (xferByte * len - addr%xferByte);
    }
  }
 end_wr_rd:
  return ret;
}

//=============================================================================
//  REGISTER
//=============================================================================
int normal_reg_wr_rd (DWORD cs)
{
  int ret = NO_ERROR;
  int status;

  DWORD csrReg, ienReg, isrReg, mbr0Reg, mbr1Reg, mcr0Reg, mcr1Reg, wprReg, lbrReg;
  DWORD mtr0Reg, mtr1Reg, gporReg;
#if (RPC2_CTRL_IP_VER >= 240)
  DWORD tarReg;
  DWORD rdata[13];
  DWORD rsvData[13];
#else
  DWORD rdata[12];
  DWORD rsvData[12];
#endif
  DWORD wrapSize[2];
  DWORD devType[2];
  DWORD CurrentMtr[2];
#if (RPC2_CTRL_IP_VER >= 230)
  DWORD maxen[2], maxlen[2];
#endif
#if (RPC2_CTRL_IP_VER >= 240)
  DWORD rta,wta;
#endif

  CT_MSG(">> Control Register Normal Test\n");

  status = RPC2_READ_REG(REG_CSR_ADDR,  &rsvData[0]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_IEN_ADDR,  &rsvData[1]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_ISR_ADDR,  &rsvData[2]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_MBR0_ADDR, &rsvData[3]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_MBR1_ADDR, &rsvData[4]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_MCR0_ADDR, &rsvData[5]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_MCR1_ADDR, &rsvData[6]); if (status != NO_ERROR) ret = ERROR;
#if (RPC2_CTRL_IP_VER >= 210)
  status = RPC2_READ_REG(REG_MTR0_ADDR, &rsvData[7]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_MTR1_ADDR, &rsvData[8]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_GPOR_ADDR, &rsvData[9]); if (status != NO_ERROR) ret = ERROR;
#endif
  status = RPC2_READ_REG(REG_WPR_ADDR,  &rsvData[10]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_LBR_ADDR,  &rsvData[11]); if (status != NO_ERROR) ret = ERROR;
#if (RPC2_CTRL_IP_VER >= 240)
  status = RPC2_READ_REG(REG_TAR_ADDR,  &rsvData[12]); if (status != NO_ERROR) ret = ERROR;
#endif
  if (ret == ERROR) {CT_MSG("Error\n");}

  CT_MSG("Initial Value\n");
  CT_MSG(" CSR   : 0x%08X\n", rsvData[0]);
  CT_MSG(" IEN   : 0x%08X\n", rsvData[1]);
  CT_MSG(" ISR   : 0x%08X\n", rsvData[2]);
  CT_MSG(" MBR0  : 0x%08X\n", rsvData[3]);
  CT_MSG(" MBR1  : 0x%08X\n", rsvData[4]);
  CT_MSG(" MCR0  : 0x%08X\n", rsvData[5]);
  CT_MSG(" MCR1  : 0x%08X\n", rsvData[6]);
#if (RPC2_CTRL_IP_VER >= 210)
  CT_MSG(" MTR0  : 0x%08X\n", rsvData[7]);
  CT_MSG(" MTR1  : 0x%08X\n", rsvData[8]);
  CT_MSG(" GPOR  : 0x%08X\n", rsvData[9]);
#endif
  CT_MSG(" WPR   : 0x%08X\n", rsvData[10]);
  CT_MSG(" LBR   : 0x%08X\n", rsvData[11]);
#if (RPC2_CTRL_IP_VER >= 240)
  CT_MSG(" TAR   : 0x%08X\n", rsvData[12]);
#endif

  rsvData[3] = 0x0;
  rsvData[4] = 0x0;
  
  wrapSize[0] = GET_WRAP_SIZE(rsvData[5]);
  wrapSize[1] = GET_WRAP_SIZE(rsvData[6]);
  devType[0] = GET_DEVTYPE(rsvData[5]);
  devType[1] = GET_DEVTYPE(rsvData[6]);
#if (RPC2_CTRL_IP_VER >= 230)
  maxen[0] = GET_MAXEN(rsvData[5]);
  maxen[1] = GET_MAXEN(rsvData[6]);
  maxlen[0] = GET_MAXLEN(rsvData[5]);
  maxlen[1] = GET_MAXLEN(rsvData[6]);
#endif
#if (RPC2_CTRL_IP_VER >= 240)
  rta = GET_RTA(rsvData[12]);
  wta = GET_WTA(rsvData[12]);
#endif
  rsvData[5] = WRAPSIZE_BIT;
  rsvData[6] = WRAPSIZE_BIT;
  CurrentMtr[0] = rsvData[7];
  CurrentMtr[1] = rsvData[8];
  rsvData[7] = MTR_INIT;
  rsvData[8] = MTR_INIT;
#if (RPC2_CTRL_IP_VER >= 240)
  rsvData[12] = TAR_INIT;
#endif

  // Write FF Data
  csrReg  = 0xFFFFFFFF;
  ienReg  = 0xFFFFFFFF;
  isrReg  = 0xFFFFFFFF;
  mbr0Reg = 0xFFFFFFFF;
  mbr1Reg = 0xFFFFFFFF;
  mcr0Reg = 0xFFFFFFFF;
  mcr1Reg = 0xFFFFFFFF;
#if (RPC2_CTRL_IP_VER >= 210)
  mtr0Reg = 0xFFFFFFFF;
  mtr1Reg = 0xFFFFFFFF;
  gporReg = 0xFFFFFFFF;
#endif
  wprReg  = 0xFFFFFFFF;
  lbrReg  = 0xFFFFFFFF;
#if (RPC2_CTRL_IP_VER >= 240)
  tarReg  = 0xFFFFFFFF;
#endif
  status = RPC2_WRITE_REG(REG_CSR_ADDR,  &csrReg);  if (status != NO_ERROR) ret = ERROR;
  status = RPC2_WRITE_REG(REG_IEN_ADDR,  &ienReg);  if (status != NO_ERROR) ret = ERROR;
  status = RPC2_WRITE_REG(REG_ISR_ADDR,  &isrReg);  if (status != NO_ERROR) ret = ERROR;
  status = RPC2_WRITE_REG(REG_MBR0_ADDR, &mbr0Reg); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_WRITE_REG(REG_MBR1_ADDR, &mbr1Reg); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_WRITE_REG(REG_MCR0_ADDR, &mcr0Reg); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_WRITE_REG(REG_MCR1_ADDR, &mcr1Reg); if (status != NO_ERROR) ret = ERROR;
#if (RPC2_CTRL_IP_VER >= 210)
  status = RPC2_WRITE_REG(REG_MTR0_ADDR, &mtr0Reg); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_WRITE_REG(REG_MTR1_ADDR, &mtr1Reg); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_WRITE_REG(REG_GPOR_ADDR, &gporReg); if (status != NO_ERROR) ret = ERROR;
#endif
  status = RPC2_WRITE_REG(REG_WPR_ADDR,  &wprReg);  if (status != NO_ERROR) ret = ERROR;
  status = RPC2_WRITE_REG(REG_LBR_ADDR,  &lbrReg);  if (status != NO_ERROR) ret = ERROR;
#if (RPC2_CTRL_IP_VER >= 240)
  status = RPC2_WRITE_REG(REG_TAR_ADDR,  &tarReg);  if (status != NO_ERROR) ret = ERROR;
#endif

  // Read
  status = RPC2_READ_REG(REG_CSR_ADDR,  &rdata[0]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_IEN_ADDR,  &rdata[1]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_ISR_ADDR,  &rdata[2]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_MBR0_ADDR, &rdata[3]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_MBR1_ADDR, &rdata[4]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_MCR0_ADDR, &rdata[5]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_MCR1_ADDR, &rdata[6]); if (status != NO_ERROR) ret = ERROR;
#if (RPC2_CTRL_IP_VER >= 210)
  status = RPC2_READ_REG(REG_MTR0_ADDR, &rdata[7]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_MTR1_ADDR, &rdata[8]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_GPOR_ADDR, &rdata[9]); if (status != NO_ERROR) ret = ERROR;
#endif
  status = RPC2_READ_REG(REG_WPR_ADDR,  &rdata[10]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_LBR_ADDR,  &rdata[11]); if (status != NO_ERROR) ret = ERROR;
#if (RPC2_CTRL_IP_VER >= 240)
  status = RPC2_READ_REG(REG_TAR_ADDR,  &rdata[12]); if (status != NO_ERROR) ret = ERROR;
#endif

  // Verify
  CT_MSG("Write FF Data -> Read Verify\n");
  CT_MSG(" CSR   : 0x%08X, 0x%08X - %s\n", csrReg,  rdata[0], (rdata[0]) ? STR_NG : STR_OK);
  CT_MSG(" IEN   : 0x%08X, 0x%08X - %s\n", ienReg,  rdata[1], (rdata[1]!=(ienReg&REG_IEN_RW_BIT))  ? STR_NG : STR_OK);
  CT_MSG(" ISR   : 0x%08X, 0x%08X - %s\n", isrReg,  rdata[2], (rdata[2]) ? STR_NG : STR_OK);
  CT_MSG(" MBR0  : 0x%08X, 0x%08X - %s\n", mbr0Reg, rdata[3], (rdata[3]!=(mbr0Reg&REG_MBR_RW_BIT)) ? STR_NG : STR_OK);
  CT_MSG(" MBR1  : 0x%08X, 0x%08X - %s\n", mbr1Reg, rdata[4], (rdata[4]!=(mbr1Reg&REG_MBR_RW_BIT)) ? STR_NG : STR_OK);
  CT_MSG(" MCR0  : 0x%08X, 0x%08X - %s\n", mcr0Reg, rdata[5], (rdata[5]!=(mcr0Reg&REG_MCR_RW_BIT)) ? STR_NG : STR_OK);
  CT_MSG(" MCR1  : 0x%08X, 0x%08X - %s\n", mcr1Reg, rdata[6], (rdata[6]!=(mcr1Reg&REG_MCR_RW_BIT)) ? STR_NG : STR_OK);
#if (RPC2_CTRL_IP_VER >= 210)
  CT_MSG(" MTR0  : 0x%08X, 0x%08X - %s\n", mtr0Reg, rdata[7], (rdata[7]!=(mtr0Reg&REG_MTR_RW_BIT)) ? STR_NG : STR_OK);
  CT_MSG(" MTR1  : 0x%08X, 0x%08X - %s\n", mtr1Reg, rdata[8], (rdata[8]!=(mtr1Reg&REG_MTR_RW_BIT)) ? STR_NG : STR_OK);
  CT_MSG(" GPOR  : 0x%08X, 0x%08X - %s\n", gporReg, rdata[9], (rdata[9]!=(gporReg&REG_GPOR_RW_BIT)) ? STR_NG : STR_OK);
#endif
  CT_MSG(" WPR   : 0x%08X, 0x%08X - %s\n", wprReg,  rdata[10], (rdata[10]!=(wprReg&REG_WPR_RW_BIT))  ? STR_NG : STR_OK);
  CT_MSG(" LBR   : 0x%08X, 0x%08X - %s\n", lbrReg,  rdata[11], (rdata[11]!=(lbrReg&REG_LBR_RW_BIT))  ? STR_NG : STR_OK);
#if (RPC2_CTRL_IP_VER >= 240)
  CT_MSG(" TAR   : 0x%08X, 0x%08X - %s\n", tarReg,  rdata[12], (rdata[12]!=(tarReg&REG_TAR_RW_BIT))  ? STR_NG : STR_OK);
#endif
  if (rdata[0]) ret = ERROR;
  if (rdata[1]!=(ienReg&REG_IEN_RW_BIT)) ret = ERROR;
  if (rdata[2]) ret = ERROR;
  if (rdata[3]!=(mbr0Reg&REG_MBR_RW_BIT)) ret = ERROR;
  if (rdata[4]!=(mbr1Reg&REG_MBR_RW_BIT)) ret = ERROR;
  if (rdata[5]!=(mcr0Reg&REG_MCR_RW_BIT)) ret = ERROR;
  if (rdata[6]!=(mcr1Reg&REG_MCR_RW_BIT)) ret = ERROR;
#if (RPC2_CTRL_IP_VER >= 210)
  if (rdata[7]!=(mtr0Reg&REG_MTR_RW_BIT))  ret = ERROR;
  if (rdata[8]!=(mtr1Reg&REG_MTR_RW_BIT))  ret = ERROR;
  if (rdata[9]!=(gporReg&REG_GPOR_RW_BIT))  ret = ERROR;
#endif
  if (rdata[10]!=(wprReg&REG_WPR_RW_BIT))  ret = ERROR;
  if (rdata[11]!=(lbrReg&REG_LBR_RW_BIT))  ret = ERROR;
#if (RPC2_CTRL_IP_VER >= 240)
  if (rdata[12]!=(tarReg&REG_TAR_RW_BIT))  ret = ERROR;
#endif

  // Write 00 Data
  csrReg  = 0x0;
  ienReg  = 0x0;
  isrReg  = 0x0;
  mbr0Reg = 0x0;
  mbr1Reg = 0x0;
  mcr0Reg = 0x0;
  mcr1Reg = 0x0;
#if (RPC2_CTRL_IP_VER >= 210)
  mtr0Reg = 0x0;
  mtr1Reg = 0x0;
  gporReg = 0x0;
#endif
  wprReg  = 0x0;
  lbrReg  = 0x0;
#if (RPC2_CTRL_IP_VER >= 240)
  tarReg  = 0x0;
#endif
  status = RPC2_WRITE_REG(REG_CSR_ADDR,  &csrReg);  if (status != NO_ERROR) ret = ERROR;
  status = RPC2_WRITE_REG(REG_IEN_ADDR,  &ienReg);  if (status != NO_ERROR) ret = ERROR;
  status = RPC2_WRITE_REG(REG_ISR_ADDR,  &isrReg);  if (status != NO_ERROR) ret = ERROR;
  status = RPC2_WRITE_REG(REG_MBR0_ADDR, &mbr0Reg); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_WRITE_REG(REG_MBR1_ADDR, &mbr1Reg); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_WRITE_REG(REG_MCR0_ADDR, &mcr0Reg); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_WRITE_REG(REG_MCR1_ADDR, &mcr1Reg); if (status != NO_ERROR) ret = ERROR;
#if (RPC2_CTRL_IP_VER >= 210)
  status = RPC2_WRITE_REG(REG_MTR0_ADDR, &mtr0Reg); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_WRITE_REG(REG_MTR1_ADDR, &mtr1Reg); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_WRITE_REG(REG_GPOR_ADDR, &gporReg); if (status != NO_ERROR) ret = ERROR;
#endif
  status = RPC2_WRITE_REG(REG_WPR_ADDR,  &wprReg);  if (status != NO_ERROR) ret = ERROR;
  status = RPC2_WRITE_REG(REG_LBR_ADDR,  &lbrReg);  if (status != NO_ERROR) ret = ERROR;
#if (RPC2_CTRL_IP_VER >= 240)
  status = RPC2_WRITE_REG(REG_TAR_ADDR,  &tarReg);  if (status != NO_ERROR) ret = ERROR;
#endif

  // Read
  status = RPC2_READ_REG(REG_CSR_ADDR,  &rdata[0]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_IEN_ADDR,  &rdata[1]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_ISR_ADDR,  &rdata[2]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_MBR0_ADDR, &rdata[3]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_MBR1_ADDR, &rdata[4]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_MCR0_ADDR, &rdata[5]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_MCR1_ADDR, &rdata[6]); if (status != NO_ERROR) ret = ERROR;
#if (RPC2_CTRL_IP_VER >= 210)
  status = RPC2_READ_REG(REG_MTR0_ADDR, &rdata[7]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_MTR1_ADDR, &rdata[8]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_GPOR_ADDR, &rdata[9]); if (status != NO_ERROR) ret = ERROR;
#endif
  status = RPC2_READ_REG(REG_WPR_ADDR,  &rdata[10]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_LBR_ADDR,  &rdata[11]); if (status != NO_ERROR) ret = ERROR;
#if (RPC2_CTRL_IP_VER >= 240)
  status = RPC2_READ_REG(REG_TAR_ADDR,  &rdata[12]); if (status != NO_ERROR) ret = ERROR;
#endif

  // Verify
  CT_MSG("Write 00 Data -> Read Verify\n");
  CT_MSG(" CSR   : 0x%08X, 0x%08X - %s\n", csrReg,  rdata[0], (rdata[0]) ? STR_NG : STR_OK);
  CT_MSG(" IEN   : 0x%08X, 0x%08X - %s\n", ienReg,  rdata[1], (rdata[1]!=(ienReg&REG_IEN_RW_BIT))  ? STR_NG : STR_OK);
  CT_MSG(" ISR   : 0x%08X, 0x%08X - %s\n", isrReg,  rdata[2], (rdata[2]) ? STR_NG : STR_OK);
  CT_MSG(" MBR0  : 0x%08X, 0x%08X - %s\n", mbr0Reg, rdata[3], (rdata[3]!=(mbr0Reg&REG_MBR_RW_BIT)) ? STR_NG : STR_OK);
  CT_MSG(" MBR1  : 0x%08X, 0x%08X - %s\n", mbr1Reg, rdata[4], (rdata[4]!=(mbr1Reg&REG_MBR_RW_BIT)) ? STR_NG : STR_OK);
  CT_MSG(" MCR0  : 0x%08X, 0x%08X - %s\n", mcr0Reg, rdata[5], (rdata[5]!=(mcr0Reg&REG_MCR_RW_BIT)) ? STR_NG : STR_OK);
  CT_MSG(" MCR1  : 0x%08X, 0x%08X - %s\n", mcr1Reg, rdata[6], (rdata[6]!=(mcr1Reg&REG_MCR_RW_BIT)) ? STR_NG : STR_OK);
#if (RPC2_CTRL_IP_VER >= 210)
  CT_MSG(" MTR0  : 0x%08X, 0x%08X - %s\n", mtr0Reg, rdata[7], (rdata[7]!=(mtr0Reg&REG_MTR_RW_BIT)) ? STR_NG : STR_OK);
  CT_MSG(" MTR1  : 0x%08X, 0x%08X - %s\n", mtr1Reg, rdata[8], (rdata[8]!=(mtr1Reg&REG_MTR_RW_BIT)) ? STR_NG : STR_OK);
  CT_MSG(" GPOR  : 0x%08X, 0x%08X - %s\n", gporReg, rdata[9], (rdata[9]!=(gporReg&REG_GPOR_RW_BIT)) ? STR_NG : STR_OK);
#endif
  CT_MSG(" WPR   : 0x%08X, 0x%08X - %s\n", wprReg,  rdata[10], (rdata[10]!=(wprReg&REG_WPR_RW_BIT))  ? STR_NG : STR_OK);
  CT_MSG(" LBR   : 0x%08X, 0x%08X - %s\n", lbrReg,  rdata[11], (rdata[11]!=(lbrReg&REG_LBR_RW_BIT))  ? STR_NG : STR_OK);
#if (RPC2_CTRL_IP_VER >= 240)
  CT_MSG(" TAR   : 0x%08X, 0x%08X - %s\n", tarReg,  rdata[12], (rdata[12]!=(tarReg&REG_TAR_RW_BIT))  ? STR_NG : STR_OK);
#endif
  if (rdata[0]) ret = ERROR;
  if (rdata[1]!=(ienReg&REG_IEN_RW_BIT)) ret = ERROR;
  if (rdata[2]) ret = ERROR;
  if (rdata[3]!=(mbr0Reg&REG_MBR_RW_BIT)) ret = ERROR;
  if (rdata[4]!=(mbr1Reg&REG_MBR_RW_BIT)) ret = ERROR;
  if (rdata[5]!=(mcr0Reg&REG_MCR_RW_BIT)) ret = ERROR;
  if (rdata[6]!=(mcr1Reg&REG_MCR_RW_BIT)) ret = ERROR;
#if (RPC2_CTRL_IP_VER >= 210)
  if (rdata[7]!=(mtr0Reg&REG_MTR_RW_BIT))  ret = ERROR;
  if (rdata[8]!=(mtr1Reg&REG_MTR_RW_BIT))  ret = ERROR;
  if (rdata[9]!=(gporReg&REG_GPOR_RW_BIT))  ret = ERROR;
#endif
  if (rdata[10]!=(wprReg&REG_WPR_RW_BIT))  ret = ERROR;
  if (rdata[11]!=(lbrReg&REG_LBR_RW_BIT))  ret = ERROR;
#if (RPC2_CTRL_IP_VER >= 240)
  if (rdata[12]!=(tarReg&REG_TAR_RW_BIT))  ret = ERROR;
#endif

  // Write Random Data
  genRndData(&csrReg,  4);
  genRndData(&ienReg,  4);
  genRndData(&isrReg,  4);
  genRndData(&mbr0Reg, 4);
  genRndData(&mbr1Reg, 4);
  genRndData(&mcr0Reg, 4);
  genRndData(&mcr1Reg, 4);
#if (RPC2_CTRL_IP_VER >= 210)
  genRndData(&mtr0Reg, 4);
  genRndData(&mtr1Reg, 4);
  genRndData(&gporReg, 4);
#endif
  genRndData(&wprReg,  4);
  genRndData(&lbrReg,  4);
#if (RPC2_CTRL_IP_VER >= 240)
  genRndData(&tarReg,  4);
#endif
  status = RPC2_WRITE_REG(REG_CSR_ADDR,  &csrReg);  if (status != NO_ERROR) ret = ERROR;
  status = RPC2_WRITE_REG(REG_IEN_ADDR,  &ienReg);  if (status != NO_ERROR) ret = ERROR;
  status = RPC2_WRITE_REG(REG_ISR_ADDR,  &isrReg);  if (status != NO_ERROR) ret = ERROR;
  status = RPC2_WRITE_REG(REG_MBR0_ADDR, &mbr0Reg); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_WRITE_REG(REG_MBR1_ADDR, &mbr1Reg); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_WRITE_REG(REG_MCR0_ADDR, &mcr0Reg); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_WRITE_REG(REG_MCR1_ADDR, &mcr1Reg); if (status != NO_ERROR) ret = ERROR;
#if (RPC2_CTRL_IP_VER >= 210)
  status = RPC2_WRITE_REG(REG_MTR0_ADDR, &mtr0Reg); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_WRITE_REG(REG_MTR1_ADDR, &mtr1Reg); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_WRITE_REG(REG_GPOR_ADDR, &gporReg); if (status != NO_ERROR) ret = ERROR;
#endif
  status = RPC2_WRITE_REG(REG_WPR_ADDR,  &wprReg);  if (status != NO_ERROR) ret = ERROR;
  status = RPC2_WRITE_REG(REG_LBR_ADDR,  &lbrReg);  if (status != NO_ERROR) ret = ERROR;
#if (RPC2_CTRL_IP_VER >= 240)
  status = RPC2_WRITE_REG(REG_TAR_ADDR,  &tarReg);  if (status != NO_ERROR) ret = ERROR;
#endif

  // Read
  status = RPC2_READ_REG(REG_CSR_ADDR,  &rdata[0]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_IEN_ADDR,  &rdata[1]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_ISR_ADDR,  &rdata[2]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_MBR0_ADDR, &rdata[3]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_MBR1_ADDR, &rdata[4]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_MCR0_ADDR, &rdata[5]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_MCR1_ADDR, &rdata[6]); if (status != NO_ERROR) ret = ERROR;
#if (RPC2_CTRL_IP_VER >= 210)
  status = RPC2_READ_REG(REG_MTR0_ADDR, &rdata[7]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_MTR1_ADDR, &rdata[8]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_GPOR_ADDR, &rdata[9]); if (status != NO_ERROR) ret = ERROR;
#endif
  status = RPC2_READ_REG(REG_WPR_ADDR,  &rdata[10]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_LBR_ADDR,  &rdata[11]); if (status != NO_ERROR) ret = ERROR;
#if (RPC2_CTRL_IP_VER >= 240)
  status = RPC2_READ_REG(REG_TAR_ADDR,  &rdata[12]); if (status != NO_ERROR) ret = ERROR;
#endif

  // Verify
  CT_MSG("Write RANDOM -> Read Verify\n");
  CT_MSG(" CSR   : 0x%08X, 0x%08X - %s\n", csrReg,  rdata[0], (rdata[0]) ? STR_NG : STR_OK);
  CT_MSG(" IEN   : 0x%08X, 0x%08X - %s\n", ienReg,  rdata[1], (rdata[1]!=(ienReg&REG_IEN_RW_BIT))  ? STR_NG : STR_OK);
  CT_MSG(" ISR   : 0x%08X, 0x%08X - %s\n", isrReg,  rdata[2], (rdata[2]) ? STR_NG : STR_OK);
  CT_MSG(" MBR0  : 0x%08X, 0x%08X - %s\n", mbr0Reg, rdata[3], (rdata[3]!=(mbr0Reg&REG_MBR_RW_BIT)) ? STR_NG : STR_OK);
  CT_MSG(" MBR1  : 0x%08X, 0x%08X - %s\n", mbr1Reg, rdata[4], (rdata[4]!=(mbr1Reg&REG_MBR_RW_BIT)) ? STR_NG : STR_OK);
  CT_MSG(" MCR0  : 0x%08X, 0x%08X - %s\n", mcr0Reg, rdata[5], (rdata[5]!=(mcr0Reg&REG_MCR_RW_BIT)) ? STR_NG : STR_OK);
  CT_MSG(" MCR1  : 0x%08X, 0x%08X - %s\n", mcr1Reg, rdata[6], (rdata[6]!=(mcr1Reg&REG_MCR_RW_BIT)) ? STR_NG : STR_OK);
#if (RPC2_CTRL_IP_VER >= 210)
  CT_MSG(" MTR0  : 0x%08X, 0x%08X - %s\n", mtr0Reg, rdata[7], (rdata[7]!=(mtr0Reg&REG_MTR_RW_BIT)) ? STR_NG : STR_OK);
  CT_MSG(" MTR1  : 0x%08X, 0x%08X - %s\n", mtr1Reg, rdata[8], (rdata[8]!=(mtr1Reg&REG_MTR_RW_BIT)) ? STR_NG : STR_OK);
  CT_MSG(" GPOR  : 0x%08X, 0x%08X - %s\n", gporReg, rdata[9], (rdata[9]!=(gporReg&REG_GPOR_RW_BIT)) ? STR_NG : STR_OK);
#endif
  CT_MSG(" WPR   : 0x%08X, 0x%08X - %s\n", wprReg,  rdata[10], (rdata[10]!=(wprReg&REG_WPR_RW_BIT))  ? STR_NG : STR_OK);
  CT_MSG(" LBR   : 0x%08X, 0x%08X - %s\n", lbrReg,  rdata[11], (rdata[11]!=(lbrReg&REG_LBR_RW_BIT))  ? STR_NG : STR_OK);
#if (RPC2_CTRL_IP_VER >= 240)
  CT_MSG(" TAR   : 0x%08X, 0x%08X - %s\n", tarReg,  rdata[12], (rdata[12]!=(tarReg&REG_TAR_RW_BIT))  ? STR_NG : STR_OK);
#endif
  if (rdata[0]) ret = ERROR;
  if (rdata[1]!=(ienReg&REG_IEN_RW_BIT)) ret = ERROR;
  if (rdata[2]) ret = ERROR;
  if (rdata[3]!=(mbr0Reg&REG_MBR_RW_BIT)) ret = ERROR;
  if (rdata[4]!=(mbr1Reg&REG_MBR_RW_BIT)) ret = ERROR;
  if (rdata[5]!=(mcr0Reg&REG_MCR_RW_BIT)) ret = ERROR;
  if (rdata[6]!=(mcr1Reg&REG_MCR_RW_BIT)) ret = ERROR;
#if (RPC2_CTRL_IP_VER >= 210)
  if (rdata[7]!=(mtr0Reg&REG_MTR_RW_BIT))  ret = ERROR;
  if (rdata[8]!=(mtr1Reg&REG_MTR_RW_BIT))  ret = ERROR;
  if (rdata[9]!=(gporReg&REG_GPOR_RW_BIT))  ret = ERROR;
#endif
  if (rdata[10]!=(wprReg&REG_WPR_RW_BIT))  ret = ERROR;
  if (rdata[11]!=(lbrReg&REG_LBR_RW_BIT))  ret = ERROR;
#if (RPC2_CTRL_IP_VER >= 240)
  if (rdata[12]!=(tarReg&REG_TAR_RW_BIT))  ret = ERROR;
#endif

  CT_MSG("Reset Control Register\n");
  RPC2_RESET_REG();

  // Read
  status = RPC2_READ_REG(REG_CSR_ADDR,  &rdata[0]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_IEN_ADDR,  &rdata[1]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_ISR_ADDR,  &rdata[2]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_MBR0_ADDR, &rdata[3]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_MBR1_ADDR, &rdata[4]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_MCR0_ADDR, &rdata[5]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_MCR1_ADDR, &rdata[6]); if (status != NO_ERROR) ret = ERROR;
#if (RPC2_CTRL_IP_VER >= 210)
  status = RPC2_READ_REG(REG_MTR0_ADDR, &rdata[7]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_MTR1_ADDR, &rdata[8]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_GPOR_ADDR, &rdata[9]); if (status != NO_ERROR) ret = ERROR;
#endif
  status = RPC2_READ_REG(REG_WPR_ADDR,  &rdata[10]); if (status != NO_ERROR) ret = ERROR;
  status = RPC2_READ_REG(REG_LBR_ADDR,  &rdata[11]); if (status != NO_ERROR) ret = ERROR;
#if (RPC2_CTRL_IP_VER >= 240)
  status = RPC2_READ_REG(REG_TAR_ADDR,  &rdata[12]); if (status != NO_ERROR) ret = ERROR;
#endif

  // Verify
  CT_MSG("Reset -> Read Verify\n");
  CT_MSG(" CSR   : 0x%08X, 0x%08X - %s\n", rsvData[0], rdata[0], (rdata[0]!=rsvData[0]) ? STR_NG : STR_OK);
  CT_MSG(" IEN   : 0x%08X, 0x%08X - %s\n", rsvData[1], rdata[1], (rdata[1]!=rsvData[1]) ? STR_NG : STR_OK);
  CT_MSG(" ISR   : 0x%08X, 0x%08X - %s\n", rsvData[2], rdata[2], (rdata[2]!=rsvData[2]) ? STR_NG : STR_OK);
  CT_MSG(" MBR0  : 0x%08X, 0x%08X - %s\n", rsvData[3], rdata[3], (rdata[3]!=rsvData[3]) ? STR_NG : STR_OK);
  CT_MSG(" MBR1  : 0x%08X, 0x%08X - %s\n", rsvData[4], rdata[4], (rdata[4]!=rsvData[4]) ? STR_NG : STR_OK);
  CT_MSG(" MCR0  : 0x%08X, 0x%08X - %s\n", rsvData[5], rdata[5], (rdata[5]!=rsvData[5]) ? STR_NG : STR_OK);
  CT_MSG(" MCR1  : 0x%08X, 0x%08X - %s\n", rsvData[6], rdata[6], (rdata[6]!=rsvData[6]) ? STR_NG : STR_OK);
#if (RPC2_CTRL_IP_VER >= 210)
  CT_MSG(" MTR0  : 0x%08X, 0x%08X - %s\n", rsvData[7], rdata[7], (rdata[7]!=rsvData[7]) ? STR_NG : STR_OK);
  CT_MSG(" MTR1  : 0x%08X, 0x%08X - %s\n", rsvData[8], rdata[8], (rdata[8]!=rsvData[8]) ? STR_NG : STR_OK);
  CT_MSG(" GPOR  : 0x%08X, 0x%08X - %s\n", rsvData[9], rdata[9], (rdata[9]!=rsvData[9]) ? STR_NG : STR_OK);
#endif
  CT_MSG(" WPR   : 0x%08X, 0x%08X - %s\n", rsvData[10], rdata[10], (rdata[10]!=rsvData[10]) ? STR_NG : STR_OK);
  CT_MSG(" LBR   : 0x%08X, 0x%08X - %s\n", rsvData[11], rdata[11], (rdata[11]!=rsvData[11]) ? STR_NG : STR_OK);
#if (RPC2_CTRL_IP_VER >= 240)
  CT_MSG(" TAR   : 0x%08X, 0x%08X - %s\n", rsvData[12], rdata[12], (rdata[12]!=rsvData[12]) ? STR_NG : STR_OK);
#endif
  if (rdata[0]!=rsvData[0]) ret = ERROR;
  if (rdata[1]!=rsvData[1]) ret = ERROR;
  if (rdata[2]!=rsvData[2]) ret = ERROR;
  if (rdata[3]!=rsvData[3]) ret = ERROR;
  if (rdata[4]!=rsvData[4]) ret = ERROR;
  if (rdata[5]!=rsvData[5]) ret = ERROR;
  if (rdata[6]!=rsvData[6]) ret = ERROR;
#if (RPC2_CTRL_IP_VER >= 210)
  if (rdata[7]!=rsvData[7]) ret = ERROR;
  if (rdata[8]!=rsvData[8]) ret = ERROR;
  if (rdata[9]!=rsvData[9]) ret = ERROR;
#endif
  if (rdata[10]!=rsvData[10]) ret = ERROR;
  if (rdata[11]!=rsvData[11]) ret = ERROR;
#if (RPC2_CTRL_IP_VER >= 240)
  if (rdata[12]!=rsvData[12]) ret = ERROR;
#endif

  CT_MSG("Set MBR1: 0x%08X\n", CS1_MEM_BASE);
  ret = setMemBaseAddress(CS1_MEM_BASE, CS1_SEL);

  // Set wrap size
  setWrapSize(wrapSize[0], CS0_SEL);
  setWrapSize(wrapSize[1], CS1_SEL);

  // Set device type
  setDevType (devType[0], CS0_SEL);
  setDevType (devType[1], CS1_SEL);

#if (RPC2_CTRL_IP_VER >= 230)
  // Set R/W Max Length & enable/disable
  setMAXEN  (maxen[0], CS0_SEL);
  setMAXEN  (maxen[1], CS1_SEL);
  setMAXLEN (maxlen[0], CS0_SEL);
  setMAXLEN (maxlen[1], CS1_SEL);
#endif

  // Set PSRAM Memory Timing
  status = RPC2_WRITE_REG(REG_MTR0_ADDR, &CurrentMtr[0]);
  status = RPC2_WRITE_REG(REG_MTR1_ADDR, &CurrentMtr[1]);

#if (RPC2_CTRL_IP_VER >= 240)
  // Set R/W Max Transaction Allocation
  status = setRTA (rta);
  status = setWTA (wta);
#endif

  CT_MSG("<< Control Register Normal Test");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  
  return ret;
}

int illegal_reg_wr_rd (DWORD cs)
{
  int ret = NO_ERROR;
  int status;
  DWORD rdReg;
  DWORD wrReg;
  DWORD addr;

  CT_MSG(">> Control Register Illegal Test\n");

  addr = REG_TOTAL_SIZE;
  CT_MSG("Read from out of CTRL Reg: addr 0x%08X\n", addr);
  status = RPC2_READ_REG(addr, &rdReg);
  if (status != RESP_ERROR) {
    ret = ERROR;
  }
  CT_MSG("  - %s\n", (status == NO_ERROR) ? STR_NG : STR_OK);

  wrReg = 0;
  CT_MSG("Write to out of CTRL Reg: addr 0x%08X\n", addr);
  status = RPC2_WRITE_REG(addr, &wrReg);
  if (status == NO_ERROR) {
    ret = ERROR;
  }
  CT_MSG("  - %s\n", (status == NO_ERROR) ? STR_NG : STR_OK);

  addr = 0xFFFFFFFC;
  CT_MSG("Read from out of CTRL Reg: addr 0x%08X\n", addr);
  status = RPC2_READ_REG(addr, &rdReg);
  if (status != RESP_ERROR) {
    ret = ERROR;
  }
  CT_MSG("  - %s\n", (status == NO_ERROR) ? STR_NG : STR_OK);

  wrReg = 0;
  CT_MSG("Write to out of CTRL Reg: addr 0x%08X\n", addr);
  status = RPC2_WRITE_REG(addr, &wrReg);
  if (status == NO_ERROR) {
    ret = ERROR;
  }
  CT_MSG("  - %s\n", (status == NO_ERROR) ? STR_NG : STR_OK);

  CT_MSG("<< Control Register Illegal Test");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int loopback_wr_rd (DWORD cs)
{
  int ret = NO_ERROR;
  DWORD len16 = (MAX_RDAT_FIFO_SIZE-MAX_RX_FIFO_SIZE)*2;
  WORD* wbuf;
  WORD* rbuf;
  DWORD pattern;
  BYTE wresp;
  BYTE rresp[MAX_LEN];

  CT_MSG(">> Loopback Write/Read Test\n");

  CT_MSG("Loopback Mode ON\n");
  ret = setLoopbackMode(1);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("setLoopbackMode ON\n");
    goto end_test;
  }

  wbuf = (WORD*)malloc(sizeof(WORD)*len16);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  ret = wr_rd_burst(0, len16, wbuf, cs);
  if (ret != NO_ERROR) {
    goto end_test;
  }

  len16 = 16;
  rbuf = (WORD*)malloc(sizeof(WORD)*len16);
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }

  writeBurst(MEM, 0, len16, FIXED, 1, &wbuf[0]);
  getWriteResp(MEM, &wresp);

  readBurst(MEM, 0, len16, FIXED, 1);
  getReadDataResp(MEM, len16, 1, &rbuf[0], rresp);

  if (verifyData(rbuf, wbuf, len16)) {
      CT_ERR_MSG("VerifyData\n");
      ret = VERIFY_ERROR;
  }

  waitUs(10);
  CT_MSG("Loopback Mode OFF\n");
  ret = setLoopbackMode(0);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("setLoopbackMode OFF\n");
  }
 end_test:
  if (rbuf) {
    free(rbuf);
  }

  if (wbuf) {
    free(wbuf);
  }
  CT_MSG("<< Loopback Write/Read Test");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int status_register (DWORD cs)
{
  int ret = NO_ERROR;
  WORD* wbuf;
  WORD* rbuf;
  DWORD addr;
  DWORD len16;
  DWORD pattern;
  WORD numRead;
  WORD numWrite;
  int numLoop;
  DWORD mbrReg;

  CT_MSG(">> Status Register Test\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
  len16 = MAX_LEN;
  wbuf = (WORD*)malloc(sizeof(WORD)*len16);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  rbuf = (WORD*)malloc(sizeof(WORD)*len16);
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  addr = mbrReg;
  CT_MSG("Addr 0x%08X: Write 0x%3X\n", addr, len16);
  ret = RPC2_WRITE(addr, len16, wbuf);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("RPC2_WRITE: %d\n", ret);
    goto end_test;
  }
  getNumTransaction(&numWrite, &numRead);
  CT_MSG("# of Trans: Write 0x%03X, Read 0x%03X\n", numWrite, numRead);

  numLoop = 0;
  while (numWrite || numRead) {
    numLoop++;
    waitUs(1);
    getNumTransaction(&numWrite, &numRead);
  }
  CT_MSG("Wait until # of Trans 0: loop=%d\n", numLoop);

  CT_MSG("Addr 0x%08X: Read 0x%3X\n", addr, len16);
  RPC_READ_BURST(addr, len16);
  waitUs(1);
  getNumTransaction(&numWrite, &numRead);
  CT_MSG("# of Trans: Write 0x%03X, Read 0x%03X\n", numWrite, numRead);

  numLoop = 0;
  while (numWrite || numRead) {
    numLoop++;
    waitUs(1);
    getNumTransaction(&numWrite, &numRead);
  }
  CT_MSG("Wait until # of Trans 0: loop=%d\n", numLoop);

  ret = RPC2_GET_DATA(len16, rbuf);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("RPC2_READ_BURST: %d\n", ret);
    goto end_test;
  }

  if (verifyData(rbuf, wbuf, len16)) {
    ret = VERIFY_ERROR;
    CT_ERR_MSG("VerifyData\n");
  }
 end_test:
  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
  CT_MSG("<< Status Register Test");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int mbr_wr_rd (DWORD cs)
{
  int ret = NO_ERROR;
  DWORD len16 = 2;
  DWORD baseAddr = 0x10000000;
  DWORD addr = 0x02000000;
  WORD  wbuf[2];
  WORD  rbuf[2];
  DWORD pattern;

  CT_MSG(">> MBR Write/Read Test\n");

  if (cs == CS1_SEL) {
    setMemBaseAddress(0x0, CS0_SEL);
  } else {
    cs = CS0_SEL;
    setMemBaseAddress(0x0, CS1_SEL);
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  CT_MSG("Set MBR%d Register=0x%08X\n", cs, addr);

  setMemBaseAddress(addr, cs);
  ret = wr_rd_burst(0x0, 1, &wbuf[0], cs);
  if (ret != NO_ERROR) {
    goto end_test;
  }

  CT_MSG("Set MBR%d Register=0x%08X\n", cs, baseAddr);
  setMemBaseAddress(baseAddr, cs);
  CT_MSG("Addr 0x%08X: Read\n", baseAddr);
  ret = RPC2_READ(baseAddr, 1, &rbuf[0]);
  if (ret != NO_ERROR) {
    goto end_test;
  }
  CT_MSG("VERIFY - %s\n", (wbuf[0] == rbuf[0]) ? STR_OK : STR_NG);
  if (wbuf[0] != rbuf[0]) {
    ret = VERIFY_ERROR;
    goto end_test;
  }

  ret = wr_rd_burst(0x0+2, 1, &wbuf[1], cs);
  if (ret != NO_ERROR) {
    goto end_test;
  }

  addr = 0x01000000;
  CT_MSG("Set MBR%d Register=0x%08X\n", cs, addr);
  setMemBaseAddress(addr, cs);
  CT_MSG("Addr 0x%08X: Read\n", addr+2);
  ret = RPC2_READ(addr+2, 1, &rbuf[1]);
  if (ret != NO_ERROR) {
    goto end_test;
  }
  CT_MSG("VERIFY - %s\n", (wbuf[1] == rbuf[1]) ? STR_OK : STR_NG);
  if (wbuf[1] != rbuf[1]) {
    ret = VERIFY_ERROR;
  }

  setMemBaseAddress(CS0_MEM_BASE, CS0_SEL);
  setMemBaseAddress(CS1_MEM_BASE, CS1_SEL);

 end_test:
  CT_MSG("<< MBR Write/Read Test");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int mcr_wr_rd(DWORD cs)
{
  int ret = NO_ERROR;
  DWORD pattern;
  DWORD len16 = MAX_LEN;
  WORD wbuf[MAX_LEN];
  DWORD addr;
  DWORD mbrReg;
  WORD  crData;

  CT_MSG(">> MCR Write/Read Test\n");

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  CT_MSG("Set CRT=1 --------------------------------\n");
  setConfigRegTarget(1, cs);

  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
  len16 = 1;
  sequential_rd16 (mbrReg, len16, 1, &crData, INCR);
  if (ret != NO_ERROR) {
    goto end_test;
  }
  CT_MSG("CR Reg = 0x%04X\n", crData);
  wbuf[0] = crData & 0xFFFB;
  addr = 0x0;
  ret = wr_rd_burst(addr, len16, wbuf, cs);
  if (ret != NO_ERROR) {
    goto end_test;
  }
  CT_MSG("Set CRT=0 --------------------------------\n");
  setConfigRegTarget(0, cs);

  len16 = MAX_LEN;
  ret = wr_rd_burst(addr, len16, wbuf, cs);
  if (ret != NO_ERROR) {
    goto end_test;
  }

  CT_MSG("Set CRT=1 --------------------------------\n");
  setConfigRegTarget(1, cs);
  len16 = 1;
  ret = wr_rd_burst(addr, len16, &crData, cs);
  if (ret != NO_ERROR) {
    goto end_test;
  }
  CT_MSG("Set CRT=0 --------------------------------\n");
  setConfigRegTarget(0, cs);

end_test:
  CT_MSG("<< MCR Write/Read Test");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int rdat_fifo_wm (DWORD cs)
{
  int ret = NO_ERROR;
  DWORD len16 = MAX_RDAT_FIFO_SIZE;
  WORD* wbuf;
  DWORD pattern;

  CT_MSG(">> WM Test\n");
  wbuf = (WORD*)malloc(sizeof(WORD)*len16);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  CT_MSG("Set Water Mark=0 --------------------------------\n");
  setWaterMark(0);
  ret = wr_rd32_burst(0, len16, wbuf, cs);
  if (ret != NO_ERROR) {
    goto end_test;
  }

  CT_MSG("Set Water Mark=1 --------------------------------\n");
  setWaterMark(1);
  ret = wr_rd32_burst(len16*sizeof(WORD), len16, wbuf, cs);
  if (ret != NO_ERROR) {
    goto end_test;
  }

  CT_MSG("Set Water Mark=2 --------------------------------\n");
  setWaterMark(2);
  ret = wr_rd32_burst(len16*sizeof(WORD)*2, len16, wbuf, cs);
  if (ret != NO_ERROR) {
    goto end_test;
  }

  CT_MSG("Set Water Mark=3 --------------------------------\n");
  setWaterMark(3);
  ret = wr_rd32_burst(len16*sizeof(WORD)*3, len16, wbuf, cs);
  if (ret != NO_ERROR) {
    goto end_test;
  }

  setWaterMark(0);
 end_test:
  if (wbuf) {
    free(wbuf);
  }
  CT_MSG("<< WM Test");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int wp_wr_rd (DWORD cs)
{
  int ret = NO_ERROR;
  DWORD len16 = 1;
  DWORD addr = 0;
  WORD  wbuf[1];
  DWORD pattern;

  CT_MSG(">> Write Protect Write/Read Test\n");

  genFixData(wbuf, 0xFFFF, len16);

  CT_MSG("Set Initial value\n");
  ret = wr_rd_burst(addr, len16, wbuf, cs);
  if (ret != NO_ERROR) {
    goto end_test;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  CT_MSG("Set Write Protection ON\n");
  setWriteProtect(0x1);

  ret = wr_rd_burst(addr, len16, wbuf, cs);
  if (ret == VERIFY_ERROR) {
    ret = NO_ERROR;
  }
  else {
    ret = ERROR;
  }
  CT_MSG("Set Write Protection OFF\n");
  setWriteProtect(0x0);
 end_test:
  CT_MSG("<< Write Protect Write/Read Test");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int interrupt_enable (DWORD cs)
{
  int ret = NO_ERROR;
  DWORD len16 = 1;
  DWORD addr = 0;
  WORD  wbuf[1];
  WORD  rbuf[1];
  DWORD pattern;
  DWORD interrupt;
  WORD numWrite;
  WORD numRead;
  DWORD mbrReg;

  CT_MSG(">> Interrupt Enable Status Test\n");

  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  CT_MSG("Set Interrupt Enable ON, active low\n");
  setInterruptEnable(0x1);
  ret = RPC2_WRITE(addr+mbrReg, len16, wbuf);
  if (ret != NO_ERROR) goto end_test;
  ret = RPC2_WRITE(addr+mbrReg, len16, wbuf);
  if (ret != NO_ERROR) goto end_test;

  do {
    // Wait for write end
    getNumTransaction(&numWrite, &numRead);
  } while (numWrite != 0);

  getInterruptStatus(&interrupt);
  CT_MSG("Interrupt  -- %s\n", (interrupt == 0x1) ? STR_OK : STR_NG);
  if (interrupt != 0x1) {
    ret = VERIFY_ERROR;
    goto end_test;
  }

  ret = RPC2_READ(addr+mbrReg, len16, rbuf);
  if (ret != NO_ERROR) goto end_test;

  // Dummy Read for Register value is changed.
  getInterruptStatus(&interrupt);
  getInterruptStatus(&interrupt);
  CT_MSG("No Interrupt  -- %s\n", (interrupt == 0x0) ? STR_OK : STR_NG);
  if (interrupt != 0x0) {
    ret = VERIFY_ERROR;
    goto end_test;
  }

  CT_MSG("Set Interrupt Enable ON, active high\n");
  setInterruptEnable(0x80000001);
  ret = RPC2_WRITE(addr+mbrReg, len16, wbuf);
  if (ret != NO_ERROR) goto end_test;
  ret = RPC2_WRITE(addr+mbrReg, len16, wbuf);
  if (ret != NO_ERROR) goto end_test;

  do {
    // Wait for write end
    getNumTransaction(&numWrite, &numRead);
  } while (numWrite != 0);

  getInterruptStatus(&interrupt);
  CT_MSG("Interrupt  -- %s\n", (interrupt == 0x1) ? STR_OK : STR_NG);
  if (interrupt != 0x1) {
    ret = VERIFY_ERROR;
    goto end_test;
  }

  ret = RPC2_READ(addr+mbrReg, len16, rbuf);
  if (ret != NO_ERROR) goto end_test;

  CT_MSG("Set Interrupt Enable OFF\n");
  setInterruptEnable(0x0);
 end_test:
  CT_MSG("<< Interrupt Enable Status Test");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int gpor_polarity (DWORD cs)
{
  int ret = NO_ERROR;

  CT_MSG(">> GPOR Output Polarity Test\n");

  CT_MSG("Set GPO0 output polarity high\n");
  ret = setGeneralPurposeOutput(1, 0);
  if (ret != NO_ERROR) goto end_test;
  waitUs(10);

  CT_MSG("Set GPO1 output polarity high\n");
  ret = setGeneralPurposeOutput(1, 1);
  if (ret != NO_ERROR) goto end_test;
  waitUs(10);

  CT_MSG("Set GPO0 output polarity low\n");
  ret = setGeneralPurposeOutput(0, 0);
  if (ret != NO_ERROR) goto end_test;
  waitUs(10);

  CT_MSG("Set GPO1 output polarity low\n");
  ret = setGeneralPurposeOutput(0, 1);
  if (ret != NO_ERROR) goto end_test;

  waitUs(10);

 end_test:
  CT_MSG("<< GPOR Output Polarity Test");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

//=============================================================================
//  MEMORY
//=============================================================================

int adr_fifo_full (DWORD cs)
{
  int i;
  int ret;
  int trans;
  DWORD len;
  DWORD len16;
  DWORD* wbuf;
  DWORD* rbuf;
  DWORD pattern;
  DWORD mbrReg;

  CT_MSG(">> ADR FIFO Full Test\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
  len = 1;
#if (RPC2_CTRL_IP_VER >= 240)
  trans = 1;
#else
  trans = MAX_OUTSTANDING_TRANS-1;
#endif
  len16 = len*2*trans;
  wbuf = (DWORD*)malloc(sizeof(WORD)*(len16));
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  rbuf = (DWORD*)malloc(sizeof(WORD)*(len16));
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  getDataPattern(&pattern);
  fillBuffer(pattern, (WORD*)wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer((WORD*)wbuf, len16);

  CT_MSG("Sequential Write addr 0x%08X, len 0x%x x%d\n", mbrReg, len, trans);
  CT_MSG("Sequential Read addr 0x%08X, len 0x%x x%d\n", mbrReg, len, trans);
  for (i = 0; i < trans; i++) {
    RPC_WRITE_BURST32(mbrReg + sizeof(DWORD)*len*i, len, &wbuf[len*i]);
    RPC_READ_BURST32(mbrReg + sizeof(DWORD)*len*i, len);
  }

  for (i = 0; i < trans; i++) {
    ret = RPC_GET_WRESP();
    if (ret != NO_ERROR) {
      CT_MSG("RPC2_WRITE_BURST32: %d\n", ret);
      return ret;
    }
    ret = RPC2_GET_DATA32(len, &rbuf[len*i]);
    if (ret != NO_ERROR) {
      CT_MSG("RPC2_READ_BURST32: %d\n", ret);
      goto end_test;
    }
  }
#if (RPC2_CTRL_IP_VER >= 240)
  RPC_READ_BURST32(mbrReg, len);
  ret = RPC2_GET_DATA32(len, &rbuf[0]);
  if (ret != NO_ERROR) {
    CT_MSG("RPC2_READ_BURST32: %d\n", ret);
    goto end_test;
  }
#endif
  if (verifyData32(rbuf, wbuf, len*trans)) {
    CT_ERR_MSG("VerifyData32\n");
    ret = VERIFY_ERROR;
    goto end_test;
  }
 end_test:
  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
  CT_MSG("<< ADR FIFO Full Test");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int adr_fifo_full_over (DWORD cs)
{
  int i;
  int ret;
  int trans;
  DWORD len = 1;
  DWORD len16;
  DWORD* wbuf;
  DWORD* rbuf;
  DWORD pattern;
  DWORD mbrReg;

  CT_MSG(">> ADR FIFO Full Over Test\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
  trans = MAX_OUTSTANDING_TRANS;
  len16 = len*2*trans;
  wbuf = (DWORD*)malloc(sizeof(WORD)*(len16));
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  rbuf = (DWORD*)malloc(sizeof(WORD)*(len16));
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  getDataPattern(&pattern);
  fillBuffer(pattern, (WORD*)wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer((WORD*)wbuf, len16);

  CT_MSG("Sequential Write addr 0x%08X, len 0x%x x%d\n", mbrReg, len, trans);
  CT_MSG("Sequential Read addr 0x%08X, len 0x%x x%d\n", mbrReg, len, trans);
  for (i = 0; i < trans; i++) {
    RPC_WRITE_BURST32(mbrReg + sizeof(DWORD)*len*i, len, &wbuf[len*i]);
    RPC_READ_BURST32(mbrReg + sizeof(DWORD)*len*i, len);
  }

  for (i = 0; i < trans; i++) {
    ret = RPC_GET_WRESP();
    if (ret != NO_ERROR) {
      CT_MSG("RPC2_WRITE_BURST32: %d\n", ret);
      return ret;
    }
    ret = RPC2_GET_DATA32(len, &rbuf[len*i]);
    if (ret != NO_ERROR) {
      CT_MSG("RPC2_READ_BURST32: %d\n", ret);
      goto end_test;
    }
  }
#if (RPC2_CTRL_IP_VER >= 240)
  for (i = 0; i < trans; i++) {
    RPC_READ_BURST32(mbrReg + sizeof(DWORD)*len*i, len);
    ret = RPC2_GET_DATA32(len, &rbuf[len*i]);
    if (ret != NO_ERROR) {
      CT_MSG("RPC2_READ_BURST32: %d\n", ret);
      goto end_test;
    }
  }
#endif
  CT_MSG("i %d\n", i);
  if (verifyData32(rbuf, wbuf, len*trans)) {
    CT_ERR_MSG("VerifyData32\n");
    ret = VERIFY_ERROR;
    goto end_test;
  }
 end_test:
  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
  CT_MSG("<< ADR FIFO Full Over Test");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int wdat_fifo_full (DWORD cs)
{
  int ret;
  int trans;
  DWORD len;
  DWORD len16;
  DWORD* wbuf;
  DWORD* rbuf;
  DWORD pattern;
  DWORD mbrReg;

  CT_MSG(">> WDAT FIFO Full Test\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
  if (MAX_WDAT_FIFO_SIZE < MAX_LEN) {
    len = MAX_WDAT_FIFO_SIZE;
    trans = 1;
    len16 = len*2*trans;
  } else {
    len = MAX_LEN;
    trans = MAX_WDAT_FIFO_SIZE/MAX_LEN;
    len16 = len*2*trans;
  }
  wbuf = (DWORD*)malloc(sizeof(WORD)*(len16));
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  rbuf = (DWORD*)malloc(sizeof(WORD)*(len16));
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  getDataPattern(&pattern);
  fillBuffer(pattern, (WORD*)wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer((WORD*)wbuf, len16);

  ret = sequential_wr32(mbrReg, len, trans, wbuf);
  if (ret != NO_ERROR) {
    goto end_test;
  }
  ret = sequential_rd32(mbrReg, len, trans, rbuf, 1);
  if (ret != NO_ERROR) {
    goto end_test;
  }
  if (verifyData32(rbuf, wbuf, len*trans)) {
    CT_ERR_MSG("VerifyData32\n");
    ret = VERIFY_ERROR;
    goto end_test;
  }
 end_test:
  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
  CT_MSG("<< WDAT FIFO Full Test");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int wdat_fifo_full_over (DWORD cs)
{
  int ret;
  int trans;
  DWORD len;
  DWORD len16;
  DWORD* wbuf;
  DWORD* rbuf;
  DWORD pattern;
  DWORD mbrReg;

  CT_MSG(">> WDAT FIFO Full Over Test\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
  if ((MAX_WDAT_FIFO_SIZE*2) < MAX_LEN) {
    len = MAX_WDAT_FIFO_SIZE*2;
    trans = 1;
    len16 = len*2*trans;
  } else {
    len = MAX_LEN;
    trans = (MAX_WDAT_FIFO_SIZE*2)/(MAX_LEN);
    len16 = len*2*trans;
  }
  wbuf = (DWORD*)malloc(sizeof(WORD)*(len16));
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  rbuf = (DWORD*)malloc(sizeof(WORD)*(len16));
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  getDataPattern(&pattern);
  fillBuffer(pattern, (WORD*)wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer((WORD*)wbuf, len16);

  ret = sequential_wr32(mbrReg, len, trans, wbuf);
  if (ret != NO_ERROR) {
    goto end_test;
  }
  ret = sequential_rd32(mbrReg, len, trans, rbuf, 1);
  if (ret != NO_ERROR) {
    goto end_test;
  }
  if (verifyData32(rbuf, wbuf, len*trans)) {
    CT_ERR_MSG("VerifyData32\n");
    ret = VERIFY_ERROR;
    goto end_test;
  }
 end_test:
  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
  CT_MSG("<< WDAT FIFO Full Over Test");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int rdat_fifo_full (DWORD cs)
{
  int ret;
  int trans;
  DWORD len;
  DWORD len16;
  DWORD* wbuf;
  DWORD* rbuf;
  DWORD pattern;
  DWORD mbrReg;

  CT_MSG(">> RDAT FIFO Full Test\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
  if (MAX_RDAT_FIFO_SIZE < MAX_LEN) {
    len = MAX_RDAT_FIFO_SIZE;
    trans = 1;
    len16 = len*2*trans;
  } else {
    len = MAX_LEN;
    trans = MAX_RDAT_FIFO_SIZE/MAX_LEN;
    len16 = len*2*trans;
  }
  wbuf = (DWORD*)malloc(sizeof(WORD)*(len16));
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  rbuf = (DWORD*)malloc(sizeof(WORD)*(len16));
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  getDataPattern(&pattern);
  fillBuffer(pattern, (WORD*)wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer((WORD*)wbuf, len16);

  ret = sequential_wr32(mbrReg, len, trans, wbuf);
  if (ret != NO_ERROR) {
    goto end_test;
  }

  CT_MSG("Sequential Read addr 0x%08X, len 0x%x x%d\n", mbrReg, len, trans);
  RPC2_IDLE_READ_DATA(200);
  ret = sequential_rd32(mbrReg, len, trans, rbuf, 1);
  if (ret != NO_ERROR) {
    goto end_test;
  }
  if (verifyData32(rbuf, wbuf, len*trans)) {
    CT_ERR_MSG("VerifyData32\n");
    ret = VERIFY_ERROR;
    goto end_test;
  }
 end_test:
  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
  CT_MSG("<< RDAT FIFO Full Test");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;

  return ret;
}

int rdat_fifo_full_over (DWORD cs)
{
  int ret;
  int trans;
  DWORD len;
  DWORD len16;
  DWORD* wbuf;
  DWORD* rbuf;
  DWORD pattern;
  DWORD mbrReg;

  CT_MSG(">> RDAT FIFO Full Over Test\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
  if ((MAX_RDAT_FIFO_SIZE*2) < MAX_LEN) {
    len = (MAX_RDAT_FIFO_SIZE*2);
    trans = 1;
    len16 = len*2*trans;
  } else {
    len = MAX_LEN;
    trans = (MAX_RDAT_FIFO_SIZE*2)/MAX_LEN;
    len16 = len*2*trans;
  }
  wbuf = (DWORD*)malloc(sizeof(WORD)*(len16));
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  rbuf = (DWORD*)malloc(sizeof(WORD)*(len16));
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  getDataPattern(&pattern);
  fillBuffer(pattern, (WORD*)wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer((WORD*)wbuf, len16);

  ret = sequential_wr32(mbrReg, len, trans, wbuf);
  if (ret != NO_ERROR) {
    goto end_test;
  }

  CT_MSG("Sequential Read addr 0x%08X, len 0x%x x%d\n", mbrReg, len, trans);
  RPC2_IDLE_READ_DATA(200);
  ret = sequential_rd32(mbrReg, len, trans, rbuf, 1);
  if (ret != NO_ERROR) {
    goto end_test;
  }
  if (verifyData32(rbuf, wbuf, len*trans)) {
    CT_ERR_MSG("VerifyData32\n");
    ret = VERIFY_ERROR;
    goto end_test;
  }
 end_test:
  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
  CT_MSG("<< RDAT FIFO Full Over Test\n");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;

  return ret;
}

int illegal_wr_rd (DWORD cs)
{
  int ret = NO_ERROR;
  DWORD status;
  DWORD addr;
  WORD *wbuf;
  WORD *rbuf;
  DWORD mbr0Reg, mbr1Reg;
  DWORD len16 = 16;
  DWORD pattern;

  CT_MSG(">> Read/Write Illegal Address Test\n");
  wbuf = (WORD*)malloc(sizeof(WORD)*len16);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  rbuf = (WORD*)malloc(sizeof(WORD)*len16);
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  mbr0Reg = 0x80000000;
  CT_MSG("Set MBR0: 0x%08X\n", mbr0Reg);
  setMemBaseAddress(mbr0Reg, CS0_SEL);

  if (cs == CS1_SEL) {
    mbr1Reg = 0x70000000;
    addr = mbr1Reg;
  } else {
    mbr1Reg = mbr0Reg;
    addr = 0;
    cs = 0;
  }
  CT_MSG("Set MBR1: 0x%08X\n", mbr1Reg);
  setMemBaseAddress(mbr1Reg, CS1_SEL);

  CT_MSG("Addr 0x%08X: Write 0x%3X\n", addr, len16);
  status = RPC2_WRITE(addr, len16, wbuf);
  CT_MSG("  - %s\n", (status == NO_ERROR) ? STR_NG : STR_OK);
  if (status == NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }

  CT_MSG("Addr 0x%08X: Read 0x%3X\n", addr, len16);
  status = RPC2_READ(addr, len16, rbuf);
  CT_MSG("  - %s\n", (status == NO_ERROR) ? STR_NG : STR_OK);
  if (status == NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }

  addr += 0x0FFFFFFF;
  CT_MSG("Addr 0x%08X: Write 0x%3X\n", addr, len16);
  status = RPC2_WRITE(addr, len16, wbuf);
  CT_MSG("  - %s\n", (status == NO_ERROR) ? STR_NG : STR_OK);
  if (status == NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }

  CT_MSG("Addr 0x%08X: Read 0x%3X\n", addr, len16);
  status = RPC2_READ(addr, len16, rbuf);
  CT_MSG("  - %s\n", (status == NO_ERROR) ? STR_NG : STR_OK);
  if (status == NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }
  
  mbr0Reg = CS0_MEM_BASE;
  CT_MSG("Set MBR0: 0x%08X\n", mbr0Reg);
  ret = setMemBaseAddress(mbr0Reg, CS0_SEL);

  mbr1Reg = CS1_MEM_BASE;
  CT_MSG("Set MBR1: 0x%08X\n", mbr1Reg);
  ret = setMemBaseAddress(mbr1Reg, CS1_SEL);

 end_test:
  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }

  CT_MSG("<< Read/Write Illegal Address Test");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

#if (RPC2_CTRL_IP_VER < 230)
int tc_rd (DWORD cs)
{
  int ret = NO_ERROR;
  int i;
  int trans = 4;
  DWORD addr;
  DWORD len = MAX_LEN;
  DWORD len16;
  DWORD rsize[] = {BYTE_1,BYTE_2,BYTE_4};
  BYTE* wbuf;
  BYTE* rbuf;
  DWORD pattern;
  DWORD mbrReg;
  DWORD devtype;

  int rxferByte;

  CT_MSG(">> TC Read Test\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
  getDevType(&devtype, cs);

  if (devtype == PSRAM) {
    getRpcClkPeriod(&rpcClk);
    while (PSRAM_TCSM <= (rpcClk*len*trans*sizeof(DWORD)/sizeof(WORD))) {
      len /= 2;
    }
  }
  len16 = len*trans*sizeof(DWORD)/sizeof(WORD);
  wbuf = (BYTE*)malloc(sizeof(WORD)*len16);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  rbuf = (BYTE*)malloc(sizeof(WORD)*len16);
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  getDataPattern(&pattern);
  fillBuffer(pattern, (WORD*)wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer((WORD*)wbuf, len16);

  addr = 0;
  // Set initial data
  ret = sequential_wr32(addr+mbrReg, len, trans, (DWORD*)wbuf);
  if (ret != NO_ERROR) {
    goto end_test;
  }
  CT_MSG("Write addr 0x%08X, len8 0x%x\n", addr+mbrReg, len*trans*sizeof(DWORD));

  for (i = 0; i < 3; i++) {
    rxferByte = 1 << rsize[i];
    CT_MSG("SIZE=%1d ---------------------------------------\n", rxferByte);
    CT_MSG("LEN=%2d ---------------------------------------\n", len);

    switch (i) {
      case BYTE_1:
        ret = sequential_rd8(addr+mbrReg, len, trans, rbuf, 1); //INCR
        break;
      case BYTE_2:
        ret = sequential_rd16(addr+mbrReg, len, trans, (WORD*)rbuf, 1); //INCR
        break;
      case BYTE_4:
        addr = 0;
        ret = sequential_rd32(addr+mbrReg, len, trans, (DWORD*)rbuf, 1); //INCR
      default:
        break;
    }

    if (ret != NO_ERROR) {
      goto end_test;
    }
    if (verifyData8(rbuf, wbuf, len*trans*rxferByte)) {
      CT_ERR_MSG("VerifyData8\n");
      ret = VERIFY_ERROR;
      goto end_test;
    }
  }

 end_test:
  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
  CT_MSG("<< TC Read Test");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;

  return ret;
}
#endif

int tc_rd_wrap_boundary (DWORD cs)
{
  int i, j;
  int ret = NO_ERROR;
  int trans = 4;
  DWORD addr;
  DWORD len = 16*trans;
  DWORD len16;
  DWORD rlen[] = {4, 8, 16};
  DWORD* wbuf;
  DWORD* rbuf;
  DWORD pattern;
  DWORD mbrReg;
#if (RPC2_CTRL_IP_VER >= 230)
  DWORD maxen;
  DWORD maxlen;
  DWORD rcs_neg_cnt;
  DWORD exp_rcs_neg_cnt;
#endif

  CT_MSG(">> TC Read Wrap Boundary Test\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
#if (RPC2_CTRL_IP_VER >= 230)
  getMAXEN(&maxen, cs);
  getMAXLEN(&maxlen, cs);
#endif
  wbuf = (DWORD*)malloc(sizeof(DWORD)*len);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  rbuf = (DWORD*)malloc(sizeof(DWORD)*len);
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }

  len16 = len*sizeof(DWORD)/sizeof(WORD);
  getDataPattern(&pattern);
  fillBuffer(pattern, (WORD*)wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer((WORD*)wbuf, len16);
  
  addr = 0;
  // Set initial data
  ret = RPC2_WRITE32(addr+mbrReg, len, wbuf);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("RPC2_WRITE32: %d\n", ret);
    goto end_test;
  }
  CT_MSG("Write addr 0x%08X, len32 0x%x\n", addr+mbrReg, len);

  addr = 0;
  for (j = 0; j < 3; j++) {
    // Set wrap size
    CT_MSG("Wrap Size=%2d -----------------------------\n", WRAP_BURST[j][0]);
    setWrapSize (WRAP_BURST[j][1], cs);
    set_cr_wrapsize (WRAP_BURST[j][1], WRAP2INCR_OFF, cs);

  for (i = 0; i < 3; i++) {
    len = rlen[i];
    CT_MSG("LEN32=%2d from Aligned Wrap address --------------------\n", len);
#if (RPC2_CTRL_IP_VER >= 230)
    startCScnt(cs);
#endif
    ret = sequential_rd32(addr+mbrReg, len, trans, rbuf, 0); //WRAP
#if (RPC2_CTRL_IP_VER >= 230)
    endCScnt(cs);
    getCScnt(cs, &rcs_neg_cnt);
#endif
    if (ret != NO_ERROR) {
      goto end_test;
    }
    if (verifyData32(rbuf, wbuf, len*trans)) {
      CT_ERR_MSG("VerifyData32\n");
      ret = VERIFY_ERROR;
      goto end_test;
    }
#if (RPC2_CTRL_IP_VER >= 230)
    // Compare CS Negadge Count
    getexp_rcsNeg_cnt(addr+mbrReg, BYTE_4, len, trans, WRAP, maxen, maxlen, &exp_rcs_neg_cnt);
    CT_MSG("Comare Read  CS Negadge Count exp: %d, act: %d ---\n", exp_rcs_neg_cnt, rcs_neg_cnt);
    if (rcs_neg_cnt != exp_rcs_neg_cnt) {
      CT_ERR_MSG("Read CS Negadge Count is mismatched\n");
      ret = VERIFY_ERROR;
      goto end_test;
    }
#endif
  }
  }
  setWrapSize (BURST_32B, cs);
  set_cr_wrapsize (BURST_32B, WRAP2INCR_OFF, cs);
 end_test:
  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
  CT_MSG("<< TC Read Wrap Boundary Test");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;

  return ret;
}

int tc_resume_rd (DWORD cs)
{
  int ret = NO_ERROR;
  int trans;
  int i;
  DWORD addr;
  DWORD len;
  DWORD len16;
  DWORD* wbuf;
  DWORD* rbuf;
  DWORD pattern;
  DWORD mbrReg;
#if (RPC2_CTRL_IP_VER >= 230)
  DWORD devtype;
  DWORD maxen;
  DWORD maxlen;
  DWORD rcs_neg_cnt;
  DWORD exp_rcs_neg_cnt;
#endif

  CT_MSG(">> TC Resume Read Test\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
#if (RPC2_CTRL_IP_VER >= 230)
  getDevType(&devtype, cs);
  getMAXEN(&maxen, cs);
  getMAXLEN(&maxlen, cs);
#endif
  if (MAX_RDAT_FIFO_SIZE*4 < MAX_LEN) {
    len = MAX_RDAT_FIFO_SIZE*4;
    trans = 1;
    len16 = len*2*trans;
  } else {
    len = MAX_LEN;
    trans = (MAX_RDAT_FIFO_SIZE*4)/MAX_LEN;
    len16 = len*2*trans;
  }
  wbuf = (DWORD*)malloc(sizeof(WORD)*(len16));
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  rbuf = (DWORD*)malloc(sizeof(WORD)*(len16));
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  getDataPattern(&pattern);
  fillBuffer(pattern, (WORD*)wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer((WORD*)wbuf, len16);
  
  addr = 0;
  for (i = 0; i < 2; i++) {
    addr = i*4;

    // Set initial data
    ret = sequential_wr32(addr+mbrReg, len, trans, wbuf);
    if (ret != NO_ERROR) {
      goto end_test;
    }
    CT_MSG("Write addr 0x%08X, len32 0x%x\n", addr+mbrReg, len);
        
    RPC2_IDLE_READ_DATA(200);
    CT_MSG("Wait until RXFIFO is full\n");

#if (RPC2_CTRL_IP_VER >= 230)
    startCScnt(cs);
#endif
    ret = sequential_rd32(addr+mbrReg, len, trans, rbuf, 1);
    if (ret != NO_ERROR) {
      goto end_test;
    }
#if (RPC2_CTRL_IP_VER >= 230)
    endCScnt(cs);
    getCScnt(cs, &rcs_neg_cnt);
#endif
    if (verifyData32(rbuf, wbuf, len*trans)) {
      CT_ERR_MSG("VerifyData32\n");
      ret = VERIFY_ERROR;
      goto end_test;
    }
#if (RPC2_CTRL_IP_VER >= 230)
    // Compare CS Negadge Count
    if ((devtype == PSRAM) || (maxen == MAXEN_ENABLED)) {
      getexp_rcsNeg_cnt(addr+mbrReg, BYTE_4, len, trans, INCR, maxen, maxlen, &exp_rcs_neg_cnt);
    } else {
      exp_rcs_neg_cnt = 2;
    }
    CT_MSG("Comare Read  CS Negadge Count exp: %d, act: %d ---\n", exp_rcs_neg_cnt, rcs_neg_cnt);
    if (rcs_neg_cnt != exp_rcs_neg_cnt) {
      CT_ERR_MSG("Read CS Negadge Count is mismatched\n");
      ret = VERIFY_ERROR;
      goto end_test;
    }
#endif
  }
 end_test:
  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
  CT_MSG("<< TC Resume Read Test");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;

  return ret;
}

int tc_rd_tc_option (DWORD cs)
{
  int ret = NO_ERROR;
  int i, j, k, l, m;
  DWORD addr;
  DWORD len = MAX_LEN;
  WORD len16;
  DWORD wrapsize = 64;
  DWORD wraplen;
  DWORD rsize[] = {BYTE_1,BYTE_2,BYTE_4};
  DWORD rlen[] = {16, 8, 4};
  DWORD roffset;
  BYTE* wbuf;
  BYTE* rbuf;
  BYTE  expect[wrapsize];
  DWORD pattern;
  DWORD mbrReg;
  DWORD devtype;
  DWORD rpcClk;
  int rxferByte;
#if (RPC2_CTRL_IP_VER >= 230)
  DWORD rcs_neg_cnt;
  DWORD exp_rcs_neg_cnt;
#endif
#if (RPC2_CTRL_IP_VER >= 240)
  DWORD maxlen;
#endif

  CT_MSG(">> TC Read w/ TC Option Test\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
  getDevType(&devtype, cs);

  if (devtype == PSRAM) {
#if (RPC2_CTRL_IP_VER >= 240)
    getMAXLEN(&maxlen, cs);

    while (((len*sizeof(DWORD)+wrapsize)/sizeof(WORD)) > maxlen + 1) {
      len /= 2;
    }
#endif
    getRpcClkPeriod(&rpcClk);
    while (PSRAM_TCSM <= (rpcClk*len*sizeof(DWORD)/sizeof(WORD))) {
      len /= 2;
    }
  }
  len16 = (wrapsize/sizeof(WORD)*2+len*sizeof(DWORD)/sizeof(WORD));
  wbuf = (BYTE*)malloc(sizeof(WORD)*len16);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  rbuf = (BYTE*)malloc(sizeof(WORD)*len16);
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  getDataPattern(&pattern);
  fillBuffer(pattern, (WORD*)wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer((WORD*)wbuf, len16);

  addr = 0;
  // Set initial data
  ret = RPC2_WRITE32(addr+mbrReg, wrapsize/sizeof(DWORD), (DWORD*)wbuf);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("RPC2_WRITE32: %d\n", ret);
    goto end_test;
  }
  CT_MSG("Write addr 0x%08X, len8 0x%x\n", addr+mbrReg, wrapsize);
  ret = RPC2_WRITE32(addr+wrapsize+mbrReg, wrapsize/sizeof(DWORD), (DWORD*)(&wbuf[wrapsize]));
  if (ret != NO_ERROR) {
    CT_ERR_MSG("RPC2_WRITE32: %d\n", ret);
    goto end_test;
  }
  CT_MSG("Write addr 0x%08X, len8 0x%x\n", addr+wrapsize+mbrReg, wrapsize);
  ret = RPC2_WRITE32(addr+wrapsize*2+mbrReg, len, (DWORD*)(&wbuf[wrapsize*2]));
  if (ret != NO_ERROR) {
    CT_ERR_MSG("RPC2_WRITE32: %d\n", ret);
    goto end_test;
  }
  CT_MSG("Write addr 0x%08X, len8 0x%x\n", addr+wrapsize*2+mbrReg, len*sizeof(DWORD));

  for (m = 0; m < 3; m++) {
    // Set wrap size
    wrapsize = WRAP_BURST[m][0];
    CT_MSG("Wrap Size=%2d -----------------------------\n", wrapsize);
    setWrapSize (WRAP_BURST[m][1], cs);
    set_cr_wrapsize (WRAP_BURST[m][1], WRAP2INCR_ON, cs);

  for (l = 0; l < 3; l++) {
    rxferByte = 1 << rsize[l];
    CT_MSG("SIZE=%1d ---------------------------------------\n", rxferByte);
    roffset = rxferByte;
    if (rxferByte == 1) {
      roffset = 2;
    }
    for (k = 0; k < 3; k++) {
      wraplen = rlen[k];

      if (rxferByte*wraplen == wrapsize) {
        CT_MSG("LEN=%2d ---------------------------------------\n", wraplen);
        addr = 0;

        for (j = 0; j < 2; j++) {
          // Clear/Set TC Option
          setTCOption(j, cs);
          CT_MSG("TC Option=%1d -----------------------------------\n", j); 

          for (i = 0; i < wrapsize; i+=roffset) {
#if (RPC2_CTRL_IP_VER >= 230)
            startCScnt(cs);
#endif
            switch (l) {
              case BYTE_1:
                RPC_READ_WRAP_BURST8(addr+mbrReg+i, wraplen);
                RPC_READ_BURST8(addr+mbrReg+wrapsize, len);
                CT_MSG("Wrap Read addr 0x%08X, len8 0x%x\n", addr+mbrReg+i, wraplen);
                CT_MSG("Incr Read addr 0x%08X, len8 0x%x\n", addr+mbrReg+wrapsize, len);
                ret = RPC2_GET_DATA8(wraplen, rbuf);
                if (ret != NO_ERROR) {
                  CT_ERR_MSG("RPC_READ_WRAP_BURST8: %d\n", ret);
                  goto end_test;
                }
                ret = RPC2_GET_DATA8(len, &rbuf[wrapsize]);
                if (ret != NO_ERROR) {
                  CT_ERR_MSG("RPC_READ_BURST8: %d\n", ret);
                  goto end_test;
                }
                break;
              case BYTE_2:
	        RPC_READ_WRAP_BURST(addr+mbrReg+i, wraplen);
                RPC_READ_BURST(addr+mbrReg+wrapsize, len);
                CT_MSG("Wrap Read addr 0x%08X, len16 0x%x\n", addr+mbrReg+i, wraplen);
                CT_MSG("Incr Read addr 0x%08X, len16 0x%x\n", addr+mbrReg+wrapsize, len);
                ret = RPC2_GET_DATA(wraplen, (WORD*)rbuf);
                if (ret != NO_ERROR) {
                  CT_ERR_MSG("RPC_READ_WRAP_BURST16: %d\n", ret);
                  goto end_test;
                }
                ret = RPC2_GET_DATA(len, (WORD*)(&rbuf[wrapsize]));
                if (ret != NO_ERROR) {
                  CT_ERR_MSG("RPC_READ_BURST: %d\n", ret);
                  goto end_test;
                }
                break;
              case BYTE_4:
                RPC_READ_WRAP_BURST32(addr+mbrReg+i, wraplen);
                RPC_READ_BURST32(addr+mbrReg+wrapsize, len);
                CT_MSG("Wrap Read addr 0x%08X, len32 0x%x\n", addr+mbrReg+i, wraplen);
                CT_MSG("Incr Read addr 0x%08X, len32 0x%x\n", addr+mbrReg+wrapsize, len);
                ret = RPC2_GET_DATA32(wraplen, (DWORD*)rbuf);
                if (ret != NO_ERROR) {
                  CT_ERR_MSG("RPC_READ_WRAP_BURST32: %d\n", ret);
                  goto end_test;
                }
                ret = RPC2_GET_DATA32(len, (DWORD*)(&rbuf[wrapsize]));
                if (ret != NO_ERROR) {
                  CT_ERR_MSG("RPC_READ_BURST32: %d\n", ret);
                  goto end_test;
                }
                break;
              default:
                break;
            }
#if (RPC2_CTRL_IP_VER >= 230)
            endCScnt(cs);
            getCScnt(cs, &rcs_neg_cnt);
#endif

            wrapMemCopy8(expect, &wbuf[addr], wrapsize, i);
            if (verifyData8(rbuf, expect, wrapsize)) {
              CT_ERR_MSG("Wrap VerifyData8\n");
                ret = VERIFY_ERROR;
              goto end_test;
            }
            if (verifyData8(&rbuf[wrapsize], &wbuf[addr+wrapsize], len*rxferByte)) {
              CT_ERR_MSG("VerifyData8\n");
              ret = VERIFY_ERROR;
              goto end_test;
            }

#if (RPC2_CTRL_IP_VER >= 240)
            if (j == 1) {
              exp_rcs_neg_cnt = 1;
            } else {
              if (i == 0) {
                exp_rcs_neg_cnt = 1;
              } else {
                exp_rcs_neg_cnt = 2;
              }
            }
            CT_MSG("Comare Read  CS Negadge Count exp: %d, act: %d ---\n", exp_rcs_neg_cnt, rcs_neg_cnt);
            if (rcs_neg_cnt != exp_rcs_neg_cnt) {
              CT_ERR_MSG("Read CS Negadge Count is mismatched\n");
              ret = VERIFY_ERROR;
              goto end_test;
            }
#elif (RPC2_CTRL_IP_VER >= 230)
            if (j == 1) {
              if (devtype == FLASH) {
                exp_rcs_neg_cnt = 1;
              } else {
                exp_rcs_neg_cnt = 2;
              }
            } else {
              if ((i == 0) && (devtype == FLASH)) {
                exp_rcs_neg_cnt = 1;
              } else {
                exp_rcs_neg_cnt = 2;
              }
            }
            CT_MSG("Comare Read  CS Negadge Count exp: %d, act: %d ---\n", exp_rcs_neg_cnt, rcs_neg_cnt);
            if (rcs_neg_cnt != exp_rcs_neg_cnt) {
              CT_ERR_MSG("Read CS Negadge Count is mismatched\n");
              ret = VERIFY_ERROR;
              goto end_test;
            }
#endif
          }
          addr += wrapsize;
        }
      }
    }
  }
  }
  // Clear TC Option
  CT_MSG("Clear TC Option\n");
  setTCOption(0, cs);
  setWrapSize (BURST_32B, cs);
  set_cr_wrapsize (BURST_32B, WRAP2INCR_OFF, cs);
 end_test:
  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
  CT_MSG("<< TC Read w/ TC Option Test");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;

  return ret;
}

int emulated_wrap_burst_rd (DWORD cs)
{
  int i, j, k, l;
  int ret = NO_ERROR;
  DWORD addr;
  DWORD len = 16;
  DWORD len16;
  DWORD rsize[] = {BYTE_1,BYTE_2,BYTE_4};
  DWORD rlen[] = {16, 8, 4};
  DWORD wraplen;
  DWORD wrapsize;
  BYTE* wbuf;
  BYTE* rbuf;
  BYTE  expect[sizeof(DWORD)*len];
  int   rxferByte;

  DWORD pattern;
  DWORD mbrReg;
#if (RPC2_CTRL_IP_VER >= 230)
  DWORD rcs_neg_cnt;
  DWORD exp_rcs_neg_cnt;
#endif

  CT_MSG(">> Emulated Wrap Burst Read Test\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
  wbuf = (BYTE*)malloc(sizeof(DWORD)*len);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  rbuf = (BYTE*)malloc(sizeof(DWORD)*len);
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  len16 = len*sizeof(DWORD)/sizeof(WORD);
  getDataPattern(&pattern);
  fillBuffer(pattern, (WORD*)wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer((WORD*)wbuf, len16);

  // Set asymmetric cache support
  setACacheSupport(1, cs);

  addr = 0;
  // Set initial data
  ret = RPC2_WRITE32(addr+mbrReg, len, (DWORD*)wbuf);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("RPC2_WRITE32: %d\n", ret);
    goto end_test;
  }
  CT_MSG("Write addr 0x%08X, len32 0x%x\n", addr+mbrReg, len);

  for (l = 0; l < 3; l++) {
    // Set wrap size
    CT_MSG("Wrap Size=%2d -----------------------------\n", WRAP_BURST[l][0]);
    setWrapSize (WRAP_BURST[l][1], cs);
    set_cr_wrapsize (WRAP_BURST[l][1], WRAP2INCR_OFF, cs);

  for (k = 0; k < 3; k++) {
    rxferByte = 1 << rsize[k];
    CT_MSG("SIZE=%1d ---------------------------------------\n", rxferByte);

    for (j = 0; j < (k+1); j++) {
      wraplen = rlen[j];
      wrapsize = wraplen*rxferByte;
      CT_MSG("LEN=%2d ---------------------------------------\n", wraplen);
      for (addr = 0; addr < 64; addr+=wrapsize) {
        for (i = 0; i < wrapsize; i+=rxferByte) {
	  CT_MSG("Wrap Read addr 0x%08X, Wrap Size 0x%02d\n", addr+mbrReg+i, wrapsize);
#if (RPC2_CTRL_IP_VER >= 230)
          startCScnt(cs);
#endif
          switch (k) {
            case BYTE_1:
	        RPC_READ_WRAP_BURST8(addr+mbrReg+i, wraplen);
                ret = RPC2_GET_DATA8(wraplen, rbuf);
	        if (ret != NO_ERROR) {
	          CT_ERR_MSG("RPC_READ_WRAP_BURST8: %d\n", ret);
	          goto end_test;
	        }
                break;
            case BYTE_2:
	        RPC_READ_WRAP_BURST(addr+mbrReg+i, wraplen);
                ret = RPC2_GET_DATA(wraplen, (WORD*)rbuf);
	        if (ret != NO_ERROR) {
	          CT_ERR_MSG("RPC_READ_WRAP_BURST: %d\n", ret);
	          goto end_test;
	        }
                break;
            case BYTE_4:
	        RPC_READ_WRAP_BURST32(addr+mbrReg+i, wraplen);
                ret = RPC2_GET_DATA32(wraplen, (DWORD*)rbuf);
	        if (ret != NO_ERROR) {
	          CT_ERR_MSG("RPC_READ_WRAP_BURST32: %d\n", ret);
	          goto end_test;
	        }
                break;
            default:
                break;
          }
#if (RPC2_CTRL_IP_VER >= 230)
          endCScnt(cs);
          getCScnt(cs, &rcs_neg_cnt);
#endif
          wrapMemCopy8(expect, &wbuf[addr], wrapsize, i);
          if (verifyData8(rbuf, expect, wrapsize)) {
            CT_ERR_MSG("Wrap VerifyData8\n");
            ret = VERIFY_ERROR;
            goto end_test;
          }
#if (RPC2_CTRL_IP_VER >= 230)
          if ((WRAP_BURST[l][0] != wrapsize) && (i)){
            exp_rcs_neg_cnt = 2;
          } else {
            exp_rcs_neg_cnt = 1;
          }
          CT_MSG("Comare Read  CS Negadge Count exp: %d, act: %d ---\n", exp_rcs_neg_cnt, rcs_neg_cnt);
          if (rcs_neg_cnt != exp_rcs_neg_cnt) {
            CT_ERR_MSG("Read CS Negadge Count is mismatched\n");
            ret = VERIFY_ERROR;
            goto end_test;
          }
#endif
        } //for i
      } //for addr
    } //for j
  } //for k
  } //for l

  // Clear asymmetric cache support
  setACacheSupport(0, cs);
  setWrapSize (BURST_32B, cs);
  set_cr_wrapsize (BURST_32B, WRAP2INCR_OFF, cs);
end_test:
  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
  CT_MSG("<< Emulated Wrap Burst Read Test");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;

  return ret;
}

int emulated_wrap_burst_w_tc_rd (DWORD cs)
{
  int i, j, k, l;
  int ret = NO_ERROR;
  DWORD addr;
  DWORD len = MAX_LEN;
  DWORD len16;
  DWORD rsize[] = {BYTE_1,BYTE_2,BYTE_4};
  DWORD rlen[] = {16, 8, 4};
  DWORD roffset;
  DWORD wraplen = 16;
  DWORD wrapsize;
  BYTE* wbuf;
  BYTE* rbuf;
  BYTE  expect[sizeof(DWORD)*len];
  int   rxferByte;

  DWORD pattern;
  DWORD mbrReg;
  DWORD devtype;
  DWORD rpcClk;
#if (RPC2_CTRL_IP_VER >= 230)
  DWORD rcs_neg_cnt;
  DWORD exp_rcs_neg_cnt;
#endif
#if (RPC2_CTRL_IP_VER >= 240)
  DWORD maxlen;
#endif

  CT_MSG(">> Emulated Wrap Burst Read Test\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
  getDevType(&devtype, cs);

  if (devtype == PSRAM) {
#if (RPC2_CTRL_IP_VER >= 240)
    getMAXLEN(&maxlen, cs);

    while ((((len+wraplen)*sizeof(DWORD))/sizeof(WORD)) > maxlen + 1) {
      len /= 2;
    }
#endif
    getRpcClkPeriod(&rpcClk);
    while (PSRAM_TCSM <= (rpcClk*len*sizeof(DWORD)/sizeof(WORD))) {
      len /= 2;
    }
  }
  wbuf = (BYTE*)malloc(sizeof(DWORD)*(wraplen+len));
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  rbuf = (BYTE*)malloc(sizeof(DWORD)*(wraplen+len));
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  len16 = (wraplen+len)*sizeof(DWORD)/sizeof(WORD);
  getDataPattern(&pattern);
  fillBuffer(pattern, (WORD*)wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer((WORD*)wbuf, len16);

  // Set asymmetric cache support
  setACacheSupport(1, cs);
  // Set TC Option
  setTCOption(1, cs);

  addr = 0;
  // Set initial data
  wrapsize = wraplen*sizeof(DWORD);
  ret = RPC2_WRITE32(addr+mbrReg, wraplen, (DWORD*)wbuf);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("RPC2_WRITE32: %d\n", ret);
    goto end_test;
  }
  CT_MSG("Write addr 0x%08X, len8 0x%x\n", addr+mbrReg, wrapsize);
  ret = RPC2_WRITE32(addr+wrapsize+mbrReg, len, (DWORD*)(&wbuf[wrapsize]));
  if (ret != NO_ERROR) {
    CT_ERR_MSG("RPC2_WRITE32: %d\n", ret);
    goto end_test;
  }
  CT_MSG("Write addr 0x%08X, len8 0x%x\n", addr+wrapsize+mbrReg, len*sizeof(DWORD));

  for (l = 0; l < 3; l++) {
    // Set wrap size
    CT_MSG("Wrap Size=%2d -----------------------------\n", WRAP_BURST[l][0]);
    setWrapSize (WRAP_BURST[l][1], cs);
    set_cr_wrapsize (WRAP_BURST[l][1], 0, cs);

  for (k = 0; k < 3; k++) {
    rxferByte = 1 << rsize[k];
    CT_MSG("SIZE=%1d ---------------------------------------\n", rxferByte);
    roffset = rxferByte;
    if (rxferByte == 1) {
      roffset = 2;
    }

    for (j = 0; j < (k+1); j++) {
      wraplen = rlen[j];
      CT_MSG("LEN=%2d ---------------------------------------\n", wraplen);
      wrapsize = wraplen*rxferByte;

      for (addr = 0; addr < 64; addr+=wrapsize) {

        for (i = 0; i < wrapsize; i+=roffset) {
#if (RPC2_CTRL_IP_VER >= 230)
          startCScnt(cs);
#endif
          switch (k) {
            case BYTE_1:
              RPC_READ_WRAP_BURST8(addr+mbrReg+i, wraplen);
              RPC_READ_BURST8(addr+mbrReg+wrapsize, len);
              CT_MSG("Wrap Read addr 0x%08X, len8 0x%x\n", addr+mbrReg+i, wraplen);
              CT_MSG("Incr Read addr 0x%08X, len8 0x%x\n", addr+mbrReg+wrapsize, len);
              ret = RPC2_GET_DATA8(wraplen, rbuf);
              if (ret != NO_ERROR) {
                CT_ERR_MSG("RPC_READ_WRAP_BURST8: %d\n", ret);
                goto end_test;
              }
              ret = RPC2_GET_DATA8(len, &rbuf[wrapsize]);
              if (ret != NO_ERROR) {
                CT_ERR_MSG("RPC_READ_BURST8: %d\n", ret);
                goto end_test;
              }
              break;
            case BYTE_2:
              RPC_READ_WRAP_BURST(addr+mbrReg+i, wraplen);
              RPC_READ_BURST(addr+mbrReg+wrapsize, len);
              CT_MSG("Wrap Read addr 0x%08X, len16 0x%x\n", addr+mbrReg+i, wraplen);
              CT_MSG("Incr Read addr 0x%08X, len16 0x%x\n", addr+mbrReg+wrapsize, len);
              ret = RPC2_GET_DATA(wraplen, (WORD*)rbuf);
              if (ret != NO_ERROR) {
                CT_ERR_MSG("RPC_READ_WRAP_BURST16: %d\n", ret);
                goto end_test;
              }
              ret = RPC2_GET_DATA(len, (WORD*)(&rbuf[wrapsize]));
              if (ret != NO_ERROR) {
                CT_ERR_MSG("RPC_READ_BURST: %d\n", ret);
                goto end_test;
              }
              break;
            case BYTE_4:
              RPC_READ_WRAP_BURST32(addr+mbrReg+i, wraplen);
              RPC_READ_BURST32(addr+mbrReg+wrapsize, len);
              CT_MSG("Wrap Read addr 0x%08X, len32 0x%x\n", addr+mbrReg+i, wraplen);
              CT_MSG("Incr Read addr 0x%08X, len32 0x%x\n", addr+mbrReg+wrapsize, len);
              ret = RPC2_GET_DATA32(wraplen, (DWORD*)rbuf);
              if (ret != NO_ERROR) {
                CT_ERR_MSG("RPC_READ_WRAP_BURST32: %d\n", ret);
                goto end_test;
              }
              ret = RPC2_GET_DATA32(len, (DWORD*)(&rbuf[wrapsize]));
              if (ret != NO_ERROR) {
                CT_ERR_MSG("RPC_READ_BURST32: %d\n", ret);
                goto end_test;
              }
              break;
            default:
              break;
          }
#if (RPC2_CTRL_IP_VER >= 230)
          endCScnt(cs);
          getCScnt(cs, &rcs_neg_cnt);
#endif
          wrapMemCopy8(expect, &wbuf[addr], wrapsize, i);
          if (verifyData8(rbuf, expect, wrapsize)) {
            CT_ERR_MSG("Wrap VerifyData8\n");
            ret = VERIFY_ERROR;
            goto end_test;
          }
          if (verifyData8(&rbuf[wrapsize], &wbuf[addr+wrapsize], len*rxferByte)) {
            CT_ERR_MSG("VerifyData8\n");
            ret = VERIFY_ERROR;
            goto end_test;
          }
#if (RPC2_CTRL_IP_VER >= 240)
          if ((WRAP_BURST[l][0] != wrapsize) && (i)) {
            exp_rcs_neg_cnt = 3;
          } else {
            exp_rcs_neg_cnt = 1;
          }
          CT_MSG("Comare Read  CS Negadge Count exp: %d, act: %d ---\n", exp_rcs_neg_cnt, rcs_neg_cnt);
          if (rcs_neg_cnt != exp_rcs_neg_cnt) {
            CT_ERR_MSG("Read CS Negadge Count is mismatched\n");
            ret = VERIFY_ERROR;
            goto end_test;
          }
#elif (RPC2_CTRL_IP_VER >= 230)
          if ((WRAP_BURST[l][0] != wrapsize) && (i)) {
            exp_rcs_neg_cnt = 3;
          } else {
            if (devtype == FLASH) {
              exp_rcs_neg_cnt = 1;
            } else {
              exp_rcs_neg_cnt = 2;
            }
          }
          CT_MSG("Comare Read  CS Negadge Count exp: %d, act: %d ---\n", exp_rcs_neg_cnt, rcs_neg_cnt);
          if (rcs_neg_cnt != exp_rcs_neg_cnt) {
            CT_ERR_MSG("Read CS Negadge Count is mismatched\n");
            ret = VERIFY_ERROR;
            goto end_test;
          }
#endif
        } //for i
      } //for addr
    } //for j
  } //for k
  } //for l

  // Clear asymmetric cache support
  setACacheSupport(0, cs);
  // Clear TC Option
  setTCOption(0, cs);
  setWrapSize (BURST_32B, cs);
  set_cr_wrapsize (BURST_32B, WRAP2INCR_OFF, cs);
end_test:
  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
  CT_MSG("<< Emulated Wrap Burst Read Test");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;

  return ret;
}

int memory_timing_control (DWORD cs)
{
  int i;
  int ret = NO_ERROR;
  int status;
  int trans = 2;

  DWORD mtrReg = REG_MTR0_ADDR;
  DWORD reg;
  DWORD addr;
  DWORD incAddr = sizeof(DWORD);
  DWORD len16 = 1;
  WORD* wbuf;
  WORD* rbuf;
  DWORD pattern;
  DWORD mbrReg;

  CT_MSG(">> Memory Timing Control Test\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }

  if (cs == CS1_SEL) {
    mtrReg = REG_MTR1_ADDR;
  } else if (cs > CS1_SEL) {
    cs = 0;
  }
  status = RPC2_READ_REG(mtrReg, &reg);
  if (ret != NO_ERROR) goto end_test;
  CT_MSG("MTR%d = 0x%08X\n", cs, reg);

  wbuf = (WORD*)malloc(sizeof(WORD)*len16*trans*16);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  rbuf = (WORD*)malloc(sizeof(WORD)*len16*trans*16);
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16*trans*16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16*trans*16);

  for (i = 0; i < 16; i++) {
    setRCSHIcycle(i, cs); if (ret != NO_ERROR) goto end_test;
    setWCSHIcycle(i, cs); if (ret != NO_ERROR) goto end_test;
    setRCSScycle(i, cs); if (ret != NO_ERROR) goto end_test;
    setWCSScycle(i, cs); if (ret != NO_ERROR) goto end_test;
    setRCSHcycle(i, cs); if (ret != NO_ERROR) goto end_test;
    setWCSHcycle(i, cs); if (ret != NO_ERROR) goto end_test;

    addr = i*(sizeof(WORD)*len16*trans + incAddr) + mbrReg;
    ret = sequential_wr_incaddr(addr, incAddr, len16, trans, &wbuf[i*len16*trans]);
    if (ret != NO_ERROR) {
      goto end_test;
    }
    ret = sequential_rd_incaddr(addr, incAddr, len16, trans, &rbuf[i*len16*trans], INCR);
    if (ret != NO_ERROR) {
      goto end_test;
    }
    if (verifyData(rbuf, wbuf, len16*trans)) {
      CT_ERR_MSG("VerifyData32\n");
      ret = VERIFY_ERROR;
      goto end_test;
    }
  }
  CT_MSG("Set MTR%d = 0x%08X\n", cs, reg);
  status = RPC2_WRITE_REG(mtrReg, &reg);
  if (ret != NO_ERROR) goto end_test;
  status = RPC2_READ_REG(mtrReg, &reg);
  if (ret != NO_ERROR) goto end_test;
  CT_MSG("MTR%d = 0x%08X\n", cs, reg);
 end_test:
  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
  CT_MSG("<< Memory Timing Control Test\n");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int wr_rd_even_odd_addr_1B(DWORD cs)
{
  int ret = NO_ERROR;
  int i;

  DWORD len8 = MAX_ADDR_LOOP;
  DWORD len16;
  BYTE* wbuf;
  DWORD pattern;

  CT_MSG(">> 1B Even/Odd Address Write/Read Test\n");
  len16 = (len8+1)/sizeof(WORD);

  wbuf = (BYTE*)malloc(sizeof(WORD)*len16);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, (WORD*)wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer((WORD*)wbuf, len16);

  CT_MSG("1B Even Address Write/Read --------------------------------\n");
  for (i = 0; i < MAX_ADDR_LOOP; i++) {
    ret = wr8_rd8(i*2, 0, 1, &(wbuf[i]), cs);
    if (ret != NO_ERROR) {
      break;
    }
  }

  CT_MSG("1B Odd Address Write/Read --------------------------------\n");
  for (i = 0; i < MAX_ADDR_LOOP; i++) {
    ret = wr8_rd8(1+i*2, 0, 1, &(wbuf[i]), cs);
    if (ret != NO_ERROR) {
      break;
    }
  }

 end_test:
  if (wbuf) {
    free(wbuf);
  }
  CT_MSG("<< 1B Even/Odd Address Write/Read Test");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int wr_rd_1B_burst(DWORD cs)
{
  int ret = NO_ERROR;
  int i;

  DWORD len8 = 2;
  DWORD len16;
  WORD* wbuf;
  DWORD pattern;

  CT_MSG(">> 1B Burst Write/Read Test\n");

  len16 = (len8+(sizeof(WORD)-1))/sizeof(WORD);
  wbuf = (WORD*)malloc(sizeof(WORD)*len16);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  CT_MSG("1B x 2 Burst Write/Read --------------------------------\n");
  for (i = 0; i < MAX_ADDR_LOOP; i++) {
    wr8_rd8_burst (1+i*4, len8, (BYTE*)wbuf, cs);
    if (ret != NO_ERROR) {
      break;
    }
  }

 end_test:
  if (wbuf) {
    free(wbuf);
  }
  CT_MSG("<< 1B Burst Write/Read Test\n");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int tc_rd_1B (DWORD cs)
{
  int ret = NO_ERROR;
  int trans = 4;
  DWORD addr;
  DWORD len8 = MAX_LEN*trans;
  DWORD len16;
  WORD* wbuf;
  WORD* rbuf;
  DWORD pattern;
  DWORD mbrReg;

  CT_MSG(">> 1B Burst TC Read Test\n");

  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }

  len16 = (len8+(sizeof(WORD)-1))/sizeof(WORD);
  wbuf = (WORD*)malloc(sizeof(WORD)*len16);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  rbuf = (WORD*)malloc(sizeof(WORD)*len16);
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  addr = 0;
  // Set initial data
  ret = RPC2_WRITE8(addr+mbrReg, len8, (BYTE*)wbuf);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("RPC2_WRITE8: %d\n", ret);
    goto end_test;
  }
  CT_MSG("Write addr 0x%08X, len 0x%x\n", addr+mbrReg, len8);

  len8 = MAX_LEN;
  ret = sequential_rd8(addr+mbrReg, len8, trans, (BYTE*)rbuf, 1); //INCR
  if (ret != NO_ERROR) {
    goto end_test;
  }
  if (verifyData8((BYTE*)rbuf, (BYTE*)wbuf, len8*trans)) {
    CT_ERR_MSG("VerifyData8\n");
    ret = VERIFY_ERROR;
    goto end_test;
  }

 end_test:
  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
  CT_MSG("<< 1B Size Burst TC Read Test");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;

  return ret;
}

int tc_rd_wrap_boundary_1B (DWORD cs)
{
  int ret = NO_ERROR;
  int trans = 4;
  DWORD addr;
  DWORD len8 = 16*trans;
  DWORD len16;
  WORD* wbuf;
  WORD* rbuf;
  DWORD pattern;
  DWORD mbrReg;

  CT_MSG(">> 1B Burst TC Read Wrap Boundary Test\n");

  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }

  len16 = (len8+(sizeof(WORD)-1))/sizeof(WORD);
  wbuf = (WORD*)malloc(sizeof(WORD)*len16);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  rbuf = (WORD*)malloc(sizeof(WORD)*len16);
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  addr = 0;
  // Set initial data
  ret = RPC2_WRITE8(addr+mbrReg, len8, (BYTE*)wbuf);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("RPC2_WRITE8: %d\n", ret);
    goto end_test;
  }
  CT_MSG("Write addr 0x%08X, len 0x%x\n", addr+mbrReg, len8);

  // Set wrap size
  CT_MSG("Wrap Size=%2d -----------------------------\n", BURST_16B);
  setWrapSize (BURST_16B, cs);
  set_cr_wrapsize (BURST_16B, WRAP2INCR_OFF, cs);

  len8 = 16;
  CT_MSG("LEN=%2d from Aligned Wrap address --------------------\n", len8);
  ret = sequential_rd8(addr+mbrReg, len8, trans, (BYTE*)rbuf, 0); //WRAP
  if (ret != NO_ERROR) {
    goto end_test;
  }
  if (verifyData8((BYTE*)rbuf, (BYTE*)wbuf, len8*trans)) {
    CT_ERR_MSG("VerifyData8\n");
    ret = VERIFY_ERROR;
    goto end_test;
  }
  setWrapSize (BURST_32B, cs);
  set_cr_wrapsize (BURST_32B, WRAP2INCR_OFF, cs);
 end_test:
  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
  CT_MSG("<< 1B Burst TC Read Wrap Boundary Test");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;

  return ret;
}

int tc_resume_rd_1B (DWORD cs)
{
  int ret = NO_ERROR;
  int trans;
  int i;
  DWORD addr;
  DWORD len8;
  DWORD len16;
  WORD* wbuf;
  WORD* rbuf;
  DWORD pattern;
  DWORD mbrReg;

  CT_MSG(">> 1B Burst TC Resume Read Test\n");

  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
  if (MAX_RDAT_FIFO_SIZE*sizeof(DWORD)*4 < MAX_LEN) {
    len8 = MAX_RDAT_FIFO_SIZE*sizeof(DWORD)*4;
    trans = 1;
    len16 = len8/2*trans;
  } else {
    len8 = MAX_LEN;
    trans = (MAX_RDAT_FIFO_SIZE*sizeof(DWORD)*4)/MAX_LEN;
    len16 = len8/2*trans;
  }
  wbuf = (WORD*)malloc(sizeof(WORD)*len16);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  rbuf = (WORD*)malloc(sizeof(WORD)*len16);
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);
  
  addr = 0;
  for (i = 0; i < 2; i++) {
    addr = i*2;
    len8 = MAX_LEN*trans;

    // Set initial data
    ret = RPC2_WRITE8(addr+mbrReg, len8, (BYTE *)wbuf);
    if (ret != NO_ERROR) {
      CT_ERR_MSG("RPC2_WRITE8: %d\n", ret);
      goto end_test;
    }
    CT_MSG("Write addr 0x%08X, len 0x%x\n", addr+mbrReg, len8);
    
    len8 = MAX_LEN;
    
    RPC2_IDLE_READ_DATA(200);
    CT_MSG("Wait until RXFIFO is full\n");

    ret = sequential_rd8(addr+mbrReg, len8, trans, (BYTE*)rbuf, 1); //INCR
    if (ret != NO_ERROR) {
      goto end_test;
    }
    if (verifyData8((BYTE *)rbuf, (BYTE *)wbuf, len8*trans)) {
      CT_ERR_MSG("VerifyData8\n");
      ret = VERIFY_ERROR;
      goto end_test;
    }
  }
 end_test:
  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
  CT_MSG("<< 1B Burst TC Resume Read Test\n");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;

  return ret;
}

int tc_rd_tc_option_1B (DWORD cs)
{
  int ret = NO_ERROR;
  int i;
  DWORD addr;
  DWORD len8 = MAX_LEN;
  WORD len16;
  DWORD wraplen = 16;
  BYTE* wbuf;
  BYTE* rbuf;
  BYTE  expect[wraplen];
  DWORD pattern;
  DWORD mbrReg;

  CT_MSG(">> 1B Burst TC Read w/ TC Option Test\n");

  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
  len16 = (wraplen*2+len8)/sizeof(WORD);
  wbuf = (BYTE*)malloc(sizeof(WORD)*len16);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  rbuf = (BYTE*)malloc(sizeof(WORD)*len16);
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  getDataPattern(&pattern);
  fillBuffer(pattern, (WORD*)wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer((WORD*)wbuf, len16);

  addr = 0;
  // Set initial data
  ret = RPC2_WRITE8(addr+mbrReg, wraplen, wbuf);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("RPC2_WRITE8: %d\n", ret);
    goto end_test;
  }
  CT_MSG("Write addr 0x%08X, len8 0x%x\n", addr+mbrReg, wraplen);
  ret = RPC2_WRITE8(addr+wraplen+mbrReg, wraplen, &wbuf[wraplen]);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("RPC2_WRITE8: %d\n", ret);
    goto end_test;
  }
  CT_MSG("Write addr 0x%08X, len8 0x%x\n", addr+wraplen+mbrReg, wraplen);
  ret = RPC2_WRITE8(addr+wraplen*2+mbrReg, len8, &wbuf[wraplen*2]);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("RPC2_WRITE8: %d\n", ret);
    goto end_test;
  }
  CT_MSG("Write addr 0x%08X, len8 0x%x\n", addr+wraplen*2+mbrReg, len8);

  CT_MSG("TC Option=0 -----------------------------------\n");
  for (i = 0; i < wraplen; i+=2) {
    RPC_READ_WRAP_BURST8(addr+mbrReg+i, wraplen);
    RPC_READ_BURST8(addr+mbrReg+wraplen, len8);
    CT_MSG("Wrap Read addr 0x%08X, len8 0x%x\n", addr+mbrReg+i, wraplen);
    CT_MSG("Incr Read addr 0x%08X, len8 0x%x\n", addr+mbrReg+wraplen, len8);

    ret = RPC2_GET_DATA8(wraplen, rbuf);
    if (ret != NO_ERROR) {
      CT_ERR_MSG("RPC_READ_WRAP_BURST8: %d\n", ret);
      goto end_test;
    }
    wrapMemCopy8(expect, &wbuf[addr], wraplen, i);

    if (verifyData8(rbuf, expect, wraplen)) {
      CT_ERR_MSG("Wrap VerifyData8\n");
      ret = VERIFY_ERROR;
      goto end_test;
    }
    ret = RPC2_GET_DATA8(len8, rbuf);
    if (ret != NO_ERROR) {
      CT_ERR_MSG("RPC_READ_BURST8: %d\n", ret);
      goto end_test;
    }
    if (verifyData8(rbuf, &wbuf[wraplen], len8)) {
      CT_ERR_MSG("VerifyData8\n");
      ret = VERIFY_ERROR;
      goto end_test;
    }
  }

  // Set TC Option
  CT_MSG("Set TC Option\n");
  setTCOption(1, cs);

  CT_MSG("TC Option=1 -----------------------------------\n");
  addr = wraplen;
  for (i = 0; i < wraplen; i+=2) {
    RPC_READ_WRAP_BURST8(addr+mbrReg+i, wraplen);
    RPC_READ_BURST8(addr+mbrReg+wraplen, len8);
    CT_MSG("Wrap Read addr 0x%08X, len8 0x%x\n", addr+mbrReg+i, wraplen);
    CT_MSG("Incr Read addr 0x%08X, len8 0x%x\n", addr+mbrReg+wraplen, len8);

    ret = RPC2_GET_DATA8(wraplen, rbuf);
    wrapMemCopy8(expect, &wbuf[addr], wraplen, i);
    if (verifyData8(rbuf, expect, wraplen)) {
      CT_ERR_MSG("Wrap VerifyData8\n");
      ret = VERIFY_ERROR;
      goto end_test;
    }
    ret = RPC2_GET_DATA8(len8, rbuf);
    if (verifyData8(rbuf, &wbuf[wraplen*2], len8)) {
      CT_ERR_MSG("VerifyData8\n");
      ret = VERIFY_ERROR;
      goto end_test;
    }
  }

  // Clear TC Option
  CT_MSG("Clear TC Option\n");
  setTCOption(0, cs);
 end_test:
  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
  CT_MSG("<< 1B Burst TC Read w/ TC Option Test");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;

  return ret;
}

int rd_wo_TC_1B_burst (DWORD cs)
{
  int ret = NO_ERROR;
  int trans = 4;
  DWORD addr;
  DWORD len8 = MAX_LEN*trans;
  DWORD len16;
  BYTE* wbuf;
  BYTE* rbuf;
  DWORD pattern;
  DWORD mbrReg;
#if (RPC2_CTRL_IP_VER >= 230)
  DWORD maxen;
  DWORD maxlen;
  DWORD rcs_neg_cnt;
  DWORD exp_rcs_neg_cnt;
#endif

  CT_MSG(">> 1B Burst Read Odd Address w/o TC Test\n");

  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
#if (RPC2_CTRL_IP_VER >= 230)
  getMAXEN(&maxen, cs);
  getMAXLEN(&maxlen, cs);
#endif
  len16 = (len8+(sizeof(WORD)-1))/sizeof(WORD) + 1;
  wbuf = (BYTE*)malloc(sizeof(WORD)*len16);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  rbuf = (BYTE*)malloc(sizeof(WORD)*len16);
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, (WORD*)wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer((WORD*)wbuf, len16);

  addr = 0x1;
  // Set initial data
  ret = RPC2_WRITE(addr+mbrReg, len16, (WORD*)wbuf);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("RPC2_WRITE: %d\n", ret);
    goto end_test;
  }
  CT_MSG("Write addr 0x%08X, len 0x%x\n", addr+mbrReg, len8);

  addr = 0x1;
  len8 = MAX_LEN;
#if (RPC2_CTRL_IP_VER >= 230)
  startCScnt(cs);
#endif
  ret = sequential_rd8(addr+mbrReg, len8, trans, rbuf, 1); //INCR
#if (RPC2_CTRL_IP_VER >= 230)
  endCScnt(cs);
  getCScnt(cs, &rcs_neg_cnt);
#endif
  if (ret != NO_ERROR) {
    goto end_test;
  }

  if (verifyData8(rbuf, wbuf, len8*trans)) {
    CT_ERR_MSG("VerifyData\n");
    ret = VERIFY_ERROR;
    goto end_test;
  }
#if (RPC2_CTRL_IP_VER >= 230)
  //exp_rcs_neg_cnt = trans;
  getexp_rcsNeg_cnt(addr+mbrReg, BYTE_1, len8, trans, INCR, maxen, maxlen, &exp_rcs_neg_cnt);
  CT_MSG("Comare Read  CS Negadge Count exp: %d, act: %d ---\n", exp_rcs_neg_cnt, rcs_neg_cnt);
  if (rcs_neg_cnt != exp_rcs_neg_cnt) {
    CT_ERR_MSG("Read CS Negadge Count is mismatched\n");
    ret = VERIFY_ERROR;
    goto end_test;
  }
#endif

 end_test:
  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
  CT_MSG("<< 1B Burst Read Odd Address w/o TC Test");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;

  return ret;
}

int concurrent_wr_rd_2cs (DWORD cs)
{
  int ret;
  int i;

  DWORD mbrReg[2];
  int XferByte[2];
  TBurstParam tBurstParam[2];
  TBurstParam *pTBurstParam[2];
  DWORD cs_array[2];

  CT_MSG(">> 2CS Concurrent WRITE/READ Test\n");

  cs_array[0] = cs;
  cs_array[1] = (cs==CS0_SEL) ? CS1_SEL: CS0_SEL;

  for (i=0; i<2; i++) {
   ret = getMemBaseAddress (&mbrReg[i], cs_array[i]);
   if (ret != NO_ERROR) {
     CT_ERR_MSG("Can't get CS%1d memory base address\n", cs_array[i]);
     goto end_test;
   }
   tBurstParam[i].size = BYTE_2;
   XferByte[i] = 1 << tBurstParam[i].size;
   tBurstParam[i].addr = mbrReg[i];
   tBurstParam[i].len = MAX_LEN;
   tBurstParam[i].burst = INCR;
  }

  tBurstParam[0].pattern = WORD_ADDRESS;
  tBurstParam[1].pattern = RANDOM;

  pTBurstParam[0] = &tBurstParam[0];
  pTBurstParam[1] = &tBurstParam[1];

  // cs_array0:Write -> cs_array1:Read
  CT_MSG("CS%1d:INCR Write LEN=%3d SIZE=%d => CS%1d:INCR Read LEN=%3d SIZE=%d ----\n", \
                                 cs_array[0], tBurstParam[0].len, tBurstParam[0].size, \
                                 cs_array[1], tBurstParam[1].len, tBurstParam[1].size);
  ret = sub_concurrent_wr_rd_2cs (WRITE_AHEAD, (TBurstParam **)&pTBurstParam);
  if (ret != NO_ERROR) goto end_test;

  // cs_array0:Write -> cs_array1:Read
  tBurstParam[0].addr += MAX_LEN*XferByte[0];
  tBurstParam[1].addr += MAX_LEN*XferByte[1];

  CT_MSG("CS%1d:INCR Read LEN=%3d SIZE=%d => CS%1d:INCR Write LEN=%3d SIZE=%d ----\n", \
                                 cs_array[1], tBurstParam[1].len, tBurstParam[1].size, \
                                 cs_array[0], tBurstParam[0].len, tBurstParam[0].size);
  ret = sub_concurrent_wr_rd_2cs (READ_AHEAD, (TBurstParam **)&pTBurstParam);
 end_test:
  CT_MSG("<< 2CS Concurrent WRITE/READ Test");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int alternative_wr_rd_2cs (DWORD cs)
{
  int ret;
  int i;

  DWORD mbrReg[2];
  int XferByte[2];
  TBurstParam tBurstParam[2];
  TBurstParam *pTBurstParam[2];
  DWORD cs_array[2];

  CT_MSG(">> 2CS Alternative WRITE/READ Test\n");

  cs_array[0] = cs;
  cs_array[1] = (cs==CS0_SEL) ? CS1_SEL: CS0_SEL;

  for (i=0; i<2; i++) {
   ret = getMemBaseAddress (&mbrReg[i], cs_array[i]);
   if (ret != NO_ERROR) {
     CT_ERR_MSG("Can't get CS%1d memory base address\n", cs_array[i]);
     goto end_test;
   }
   tBurstParam[i].size = BYTE_2;
   XferByte[i] = 1 << tBurstParam[i].size;
   tBurstParam[i].addr = mbrReg[i];
   tBurstParam[i].len = MAX_LEN;
   tBurstParam[i].burst = INCR;
  }

  tBurstParam[0].pattern = WORD_ADDRESS;
  tBurstParam[1].pattern = RANDOM;

  pTBurstParam[0] = &tBurstParam[0];
  pTBurstParam[1] = &tBurstParam[1];

  // cs_array0:Write -> cs_array1:Write & cs_array0:Read -> cs_array1:Read 
  CT_MSG("CS%1d:INCR Write/Read LEN=%3d SIZE=%d => CS%1d:INCR Write/Read LEN=%3d SIZE=%d ----\n", \
                                            cs_array[0], tBurstParam[0].len, tBurstParam[0].size, \
                                            cs_array[1], tBurstParam[1].len, tBurstParam[1].size);
  ret = sub_alternative_wr_rd_2cs ((TBurstParam **)&pTBurstParam);
 end_test:
  CT_MSG("<< 2CS Alternative WRITE/READ Test");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int tc_rd_exchange_2cs (DWORD cs)
{
  int ret = NO_ERROR;
  int i;

  int trans[2];
  DWORD mbrReg[2];
  DWORD addr = 0x0;
  WORD* wbuf[2];
  WORD* rbuf[2];
  TBurstParam tBurstParam[2];
  DWORD cs_array[2];
#if (RPC2_CTRL_IP_VER >= 230)
  DWORD maxen[2];
  DWORD maxlen[2];
  DWORD rcs_neg_cnt[2];
  DWORD exp_rcs_neg_cnt[2];
#endif

#if (RPC2_CTRL_IP_VER >= 230)
  CT_MSG(">> 2CS TC Write/Read exchange Test\n");
#else  
  CT_MSG(">> 2CS TC Read exchange Test\n");
#endif

  cs_array[0] = cs;
  cs_array[1] = (cs==CS0_SEL) ? CS1_SEL: CS0_SEL;
  
  trans[0] = trans[1] = 4;
  tBurstParam[0].pattern = WORD_ADDRESS;
  tBurstParam[1].pattern = RANDOM;

#if (RPC2_CTRL_IP_VER >= 230)
  setRndDelay(MEM, 0, 0);
#endif

  for (i=0; i<2; i++) {
    ret = getMemBaseAddress (&mbrReg[i], cs_array[i]);
    if (ret != NO_ERROR) {
      CT_ERR_MSG("Can't get CS%1d memory base address\n", i);
      goto end_test;
    }
#if (RPC2_CTRL_IP_VER >= 230)
    getMAXEN(&maxen[i], cs_array[i]);
    getMAXLEN(&maxlen[i], cs_array[i]);
#endif
    tBurstParam[i].size = BYTE_2;
    tBurstParam[i].addr = addr+mbrReg[i];
    tBurstParam[i].len = MAX_LEN;
    tBurstParam[i].burst = INCR;

    wbuf[i] = (WORD*)malloc(sizeof(WORD)*tBurstParam[i].len*trans[i]);
    if (!wbuf[i]) {
      CT_ERR_MSG("Can't allocate memory for write data addr%1d\n", i);
      ret = ALLOC_ERROR;
      goto end_test;
    }
    rbuf[i] = (WORD*)malloc(sizeof(WORD)*tBurstParam[i].len*trans[i]);
    if (!rbuf[i]) {
      CT_ERR_MSG("Can't allocate memory for read data addr%1d\n", i);
      ret = ALLOC_ERROR;
      goto end_test;
    }

    fillBuffer(tBurstParam[i].pattern, wbuf[i], tBurstParam[i].len*trans[i]);
    CT_MSG("Data Pattern addr%1d", i);
    printBuffer(wbuf[i], tBurstParam[i].len*trans[i]);

    addr += sizeof(WORD)*tBurstParam[i].len*trans[i];
  }

  ret = sequential_wr_2cs(&tBurstParam[0], trans[0], wbuf[0], &tBurstParam[1], trans[1], wbuf[1]);
#if (RPC2_CTRL_IP_VER >= 230)
  startCScnt(0);
  startCScnt(1);
#endif
  ret = sequential_rd_2cs(&tBurstParam[0], trans[0], rbuf[0], &tBurstParam[1], trans[1], rbuf[1]);
#if (RPC2_CTRL_IP_VER >= 230)
  endCScnt(0);
  endCScnt(1);
  getCScnt(cs_array[0], &rcs_neg_cnt[0]);
  getCScnt(cs_array[1], &rcs_neg_cnt[1]);
#endif
  if (ret != NO_ERROR) {
    goto end_test;
  }
  for (i=0; i<2; i++) {
    if (verifyData(rbuf[i], wbuf[i], tBurstParam[i].len*trans[i])) {
      CT_ERR_MSG("VerifyData addr%1d\n", i);
      ret = VERIFY_ERROR;
      goto end_test;
    }
  }
#if (RPC2_CTRL_IP_VER >= 230)
  for (i=0; i<2; i++) {
    getexp_rcsNeg_cnt(tBurstParam[i].addr, tBurstParam[i].size, tBurstParam[i].len, trans[i], \
                      INCR, maxen[i], maxlen[i], &exp_rcs_neg_cnt[i]);

    CT_MSG("Comare Read  CS%1d Negadge Count exp: %d, act: %d ---\n", cs_array[i], exp_rcs_neg_cnt[i], rcs_neg_cnt[i]);
    if (rcs_neg_cnt[i] != exp_rcs_neg_cnt[i]) {
      CT_ERR_MSG("Read  CS%1d Negadge Count is mismatched\n");
      ret = VERIFY_ERROR;
      goto end_test;
    }
  }
#endif
 end_test:
#if (RPC2_CTRL_IP_VER >= 230)
  setRndDelay(MEM, 10, 10);
#endif
  for (i=0; i<2; i++) {
    if (wbuf[i]) {
      free(wbuf[i]);
    }
    if (rbuf[i]) {
      free(rbuf[i]);
    }
  }
  CT_MSG("<< 2CS TC Read exchange Test\n");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;

  return ret;
}

int psram_refresh_collison(DWORD cs)
{
  int i;
  int ret = NO_ERROR;
  DWORD pattern;
  DWORD len16 = MAX_LEN;
  WORD wbuf[MAX_LEN];
  DWORD addr = 0x0;
  DWORD mbrReg;
  WORD  crData, crwData, cr3;

  CT_MSG(">> PSRAM Write/Read Refresh Collison Test\n");

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }

  setConfigRegTarget(1, cs);
  len16 = 1;
  sequential_rd16 (mbrReg, len16, 1, &crData, INCR);
  if (ret != NO_ERROR) {
    goto end_test;
  }

  for (cr3 = 0; cr3 < 2; cr3++) {
    CT_MSG("Set CRT=1 --------------------------------\n");
    setConfigRegTarget(1, cs);

    CT_MSG("Write CR[3]=%d -------------\n", cr3);
    crwData = ((crData & 0xFFF7) | (cr3 << 3));
    len16 = 1;
    ret = wr_rd_burst(addr, len16, &crwData, cs);
    if (ret != NO_ERROR) {
      goto end_test;
    }
    CT_MSG("Set CRT=0 --------------------------------\n");
    setConfigRegTarget(0, cs);

    for (i=0; i<10; i++) {
      ret = wr_rd_burst(addr, len16, wbuf, cs);
      if (ret != NO_ERROR) {
        goto end_test;
      }
    }

    len16 = MAX_LEN;
    for (i=0; i<10; i++) {
      ret = wr_rd_burst(addr, len16, wbuf, cs);
      if (ret != NO_ERROR) {
        goto end_test;
      }
    }
  }

  CT_MSG("Set CRT=1 --------------------------------\n");
  setConfigRegTarget(1, cs);
  len16 = 1;
  ret = wr_rd_burst(addr, len16, &crData, cs);
  if (ret != NO_ERROR) {
    goto end_test;
  }
  CT_MSG("Set CRT=0 --------------------------------\n");
  setConfigRegTarget(0, cs);

end_test:
  CT_MSG("<< PSRAM Write/Read Refresh Collison Test");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int psram_latency_cycle (DWORD cs)
{
  int i;
  int ret = NO_ERROR;
  int status;

  DWORD mtrReg = REG_MTR0_ADDR;
  DWORD reg;
  DWORD addr = 0;
  DWORD len16 = MAX_LEN;
  WORD* wbuf;
  DWORD pattern;
  DWORD mbrReg;
  WORD crData, crwData;

  CT_MSG(">> PSRAM Latency Cycle Test\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }

  if (cs == CS1_SEL) {
    mtrReg = REG_MTR1_ADDR;
  } else if (cs > CS1_SEL) {
    cs = 0;
  }
  status = RPC2_READ_REG(mtrReg, &reg);
  if (ret != NO_ERROR) goto end_test;
  CT_MSG("MTR%d = 0x%08X\n", cs, reg);

  CT_MSG("Set CRT=1 --------------------------------\n");
  setConfigRegTarget(1, cs);

  sequential_rd16 (mbrReg, 1, 1, &crData, INCR);
  if (ret != NO_ERROR) {
    goto end_test;
  }
  CT_MSG("CR Reg = 0x%04X\n", crData);

  wbuf = (WORD*)malloc(sizeof(WORD)*len16);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  for (i = 0; i < (sizeof(PSRAM_LTCY)/sizeof(DWORD)); i++) {
    CT_MSG("Latency %d Cycle Read/Write\n", i+3);

    CT_MSG("Set MTR%d LTCY=0x%01X\n", cs, PSRAM_LTCY[i]);
    setLTCYcycle(PSRAM_LTCY[i], cs);

    CT_MSG("Set CRT=1 --------------------------------\n");
    setConfigRegTarget(1, cs);

    CT_MSG("Set CR[7:4]=0x%01X\n", PSRAM_LTCY[i]);
    crwData = ((crData & 0xFF0F) | (PSRAM_LTCY[i] << 4));
    ret = wr_rd_burst(addr, 1, &crwData, cs);
    if (ret != NO_ERROR) {
      goto end_test;
    }

    CT_MSG("Set CRT=0 --------------------------------\n");
    setConfigRegTarget(0, cs);
    ret = wr_rd_burst(addr, len16, wbuf, cs);
    if (ret != NO_ERROR) {
      goto end_test;
    }
  }

  CT_MSG("Set MTR%d = 0x%08X\n", cs, reg);
  status = RPC2_WRITE_REG(mtrReg, &reg);
  if (ret != NO_ERROR) goto end_test;

  CT_MSG("Set CRT=1 --------------------------------\n");
  setConfigRegTarget(1, cs);

  ret = wr_rd_burst(addr, 1, &crData, cs);
  if (ret != NO_ERROR) {
    goto end_test;
  }
  CT_MSG("Set CRT=0 --------------------------------\n");
  setConfigRegTarget(0, cs);

 end_test:
  if (wbuf) {
    free(wbuf);
  }
  CT_MSG("<< PSRAM Latency Cycle Test\n");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr_rd_error_rsto (DWORD cs)
{
  int ret = NO_ERROR;
  DWORD wlen = 1;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_2;
  DWORD rlen = wlen;
  DWORD rburst = INCR;
  DWORD rsize  = BYTE_2;

  DWORD addr;
  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  WORD* rbuf;
  int wxferByte;
  DWORD mbrReg;
#if (RPC2_CTRL_IP_VER >= 220)
  int status;
  DWORD mbr0Reg, mbr1Reg;
  DWORD expcsrReg;
#endif

  CT_MSG(">> Flash Write/Read ERROR RSTO#\n");
  
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
  wxferByte = 1 << wsize;
  len16 = ((wxferByte*wlen)+(sizeof(WORD)-1))/sizeof(WORD);

  wbuf = (WORD*)malloc(len16*sizeof(WORD));
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  rbuf = (WORD*)malloc(len16*sizeof(WORD));
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

#if (RPC2_CTRL_IP_VER >= 220)
  expcsrReg = CSR_DEFAULT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;
#endif

  addr = mbrReg;
  ret = wr_slave_error(MEM, addr, wlen, wburst, wsize, wbuf); if (ret != NO_ERROR) goto end_test;
#if (RPC2_CTRL_IP_VER >= 220)
  expcsrReg = WRSTOERR_BIT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;
#endif

  ret = rd_slave_error(MEM, addr, rlen, rburst, rsize, rbuf); if (ret != NO_ERROR) goto end_test;
#if (RPC2_CTRL_IP_VER >= 220)
  expcsrReg = (WRSTOERR_BIT | RRSTOERR_BIT);
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  CT_MSG("Check WTRSERR/RTRSERR /w RSTO# is Low\n");
  addr = mbrReg;
  wburst = FIXED;
  ret = wr_slave_error(MEM, addr, wlen, wburst, wsize, wbuf); if (ret != NO_ERROR) goto end_test;
  expcsrReg = (WRSTOERR_BIT | WTRSERR_BIT | RRSTOERR_BIT);
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  addr = mbrReg;
  rburst = FIXED;
  ret = rd_slave_error(MEM, addr, rlen, rburst, rsize, rbuf); if (ret != NO_ERROR) goto end_test;
  expcsrReg = (WRSTOERR_BIT | WTRSERR_BIT | RRSTOERR_BIT | RTRSERR_BIT);
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  CT_MSG("Check WRSTO/RRSTO /w RSTO# is Low\n");
  addr = mbrReg;
  wburst = INCR;
  ret = wr_slave_error(MEM, addr, wlen, wburst, wsize, wbuf); if (ret != NO_ERROR) goto end_test;
  expcsrReg = (WRSTOERR_BIT | RRSTOERR_BIT | RTRSERR_BIT);
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  addr = mbrReg;
  rburst = INCR;
  ret = rd_slave_error(MEM, addr, rlen, rburst, rsize, rbuf); if (ret != NO_ERROR) goto end_test;
  expcsrReg = (WRSTOERR_BIT | RRSTOERR_BIT);
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  CT_MSG("Check WDECERR/RDECERR /w RSTO# is Low\n");
  if (cs == CS1_SEL) {
    ret = getMemBaseAddress (&mbr0Reg, CS0_SEL);
    if (ret != NO_ERROR) {
      CT_ERR_MSG("Can't get memory base address\n");
      goto end_test;
    }
    mbr1Reg = mbrReg;
  } else {
    ret = getMemBaseAddress (&mbr1Reg, CS1_SEL);
    if (ret != NO_ERROR) {
      CT_ERR_MSG("Can't get memory base address\n");
      goto end_test;
    }
    mbr0Reg = mbrReg;
    cs = 0;
  }

  addr = 0x80000000;
  CT_MSG("Set MBR0: 0x%08X\n", addr);
  setMemBaseAddress(addr, CS0_SEL);

  if (cs == CS1_SEL) {
    addr = 0x70000000;
  }
  CT_MSG("Set MBR1: 0x%08X\n", addr);
  setMemBaseAddress(addr, CS1_SEL);

  addr = 0x70000000;
  CT_MSG("Addr 0x%08X: Write 0x%3X\n", addr, len16);
  status = RPC2_WRITE(addr, len16, wbuf);
  CT_MSG("  - %s\n", (status == NO_ERROR) ? STR_NG : STR_OK);
  if (status == NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }

  expcsrReg = (WDECERR_BIT | RRSTOERR_BIT);
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  addr = 0x70000000;
  CT_MSG("Addr 0x%08X: Read 0x%3X\n", addr, len16);
  status = RPC2_READ(addr, len16, rbuf);
  CT_MSG("  - %s\n", (status == NO_ERROR) ? STR_NG : STR_OK);
  if (status == NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }
  expcsrReg = (WDECERR_BIT | RDECERR_BIT);
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  CT_MSG("Set MBR0: 0x%08X\n", mbr0Reg);
  CT_MSG("Set MBR1: 0x%08X\n", mbr1Reg);
  setMemBaseAddress(mbr0Reg, CS0_SEL);
  setMemBaseAddress(mbr1Reg, CS1_SEL);

  CT_MSG("Check WRSTO/RRSTO /w RSTO# is Low\n");
  addr = mbrReg;
  wburst = INCR;
  ret = wr_slave_error(MEM, addr, wlen, wburst, wsize, wbuf); if (ret != NO_ERROR) goto end_test;
  expcsrReg = (WRSTOERR_BIT | RDECERR_BIT);
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  addr = mbrReg;
  rburst = INCR;
  ret = rd_slave_error(MEM, addr, rlen, rburst, rsize, rbuf); if (ret != NO_ERROR) goto end_test;
  expcsrReg = (WRSTOERR_BIT | RRSTOERR_BIT);
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  waitUs(300);

  CT_MSG("Write/Read data /w RSTO# is High\n");
  addr = mbrReg;
  CT_MSG("Addr 0x%08X: Write 0x%3X\n", addr, len16);
  status = RPC2_WRITE(addr, len16, wbuf);
  CT_MSG("  - %s\n", (status != NO_ERROR) ? STR_NG : STR_OK);
  if (status != NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }
  expcsrReg = RRSTOERR_BIT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  addr = mbrReg;
  CT_MSG("Addr 0x%08X: Read 0x%3X\n", addr, len16);
  status = RPC2_READ(addr, len16, rbuf);
  CT_MSG("  - %s\n", (status != NO_ERROR) ? STR_NG : STR_OK);
  if (status != NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }
  expcsrReg = CSR_DEFAULT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  if (verifyData(rbuf, wbuf, len16)) {
    CT_ERR_MSG("VerifyData\n");
    ret = VERIFY_ERROR;
    goto end_test;
  }
#endif

end_test:
  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
  CT_MSG("<< Flash Write/Read ERROR RSTO#");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

#if (RPC2_CTRL_IP_VER >= 240)
int csr_rd (DWORD cs)
{
  int i;
  int ret = NO_ERROR;
  int status;
  int trans;

  DWORD expcsrReg;
  DWORD wlen;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_2;
  DWORD rlen;
  DWORD rburst = INCR;
  DWORD rsize  = BYTE_2;

  DWORD addr;
  DWORD pattern;
  DWORD len16 = MAX_LEN;
  WORD* wbuf;
  WORD* rbuf;
  DWORD mbrReg, mbr0Reg, mbr1Reg;
  DWORD devtype;
  DWORD rpcClk;
  WORD crData, crwData;

  CT_MSG(">> Controller Status Register Test\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
  getDevType(&devtype, cs);
  if (devtype == PSRAM) {
    getRpcClkPeriod(&rpcClk);
    while (PSRAM_TCSM <= (rpcClk*len16)) {
      len16 /= 2;
    }
  }
  trans = MAX_OUTSTANDING_TRANS-1;
  wlen = len16*trans;
  wbuf = (WORD*)malloc(sizeof(WORD)*(wlen));
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  rlen = wlen;
  rbuf = (WORD*)malloc(sizeof(WORD)*(rlen));
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, wlen);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, wlen);

  expcsrReg = CSR_DEFAULT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  CT_MSG("Check WACT/RACT\n");
  CT_MSG("Sequential Write addr 0x%08X, len16 0x%x x%d\n", mbrReg, len16, trans);
  expcsrReg = WACT_BIT;
  for (i = 0; i < trans; i++) {
    RPC_WRITE_BURST(mbrReg + sizeof(WORD)*len16*i, len16, &wbuf[len16*i]);
    ret = csr_reg_rd_verify(expcsrReg);
    if (ret != NO_ERROR) goto end_test;
  }

  CT_MSG("Get Write Response x%d\n", trans);
  for (i = 0; i < trans; i++) {
    CT_MSG("Write Resp#%d\n", i);
    ret = RPC_GET_WRESP();
    if (ret != NO_ERROR) {
      CT_MSG("RPC2_WRITE_BURST: %d\n", ret);
      return ret;
    }
    if (i == 0) {
      ret = csr_reg_rd_verify(expcsrReg);
    }
  }
  expcsrReg = CSR_DEFAULT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  CT_MSG("Sequential Read addr 0x%08X, len16 0x%x x%d\n", mbrReg, len16, trans);
  expcsrReg = RACT_BIT;
  for (i = 0; i < trans; i++) {
    RPC_READ_BURST(mbrReg + sizeof(WORD)*len16*i, len16);
    ret = csr_reg_rd_verify(expcsrReg);
    if (ret != NO_ERROR) goto end_test;
  }

  CT_MSG("Get Read Data x%d\n", trans);
  for (i = 0; i < trans; i++) {
    CT_MSG("Read Data#%d\n", i);
    ret = RPC2_GET_DATA(len16, &rbuf[len16*i]);
    if (ret != NO_ERROR) {
      CT_MSG("RPC2_GET_DATA: %d\n", ret);
      goto end_test;
    }
    if (i == 0) {
      ret = csr_reg_rd_verify(expcsrReg);
    }
  }
  expcsrReg = CSR_DEFAULT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  if (verifyData(rbuf, wbuf, len16*trans)) {
    CT_ERR_MSG("VerifyData\n");
    ret = VERIFY_ERROR;
    goto end_test;
  }

  // Slave error
  CT_MSG("Check WTRSERR/RTRSERR\n");
  addr = mbrReg;
  wburst = FIXED;
  wlen = 16;
  ret = wr_slave_error(MEM, addr, wlen, wburst, wsize, wbuf); if (ret != NO_ERROR) goto end_test;
  expcsrReg = WTRSERR_BIT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  addr = mbrReg;
  rburst = FIXED;
  rlen = 16;
  ret = rd_slave_error(MEM, addr, rlen, rburst, rsize, rbuf); if (ret != NO_ERROR) goto end_test;
  expcsrReg = (WTRSERR_BIT | RTRSERR_BIT);
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  addr = mbrReg;
  CT_MSG("Addr 0x%08X: Write 0x%3X\n", addr, len16);
  status = RPC2_WRITE(addr, len16, wbuf);
  CT_MSG("  - %s\n", (status != NO_ERROR) ? STR_NG : STR_OK);
  if (status != NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }
  expcsrReg = RTRSERR_BIT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  addr = mbrReg;
  CT_MSG("Addr 0x%08X: Read 0x%3X\n", addr, len16);
  status = RPC2_READ(addr, len16, rbuf);
  CT_MSG("  - %s\n", (status != NO_ERROR) ? STR_NG : STR_OK);
  if (status != NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }
  expcsrReg = CSR_DEFAULT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  if (verifyData(rbuf, wbuf, len16)) {
    CT_ERR_MSG("VerifyData\n");
    ret = VERIFY_ERROR;
    goto end_test;
  }

  // RDS Stall
  CT_MSG("Check RDSSTALL\n");
  CT_MSG("Set CRT=1 --------------------------------\n");
  setConfigRegTarget(1, cs);
  RPC2_READ(mbrReg, 1, &crData);
  CT_MSG("Read CR Reg = 0x%04X\n", crData);
  crwData = (crData & 0x7FFF);
  CT_MSG("Write CR Reg = 0x%04X\n", crwData);
  RPC2_WRITE(mbrReg, 1, &crwData);
  CT_MSG("Enter Deep Power Down --------------------\n");
  CT_MSG("Set CRT=0 --------------------------------\n");
  setConfigRegTarget(0, cs);

  addr = mbrReg;
  CT_MSG("Addr 0x%08X: Write 0x%3X\n", addr, len16);
  status = RPC2_WRITE(addr, len16, wbuf);
  CT_MSG("  - %s\n", (status != NO_ERROR) ? STR_NG : STR_OK);
  if (status != NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }
  expcsrReg = CSR_DEFAULT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  addr = mbrReg;
  CT_MSG("Addr 0x%08X: Read 0x%3X\n", addr, len16);
  status = RPC2_READ(addr, len16, rbuf);
  CT_MSG("  - %s\n", (status == NO_ERROR) ? STR_NG : STR_OK);
  if (status == NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }
  expcsrReg = RDSSTALL_BIT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  if (devtype == PSRAM) {
    waitUs(150);
  }
  CT_MSG("Set CRT=1 --------------------------------\n");
  setConfigRegTarget(1, cs);
  CT_MSG("Write CR Reg = 0x%04X\n", crData);
  RPC2_WRITE(mbrReg, 1, &crData);
  CT_MSG("Return from Deep Power Down --------------\n");
  CT_MSG("Set CRT=0 --------------------------------\n");
  setConfigRegTarget(0, cs);

  expcsrReg = RDSSTALL_BIT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  addr = mbrReg;
  CT_MSG("Addr 0x%08X: Write 0x%3X\n", addr, len16);
  status = RPC2_WRITE(addr, len16, wbuf);
  CT_MSG("  - %s\n", (status != NO_ERROR) ? STR_NG : STR_OK);
  if (status != NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }
  expcsrReg = RDSSTALL_BIT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  addr = mbrReg;
  CT_MSG("Addr 0x%08X: Read 0x%3X\n", addr, len16);
  status = RPC2_READ(addr, len16, rbuf);
  CT_MSG("  - %s\n", (status != NO_ERROR) ? STR_NG : STR_OK);
  if (status != NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }
  expcsrReg = CSR_DEFAULT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  if (verifyData(rbuf, wbuf, len16)) {
    CT_ERR_MSG("VerifyData\n");
    ret = VERIFY_ERROR;
    goto end_test;
  }

  // Decode error
  CT_MSG("Check WDECERR/RDECERR\n");
  if (cs == CS1_SEL) {
    ret = getMemBaseAddress (&mbr0Reg, CS0_SEL);
    if (ret != NO_ERROR) {
      CT_ERR_MSG("Can't get memory base address\n");
      goto end_test;
    }
    mbr1Reg = mbrReg;
  } else {
    ret = getMemBaseAddress (&mbr1Reg, CS1_SEL);
    if (ret != NO_ERROR) {
      CT_ERR_MSG("Can't get memory base address\n");
      goto end_test;
    }
    mbr0Reg = mbrReg;
    cs = 0;
  }

  addr = 0x80000000;
  CT_MSG("Set MBR0: 0x%08X\n", addr);
  setMemBaseAddress(addr, CS0_SEL);

  if (cs == CS1_SEL) {
    addr = 0x70000000;
  }
  CT_MSG("Set MBR1: 0x%08X\n", addr);
  setMemBaseAddress(addr, CS1_SEL);

  addr = 0x70000000;
  wburst = FIXED;
  wlen = 16;
  ret = wr_decode_error(MEM, addr, wlen, wburst, wsize, wbuf); if (ret != NO_ERROR) goto end_test;
  expcsrReg = WDECERR_BIT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  addr = 0x70000000;
  rburst = FIXED;
  rlen = 16;
  ret = rd_decode_error(MEM, addr, rlen, rburst, rsize, rbuf); if (ret != NO_ERROR) goto end_test;
  expcsrReg = (WDECERR_BIT | RDECERR_BIT);
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  CT_MSG("Set MBR0: 0x%08X\n", mbr0Reg);
  CT_MSG("Set MBR1: 0x%08X\n", mbr1Reg);
  setMemBaseAddress(mbr0Reg, CS0_SEL);
  setMemBaseAddress(mbr1Reg, CS1_SEL);

  addr = mbrReg;
  CT_MSG("Addr 0x%08X: Write 0x%3X\n", addr, len16);
  status = RPC2_WRITE(addr, len16, wbuf);
  CT_MSG("  - %s\n", (status != NO_ERROR) ? STR_NG : STR_OK);
  if (status != NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }
  expcsrReg = RDECERR_BIT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  addr = mbrReg;
  CT_MSG("Addr 0x%08X: Read 0x%3X\n", addr, len16);
  status = RPC2_READ(addr, len16, rbuf);
  CT_MSG("  - %s\n", (status != NO_ERROR) ? STR_NG : STR_OK);
  if (status != NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }
  expcsrReg = CSR_DEFAULT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  if (verifyData(rbuf, wbuf, len16)) {
    CT_ERR_MSG("VerifyData\n");
    ret = VERIFY_ERROR;
    goto end_test;
  }

  // Error Comination
  CT_MSG("Check Error Combination\n");
  CT_MSG("Set CRT=1 --------------------------------\n");
  setConfigRegTarget(1, cs);
  CT_MSG("Write CR Reg = 0x%04X\n", crwData);
  RPC2_WRITE(mbrReg, 1, &crwData);
  CT_MSG("Enter Deep Power Down --------------------\n");
  CT_MSG("Set CRT=0 --------------------------------\n");
  setConfigRegTarget(0, cs);

  CT_MSG(" 1:WTRSERR/RTRSERR\n");
  addr = mbrReg;
  wburst = FIXED;
  wlen = 16;
  ret = wr_slave_error(MEM, addr, wlen, wburst, wsize, wbuf); if (ret != NO_ERROR) goto end_test;
  expcsrReg = WTRSERR_BIT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  addr = mbrReg;
  rburst = FIXED;
  rlen = 16;
  ret = rd_slave_error(MEM, addr, rlen, rburst, rsize, rbuf); if (ret != NO_ERROR) goto end_test;
  expcsrReg = (WTRSERR_BIT | RTRSERR_BIT);
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  CT_MSG(" 2:WDECERR/RDECERR\n");
  addr = 0x80000000;
  CT_MSG("Set MBR0: 0x%08X\n", addr);
  setMemBaseAddress(addr, CS0_SEL);

  if (cs == CS1_SEL) {
    addr = 0x70000000;
  }
  CT_MSG("Set MBR1: 0x%08X\n", addr);
  setMemBaseAddress(addr, CS1_SEL);

  addr = 0x70000000;
  CT_MSG("Addr 0x%08X: Write 0x%3X\n", addr, len16);
  status = RPC2_WRITE(addr, len16, wbuf);
  CT_MSG("  - %s\n", (status == NO_ERROR) ? STR_NG : STR_OK);
  if (status == NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }
  expcsrReg = (WDECERR_BIT | RTRSERR_BIT);
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  addr = 0x70000000;
  CT_MSG("Addr 0x%08X: Read 0x%3X\n", addr, len16);
  status = RPC2_READ(addr, len16, rbuf);
  CT_MSG("  - %s\n", (status == NO_ERROR) ? STR_NG : STR_OK);
  if (status == NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }
  expcsrReg = (WDECERR_BIT | RDECERR_BIT);
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  CT_MSG("Set MBR0: 0x%08X\n", mbr0Reg);
  CT_MSG("Set MBR1: 0x%08X\n", mbr1Reg);
  setMemBaseAddress(mbr0Reg, CS0_SEL);
  setMemBaseAddress(mbr1Reg, CS1_SEL);

  CT_MSG(" 3:RDSSTALL\n");
  addr = mbrReg;
  CT_MSG("Addr 0x%08X: Read 0x%3X\n", addr, len16);
  status = RPC2_READ(addr, len16, rbuf);
  CT_MSG("  - %s\n", (status == NO_ERROR) ? STR_NG : STR_OK);
  if (status == NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }
  expcsrReg = (WDECERR_BIT | RDSSTALL_BIT);
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  CT_MSG(" 4:RTRSERR\n");
  addr = mbrReg;
  rburst = FIXED;
  rlen = 16;
  ret = rd_slave_error(MEM, addr, rlen, rburst, rsize, rbuf); if (ret != NO_ERROR) goto end_test;
  expcsrReg = (WDECERR_BIT | RTRSERR_BIT);
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  CT_MSG(" 5:RDSSTALL\n");
  addr = mbrReg;
  CT_MSG("Addr 0x%08X: Read 0x%3X\n", addr, len16);
  status = RPC2_READ(addr, len16, rbuf);
  CT_MSG("  - %s\n", (status == NO_ERROR) ? STR_NG : STR_OK);
  if (status == NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }
  expcsrReg = (WDECERR_BIT | RDSSTALL_BIT);
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  CT_MSG(" 6:RDECERR\n");
  addr = 0x80000000;
  CT_MSG("Set MBR0: 0x%08X\n", addr);
  setMemBaseAddress(addr, CS0_SEL);

  if (cs == CS1_SEL) {
    addr = 0x70000000;
  }
  CT_MSG("Set MBR1: 0x%08X\n", addr);
  setMemBaseAddress(addr, CS1_SEL);

  addr = 0x70000000;
  CT_MSG("Addr 0x%08X: Read 0x%3X\n", addr, len16);
  status = RPC2_READ(addr, len16, rbuf);
  CT_MSG("  - %s\n", (status == NO_ERROR) ? STR_NG : STR_OK);
  if (status == NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }
  expcsrReg = (WDECERR_BIT | RDECERR_BIT);
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  CT_MSG("Set MBR0: 0x%08X\n", mbr0Reg);
  CT_MSG("Set MBR1: 0x%08X\n", mbr1Reg);
  setMemBaseAddress(mbr0Reg, CS0_SEL);
  setMemBaseAddress(mbr1Reg, CS1_SEL);

  CT_MSG(" 7:WTRSERR/RTRSERR\n");
  addr = mbrReg;
  wburst = FIXED;
  wlen = 16;
  ret = wr_slave_error(MEM, addr, wlen, wburst, wsize, wbuf); if (ret != NO_ERROR) goto end_test;
  expcsrReg = (WTRSERR_BIT | RDECERR_BIT);
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  addr = mbrReg;
  rburst = FIXED;
  rlen = 16;
  ret = rd_slave_error(MEM, addr, rlen, rburst, rsize, rbuf); if (ret != NO_ERROR) goto end_test;
  expcsrReg = (WTRSERR_BIT | RTRSERR_BIT);
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  if (devtype == PSRAM) {
    waitUs(150);
  }

  CT_MSG("Set CRT=1 --------------------------------\n");
  setConfigRegTarget(1, cs);
  CT_MSG("Write CR Reg = 0x%04X\n", crData);
  RPC2_WRITE(mbrReg, 1, &crData);
  CT_MSG("Return from Deep Power Down --------------\n");
  CT_MSG("Set CRT=0 --------------------------------\n");
  setConfigRegTarget(0, cs);

  expcsrReg = RTRSERR_BIT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  addr = mbrReg;
  CT_MSG("Addr 0x%08X: Write 0x%3X\n", addr, len16);
  status = RPC2_WRITE(addr, len16, wbuf);
  CT_MSG("  - %s\n", (status != NO_ERROR) ? STR_NG : STR_OK);
  if (status != NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }
  expcsrReg = RTRSERR_BIT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  addr = mbrReg;
  CT_MSG("Addr 0x%08X: Read 0x%3X\n", addr, len16);
  status = RPC2_READ(addr, len16, rbuf);
  CT_MSG("  - %s\n", (status != NO_ERROR) ? STR_NG : STR_OK);
  if (status != NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }
  expcsrReg = CSR_DEFAULT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  if (verifyData(rbuf, wbuf, len16)) {
    CT_ERR_MSG("VerifyData\n");
    ret = VERIFY_ERROR;
    goto end_test;
  }

end_test:
  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
  CT_MSG("<< Controller Status Register Test\n");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL; 
  return ret;
}
#elif (RPC2_CTRL_IP_VER >= 220)
int csr_rd (DWORD cs)
{
  int i;
  int ret = NO_ERROR;
  int status;
  int trans;

  DWORD expcsrReg;
  DWORD wlen;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_2;
  DWORD rlen;
  DWORD rburst = INCR;
  DWORD rsize  = BYTE_2;

  DWORD addr;
  DWORD pattern;
  DWORD len16 = MAX_LEN;
  WORD* wbuf;
  WORD* rbuf;
  DWORD mbrReg, mbr0Reg, mbr1Reg;
  DWORD devtype;
  DWORD rpcClk;
  WORD crData, crwData;
  BYTE rresp[MAX_LEN];
  BYTE wresp;

  CT_MSG(">> Controller Status Register Test\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
  getDevType(&devtype, cs);
  if (devtype == PSRAM) {
    getRpcClkPeriod(&rpcClk);
    while (PSRAM_TCSM <= (rpcClk*len16)) {
      len16 /= 2;
    }
  }
  trans = MAX_OUTSTANDING_TRANS-1;
  wlen = len16*trans;
  wbuf = (WORD*)malloc(sizeof(WORD)*(wlen));
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  rlen = wlen;
  rbuf = (WORD*)malloc(sizeof(WORD)*(rlen));
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, wlen);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, wlen);

  expcsrReg = CSR_DEFAULT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  CT_MSG("Check WACT/RACT\n");
  CT_MSG("Sequential Write addr 0x%08X, len16 0x%x x%d\n", mbrReg, len16, trans);
  expcsrReg = WACT_BIT;
  for (i = 0; i < trans; i++) {
    RPC_WRITE_BURST(mbrReg + sizeof(WORD)*len16*i, len16, &wbuf[len16*i]);
    ret = csr_reg_rd_verify(expcsrReg);
    if (ret != NO_ERROR) goto end_test;
  }

  CT_MSG("Sequential Read addr 0x%08X, len16 0x%x x%d\n", mbrReg, len16, trans);
  expcsrReg = (WACT_BIT | RACT_BIT);
  for (i = 0; i < trans; i++) {
    RPC_READ_BURST(mbrReg + sizeof(WORD)*len16*i, len16);
    ret = csr_reg_rd_verify(expcsrReg);
    if (ret != NO_ERROR) goto end_test;
  }

  CT_MSG("Get Write Response x%d\n", trans);
  for (i = 0; i < trans; i++) {
    CT_MSG("Write Resp#%d\n", i);
    ret = RPC_GET_WRESP();
    if (ret != NO_ERROR) {
      CT_MSG("RPC2_WRITE_BURST: %d\n", ret);
      return ret;
    }
    if (i == trans - 1) {
      expcsrReg = RACT_BIT;
    }
    ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;
  }

  CT_MSG("Get Read Data x%d\n", trans);
  for (i = 0; i < trans; i++) {
    CT_MSG("Read Data#%d\n", i);
    ret = RPC2_GET_DATA(len16, &rbuf[len16*i]);
    if (ret != NO_ERROR) {
      CT_MSG("RPC2_GET_DATA: %d\n", ret);
      goto end_test;
    }

    if (i == trans - 1) {
      expcsrReg = CSR_DEFAULT;
    }
    ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;;
  }

  if (verifyData(rbuf, wbuf, len16*trans)) {
    CT_ERR_MSG("VerifyData\n");
    ret = VERIFY_ERROR;
    goto end_test;
  }

  // Slave error
  CT_MSG("Check WTRSERR/RTRSERR\n");
  addr = mbrReg;
  wburst = FIXED;
  wlen = 16;
  ret = wr_slave_error(MEM, addr, wlen, wburst, wsize, wbuf); if (ret != NO_ERROR) goto end_test;
  expcsrReg = WTRSERR_BIT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  addr = mbrReg;
  rburst = FIXED;
  rlen = 16;
  ret = rd_slave_error(MEM, addr, rlen, rburst, rsize, rbuf); if (ret != NO_ERROR) goto end_test;
  expcsrReg = (WTRSERR_BIT | RTRSERR_BIT);
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  addr = mbrReg;
  CT_MSG("Addr 0x%08X: Write 0x%3X\n", addr, len16);
  status = RPC2_WRITE(addr, len16, wbuf);
  CT_MSG("  - %s\n", (status != NO_ERROR) ? STR_NG : STR_OK);
  if (status != NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }
  expcsrReg = RTRSERR_BIT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  addr = mbrReg;
  CT_MSG("Addr 0x%08X: Read 0x%3X\n", addr, len16);
  status = RPC2_READ(addr, len16, rbuf);
  CT_MSG("  - %s\n", (status != NO_ERROR) ? STR_NG : STR_OK);
  if (status != NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }
  expcsrReg = CSR_DEFAULT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  if (verifyData(rbuf, wbuf, len16)) {
    CT_ERR_MSG("VerifyData\n");
    ret = VERIFY_ERROR;
    goto end_test;
  }

  // RDS Stall
  CT_MSG("Check RDSSTALL\n");
  CT_MSG("Set CRT=1 --------------------------------\n");
  setConfigRegTarget(1, cs);
  RPC2_READ(mbrReg, 1, &crData);
  CT_MSG("Read CR Reg = 0x%04X\n", crData);
  crwData = (crData & 0x7FFF);
  CT_MSG("Write CR Reg = 0x%04X\n", crwData);
  RPC2_WRITE(mbrReg, 1, &crwData);
  CT_MSG("Enter Deep Power Down --------------------\n");
  CT_MSG("Set CRT=0 --------------------------------\n");
  setConfigRegTarget(0, cs);

  addr = mbrReg;
  CT_MSG("Addr 0x%08X: Write 0x%3X\n", addr, len16);
  status = RPC2_WRITE(addr, len16, wbuf);
  CT_MSG("  - %s\n", (status != NO_ERROR) ? STR_NG : STR_OK);
  if (status != NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }
  expcsrReg = CSR_DEFAULT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  addr = mbrReg;
  CT_MSG("Addr 0x%08X: Read 0x%3X\n", addr, len16);
  status = RPC2_READ(addr, len16, rbuf);
  CT_MSG("  - %s\n", (status == NO_ERROR) ? STR_NG : STR_OK);
  if (status == NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }
  expcsrReg = RDSSTALL_BIT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  if (devtype == PSRAM) {
    waitUs(150);
  }
  CT_MSG("Set CRT=1 --------------------------------\n");
  setConfigRegTarget(1, cs);
  CT_MSG("Write CR Reg = 0x%04X\n", crData);
  RPC2_WRITE(mbrReg, 1, &crData);
  CT_MSG("Return from Deep Power Down --------------\n");
  CT_MSG("Set CRT=0 --------------------------------\n");
  setConfigRegTarget(0, cs);

  expcsrReg = RDSSTALL_BIT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  addr = mbrReg;
  CT_MSG("Addr 0x%08X: Write 0x%3X\n", addr, len16);
  status = RPC2_WRITE(addr, len16, wbuf);
  CT_MSG("  - %s\n", (status != NO_ERROR) ? STR_NG : STR_OK);
  if (status != NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }
  expcsrReg = RDSSTALL_BIT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  addr = mbrReg;
  CT_MSG("Addr 0x%08X: Read 0x%3X\n", addr, len16);
  status = RPC2_READ(addr, len16, rbuf);
  CT_MSG("  - %s\n", (status != NO_ERROR) ? STR_NG : STR_OK);
  if (status != NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }
  expcsrReg = CSR_DEFAULT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  if (verifyData(rbuf, wbuf, len16)) {
    CT_ERR_MSG("VerifyData\n");
    ret = VERIFY_ERROR;
    goto end_test;
  }

  // Decode error
  CT_MSG("Check WDECERR/RDECERR\n");
  if (cs == CS1_SEL) {
    ret = getMemBaseAddress (&mbr0Reg, CS0_SEL);
    if (ret != NO_ERROR) {
      CT_ERR_MSG("Can't get memory base address\n");
      goto end_test;
    }
    mbr1Reg = mbrReg;
  } else {
    ret = getMemBaseAddress (&mbr1Reg, CS1_SEL);
    if (ret != NO_ERROR) {
      CT_ERR_MSG("Can't get memory base address\n");
      goto end_test;
    }
    mbr0Reg = mbrReg;
    cs = 0;
  }

  addr = 0x80000000;
  CT_MSG("Set MBR0: 0x%08X\n", addr);
  setMemBaseAddress(addr, CS0_SEL);

  if (cs == CS1_SEL) {
    addr = 0x70000000;
  }
  CT_MSG("Set MBR1: 0x%08X\n", addr);
  setMemBaseAddress(addr, CS1_SEL);

  addr = 0x70000000;
  wburst = FIXED;
  wlen = 16;
  ret = wr_decode_error(MEM, addr, wlen, wburst, wsize, wbuf); if (ret != NO_ERROR) goto end_test;
  expcsrReg = WDECERR_BIT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  addr = 0x70000000;
  rburst = FIXED;
  rlen = 16;
  ret = rd_decode_error(MEM, addr, rlen, rburst, rsize, rbuf); if (ret != NO_ERROR) goto end_test;
  expcsrReg = (WDECERR_BIT | RDECERR_BIT);
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  CT_MSG("Set MBR0: 0x%08X\n", mbr0Reg);
  CT_MSG("Set MBR1: 0x%08X\n", mbr1Reg);
  setMemBaseAddress(mbr0Reg, CS0_SEL);
  setMemBaseAddress(mbr1Reg, CS1_SEL);

  addr = mbrReg;
  CT_MSG("Addr 0x%08X: Write 0x%3X\n", addr, len16);
  status = RPC2_WRITE(addr, len16, wbuf);
  CT_MSG("  - %s\n", (status != NO_ERROR) ? STR_NG : STR_OK);
  if (status != NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }
  expcsrReg = RDECERR_BIT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  addr = mbrReg;
  CT_MSG("Addr 0x%08X: Read 0x%3X\n", addr, len16);
  status = RPC2_READ(addr, len16, rbuf);
  CT_MSG("  - %s\n", (status != NO_ERROR) ? STR_NG : STR_OK);
  if (status != NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }
  expcsrReg = CSR_DEFAULT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  if (verifyData(rbuf, wbuf, len16)) {
    CT_ERR_MSG("VerifyData\n");
    ret = VERIFY_ERROR;
    goto end_test;
  }

  // Error Comination
  CT_MSG("Check Error Combination\n");
  CT_MSG("Set CRT=1 --------------------------------\n");
  setConfigRegTarget(1, cs);
  CT_MSG("Write CR Reg = 0x%04X\n", crwData);
  RPC2_WRITE(mbrReg, 1, &crwData);
  CT_MSG("Enter Deep Power Down --------------------\n");
  CT_MSG("Set CRT=0 --------------------------------\n");
  setConfigRegTarget(0, cs);

  CT_MSG(" 1:WTRSERR/RTRSERR\n");
  addr = mbrReg;
  wburst = FIXED;
  wlen = 16;
  ret = wr_slave_error(MEM, addr, wlen, wburst, wsize, wbuf); if (ret != NO_ERROR) goto end_test;
  expcsrReg = WTRSERR_BIT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  addr = mbrReg;
  rburst = FIXED;
  rlen = 16;
  ret = rd_slave_error(MEM, addr, rlen, rburst, rsize, rbuf); if (ret != NO_ERROR) goto end_test;
  expcsrReg = (WTRSERR_BIT | RTRSERR_BIT);
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  CT_MSG(" 2:WDECERR/RDECERR\n");
  addr = 0x80000000;
  CT_MSG("Set MBR0: 0x%08X\n", addr);
  setMemBaseAddress(addr, CS0_SEL);

  if (cs == CS1_SEL) {
    addr = 0x70000000;
  }
  CT_MSG("Set MBR1: 0x%08X\n", addr);
  setMemBaseAddress(addr, CS1_SEL);

  addr = 0x70000000;
  CT_MSG("Addr 0x%08X: Write 0x%3X\n", addr, len16);
  status = RPC2_WRITE(addr, len16, wbuf);
  CT_MSG("  - %s\n", (status == NO_ERROR) ? STR_NG : STR_OK);
  if (status == NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }
  expcsrReg = (WDECERR_BIT | RTRSERR_BIT);
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  addr = 0x70000000;
  CT_MSG("Addr 0x%08X: Read 0x%3X\n", addr, len16);
  status = RPC2_READ(addr, len16, rbuf);
  CT_MSG("  - %s\n", (status == NO_ERROR) ? STR_NG : STR_OK);
  if (status == NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }
  expcsrReg = (WDECERR_BIT | RDECERR_BIT);
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  CT_MSG("Set MBR0: 0x%08X\n", mbr0Reg);
  CT_MSG("Set MBR1: 0x%08X\n", mbr1Reg);
  setMemBaseAddress(mbr0Reg, CS0_SEL);
  setMemBaseAddress(mbr1Reg, CS1_SEL);

  CT_MSG(" 3:RDSSTALL\n");
  addr = mbrReg;
  CT_MSG("Addr 0x%08X: Read 0x%3X\n", addr, len16);
  status = RPC2_READ(addr, len16, rbuf);
  CT_MSG("  - %s\n", (status == NO_ERROR) ? STR_NG : STR_OK);
  if (status == NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }
  expcsrReg = (WDECERR_BIT | RDSSTALL_BIT);
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  CT_MSG(" 4:RTRSERR\n");
  addr = mbrReg;
  rburst = FIXED;
  rlen = 16;
  ret = rd_slave_error(MEM, addr, rlen, rburst, rsize, rbuf); if (ret != NO_ERROR) goto end_test;
  expcsrReg = (WDECERR_BIT | RTRSERR_BIT);
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  CT_MSG(" 5:RDSSTALL\n");
  addr = mbrReg;
  CT_MSG("Addr 0x%08X: Read 0x%3X\n", addr, len16);
  status = RPC2_READ(addr, len16, rbuf);
  CT_MSG("  - %s\n", (status == NO_ERROR) ? STR_NG : STR_OK);
  if (status == NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }
  expcsrReg = (WDECERR_BIT | RDSSTALL_BIT);
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  CT_MSG(" 6:RDECERR\n");
  addr = 0x80000000;
  CT_MSG("Set MBR0: 0x%08X\n", addr);
  setMemBaseAddress(addr, CS0_SEL);

  if (cs == CS1_SEL) {
    addr = 0x70000000;
  }
  CT_MSG("Set MBR1: 0x%08X\n", addr);
  setMemBaseAddress(addr, CS1_SEL);

  addr = 0x70000000;
  CT_MSG("Addr 0x%08X: Read 0x%3X\n", addr, len16);
  status = RPC2_READ(addr, len16, rbuf);
  CT_MSG("  - %s\n", (status == NO_ERROR) ? STR_NG : STR_OK);
  if (status == NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }
  expcsrReg = (WDECERR_BIT | RDECERR_BIT);
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  CT_MSG("Set MBR0: 0x%08X\n", mbr0Reg);
  CT_MSG("Set MBR1: 0x%08X\n", mbr1Reg);
  setMemBaseAddress(mbr0Reg, CS0_SEL);
  setMemBaseAddress(mbr1Reg, CS1_SEL);

  CT_MSG(" 7:WTRSERR/RTRSERR\n");
  addr = mbrReg;
  wburst = FIXED;
  wlen = 16;
  ret = wr_slave_error(MEM, addr, wlen, wburst, wsize, wbuf); if (ret != NO_ERROR) goto end_test;
  expcsrReg = (WTRSERR_BIT | RDECERR_BIT);
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  addr = mbrReg;
  rburst = FIXED;
  rlen = 16;
  ret = rd_slave_error(MEM, addr, rlen, rburst, rsize, rbuf); if (ret != NO_ERROR) goto end_test;
  expcsrReg = (WTRSERR_BIT | RTRSERR_BIT);
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  if (devtype == PSRAM) {
    waitUs(150);
  }

  CT_MSG("Set CRT=1 --------------------------------\n");
  setConfigRegTarget(1, cs);
  CT_MSG("Write CR Reg = 0x%04X\n", crData);
  RPC2_WRITE(mbrReg, 1, &crData);
  CT_MSG("Return from Deep Power Down --------------\n");
  CT_MSG("Set CRT=0 --------------------------------\n");
  setConfigRegTarget(0, cs);

  expcsrReg = RTRSERR_BIT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  addr = mbrReg;
  CT_MSG("Addr 0x%08X: Write 0x%3X\n", addr, len16);
  status = RPC2_WRITE(addr, len16, wbuf);
  CT_MSG("  - %s\n", (status != NO_ERROR) ? STR_NG : STR_OK);
  if (status != NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }
  expcsrReg = RTRSERR_BIT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  addr = mbrReg;
  CT_MSG("Addr 0x%08X: Read 0x%3X\n", addr, len16);
  status = RPC2_READ(addr, len16, rbuf);
  CT_MSG("  - %s\n", (status != NO_ERROR) ? STR_NG : STR_OK);
  if (status != NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }
  expcsrReg = CSR_DEFAULT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  if (verifyData(rbuf, wbuf, len16)) {
    CT_ERR_MSG("VerifyData\n");
    ret = VERIFY_ERROR;
    goto end_test;
  }

  // Concurrent Write/Read
  CT_MSG("Check Concurrent Write/Read\n");
  addr = mbrReg;
  wburst = INCR;
  rburst = INCR;
  wlen = len16;
  rlen = len16;

  CT_MSG("Concurrent Write: addr=0x%08X len=0x%03X burst=%1d size=%1d\n", addr, wlen, wburst, wsize);
  CT_MSG("           Read : addr=0x%08X len=0x%03X burst=%1d size=%1d\n", addr, rlen, rburst, rsize);
  writeBurst(MEM, addr, wlen, wburst, wsize, wbuf);
  readBurst(MEM, addr, rlen, rburst, rsize);
  expcsrReg = (WACT_BIT | RACT_BIT);
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  CT_MSG("Get Write Response\n");
  getWriteResp(MEM, &wresp);
  expcsrReg = RACT_BIT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  CT_MSG("Get Read Data\n");
  getReadDataResp(MEM, rlen, rsize, rbuf, rresp);
  expcsrReg = CSR_DEFAULT;
  ret = csr_reg_rd_verify(expcsrReg); if (ret != NO_ERROR) goto end_test;

  if (wresp) {
    CT_ERR_MSG("Write Response 0x%x\n", wresp);
    ret = RESP_ERROR;
    goto end_test;
  }
  for (i = 0; i < rlen; i++) {
    if (rresp[i]) {
      CT_ERR_MSG("Read Response %d: 0x%x\n", i, rresp[i]);
      ret = RESP_ERROR;
      goto end_test;
    }
  }
  if (verifyData(rbuf, wbuf, wlen)) {
    CT_ERR_MSG("VerifyData\n");
    ret = VERIFY_ERROR;
    goto end_test;
  }

end_test:
  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
  CT_MSG("<< Controller Status Register Test\n");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL; 
  return ret;
}
#endif

#if (RPC2_CTRL_IP_VER >= 230)
int wr_rd_max_len_split (DWORD cs)
{
  int i, j, k, l, m;
  int ret = NO_ERROR;
  DWORD addr;
  DWORD len;
  DWORD len8;
  DWORD len16 = (MAXLEN_MAX+1);
  DWORD size[] = {BYTE_1,BYTE_2,BYTE_4};
#if (MAX_LEN == 16)
  DWORD incr_len[] = {1, 16};
#else
  DWORD incr_len[] = {1, 16, MAX_LEN};
#endif
  DWORD wrap_rlen[] = {4, 8, 16};
  DWORD incr_max_len[] = {1, 7, 8, 9, 15, 16, 17, 31, 32, 33, \
                          127, 128, 129, 255, 256, 257, 511, 512};
  DWORD wrap_max_len[] = {1, 7, 8, 9, 15, 16, 17, 31, 32, 33, 512};
  DWORD wrapsize;
  BYTE* wbuf;
  BYTE* rbuf;
  BYTE  expect[sizeof(WORD)*len16];
  int   xferByte;

  DWORD pattern;
  DWORD mbrReg;
  DWORD devtype;
  DWORD rpcClk;
  DWORD maxen;
  DWORD maxlen;
  DWORD wcs_neg_cnt, rcs_neg_cnt;
  DWORD exp_wcs_neg_cnt, exp_rcs_neg_cnt;
  DWORD skip = 0;

  CT_MSG(">> Write/Read max length split Test\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }

  getDevType(&devtype, cs);
  getRpcClkPeriod(&rpcClk);
  getMAXEN(&maxen, cs);
  getMAXLEN(&maxlen, cs);

  wbuf = (BYTE*)malloc(sizeof(WORD)*len16);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  rbuf = (BYTE*)malloc(sizeof(WORD)*len16);
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  getDataPattern(&pattern);
  fillBuffer(pattern, (WORD*)wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer((WORD*)wbuf, len16);

  addr = 0;

  CT_MSG("Incr Write/INCR Read\n");
  for (m = 0; m < (sizeof(incr_max_len)/sizeof(incr_max_len[0])) ; m++) {
    CT_MSG("MAXLEN=%3d ----------------------\n", m);
    setMAXLEN(incr_max_len[m]-1, cs);

    for (l = 0; l < (sizeof(WMAXEN_RMAXEN)/sizeof(WMAXEN_RMAXEN[0])); l++) {

      for (k = 0; k < 3; k++) {
        xferByte = 1 << size[k];
        CT_MSG("SIZE=%1d ---------------------------------------\n", xferByte);

        for (j = 0; j < (sizeof(incr_len)/sizeof(incr_len[0])); j++) {
          len = incr_len[j];
          CT_MSG("LEN=%2d ---------------------------------------\n", len);

          for (i = 0; i < 4; i++) {
            switch (size[k]) {
            case BYTE_1:
              if (devtype == PSRAM) {
                if (PSRAM_TCSM <= rpcClk*(len/2)) {
                  if (MAXEN_ENABLED == WMAXEN_RMAXEN[l][0]) {
                    if ((len/2) <= incr_max_len[m]) {
                      CT_MSG("SKIP1\n");
                      skip = 1;
                      break;
                    } else if (PSRAM_TCSM <= rpcClk*incr_max_len[m]) {
                      CT_MSG("SKIP2\n");
                      skip = 1;
                      break;
                    }
                  } else {
                    CT_MSG("SKIP3\n");
                    skip = 1;
                    break;
                  }

                  if (MAXEN_ENABLED == WMAXEN_RMAXEN[l][1]) {
                    if ((len/2) <= incr_max_len[m]) {
                      CT_MSG("SKIP4\n");
                      skip = 1;
                      break;
                    } else if (PSRAM_TCSM <= rpcClk*incr_max_len[m]) {
                      CT_MSG("SKIP5\n");
                      skip = 1;
                      break;
                    }
                  } else {
                    CT_MSG("SKIP6\n");
                    skip = 1;
                    break;
                  }
                }
              }
              CT_MSG("MAXEN=%1d -----------------------------------\n", WMAXEN_RMAXEN[l][0]);
              CT_MSG("Addr 0x%08X: %d-len Write8\n", addr+mbrReg+i, len);
              setMAXEN(WMAXEN_RMAXEN[l][0], cs);
              startCScnt(cs);
              RPC_WRITE_BURST8(addr+mbrReg+i, len, wbuf);
              ret = RPC_GET_WRESP();
              endCScnt(cs);
              getCScnt(cs, &wcs_neg_cnt);
              if (ret != NO_ERROR) {
                CT_ERR_MSG("RPC2_WRITE_BURST8: %d\n", ret);
                goto end_test;
              }
              CT_MSG("MAXEN=%1d -----------------------------------\n", WMAXEN_RMAXEN[l][1]);
              CT_MSG("Addr 0x%08X: %d-len Read8\n", addr+mbrReg+i, len);
              setMAXEN(WMAXEN_RMAXEN[l][1], cs);
              startCScnt(cs);
              RPC_READ_BURST8(addr+mbrReg+i, len);
              ret = RPC2_GET_DATA8(len, rbuf);
              endCScnt(cs);
              getCScnt(cs, &rcs_neg_cnt);
              if (ret != NO_ERROR) {
                CT_ERR_MSG("RPC2_READ_BURST8: %d\n", ret);
                goto end_test;
              }
              break;
            case BYTE_2:
              if (devtype == PSRAM) {
                if (PSRAM_TCSM <= rpcClk*len) {
                  if (MAXEN_ENABLED == WMAXEN_RMAXEN[l][0]) {
                    if (len <= incr_max_len[m]) {
                      CT_MSG("SKIP1\n");
                      skip = 1;
                      break;
                    } else if (PSRAM_TCSM <= rpcClk*incr_max_len[m]) {
                      CT_MSG("SKIP2\n");
                      skip = 1;
                      break;
                    }
                  } else {
                    CT_MSG("SKIP3\n");
                    skip = 1;
                    break;
                  }

                  if (MAXEN_ENABLED == WMAXEN_RMAXEN[l][1]) {
                    if (len <= incr_max_len[m]) {
                      CT_MSG("SKIP4\n");
                      skip = 1;
                      break;
                    } else if (PSRAM_TCSM <= rpcClk*incr_max_len[m]) {
                      CT_MSG("SKIP5\n");
                      skip = 1;
                      break;
                    }
                  } else {
                    CT_MSG("SKIP6\n");
                    skip = 1;
                    break;
                  }
                }
              }
              CT_MSG("MAXEN=%1d -----------------------------------\n", WMAXEN_RMAXEN[l][0]);
              CT_MSG("Addr 0x%08X: %d-len Write16\n", addr+mbrReg+i, len);
              setMAXEN(WMAXEN_RMAXEN[l][0], cs);
              startCScnt(cs);
              RPC_WRITE_BURST(addr+mbrReg+i, len, (WORD*)wbuf);
              ret = RPC_GET_WRESP();
              endCScnt(cs);
              getCScnt(cs, &wcs_neg_cnt);
              if (ret != NO_ERROR) {
                CT_ERR_MSG("RPC_WRITE_BURST: %d\n", ret);
                goto end_test;
              }
              CT_MSG("MAXEN=%1d -----------------------------------\n", WMAXEN_RMAXEN[l][1]);
              CT_MSG("Addr 0x%08X: %d-len Read16\n", addr+mbrReg+i, len);
              setMAXEN(WMAXEN_RMAXEN[l][1], cs);
              startCScnt(cs);
              RPC_READ_BURST(addr+mbrReg+i, len);
              ret = RPC2_GET_DATA(len, (WORD*)rbuf);
              endCScnt(cs);
              getCScnt(cs, &rcs_neg_cnt);
              if (ret != NO_ERROR) {
                CT_ERR_MSG("RPC2_READ_BURST: %d\n", ret);
                goto end_test;
              }
              break;
            case BYTE_4:
              if (devtype == PSRAM) {
                if (PSRAM_TCSM <= rpcClk*len*2) {
                  if (MAXEN_ENABLED == WMAXEN_RMAXEN[l][0]) {
                    if (len*2 <= incr_max_len[m]) {
                      CT_MSG("SKIP1\n");
                      skip = 1;
                      break;
                    } else if (PSRAM_TCSM <= rpcClk*incr_max_len[m]) {
                      CT_MSG("SKIP2\n");
                      skip = 1;
                      break;
                    }
                  } else {
                    CT_MSG("SKIP3\n");
                    skip = 1;
                    break;
                  }

                  if (MAXEN_ENABLED == WMAXEN_RMAXEN[l][1]) {
                    if (len*2 <= incr_max_len[m]) {
                      CT_MSG("SKIP4\n");
                      skip = 1;
                      break;
                    } else if (PSRAM_TCSM <= rpcClk*incr_max_len[m]) {
                      CT_MSG("SKIP5\n");
                      skip = 1;
                      break;
                    }
                  } else {
                    CT_MSG("SKIP6\n");
                    skip = 1;
                    break;
                  }
                }
              }
              CT_MSG("MAXEN=%1d -----------------------------------\n", WMAXEN_RMAXEN[l][0]);
              CT_MSG("Addr 0x%08X: %d-len Write32\n", addr+mbrReg+i, len);
              setMAXEN(WMAXEN_RMAXEN[l][0], cs);
              startCScnt(cs);
              RPC_WRITE_BURST32(addr+mbrReg+i, len, (DWORD*)wbuf);
              ret = RPC_GET_WRESP();
              endCScnt(cs);
              getCScnt(cs, &wcs_neg_cnt);
              if (ret != NO_ERROR) {
                CT_ERR_MSG("RPC_WRITE_BURST32: %d\n", ret);
                goto end_test;
              }
              CT_MSG("MAXEN=%1d -----------------------------------\n", WMAXEN_RMAXEN[l][1]);
              CT_MSG("Addr 0x%08X: %d-len Read32\n", addr+mbrReg+i, len);
              setMAXEN(WMAXEN_RMAXEN[l][1], cs);
              startCScnt(cs);
              RPC_READ_BURST32(addr+mbrReg+i, len);
              ret = RPC2_GET_DATA32(len, (DWORD*)rbuf);
              endCScnt(cs);
              getCScnt(cs, &rcs_neg_cnt);
              if (ret != NO_ERROR) {
                CT_ERR_MSG("RPC2_READ_BURST32: %d\n", ret);
                goto end_test;
              }
              
              break;
            default:
              break;
            }
            if (skip == 1) {
              skip = 0;
              break;
            }
            len8 = (xferByte*len) - (addr+mbrReg+i)%xferByte;
            if (verifyData8(rbuf, wbuf, len8)) {
              ret = VERIFY_ERROR;
              CT_ERR_MSG("VerifyData8\n");
              goto end_test;
            }
            getexp_wcsNeg_cnt(addr+mbrReg+i, size[k], len, 1, WMAXEN_RMAXEN[l][0], incr_max_len[m]-1, &exp_wcs_neg_cnt);
            getexp_rcsNeg_cnt(addr+mbrReg+i, size[k], len, 1, INCR, WMAXEN_RMAXEN[l][1], incr_max_len[m]-1, &exp_rcs_neg_cnt);

            // Compare CS Negadge Count
            CT_MSG("Comare Write CS Negadge Count exp: %d, act: %d ---\n", exp_wcs_neg_cnt, wcs_neg_cnt);
            CT_MSG("Comare Read  CS Negadge Count exp: %d, act: %d ---\n", exp_rcs_neg_cnt, rcs_neg_cnt);
            if (wcs_neg_cnt != exp_wcs_neg_cnt) {
              CT_ERR_MSG("Write CS Negadge Count is mismatched\n");
              ret = VERIFY_ERROR;
              goto end_test;
            }
            if (rcs_neg_cnt != exp_rcs_neg_cnt) {
              CT_ERR_MSG("Read CS Negadge Count is mismatched\n");
              ret = VERIFY_ERROR;
              goto end_test;
            }
          }
        }
      }
    }
  }

  CT_MSG("WRAP Read\n");
  setMAXEN(maxen, cs);
  setMAXLEN(maxlen, cs);
  // Set initial data
  ret = RPC2_WRITE32(addr+mbrReg, len, (DWORD*)wbuf);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("RPC2_WRITE32: %d\n", ret);
    goto end_test;
  }
  CT_MSG("Write addr 0x%08X, len32 0x%x\n", addr+mbrReg, len);

  CT_MSG("MAXEN=%1d -----------------------------------\n", MAXEN_ENABLED);
  setMAXEN(MAXEN_ENABLED, cs);

  for (m = 0; m < (sizeof(wrap_max_len)/sizeof(wrap_max_len[0])) ; m++) {
    CT_MSG("MAXLEN=%3d ----------------------\n", m);
    setMAXLEN(wrap_max_len[m]-1, cs);

    for (l = 0; l < 3; l++) {
      // Set wrap size
      CT_MSG("Wrap Size=%2d -----------------------------\n", WRAP_BURST[l][0]);
      setWrapSize (WRAP_BURST[l][1], cs);
      set_cr_wrapsize (WRAP_BURST[l][1], WRAP2INCR_OFF, cs);

      for (k = 0; k < 3; k++) {
        xferByte = 1 << size[k];
        CT_MSG("SIZE=%1d ---------------------------------------\n", xferByte);

        for (j = 0; j < (sizeof(wrap_rlen)/sizeof(wrap_rlen[0])); j++) {
          len = wrap_rlen[j];
          wrapsize = len*xferByte;
          if (wrapsize != WRAP_BURST[l][0]) continue;          

          CT_MSG("LEN=%2d ---------------------------------------\n", len);

          for (i = 0; i < wrapsize; i+=xferByte) {
	      CT_MSG("Wrap Read addr 0x%08X, Wrap Size 0x%02d\n", addr+mbrReg+i, wrapsize);
              switch (k) {
              case BYTE_1:
                CT_MSG("%d-len Read8\n", len);
                startCScnt(cs);
	        RPC_READ_WRAP_BURST8(addr+mbrReg+i, len);
                ret = RPC2_GET_DATA8(len, rbuf);
                endCScnt(cs);
                getCScnt(cs, &rcs_neg_cnt);
	        if (ret != NO_ERROR) {
	          CT_ERR_MSG("RPC_READ_WRAP_BURST8: %d\n", ret);
	          goto end_test;
	        }
              break;
              case BYTE_2:
                CT_MSG("%d-len Read16\n", len);
                startCScnt(cs);
	        RPC_READ_WRAP_BURST(addr+mbrReg+i, len);
                ret = RPC2_GET_DATA(len, (WORD*)rbuf);
                endCScnt(cs);
                getCScnt(cs, &rcs_neg_cnt);
	        if (ret != NO_ERROR) {
	          CT_ERR_MSG("RPC_READ_WRAP_BURST: %d\n", ret);
	          goto end_test;
	        }
                break;
              case BYTE_4:
                CT_MSG("%d-len Read32\n", len);
                startCScnt(cs);
	        RPC_READ_WRAP_BURST32(addr+mbrReg+i, len);
                ret = RPC2_GET_DATA32(len, (DWORD*)rbuf);
                endCScnt(cs);
                getCScnt(cs, &rcs_neg_cnt);
	        if (ret != NO_ERROR) {
	          CT_ERR_MSG("RPC_READ_WRAP_BURST32: %d\n", ret);
	          goto end_test;
	        }
                break;
              default:
                break;
              }

              getexp_rcsNeg_cnt(addr+mbrReg+i, k, len, 1, WRAP, MAXEN_ENABLED, wrap_max_len[m]-1, &exp_rcs_neg_cnt);
              wrapMemCopy8(expect, &wbuf[addr], wrapsize, i);
              if (verifyData8(rbuf, expect, wrapsize)) {
                CT_ERR_MSG("Wrap VerifyData8\n");
                ret = VERIFY_ERROR;
                goto end_test;
              }

              // Compare CS Negadge Count
              CT_MSG("Comare Read  CS Negadge Count exp: %d, act: %d ---\n", exp_rcs_neg_cnt, rcs_neg_cnt);
              if (rcs_neg_cnt != exp_rcs_neg_cnt) {
                CT_ERR_MSG("Read CS Negadge Count is mismatched\n");
                ret = VERIFY_ERROR;
                goto end_test;
              }
          } //for i
        } //for j
      } //for k
    } //for l
  } //for m

  setMAXEN(maxen, cs);
  setMAXLEN(maxlen, cs);
  setWrapSize (BURST_32B, cs);
  set_cr_wrapsize (BURST_32B, WRAP2INCR_OFF, cs);
end_test:
  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
  CT_MSG("<< Write/Read max length split Test");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;

  return ret;
}

int tc_rd (DWORD cs)
{
  int ret = NO_ERROR;
  int trans = 2;
  int trans_cnt;
  DWORD addr;
  DWORD len = MAX_LEN;
  DWORD len16;
  DWORD len8;
  DWORD size;
  BYTE* wbuf;
  BYTE* rbuf;
  DWORD pattern;
  DWORD mbrReg;
  DWORD devtype;
  DWORD rpcClk;
  DWORD maxen;
  DWORD maxlen;
  int xferByte;
  DWORD wcs_neg_cnt, rcs_neg_cnt;
  DWORD exp_wcs_neg_cnt, exp_rcs_neg_cnt;
#if (RPC2_CTRL_IP_VER >= 240)
  DWORD maxlen_test = MAXLEN_MAX+1;
#endif

  CT_MSG(">> TC Read Test\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
  getDevType(&devtype, cs);
  getRpcClkPeriod(&rpcClk);
  getMAXEN(&maxen, cs);
  getMAXLEN(&maxlen, cs);
  setRndDelay(MEM, 0, 0);

#if (RPC2_CTRL_IP_VER >= 240)
  if (devtype == PSRAM) {
    while (PSRAM_TCSM <= (rpcClk*maxlen_test*2)) {
      maxlen_test /= 2;
    }
    while ((len*sizeof(DWORD)/sizeof(WORD)) > maxlen_test) {
      len /= 2;
    }
  }
  while (len*trans <= maxlen_test) {
    trans <<= 1;
  }
#else
  if (devtype == PSRAM) {
    while (PSRAM_TCSM <= (rpcClk*len*sizeof(DWORD)/sizeof(WORD))) {
      len /= 2;
    }
  }
  while (len*trans <= (MAXLEN_MAX + 1)) {
    trans <<= 1;
  }
#endif

  len16 = len*trans*sizeof(DWORD)/sizeof(WORD)*4;
  wbuf = (BYTE*)malloc(sizeof(WORD)*len16);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  rbuf = (BYTE*)malloc(sizeof(WORD)*len16);
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  getDataPattern(&pattern);
  fillBuffer(pattern, (WORD*)wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer((WORD*)wbuf, len16);

#if (RPC2_CTRL_IP_VER >= 240)
  CT_MSG("MAXLEN=%3d ----------------------\n", maxlen_test);
  setMAXLEN(maxlen_test-1, cs);
#else
  CT_MSG("MAXLEN=%3d ----------------------\n", MAXLEN_MAX);
  setMAXLEN(MAXLEN_MAX, cs);
#endif

  for (size = BYTE_1; size <= BYTE_4; size++) {
    xferByte = 1 << size;
    CT_MSG("SIZE=%1d LEN=%3d -------------------------------\n", xferByte, len);

    if (xferByte < sizeof(WORD)) trans_cnt = trans*(sizeof(WORD)/xferByte);
    else                         trans_cnt = trans/(xferByte/sizeof(WORD));
    CT_MSG("trans=%3d -----------------------------------\n", trans_cnt);
    
    addr = OFFSET & (~sizeof(DWORD));
    len8 = xferByte*len*trans_cnt;
    CT_MSG("OFFSET 0x%08X\n", addr);

    while ((addr & sizeof(DWORD)) < sizeof(DWORD)) {
      CT_MSG("MAXEN=0 -----------------------------------\n");
      setMAXEN(MAXEN_DISABLED, cs);

      CT_MSG("Write addr 0x%08X\n", addr+mbrReg);
      startCScnt(cs);
      ret = sequential_wr (addr+mbrReg, size, len, trans_cnt, wbuf);
      endCScnt(cs);
      getCScnt(cs, &wcs_neg_cnt);

      // Compare Write CS Negadge Count
#if (RPC2_CTRL_IP_VER >= 240)
      getexp_wcsNeg_cnt(addr+mbrReg, size, len, trans_cnt, MAXEN_DISABLED, maxlen_test-1, &exp_wcs_neg_cnt);
#else
      getexp_wcsNeg_cnt(addr+mbrReg, size, len, trans_cnt, MAXEN_DISABLED, MAXLEN_MAX, &exp_wcs_neg_cnt);
#endif
      CT_MSG("Comare Write CS Negadge Count exp: %d, act: %d ---\n", exp_wcs_neg_cnt, wcs_neg_cnt);
      if (wcs_neg_cnt != exp_wcs_neg_cnt) {
        CT_ERR_MSG("Write CS Negadge Count is mismatched\n");
        ret = VERIFY_ERROR;
        goto end_test;
      }

      CT_MSG("Read addr 0x%08X\n", addr+mbrReg);
      startCScnt(cs);
      ret = sequential_rd (addr+mbrReg, size, len, trans_cnt, rbuf, 1);
      endCScnt(cs);
      getCScnt(cs, &rcs_neg_cnt);

      // Compare Read CS Negadge Count
#if (RPC2_CTRL_IP_VER >= 240)
      getexp_rcsNeg_cnt(addr+mbrReg, size, len, trans_cnt, INCR, MAXEN_DISABLED, maxlen_test-1, &exp_rcs_neg_cnt);
#else
      getexp_rcsNeg_cnt(addr+mbrReg, size, len, trans_cnt, INCR, MAXEN_DISABLED, MAXLEN_MAX, &exp_rcs_neg_cnt);
#endif
      CT_MSG("Comare Read  CS Negadge Count exp: %d, act: %d ---\n", exp_rcs_neg_cnt, rcs_neg_cnt);
      if (rcs_neg_cnt != exp_rcs_neg_cnt) {
        CT_ERR_MSG("Read CS Negadge Count is mismatched\n");
        ret = VERIFY_ERROR;
        goto end_test;
      }

      // Verify Write/Read Data
      if (verifyData8(rbuf, wbuf, len*trans_cnt*xferByte)) {
        CT_ERR_MSG("VerifyData8\n");
        ret = VERIFY_ERROR;
        goto end_test;
      }

      CT_MSG("MAXEN=1 -----------------------------------\n"); 
      setMAXEN(MAXEN_ENABLED, cs);

      CT_MSG("Read addr 0x%08X\n", addr+mbrReg);
      startCScnt(cs);
      ret = sequential_rd (addr+mbrReg, size, len, trans_cnt, rbuf, 1);
      endCScnt(cs);
      getCScnt(cs, &rcs_neg_cnt);

      // Compare Read CS Negadge Count
#if (RPC2_CTRL_IP_VER >= 240)
      getexp_rcsNeg_cnt(addr+mbrReg, size, len, trans_cnt, INCR, MAXEN_ENABLED, maxlen_test-1, &exp_rcs_neg_cnt);
#else
      getexp_rcsNeg_cnt(addr+mbrReg, size, len, trans_cnt, INCR, MAXEN_ENABLED, MAXLEN_MAX, &exp_rcs_neg_cnt);
#endif
      CT_MSG("Comare Read  CS Negadge Count exp: %d, act: %d ---\n", exp_rcs_neg_cnt, rcs_neg_cnt);
      if (rcs_neg_cnt != exp_rcs_neg_cnt) {
        CT_ERR_MSG("Read CS Negadge Count is mismatched\n");
        ret = VERIFY_ERROR;
        goto end_test;
      }

      // Verify Write/Read Data
      if (verifyData8(rbuf, wbuf, len*trans_cnt*xferByte)) {
        CT_ERR_MSG("VerifyData8\n");
        ret = VERIFY_ERROR;
        goto end_test;
      }

      CT_MSG("Write addr 0x%08X\n", addr+len8+mbrReg);
      startCScnt(cs);
      ret = sequential_wr (addr+len8+mbrReg, size, len, trans_cnt, &wbuf[len8]);
      endCScnt(cs);
      getCScnt(cs, &wcs_neg_cnt);

      // Compare Write CS Negadge Count
#if (RPC2_CTRL_IP_VER >= 240)
      getexp_wcsNeg_cnt(addr+len8+mbrReg, size, len, trans_cnt, MAXEN_ENABLED, maxlen_test-1, &exp_wcs_neg_cnt);
#else
      getexp_wcsNeg_cnt(addr+len8+mbrReg, size, len, trans_cnt, MAXEN_ENABLED, MAXLEN_MAX, &exp_wcs_neg_cnt);
#endif
      CT_MSG("Comare Write CS Negadge Count exp: %d, act: %d ---\n", exp_wcs_neg_cnt, wcs_neg_cnt);
      if (wcs_neg_cnt != exp_wcs_neg_cnt) {
        CT_ERR_MSG("Write CS Negadge Count is mismatched\n");
        ret = VERIFY_ERROR;
        goto end_test;
      }

      CT_MSG("Read addr 0x%08X\n", addr+len8+mbrReg);
      startCScnt(cs);
      ret = sequential_rd (addr+len8+mbrReg, size, len, trans_cnt, &rbuf[len8], 1);
      endCScnt(cs);
      getCScnt(cs, &rcs_neg_cnt);

      // Compare Read CS Negadge Count
#if (RPC2_CTRL_IP_VER >= 240)
      getexp_rcsNeg_cnt(addr+len8+mbrReg, size, len, trans_cnt, INCR, MAXEN_ENABLED, maxlen_test-1, &exp_rcs_neg_cnt);
#else
      getexp_rcsNeg_cnt(addr+len8+mbrReg, size, len, trans_cnt, INCR, MAXEN_ENABLED, MAXLEN_MAX, &exp_rcs_neg_cnt);
#endif
      CT_MSG("Comare Read  CS Negadge Count exp: %d, act: %d ---\n", exp_rcs_neg_cnt, rcs_neg_cnt);
      if (rcs_neg_cnt != exp_rcs_neg_cnt) {
        CT_ERR_MSG("Read CS Negadge Count is mismatched\n");
        ret = VERIFY_ERROR;
        goto end_test;
      }

      // Verify Write/Read Data
      if (verifyData8(&rbuf[len8], &wbuf[len8], len8)) {
        CT_ERR_MSG("VerifyData8\n");
        ret = VERIFY_ERROR;
        goto end_test;
      }

      if (size <= BYTE_2) addr = addr + sizeof(WORD);
      else addr = addr + xferByte;
    }
  }
  setMAXEN(maxen, cs);
  setMAXLEN(maxlen, cs);
 end_test:
  setRndDelay(MEM, 10, 10);
  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
  CT_MSG("<< TC Read Test\n");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;

  return ret;
}
#endif

#if (RPC2_CTRL_IP_VER >= 240)
int tar_wr_rd_2cs (DWORD cs)
{
  int ret;
  int i;

  DWORD startAddress[2];
  int XferByte[2];
  DWORD wta, rta;
  DWORD w_outstanding_cnt = 16;
  DWORD r_outstanding_cnt = 64;
  TBurstParam **wppTBurstParam;
  TBurstParam **rppTBurstParam;
  DWORD cs_array[2];

  CT_MSG(">> 2CS Transaction Arbitration Test\n");

  cs_array[0] = cs;
  cs_array[1] = (cs==CS0_SEL) ? CS1_SEL: CS0_SEL;

  for (i=0; i<2; i++) {
   ret = getMemBaseAddress (&startAddress[i], cs_array[i]);
   if (ret != NO_ERROR) {
     CT_ERR_MSG("Can't get CS%1d memory base address\n", cs_array[i]);
     goto end_test;
   }
   XferByte[i] = 1 << BYTE_2;
  }

  wppTBurstParam = (TBurstParam **)malloc((sizeof(TBurstParam *)*w_outstanding_cnt));
  rppTBurstParam = (TBurstParam **)malloc((sizeof(TBurstParam *)*r_outstanding_cnt));

  for (i=0; i<w_outstanding_cnt; i++) {
   wppTBurstParam[i] = (TBurstParam *)malloc(sizeof(TBurstParam));
   wppTBurstParam[i]->size = BYTE_2;
   wppTBurstParam[i]->len = 16;
//   wppTBurstParam[i]->len = 1;
   wppTBurstParam[i]->burst = INCR;
   wppTBurstParam[i]->pattern = WORD_ADDRESS;
  }

  for (i=0; i<r_outstanding_cnt; i++) {
   rppTBurstParam[i] = (TBurstParam *)malloc(sizeof(TBurstParam));
   rppTBurstParam[i]->size = BYTE_2;
   rppTBurstParam[i]->len = 16;
   rppTBurstParam[i]->burst = INCR;
   rppTBurstParam[i]->pattern = RANDOM;
  }

  for (wta = 0; wta < WTA_MAX+1; wta++) {
    setWTA(wta);
    CT_MSG("CS%1d:Write Arbitration %d transaction ----\n", cs_array[0], wta+1);
    for (rta = 0; rta < RTA_MAX+1; rta++) {
      setRTA(rta);
      CT_MSG("CS%1d:Read  Arbitration %d transaction ----\n", cs_array[1], rta+1);
      for (i=0; i<w_outstanding_cnt; i++) {
        wppTBurstParam[i]->addr = startAddress[0];
        startAddress[0] += XferByte[0]*16*2;
      }
      for (i=0; i<r_outstanding_cnt; i++) {
        rppTBurstParam[i]->addr = startAddress[1];
        startAddress[1] += XferByte[1]*16*2;
      }
      ret = sub_concurrent_wr_rd_outstanding_2cs (wppTBurstParam, w_outstanding_cnt, \
                                                  rppTBurstParam, r_outstanding_cnt, \
                                                  (w_outstanding_cnt+wta)/(wta+1));
      if (ret != NO_ERROR) goto end_test;
    }
  }
 end_test:
  if (wppTBurstParam) {
    for (i=0; i<w_outstanding_cnt; i++) {
      if (wppTBurstParam[i]) free(wppTBurstParam[i]);
    }
    free(wppTBurstParam);
  }
  if (rppTBurstParam) {
    for (i=0; i<r_outstanding_cnt; i++) {
      if (rppTBurstParam[i]) free(rppTBurstParam[i]);
    }
    free(rppTBurstParam);
  }
  CT_MSG("<< 2CS Transaction Arbitration Test");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}
#endif

int reset_output (DWORD cs)
{
  int ret = NO_ERROR;
  WORD crData, crrData, rstcrrData;

  CT_MSG(">> Reset# Output Test\n");

  ret = read_cr_reg (&crData, cs);
  if (ret != NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }

  // Write CR register
  ret = set_cr_wrapsize (BURST_64B, WRAP2INCR_ON, cs);
  if (ret != NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }

  ret = read_cr_reg (&crrData, cs);
  if (ret != NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }
  MSG("Read CR Reg = 0x%04X\n", crrData);

  // Reset
  CT_MSG("Reset Target Memory\n");
  RPC2_RESET();
  waitUs(300);

  ret = read_cr_reg (&rstcrrData, cs);
  if (ret != NO_ERROR) {
    ret = ERROR;
    goto end_test;
  }
  MSG("Read CR Reg = 0x%04X\n", rstcrrData);

  CT_MSG("VERIFY - %s\n", (crrData != rstcrrData) ? STR_OK : STR_NG);
  if (crrData == rstcrrData) {
    ret = VERIFY_ERROR;
    goto end_test;
  }

  set_cr_reg (crData, cs);
 end_test:
  CT_MSG("<< Reset# Output Test\n");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int debug_test (DWORD cs)
{
  int ret = NO_ERROR;
  int i, j;
  DWORD reg;
  DWORD mtr_rsvd;
  DWORD mcr_rsvd;
  DWORD dev_type;
  WORD *wbuf;
  DWORD *wbuf32;
  BYTE *wbuf8;
  WORD *rbuf;
  BYTE *rbuf8;
  DWORD *rbuf32;
  DWORD pattern;
  DWORD addr = 0x0;
  DWORD mcr_addr;
  DWORD mtr_addr;
  DWORD mbr_addr;
  DWORD len16 = 16;
  WORD cr_data;
  WORD cr_rsvd;
  DWORD rpc_freq;
  DWORD wrap_len[] = {2, 4, 8, 16};
  int wrap_size;
  DWORD *ebuf32;
  WORD *ebuf;
  BYTE *ebuf8;

  MSG("\n");
  CT_MSG(">> Unexpected Config Setting\n");
  wbuf32 = (DWORD*)malloc(sizeof(DWORD)*len16);
  if (!wbuf32) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  wbuf8 = (BYTE*)wbuf32;
  wbuf  = (WORD*)wbuf32;

  rbuf32 = (DWORD*)malloc(sizeof(DWORD)*len16);
  if (!rbuf32) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  rbuf = (WORD*)rbuf32;
  rbuf8 = (BYTE*)rbuf32;

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16*2);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  getMemBaseAddress(&mbr_addr, cs);
  mtr_addr = (cs == CS0_SEL) ? REG_MTR0_ADDR: REG_MTR1_ADDR;
  mcr_addr = (cs == CS0_SEL) ? REG_MCR0_ADDR: REG_MCR1_ADDR;

  RPC2_READ_REG(mcr_addr, &mcr_rsvd);
  dev_type = GET_DEVTYPE(mcr_rsvd);

  CT_MSG("UNSUPPORTED LATENCY---------------------------\n");
  if (dev_type == PSRAM) {
    setConfigRegTarget(1, cs);
    RPC2_READ(mbr_addr, 1, &cr_rsvd);

    // set latency in device from freq
    getRpcClkPeriod(&rpc_freq);
    CT_MSG("RPC CK %d ps, set latency\n", rpc_freq);

    cr_data = cr_rsvd & 0xFF0F;
    if ((rpc_freq >= 6000) && (rpc_freq < 7500)) {
      cr_data |= 0x10;
    }
    else if ((rpc_freq >= 7500) && (rpc_freq < 10000)) {
      cr_data |= 0x00;
    }
    else if ((rpc_freq >= 10000) && (rpc_freq < 12000)) {
      cr_data |= 0xF0;
    }
    else {
      cr_data |= 0xE0;
    }
    RPC2_WRITE(mbr_addr, 1, &cr_data);
    setConfigRegTarget(0, cs);    
  }

  RPC2_READ_REG(mtr_addr, &mtr_rsvd);

  addr = mbr_addr;
  // test all latency in controller
  for (i = 0; i < (sizeof(PSRAM_LTCY)/sizeof(DWORD)); i++) {
    setLTCYcycle(PSRAM_LTCY[i], cs);
    CT_MSG("Addr 0x%08X: %d len Write -> Read\n", addr, len16);
    RPC2_WRITE(addr, len16, wbuf);
    RPC2_READ(addr, len16, rbuf);
    addr += len16*sizeof(WORD);
  }
  RPC2_WRITE_REG(mtr_addr, &mtr_rsvd);

  if (dev_type == PSRAM) {
    // return to default cr value
    setConfigRegTarget(1, cs);
    RPC2_WRITE(mbr_addr, 1, &cr_rsvd);
    setConfigRegTarget(0, cs);
  }

  // nomal write/read
  CT_MSG("Addr 0x%08X: %d len Write -> Read\n", addr, len16);
  ret = RPC2_WRITE(addr, len16, wbuf);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("RPC2_WRITE: %d\n", ret);
    goto end_test;
  }
  ret = RPC2_READ(addr, len16, rbuf);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("RPC2_READ: %d\n", ret);
    goto end_test;
  }
  if (verifyData(rbuf, wbuf, len16)) {
    ret = VERIFY_ERROR;
    CT_ERR_MSG("VerifyData\n");
    goto end_test;
  }
  addr += len16*sizeof(WORD);

  CT_MSG("OPPOSITE TARGET-------------------------------\n");  
  reg = mcr_rsvd;
  dev_type = (~dev_type) & 0x1;
  CT_MSG("Set device type to %d\n", dev_type);
  reg &= CLR_DEVTYPE;
  reg |= SET_DEVTYPE(dev_type);
  RPC2_WRITE_REG(mcr_addr, &reg);

  for (i = 0; i < 2; i++) {
    CT_MSG("Addr 0x%08X: %d len Write -> Read\n", addr, len16);
    RPC2_WRITE(addr, len16, wbuf);
    RPC2_READ(addr, len16, rbuf);
    addr += len16*sizeof(WORD);
  }
  // return to init setting
  RPC2_WRITE_REG(mcr_addr, &mcr_rsvd);
  
  CT_MSG("WRAPSIZE MISMATCH-----------------------------\n");
  setACacheSupport(1, cs);
  for (wrap_size = 0; wrap_size < 4; wrap_size++) {
    CT_MSG("Set MCR.WRAPSIZE=%d\n", wrap_size);
    setWrapSize(wrap_size, cs);
    for (i = 0; i < sizeof(wrap_len)/sizeof(DWORD); i++) {
      addr = mbr_addr;
      for (j = 0; j < wrap_len[i]; j++) {
	CT_MSG("Wrap Read Addr 0x%08X: %d len\n", addr, wrap_len[i]);
	RPC_READ_WRAP_BURST32(addr, wrap_len[i]);
	ret = RPC2_GET_DATA32(wrap_len[i], rbuf32);
	if (ret != NO_ERROR) {
	  CT_ERR_MSG("WRAP READ: %d\n", ret);
	  goto end_test;
	}
	addr += 4;
      }
    }
  }
  // return to init setting
  RPC2_WRITE_REG(mcr_addr, &mcr_rsvd);

  // nomal write/read
  CT_MSG("Addr 0x%08X: %d len Write -> Read\n", addr, len16);
  ret = RPC2_WRITE(addr, len16, wbuf);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("RPC2_WRITE: %d\n", ret);
    goto end_test;
  }
  ret = RPC2_READ(addr, len16, rbuf);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("RPC2_READ: %d\n", ret);
    goto end_test;
  }
  if (verifyData(rbuf, wbuf, len16)) {
    ret = VERIFY_ERROR;
    CT_ERR_MSG("VerifyData\n");
    goto end_test;
  }

  CT_MSG("UNSUPPORTED WRAPLEN---------------------------\n"); 
  CT_MSG("*** MCR.ACS=0 ********************************\n");
  addr = mbr_addr;
  RPC2_WRITE(addr, len16*2, wbuf);

  for (i = 0; i < sizeof(wrap_len)/sizeof(DWORD); i++) {
    addr = mbr_addr;
    for (j = 0; j < wrap_len[i]; j++) {
      CT_MSG("Wrap x32 Read Addr 0x%08X: %d len\n", addr, wrap_len[i]);
      RPC_READ_WRAP_BURST32(addr, wrap_len[i]);
      ret = RPC2_GET_DATA32(wrap_len[i], rbuf32);
      if (ret != NO_ERROR) {
	CT_ERR_MSG("WRAP READ: %d\n", ret);
	goto end_test;
      }
      addr += 4;
    }
  }
  
  for (i = 0; i < sizeof(wrap_len)/sizeof(DWORD); i++) {
    addr = mbr_addr;
    for (j = 0; j < wrap_len[i]; j++) {
      CT_MSG("Wrap x16 Read Addr 0x%08X: %d len\n", addr, wrap_len[i]);
      RPC_READ_WRAP_BURST(addr, wrap_len[i]);
      ret = RPC2_GET_DATA(wrap_len[i], rbuf);
      if (ret != NO_ERROR) {
	CT_ERR_MSG("WRAP READ: %d\n", ret);
	goto end_test;
      }
      addr += 2;
    }
  }

  for (i = 0; i < sizeof(wrap_len)/sizeof(DWORD); i++) {
    addr = mbr_addr;
    for (j = 0; j < wrap_len[i]; j++) {
      CT_MSG("Wrap x8  Read Addr 0x%08X: %d len\n", addr, wrap_len[i]);
      RPC_READ_WRAP_BURST8(addr, wrap_len[i]);
      ret = RPC2_GET_DATA8(wrap_len[i], rbuf8);
      if (ret != NO_ERROR) {
	CT_ERR_MSG("WRAP READ: %d\n", ret);
	goto end_test;
      }
      addr += 1;
    }
  }

  ebuf32 = (DWORD*)malloc(sizeof(DWORD)*len16);
  if (!ebuf32) {
    CT_ERR_MSG("Can't allocate memory for expected data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  ebuf = (WORD*)ebuf32;
  ebuf8 = (BYTE*)ebuf32;

  CT_MSG("*** MCR.ACS=1 ********************************\n");
  setACacheSupport(1, cs);
  for (i = 0; i < sizeof(wrap_len)/sizeof(DWORD); i++) {
    addr = mbr_addr;
    for (j = 0; j < wrap_len[i]; j++) {
      CT_MSG("Wrap x32 Read Addr 0x%08X: %d len\n", addr, wrap_len[i]);
      RPC_READ_WRAP_BURST32(addr, wrap_len[i]);
      ret = RPC2_GET_DATA32(wrap_len[i], rbuf32);
      if (ret != NO_ERROR) {
	CT_ERR_MSG("WRAP READ: %d\n", ret);
	goto end_test;
      }
      wrapMemCopy32(ebuf32, wbuf32, wrap_len[i], j);
      if (verifyData32(rbuf32, ebuf32, wrap_len[i])) {
	ret = VERIFY_ERROR;
	CT_ERR_MSG("VerifyData\n");
	goto end_test;
      }
      addr += 4;
    }
  }
  
  for (i = 0; i < sizeof(wrap_len)/sizeof(DWORD); i++) {
    addr = mbr_addr;
    for (j = 0; j < wrap_len[i]; j++) {
      CT_MSG("Wrap x16 Read Addr 0x%08X: %d len\n", addr, wrap_len[i]);
      RPC_READ_WRAP_BURST(addr, wrap_len[i]);
      ret = RPC2_GET_DATA(wrap_len[i], rbuf);
      if (ret != NO_ERROR) {
	CT_ERR_MSG("WRAP READ: %d\n", ret);
	goto end_test;
      }
      wrapMemCopy(ebuf, wbuf, wrap_len[i], j);
      if (verifyData(rbuf, ebuf, wrap_len[i])) {
	ret = VERIFY_ERROR;
	CT_ERR_MSG("VerifyData\n");
	goto end_test;
      }
      addr += 2;
    }
  }

  for (i = 0; i < sizeof(wrap_len)/sizeof(DWORD); i++) {
    addr = mbr_addr;
    for (j = 0; j < wrap_len[i]; j++) {
      CT_MSG("Wrap x8  Read Addr 0x%08X: %d len\n", addr, wrap_len[i]);
      RPC_READ_WRAP_BURST8(addr, wrap_len[i]);
      ret = RPC2_GET_DATA8(wrap_len[i], rbuf8);
      if (ret != NO_ERROR) {
	CT_ERR_MSG("WRAP READ: %d\n", ret);
	goto end_test;
      }
      wrapMemCopy8(ebuf8, wbuf8, wrap_len[i], j);
      if (verifyData8(rbuf8, ebuf8, wrap_len[i])) {
	ret = VERIFY_ERROR;
	CT_ERR_MSG("VerifyData\n");
	goto end_test;
      }
      addr += 1;
    }
  }

  // return to init setting
  RPC2_WRITE_REG(mcr_addr, &mcr_rsvd);

  // nomal write/read
  CT_MSG("Addr 0x%08X: %d len Write -> Read\n", addr, len16);
  ret = RPC2_WRITE(addr, len16, wbuf);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("RPC2_WRITE: %d\n", ret);
    goto end_test;
  }
  ret = RPC2_READ(addr, len16, rbuf);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("RPC2_READ: %d\n", ret);
    goto end_test;
  }
  if (verifyData(rbuf, wbuf, len16)) {
    ret = VERIFY_ERROR;
    CT_ERR_MSG("VerifyData\n");
    goto end_test;
  }

 end_test:
  if (ebuf32) {
    free(ebuf32);
  }
  if (rbuf32) {
    free(rbuf32);
  }
  if (wbuf32) {
    free(wbuf32);
  }
  CT_MSG("<< Unexpected Config Setting");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int reserved (DWORD cs)
{
  return NO_ERROR;
}

//=============================================================================
//  MAIN
//=============================================================================
#define BT_WR_REG              0x00000001
#define BT_WR_ILLEGAL_REG      0x00000002
#define BT_LOOPBACK            0x00000004
#define BT_MCR                 0x00000008
#define BT_MBR                 0x00000010
#define BT_MTR                 0x00000020
#define BT_GPOR_POLARITY       0x00000040
#define BT_WP                  0x00000080
#define BT_INTERRUPT_EN        0x00000100
#define BT_CSR                 0x00000200
#define BT_ADR_FIFO_FULL       0x00000400
#define BT_ADR_FIFO_FULL_OVER  0x00000800
#define BT_WDAT_FIFO_FULL      0x00001000
#define BT_WDAT_FIFO_FULL_OVER 0x00002000
#define BT_RDAT_FIFO_FULL      0x00004000
#define BT_RDAT_FIFO_FULL_OVER 0x00008000
#define BT_WR_ILLEGAL          0x00010000
#define BT_WR_EVEN_ODD_ADDR_1B 0x00020000
#if (RPC2_CTRL_IP_VER >= 230)
#define BT_WR_MAX_LEN_SPLIT    0x00040000
#define BT_TC                  0x00080000
#define BT_TC_WRAP_BOUNDARY    0x00100000
#define BT_TC_RESUME           0x00200000
#define BT_TC_TCOPTION         0x00400000
#define BT_EMU_WRAP_BURST      0x00800000
#define BT_EMU_WRAP_BURST_W_TC 0x01000000
#define BT_RW_WO_TC_1B_BURST   0x02000000
#define BT_LATENCY_CYCLE       0x04000000
#define BT_REFRESH_COLLISON    0x08000000
#define BT_WR_ERR_RSTO         0x10000000
#define BT_RESET               0x20000000
#define BT2_TC_EXCHANGE_2CS    0x00000001
#define BT2_WR_CONCURRENT_2CS  0x00000002
#define BT2_WR_ALTERNATIVE_2CS 0x00000004
#if (RPC2_CTRL_IP_VER >= 240)
#define BT2_WR_TAR_2CS         0x00000008
#endif
#else
#define BT_TC                  0x00040000
#define BT_TC_WRAP_BOUNDARY    0x00080000
#define BT_TC_RESUME           0x00100000
#define BT_TC_TCOPTION         0x00200000
#define BT_EMU_WRAP_BURST      0x00400000
#define BT_EMU_WRAP_BURST_W_TC 0x00800000
#define BT_RW_WO_TC_1B_BURST   0x01000000
#define BT_LATENCY_CYCLE       0x02000000
#define BT_REFRESH_COLLISON    0x04000000
#define BT_WR_ERR_RSTO         0x08000000
#define BT_TC_EXCHANGE_2CS     0x10000000
#define BT_WR_CONCURRENT_2CS   0x20000000
#define BT_WR_ALTERNATIVE_2CS  0x40000000
#endif
#define BT2_STATUS_REG         0x20000000
#define BT2_WM                 0x40000000
#define BT2_DEBUG              0x80000000
#define BT_RESERVED            0xFFFFFFFF
//#define BT_WR_RD_1B            0x00800000
//#define BT_TC_RD_1B            0x01000000
//#define BT_TC_WRAP_BOUNDARY_1B 0x02000000
//#define BT_TC_RESUME_1B        0x04000000

TTestCase BT[] = {
  {BT_WR_REG,              normal_reg_wr_rd,           "4B Write Data to CTRL REG"},
  {BT_WR_ILLEGAL_REG,      illegal_reg_wr_rd,          "Illegal Access to CTRL REG"},
  {BT_LOOPBACK,            loopback_wr_rd,             "W/R in Loopback mode"},
  {BT_MCR,                 mcr_wr_rd,                  "Memory Configuration Reg"},
  {BT_MBR,                 mbr_wr_rd,                  "Memory Base Address"},
  {BT_MTR,                 memory_timing_control,      "Memory Timing Control"},
  {BT_GPOR_POLARITY,       gpor_polarity,              "GPOR Output Polarity"},
  {BT_WP,                  wp_wr_rd,                   "Write Protection"},
  {BT_INTERRUPT_EN,        interrupt_enable,           "Interrupt Enable"},
  {BT_CSR,                 csr_rd,                     "Controller Status Reg"},
  {BT_ADR_FIFO_FULL,       adr_fifo_full,              "ADR FIFO Full W/R"},
  {BT_ADR_FIFO_FULL_OVER,  adr_fifo_full_over,         "ADR FIFO Full Over W/R"},
  {BT_WDAT_FIFO_FULL,      wdat_fifo_full,             "WDAT FIFO Full W/R"},
  {BT_WDAT_FIFO_FULL_OVER, wdat_fifo_full_over,        "WDAT FIFO Full Over W/R"},
  {BT_RDAT_FIFO_FULL,      rdat_fifo_full,             "RDAT FIFO Full W/R"},
  {BT_RDAT_FIFO_FULL_OVER, rdat_fifo_full_over,        "RDAT FIFO Full Over W/R"},
  {BT_WR_ILLEGAL,          illegal_wr_rd,              "Illegal Access to MEM"},
  {BT_WR_EVEN_ODD_ADDR_1B, wr_rd_even_odd_addr_1B,     "1B Write/Read Even/Odd Address"},
#if (RPC2_CTRL_IP_VER >= 230)
  {BT_WR_MAX_LEN_SPLIT,    wr_rd_max_len_split,        "Write/Read Max length Split"},
#endif
  {BT_TC,                  tc_rd,                      "TC Read"},
  {BT_TC_WRAP_BOUNDARY,    tc_rd_wrap_boundary,        "TC Read aligned wrap boundary"},
  {BT_TC_RESUME,           tc_resume_rd,               "TC Resume Read"},
  {BT_TC_TCOPTION,         tc_rd_tc_option,            "TC Read w/ TC Option"},
  {BT_EMU_WRAP_BURST,      emulated_wrap_burst_rd,     "Emulated Wrap Burst read"},
  {BT_EMU_WRAP_BURST_W_TC, emulated_wrap_burst_w_tc_rd,"Emulated Wrap Burst read w/ TC Option"},
  {BT_RW_WO_TC_1B_BURST,   rd_wo_TC_1B_burst,          "1B Burst Read Odd Address w/o TC Test"},
  {BT_LATENCY_CYCLE,       psram_latency_cycle,        "PSRAM Latency Cycle"},
  {BT_REFRESH_COLLISON,    psram_refresh_collison,     "PSRAM Write/Read Refresh Collison"},
  {BT_WR_ERR_RSTO,         axi_wr_rd_error_rsto,       "Flash RSTO# Write/Read Error"},
#if (RPC2_CTRL_IP_VER >= 230)
  {BT_RESET,               reset_output,               "RESET# Output"},
  {BT_RESERVED,            reserved,                   "RESERVED"},
  {BT_RESERVED,            reserved,                   "RESERVED"},
  {BT2_TC_EXCHANGE_2CS,    tc_rd_exchange_2cs,         "2CS TC Read exchange"},
  {BT2_WR_CONCURRENT_2CS,  concurrent_wr_rd_2cs,       "2CS Concurrent WRITE/READ"},
  {BT2_WR_ALTERNATIVE_2CS, alternative_wr_rd_2cs,      "2CS Alternative WRITE/READ"},
#if (RPC2_CTRL_IP_VER >= 240)
  {BT2_WR_TAR_2CS,         tar_wr_rd_2cs,              "2CS Transaction Arbitration"},
#endif
#else
  {BT_TC_EXCHANGE_2CS,     tc_rd_exchange_2cs,         "2CS TC Read exchange"},
  {BT_WR_CONCURRENT_2CS,   concurrent_wr_rd_2cs,       "2CS Concurrent WRITE/READ"},
  {BT_WR_ALTERNATIVE_2CS,  alternative_wr_rd_2cs,      "2CS Alternative WRITE/READ"},
#endif
  {BT2_DEBUG,              debug_test,                 "For debug"}
//  {BT2_STATUS_REG,          status_register,            "Status Register"},
//  {BT2_WM,                  rdat_fifo_wm,               "Water Mark=0-3"},
//  {BT_TC_RD_1B,            tc_rd_1B,                   "1B Burst TC Read"},
//  {BT_TC_WRAP_BOUNDARY_1B, tc_rd_wrap_boundary_1B,     "1B Burst TC Read Wrap Boundary"},
//  {BT_TC_RESUME_1B,        tc_resume_rd_1B,            "1B Burst TC Resume Read"},
//  {BT_WR_RD_1B,            wr_rd_1B_burst,             "1B Burst Write/Read"},
};

#define NUM_BT  (sizeof(BT)/sizeof(BT[0]))

#if (RPC2_CTRL_IP_VER >= 230)
#define BT2_2CS (BT2_WR_CONCURRENT_2CS | \
                 BT2_WR_ALTERNATIVE_2CS)
#else
#define BT_2CS  (BT_TC_EXCHANGE_2CS   | \
                 BT_WR_CONCURRENT_2CS | \
                 BT_WR_ALTERNATIVE_2CS)
#endif

#define BT_WDAT_FIFO    (BT_WDAT_FIFO_FULL     | \
                         BT_WDAT_FIFO_FULL_OVER)

#define BT_RDAT_FIFO    (BT_RDAT_FIFO_FULL     | \
                         BT_RDAT_FIFO_FULL_OVER)

static int initialization (DWORD pattern)
{
  int i;
  int ret = NO_ERROR;

  WORD  crData;
  DWORD rpcClk;
  DWORD devType[2];
#if (RPC2_CTRL_IP_VER >= 230)
  DWORD maxlen;
#endif

#ifndef RSTO
  // Reset
  RPC2_RESET();
#endif

  // Set data pattern
  setDataPattern(pattern);

  // Set CS0/1 memory base addresss
  setMemBaseAddress(CS0_MEM_BASE, CS0_SEL);
  setMemBaseAddress(CS1_MEM_BASE, CS1_SEL);

  devType[0] = CS0_DEVTYPE;
  devType[1] = CS1_DEVTYPE;

  for (i = 0; i < 2; i++) {
    MSG("Set CS%1d:DEVTYPE=%1d\n", i, devType[i]);
    setDevType (devType[i], i);
    if (devType[i] == PSRAM) {
      getRpcClkPeriod(&rpcClk);

      if (rpcClk < 10000) {
        setRCSHIcycle(1, i);
        setWCSHIcycle(1, i);
      }
      if (rpcClk < 7500) {
        setRCSScycle(1, i);
        setWCSScycle(1, i);
      }
      crData = PSRAM_CS_INIT;
    } else {
      crData = FLSH_CS_INIT;
    }

#if (RPC2_CTRL_IP_VER >= 230)
    if (devType[i] == PSRAM) {
      setMAXEN(MAXEN_ENABLED, i);
    }
    maxlen = MAXLEN_MAX + 1;
    while (PSRAM_TCSM <= (rpcClk*maxlen)) {
      maxlen /= 2;
    }
    setMAXLEN(maxlen-1, i);
#endif

    // Set wrap size
    setWrapSize (BURST_32B, i);
#ifndef RSTO
    set_cr_reg (crData, i);
#endif
  }
  return ret;
}

int c_test()
{
  int ret;
  int i, j;
  int btResult[NUM_BT];
  char *btStr[] = {"UNDO", "PASS", "FAIL"};
  DWORD btFlag[2] = {0, 0};
  DWORD pattern;
  DWORD cs = CS0_SEL;
#if (RPC2_CTRL_IP_VER >= 230)
#if (!defined RSTO && !defined BTFLAG && !defined BTFLAG2)
  DWORD rpcClk;
  DWORD axiClk;
#endif
#else
#if (!defined ONLY_2CS_TC && !defined RSTO && !defined BTFLAG)
  DWORD rpcClk;
#endif
#endif
  DWORD devtype;

  MSG("RPC2 Basic Function Test\n");
#ifdef PATTERN
  pattern = PATTERN;
#else
  pattern = WORD_ADDRESS;
#endif

#ifdef CS1_ENABLED
  cs = CS1_SEL;
  devtype = CS1_DEVTYPE;
  MSG(" CS1 Selected\n");
#else
  cs = CS0_SEL;
  devtype = CS0_DEVTYPE;
  MSG(" CS0 Selected\n");
#endif

#if (RPC2_CTRL_IP_VER >= 230)
#if (!defined RSTO && !defined BTFLAG && !defined BTFLAG2)
  getRpcClkPeriod(&rpcClk);
  MSG(" RPC CLK = %d ps\n", rpcClk);
  getAxiClkPeriod(&axiClk);
  MSG(" AXI CLK = %d ps\n", axiClk);
#endif
#endif

#ifdef BTFLAG
  btFlag[0] = BTFLAG;
#elif (defined BTFLAG2)
  btFlag[0] = 0;
#elif (defined RSTO)
  btFlag[0] = BT_WR_ERR_RSTO;
#else
#if (RPC2_CTRL_IP_VER >= 240)
#ifdef ONLY_2CS_TC
  btFlag[0] = 0;
#else
  btFlag[0] = (0x23C70E5F);
  btFlag[0] |= (BT_WDAT_FIFO | BT_RDAT_FIFO);
#endif
#elif (RPC2_CTRL_IP_VER >= 230)
#ifdef ONLY_2CS_TC
  btFlag[0] = 0;
#else
  btFlag[0] = (0x23D70E5F);
  btFlag[0] |= (BT_WDAT_FIFO | BT_RDAT_FIFO);
#endif
#else
#ifdef ONLY_2CS_TC
  btFlag[0] = BT_2CS;
#else
  btFlag[0] = (0x01EF0E5F | BT_2CS);
#endif
#endif

#ifndef ONLY_2CS_TC
#if (RPC2_CTRL_IP_VER >= 240)
  if (rpcClk/axiClk >= 2) {
    btFlag[0] |= (BT_TC|BT_TC_WRAP_BOUNDARY);
  }
#elif (RPC2_CTRL_IP_VER >= 230)
  if (rpcClk/axiClk >= 2) {
    btFlag[0] |= BT_TC;
  }
#endif
  if (devtype == PSRAM) {
    btFlag[0] |= BT_REFRESH_COLLISON;

#if (RPC2_CTRL_IP_VER < 230)
    getRpcClkPeriod(&rpcClk);
    MSG(" RPC CLK = %d ps\n", rpcClk);
#endif
    if (rpcClk >= 12000) {
      btFlag[0] |= BT_LATENCY_CYCLE;
    }
    if (rpcClk >= 10000) {
      btFlag[0] |= BT_MTR;
    }

#if (RPC2_CTRL_IP_VER >= 230)
    if (rpcClk/axiClk >= 1)
      btFlag[0] |= BT_TC_RESUME;
#elif (RPC2_CTRL_IP_VER >= 210)
    if (PSRAM_TCSM > (rpcClk*MAX_LEN*sizeof(DWORD)/sizeof(WORD))) {
      btFlag[0] |= (BT_WDAT_FIFO | BT_RDAT_FIFO);
      btFlag[0] |= BT_TC_RESUME;
    }
#endif
  } else {
    btFlag[0] |= (BT_WP | BT_INTERRUPT_EN);
    btFlag[0] |= (BT_WDAT_FIFO | BT_RDAT_FIFO);
#if (RPC2_CTRL_IP_VER >= 230)
      if (rpcClk/axiClk >= 1)
#endif
    btFlag[0] |= BT_TC_RESUME;
  }
#endif
#endif

#ifdef BTFLAG2
  btFlag[1] = BTFLAG2;
#elif (defined BTFLAG)
  btFlag[1] = 0;
#elif (defined RSTO)
  btFlag[1] = 0;
#else
#if (RPC2_CTRL_IP_VER >= 230)
  btFlag[1] = BT2_2CS;
  if (rpcClk/axiClk >= 2) {
    btFlag[1] |= BT2_TC_EXCHANGE_2CS;
#if (RPC2_CTRL_IP_VER >= 240)
    btFlag[1] |= BT2_WR_TAR_2CS;
#endif
  }
#else
  btFlag[1] = 0;
#endif
#endif

  for (i = 0; i < NUM_BT; i++) {
    btResult[i] = UNDO;
  }

  ret = initialization(pattern);

  j = 0;
  for (i = 0; i < NUM_BT; i++) {
    if (i > 31) j=1;
    if (BT[i].sig == BT_RESERVED) continue;
    if (btFlag[j] & BT[i].sig) {
      btFlag[j] &= ~BT[i].sig;
      if (BT[i].func) {
        ret = BT[i].func(cs);
        if (ret != NO_ERROR) {
          btResult[i] = FAIL;
          break;
        }
        else btResult[i] = PASS;
      }
    }
  }

  MSG("\nTest Report ---------------------------------------------\n");
  j = 0;
  for (i = 0; i < NUM_BT; i++) {
    if (BT[i].sig == BT_RESERVED) continue;
    MSG("  %2d: %-40s -- %s\n", j, BT[i].title, btStr[btResult[i]]);
    j++;
  }
  MSG("-----------------------------------------------------------\n");
  return 0;
}
