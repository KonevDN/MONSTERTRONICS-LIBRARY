#ifdef SIMULATION
#include "sltapi_sim.h"
#include "svdpi.h"
#include "dpiheader.h"
#include <math.h>
#include "rpc2_vlld.h"
#include "rpc2_llops.h"
#else
#include <sltapi.h>
#endif
#include "rpc2.h"
#ifdef NCSC
extern int io_printf(const char *fmt, ...);
#define printf io_printf
#endif

//
//----------------------------------------------------------------------------------
//  Script: Program suspend/resume with fixed suspend latency
//----------------------------------------------------------------------------------
/* Test flow
1.  erase sector 0
2.  delay 30 usec ("sd")
3.  suspend erase
4.  delay 30 usec ("TBD")
5.  read status register, should see 0x84h
6.  resume erase
7.  random delay (50 % < 30 usec) ("delay")
8.  repeat step 3 to 7 until erase completes
9.  repeat step 1 to 8 for other selected sectors
10. repeat step 1 to 9 for 100 times ("cycle")
*/
char Script[] = "508_Prog_sus_res_rand";

//Command line arguments and their defaults
DWORD susp_delay    = 100;                       // "sd"
DWORD delay         = 100;                       // "delay"
DWORD max_delay     = 150;                      // "max"
//DWORD cycle         = 100;                      // "cycle"
DWORD cycle         = 5;                      // "cycle"
DWORD tPSL          = 30;                       // usec

// undocumented command line arguments and their default values
DWORD help_only = NO;       // display help only (NO), execute test (YES)
DWORD diag = NO;

//Global variables
PDEV pDevice;
PTEST pTest = 1;
STS t0, t1;
char s[81];
WORD * pData = (WORD *)NULL;
DWORD bufSize;
DWORD DISP_DATA_PATTERN = 1;
DWORD max_rand_half;
DWORD delay_diff;

DWORD EraseSuspendResume(PDEV pDevice, DWORD tSector, DWORD *scount);
DWORD test_exit(DWORD exit_val);
void help(void);
void linespace(DWORD n);
DWORD GetCommandLineArg(void);
DWORD SCRPPrimEraseTimedSusp(PTEST pT, PDEV pDev, DWORD sector, DWORD wait);
DWORD SCRPPrimEraseResSusp(PTEST pT, PDEV pDev, DWORD sector, DWORD wait, DWORD *dstat);
    
#ifdef SIMULATION
int c_test()
#else
int main(int argc, char* argv[])
#endif
{
    DWORD tBank, tSector, tSecAddr;
    DWORD errCode, totalSectors, largeSecSize;
    DWORD totalBanks;
    DWORD i, loop;
    DWORD susp_count;

    linespace(2);
    printf("Test: %s\n", Script);
#ifndef SIMULATION
    SKIP = GetGlobalVar("SKIP");
#endif
    if (SKIP)
    {
        line_space(2);
        printf("Test is skipped\n");
        return __LINE__;
    }
#ifndef SIMULATION
    GetArgEnum("help", &help_only, "YES_NO");
#endif
    if (help_only == YES)
    {
        help();
        return 0;
    }
#ifdef SIMULATION
    pDevice = NewDeviceObject(0, RPC);
#endif
    pDevice = Find_Device(RPC);
    if (!pDevice)
    {
        printf("Error: NOR device not found.\n");
        return (__LINE__);
    }

    printf("Device: %s\n", SCRPGetFAPIInfo(pDevice, DEVICE_NAME));
    SCRPCmdResetFlash(pDevice);
    SYS_GetTimestamp(&t0);

    //SCRPASPUnlock(pDevice);
    errCode = EC_NONE;
    totalBanks = SCRPGetFAPIInfo(pDevice, BANK_COUNT);
    bufSize = SCRPGetFAPIInfo(pDevice, WRITE_BUFFER_SIZE);
    largeSecSize = SCRPGetFAPIInfo(pDevice, LARGEST_SECTOR);
    pData = (WORD *)malloc(sizeof(WORD)*largeSecSize);

    printf("bank %d, buf %d, size %d\n",totalBanks,bufSize,largeSecSize);
    if (!pData)
    {
        printf("Error: malloc()\n");
        return test_exit(__LINE__);
    }

    errCode = GetCommandLineArg();
    if (errCode != EC_NONE)
        return test_exit(__LINE__);

    max_rand_half = (DWORD) GetRAND_MAX() >> 1;
    delay_diff = max_delay - delay;
    for (loop = 1; loop <= cycle; loop++)
    {
        printf("\nLoop = %d, suspend latency %d uSec\n", loop, delay);

        for (tBank = 0; tBank < totalBanks; tBank++)
        {
            printf("\nBank %d\n", tBank);
            if (SYS_CheckUserBreak())
            {
                linespace(2);
                printf("User break\n");
                return test_exit(0);
            }

            // get the first sector number of a bank
            tSecAddr = SCRPGetFAPIGeometry(pDevice, ADDRESS_OF_BANK, tBank);
            tSector = SCRPGetFAPIGeometry(pDevice, SECTOR_FROM_ADDRESS, tSecAddr);
            totalSectors  = SCRPGetFAPIGeometry(pDevice, SECTOR_COUNT_OF_BANK, tBank);
            // Note: do only first and last sectors in a bank
            for (i = 0; i < totalSectors; i = i + totalSectors - 1)
            {
                tSector += i;
                printf("\nTesing sector %d\n", tSector);
                if (SYS_CheckUserBreak())
                {
                    linespace(2);
                    printf("User break\n");
                    return test_exit(0);
                }
                /*
                if (SCRPGetBadSector(pDevice, tSector))
                {
                    printf("Skip Bad Sector: %d\n", tSector);
                    continue;
                }
                */
                printf("Erasing the sector...");
                #ifndef SIMULATION
                ClearDevLog(pDevice);
                #endif
                errCode = SCRPEraseSector(pDevice, tSector, FALSE);
                if (errCode)
                {
                    printf("\nError: %s\n", GetErrorText(errCode));
                    //DumpLog(pDevice, LOG_DISP_NORM);
                    continue;
                }
                else
                    printf("OK\n");

                printf("Erase suspend resume testing...");
                susp_count = 0;
                errCode = EraseSuspendResume(pDevice, tSector, &susp_count);
                if (errCode != EC_NONE)
                {
                    printf("erase suspend count = %d\n", susp_count);
                    return test_exit(__LINE__);
                }
                else
                {
                    printf("OK\n");
                    printf("erase suspend count = %d\n", susp_count);
                }
            } // for (i = 0; i < totalSectors; i++)

        } // for (tBank = 0; tBank < totalBanks; tBank++)

    } // for (loop = 1; ; loop++)

    printf("Test complete\n");
#ifndef SIMULATION
    if (TASK_DELAY)
        SYS_OSTickDelay(TASK_DELAY);
#endif
    return test_exit(0);
} // main()


DWORD EraseSuspendResume(PDEV pDevice, DWORD tSector, DWORD *scount)
{
    DWORD i, j;
    DWORD bw_loop;
    DWORD errCode, status;
    DWORD secAddr, secSize;
    WORD data;
    DWORD rand_delay;

    secAddr = SCRPGetFAPIGeometry(pDevice, ADDRESS_OF_SECTOR, tSector);
    secSize = SCRPGetFAPIGeometry(pDevice, WORD_COUNT_OF_SECTOR, tSector);

    {
        errCode = SYS_CheckUserBreak();
        if (errCode)
        {
            linespace(2);
            printf("User break\n");
            return errCode;
        }
#ifndef SIMULATION
        if (diag == YES) ClearDevLog(pDevice);
#endif
        errCode = SCRPPrimEraseTimedSusp(pTest, pDevice, tSector, susp_delay);
        //errCode = SCRPEraseSuspend(pDevice, tSector, TRUE);
        SYS_WaitUSec(tPSL);
#ifndef SIMULATION
        if (diag == YES)
        {
            linespace(2);
            DumpLog(pDevice, LOG_DISP_NORM);
        }
#endif
        if (errCode != EC_NONE)
        {
            printf("\nError: %s\n", GetErrorText(errCode));
            printf("Address 0x%08X (in Sector %d)\n", secAddr, tSector);
            return errCode;
        }

        do
        {
            rand_delay = rand();
            if (rand_delay > max_rand_half)
                rand_delay = delay + (rand_delay % delay_diff);
            else
                rand_delay = rand_delay % delay;

            if (rand_delay<125) rand_delay = 125;
            *scount = *scount + 1;
            #ifndef SIMULATION
            if (diag == YES) ClearDevLog(pDevice);
            #endif
            errCode = SCRPPrimEraseResSusp(pTest, pDevice, tSector, rand_delay, &status);
            //errCode = SCRPEraseResume(pDevice, tSector);
            SYS_WaitUSec(tPSL);
            if (errCode != EC_NONE)
            {
                printf("Error: %s\n", GetErrorText(errCode));
                return errCode;
            }
            SCRPDeviceStatus(pDevice, secAddr, 0, &status);
#ifndef SIMULATION
            if (diag == YES)
            {
                linespace(2);
                DumpLog(pDevice, LOG_DISP_NORM);
                return EC_USERBREAK;
            }
#endif
//andy        } while (status == NOR_DS_ERASE_SUSPENDED);
        } while ((status & NOR_DS_ERASE_SUSPENDED) == NOR_DS_ERASE_SUSPENDED);

    }

    return EC_NONE;
} // EraseSuspendResume()

void help(void)
{
    linespace(2);
    printf("%s command line arguments\n", Script);
    printf("sd: suspend delay time in usec after buffer write command is issued, default %d\n", susp_delay);
    printf("delay: suspend delay time in usec after buffer write resume, default %d\n", delay);
    printf("max: max delay time in usec after buffer write resume, default %d\n", max_delay);
    printf("cycle: test loop count\n");
    printf("example:\n");
    printf("Tgt1=> - sd=17 delay=30 max=100 cycle=100\n");
    linespace(0);
} // help()

void linespace(DWORD n)
{
    DWORD i;

    for (i = 0; i < n; i++)
        printf("\n");
    printf("*******************************************\n");
} // linespace()

DWORD GetCommandLineArg(void)
{
    DWORD errCount = 0;
#ifndef SIMULATION
    GetArg("sd", &susp_delay);
    GetArg("delay", &delay);
    GetArg("max", &max_delay);
    GetArg("cycle", &cycle);
    GetArgEnum("diag", &diag, "YES_NO");
#endif
    printf("sd = %d usec\n", susp_delay);
    printf("delay = %d usec\n", delay);
    printf("max = %d usec\n", max_delay);
    printf("cycle = %d", cycle);

    if (delay > max_delay)
    {
        printf("Error: delay is greater than max.\n");
        errCount++;
    }

    return EC_NONE;
} // GetCommandLineArg()

DWORD test_exit(DWORD exit_val)
{
    if (pData) free(pData);

    linespace(2);
    SYS_GetTimestamp(&t1);
    FormatDeltaTime(s, &t0, &t1);
    printf("Test time: %s\n", s);

    if (exit_val)
    {
        SetGlobalVar("SKIP", 1);
	printf("<TC> Test =========================== Fail\n");
    }
    else {
      printf("<TC> Test =========================== Pass\n");
    }
    return (exit_val);

} // test_exit()
#ifdef SIMULATION
DWORD SCRPPrimEraseTimedSusp(PTEST pT, PDEV pDev, DWORD sector, DWORD wait)
{
    DWORD errCode;
    if ((errCode = SCRPEraseSector(pDev, sector, FALSE)) != EC_NONE) return errCode;
    SYS_WaitUSec(wait);
    errCode = SCRPEraseSuspend(pDev, sector, TRUE);
    return errCode;
}

DWORD SCRPPrimEraseResSusp(PTEST pT, PDEV pDev, DWORD sector, DWORD wait, DWORD *dstat)
{
    DWORD errCode, status;
    if ((errCode = SCRPEraseResume(pDev, sector)) != EC_NONE) return errCode;
    errCode = SCRPDeviceStatus(pDev, sector, 0, &status);
    if ((status & NOR_DS_BUSY) != NOR_DS_BUSY)
    {
        *dstat = status;
        return errCode;
    }
    SYS_WaitUSec(wait);
    if ((errCode = SCRPEraseSuspend(pDev, sector, FALSE)) != EC_NONE) return errCode;
    errCode = SCRPDeviceStatus(pDev, sector, 0, &status);
    *dstat = status;
    return errCode;
}
#endif
