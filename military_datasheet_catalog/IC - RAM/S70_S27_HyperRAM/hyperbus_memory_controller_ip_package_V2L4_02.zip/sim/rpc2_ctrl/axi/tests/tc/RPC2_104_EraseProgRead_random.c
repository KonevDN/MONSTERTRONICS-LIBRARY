#ifdef SIMULATION
#include "sltapi_sim.h"
#include "svdpi.h"
#include "dpiheader.h"
#include <math.h>
#include "rpc2_vlld.h"
#include "rpc2_llops.h"
#else
#include <sltapi.h>
#endif
#include "rpc2.h"
#ifdef NCSC
extern int io_printf(const char *fmt, ...);
#define printf io_printf
#endif
//
//----------------------------------------------------------------------------------
//  Script: Erase Program and Read test
//  Before running this script, the Include.scp needs to be downloaded first.
//----------------------------------------------------------------------------------
char Script[] = "104_EraseProgRead_random";
char TestTitle[] = "Erase, Program and Read Test";
/* Test Configuration */
#ifdef SIMULATION
SOE = SOE_SETTING;
SKIP = 0;
LOOP_COUNT = 1;
#else
DWORD LOOP_COUNT = 1;
DWORD SOE = SOE_SETTING;
DWORD SKIP = 0;
#endif
DWORD ERASE     = 1;
DWORD PROGRAM   = 1;
DWORD READ_VER  = 1;
DWORD SET_BAD   = 0;
DWORD rv_loop   = 1;

//----------------------------------------------------------------------------------
//NOR Test script begin
//----------------------------------------------------------------------------------
PDEV pDevice;

//DWORD DATAP      =  WORDS_ALT_0X5555_0XAAAA;
//char DATAP_str[] = "WORDS_ALT_0X5555_0XAAAA";

//DWORD DATAP      =  WORDS_ARE_ADDRESS_PLUS_1;
//char DATAP_str[] = "WORDS_ARE_ADDRESS_PLUS_1";

//DWORD DATAP      =  WORDS_ALT_0X55AA_0XAA55;
//char DATAP_str[] = "WORDS_ALT_0X55AA_0XAA55";

//DWORD DATAP      =  WORDS_ARE_0XFFFF;
//char DATAP_str[] = "WORDS_ARE_0XFFFF";

DWORD DATAP      =  WORDS_ARE_RANDOM;
char DATAP_str[] = "WORDS_ARE_RANDOM";

WORD *pSrcData = (WORD *)NULL;
WORD *pDestData = (WORD *)NULL;
WORD *pEraseData = (WORD *)NULL;
STS t0, t1;
char s[81];

void print_buf(WORD * buff, DWORD count);
DWORD BufferWrite(DWORD secAddr, DWORD bufSize, DWORD progSize, WORD *pData);
DWORD ReadData(DWORD SecAddr, DWORD readSize, WORD *pSrcData, WORD *pDestData);
DWORD test_exit(DWORD exit_val);
#ifdef SIMULATION
int c_test()
#else
int main(int argc, char* argv[])
#endif
{
    DWORD tSector, tSecAddr, tSecSize;
    DWORD errCode, totalSectors, bufSize, largeSecSize;
    DWORD i;


    printf("<TC> Test: %s\n", Script);
    printf("<TC>       %s\n", TestTitle);

#ifndef SIMULATION
    SKIP = GetGlobalVar("SKIP");
#endif
    if (SKIP)
    {
        line_space(2);
        printf("Test is skipped\n");
        return __LINE__;
    }

    printf("<TC> ERASE    = %d\n", ERASE);
    printf("<TC> PROGRAM  = %d\n", PROGRAM);
    printf("<TC> READ_VER = %d\n", READ_VER);
    printf("<TC> SET_BAD  = %d\n", SET_BAD);
    printf("<TC> Data Pattern = %s\n", DATAP_str);

#ifdef SIMULATION
    pDevice = NewDeviceObject(0, RPC);
#endif

    pDevice = Find_Device(RPC);
    if (!pDevice)
        return printf("<TC> Error: No device found\n"), __LINE__;
    else
        printf("<TC> Device: %s\n", SCRPGetFAPIInfo(pDevice, DEVICE_NAME));
    SCRPQSPISetWP(pDevice, FALSE);
    printf("<TC> Enable write\n");
    SYS_WaitUSec(300);
    SYS_GetTimestamp(&t0);

#ifdef SIMULATION
    #ifdef TEST_CONFIG
    if(EC_NONE!=test_config())
    {
        printf("Config fail!\n");
        return __LINE__;
    }
    #endif
#endif

    //SCRPCmdResetFlash(pDevice);
    totalSectors = SCRPGetFAPIInfo(pDevice, SECTOR_COUNT);
    bufSize = SCRPGetFAPIInfo(pDevice, WRITE_BUFFER_SIZE);
    largeSecSize = SCRPGetFAPIInfo(pDevice, LARGEST_SECTOR);
    printf("<TC> totalSectors = %d, bufSize = %d, largeSecSize = 0x%08X\n",totalSectors,bufSize,largeSecSize);

    pSrcData = (WORD *) malloc(sizeof(WORD) * largeSecSize);
    pDestData = (WORD *) malloc(sizeof(WORD) * largeSecSize);
    pEraseData = (WORD *) malloc(sizeof(WORD) * largeSecSize);

    if (!pSrcData || !pDestData || !pEraseData)
    {
        printf("<TC> Error: Malloc error\n");
        return test_exit(__LINE__);
    }

#ifndef SIMULATION
    ClearDevLog(pDevice);
#endif
    printf("Initializing buffers - %d words ...\n", largeSecSize);

    if (DATAP == WORDS_ARE_RANDOM)
    {
        srand(100);
        printf("<TC> Random Seed = 100\n");
    }
    FillBuffer(DATAP, pSrcData, largeSecSize);
    print_buf(pSrcData, 256);

    DATAP =  WORDS_ARE_0XFFFF;
    FillBuffer(DATAP, pEraseData, largeSecSize);
    

    for (tSector = 0; tSector < totalSectors; tSector++)
    {
        if (errCode = SYS_CheckUserBreak())
            return test_exit(0);
#ifndef SIMULATION
        //if (SCRPGetBadSector(pDevice, tSector))
        //    continue;
#endif
        tSecAddr  = SCRPGetFAPIGeometry(pDevice, ADDRESS_OF_SECTOR, tSector );
        tSecSize = SCRPGetFAPIGeometry(pDevice, WORD_COUNT_OF_SECTOR, tSector );
	//tSecSize = 16; //wendong

        if (ERASE)
        {
            printf("Erase Sector %d ...\n", tSector);
            errCode = SCRPEraseSector(pDevice, tSector, TRUE);
            if (errCode != EC_NONE)
            {
                printf("<TC> Error: sector %04d %s\n", tSector, GetErrorText(errCode));
#ifndef SIMULATION
                OutputLog(pDevice, LOG_DISP_NORM, 0, -10);
                //if (SET_BAD)
                //    SCRPSetBadSector(pDevice, tSector);
#endif
                if (SOE)
                    return test_exit(__LINE__);
                else
                    continue;
            }
	    printf("<TC> EraseSector =============== Completed\n");


	    errCode = ReadData(tSecAddr, tSecSize, pEraseData, pDestData);
	    if (errCode == EC_USERBREAK) {
	      printf("<TC> Test ends with EC_USERBREAK\n");
	      return test_exit(__LINE__);
	    }
	    if (errCode != EC_NONE)
	      {
		if (SOE) {
		  printf("<TC> Test ends with !EC_NONE\n");
		  return test_exit(__LINE__);
		}
	      }
	    printf("<TC> EraseSector =============== Verified and Passed\n");
        } // Erase sectors
	
        if (PROGRAM)
        {
            printf("<TC> Program sector %d ...\n", tSector);

	    //tSecSize = 8*1024;
            errCode = SCRPWriteArray(pDevice, pSrcData, tSecAddr, tSecSize, TRUE, TRUE);
            //errCode = SCRPWriteArray(pDevice, pSrcData, tSecAddr, tSecSize, TRUE, FALSE);
            if (errCode != EC_NONE)
            {
#ifndef SIMULATION
                printf("<TC> Error: sector %04d %s\n", tSector, GetErrorText(errCode));
                OutputLog(pDevice, LOG_DISP_NORM, 0, -20);
                //if (SET_BAD)
                //    SCRPSetBadSector(pDevice, tSector);
#endif
                if (SOE)
                    return test_exit(__LINE__);
                else
                    continue;
            }
	    printf("<TC> Program Sector =============== Completed\n");
        } // Program sectors

        // Read-verify
        if (READ_VER)
        {
            for (i = 0; i < rv_loop; i++)
            {
	      //tSecSize = 8*1024;
                errCode = ReadData(tSecAddr, tSecSize, pSrcData, pDestData);
                if (errCode == EC_USERBREAK) {
		  printf("<TC> Test ends with EC_USERBREAK\n");
		  return test_exit(__LINE__);
		}

                if (errCode != EC_NONE)
                {
#ifndef SIMULATION
		  //if (SET_BAD)
                  //      SCRPSetBadSector(pDevice, tSector);
#endif
                    if (SOE) {
		      printf("<TC> Test ends with !EC_NONE\n");
                        return test_exit(__LINE__);
		    }
                }
            } //for (i = 0; i < rv_loop; i++)
	    printf("<TC> Read Verify =============== Completed and Passed\n");
        } // Read-verify
	
    } // for (tSector = 0; tSector < totalSectors; tSector++)

    printf("<TC> Test complete\n");
#ifndef SIMULATION
    if (TASK_DELAY)
        SYS_OSTickDelay(TASK_DELAY);
#endif
    return test_exit(0);
} // main()

void print_buf(WORD * buff, DWORD count)
{
    DWORD i;

    for (i = 0; i < count; i++)
    {
        if ((i % 8) == 0) printf("\n0x%08X ", i);
        printf("%04X ", buff[i]);
    }
    printf("\n");
} // printf_buf()

DWORD BufferWrite(DWORD secAddr, DWORD bufSize, DWORD progSize, WORD *pData)
{
    DWORD errCode;

    errCode = SCRPWriteArray(pDevice, pData, secAddr, progSize, TRUE, TRUE);
    if (errCode != EC_NONE)
        printf("<TC> Error: %s\n", GetErrorText(errCode));

    return errCode;
} // BufferWrite()

DWORD ReadData(DWORD SecAddr, DWORD readSize, WORD *pSrcData, WORD *pDestData)
{
    DWORD errCode, i, j;
    //DWORD readAddr;

    errCode = EC_NONE;
    printf("<TC> Read on address 0x%08X with length of 0x%08X\n", SecAddr, readSize);

    //readSize = 1024; //wendong
    if ((errCode = SCRPReadArray(pDevice, pDestData, SecAddr, readSize)) != EC_NONE){
      printf("<TC> Error: %s\n", GetErrorText(errCode));
      return(errCode);
    }

    //SCRPReadArray(pDevice, pDestData, SecAddr, readSize);
    //SCRPReadArray(pDevice, pDestData, SecAddr, readSize);
    //SCRPReadArray(pDevice, pDestData, SecAddr, readSize);
    //SCRPReadArray(pDevice, pDestData, SecAddr, readSize);
    //
    //
    // The following codes might be able to detect device read issue
    //readAddr = SecAddr;
    //for (i = 0; i < readSize; i++)
    //{
    //    pDestData[i] = SCRPRead(pDevice, readAddr);
    //    pDestData[i] = SCRPRead(pDevice, readAddr);
    //    pDestData[i] = SCRPRead(pDevice, readAddr);
    //    pDestData[i] = SCRPRead(pDevice, readAddr++);
    //}

    if (memcmp(pSrcData, pDestData, sizeof(WORD) * readSize))
    {
        for (i = 0, j = 0; i < readSize; i++)
        {
            if (pSrcData[i] != pDestData[i])
            {
                printf("<TC> Error: addr 0x%08X, read 0x%04X, expect 0x%04X\n", SecAddr + i, pDestData[i], pSrcData[i]);
                j++;
                if (errCode = SYS_CheckUserBreak())
                {
                    return errCode;
                }
            }

            // Remove the following codes to show all errors
            if (j > 20)
            {
                printf("<TC> too many errors...\n");
                break;
            }
        } // for (i = 0; i < readSize; i++)

        errCode = EC_READDATA;

    } // if (memcmp(pSrcData, pDestData, sizeof(WORD) * readSize))
    else {
      printf("<TC> Read Data and Verify ===== OK\n");
      //print_buf(pDestData, readSize);
    }

    return(errCode);
} // ReadData()

DWORD test_exit(DWORD exit_val)
{

    if (pSrcData)
        free(pSrcData);

    if (pDestData)
        free(pDestData);

    if (pEraseData)
        free(pEraseData);

    SYS_GetTimestamp(&t1);
    FormatDeltaTime(s, &t0, &t1);
    printf("<TC> Test time: %s\n", s);

    if (exit_val)
    {
        SetGlobalVar("SKIP", 1);
	printf("<TC> Test =========================== Fail\n");
    }
    else {
      printf("<TC> Test =========================== Pass\n");
    }

    return (exit_val);
} // test_exit()
