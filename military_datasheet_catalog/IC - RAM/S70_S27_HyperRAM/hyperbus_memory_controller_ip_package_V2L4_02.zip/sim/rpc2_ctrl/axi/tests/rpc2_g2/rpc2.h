#ifndef __RPC_HEADER
#define __RPC_HEADER

// SLT global variables
int LOOP_COUNT;
int ERASE_RS;
int PROG_RS;
int SOE;
int SKIP;
int TOTALSECTORS;
int BEGINSECTOR;
int ENDSECTOR;
int BUFSIZE;
int LARGESECSIZE;
int SPICLOCK;              //MHz
int READMODE;
int ADDRMODE;
int WRITEMODE;
int DATAPATTERN;
int TESL;
int TERS;
int TSE;            // sector erase time (msec)
int TPSL;
int TPRS;
int TPP;            // page program time (usec)
int TBE;            // bulk erase time (sec)
int TRP;            // register program time (usec)
int OTP_LR1;
int OTP_LR2;
int OTP_LR3;
int OTP_PR1;
int OTP_PR2;
int OTP_PR3;
// New for RPC
int sel_die0;
int sel_die1;
int sel_die2;
int sel_die3;
int wram_addr;
int rdram_addr;
int direct_mode;
int slt_mode;
int loopbk_mode;
int burst_mode;
int latency;
int rpc_flash_burst_len;
int drive_strength;
//DWORD rpc_clk;
DWORD MAX_POLLLING_CNT = 80000;

struct OTP_REG0
{
    unsigned char otp_matecode[16];
    unsigned char otp_reglock[4];
    unsigned char otp_rsv[12];
};

// OTP area
#if 0
#define OTP_SIZE            8192  // bytes
#define OTP_REG_SIZE        256    // bytes
#define OTP_REG_CNT         32    // count of region
#else
#define OTP_SIZE            1024  // bytes
#define OTP_REG_SIZE        256    // bytes
#define OTP_REG_CNT         4    // count of region
#endif
#define OTP_CONTROL_REG     0
#define OTP_LOCK_REG1       2
#define OTP_LOCK_REG2       4
#define OTP_LOCK_REG3       6
#define OTP_PROG_REG1       1
#define OTP_PROG_REG2       2
#define OTP_PROG_REG3       3

/*
struct Enum Enum_Table[] = {
     {"NO", NO},
     {"Yes", YES},
     {"no", no},
     {"yes", yes},
     {"BYTES_ARE_0X00", BYTES_ARE_0X00},
     {"BYTES_ARE_0X55", BYTES_ARE_0X55},
     {"BYTES_ARE_0XAA", BYTES_ARE_0XAA},
     {"BYTES_ARE_0XFF", BYTES_ARE_0XFF},
     {"BYTES_ARE_0XFE", BYTES_ARE_0XFE},
     {"BYTES_ALT_0X00_0XFF", BYTES_ALT_0X00_0XFF},
     {"BYTES_ALT_0X55_0XAA", BYTES_ALT_0X55_0XAA},
     {"BYTES_ALT_0XAA_0X55", BYTES_ALT_0XAA_0X55},
     {"BYTES_ALT_0XFF_0X00", BYTES_ALT_0XFF_0X00},
     {"BYTES_ARE_ADDRESSES", BYTES_ARE_ADDRESSES},
     {"BYTES_ARE_ADDRESSES_PLUS_1", BYTES_ARE_ADDRESSES_PLUS_1},
     {"BYTES_ARE_RANDOM", BYTES_ARE_RANDOM},
     {"WORDS_ARE_0X0000", WORDS_ARE_0X0000},
     {"WORDS_ARE_0X5555", WORDS_ARE_0X5555},
     {"WORDS_ARE_0XAAAA", WORDS_ARE_0XAAAA},
     {"WORDS_ARE_0XFFFF", WORDS_ARE_0XFFFF},
     {"WORDS_ARE_0XFFFE", WORDS_ARE_0XFFFE},
     {"WORDS_ALT_0X0000_0XFFFF", WORDS_ALT_0X0000_0XFFFF},
     {"WORDS_ALT_0X00FF_0XFF00", WORDS_ALT_0X00FF_0XFF00},
     {"WORDS_ALT_0X5555_0XAAAA", WORDS_ALT_0X5555_0XAAAA},
     {"WORDS_ALT_0X55AA_0XAA55", WORDS_ALT_0X55AA_0XAA55},
     {"WORDS_ALT_0XAA55_0X55AA", WORDS_ALT_0XAA55_0X55AA},
     {"WORDS_ALT_0XAAAA_0X5555", WORDS_ALT_0XAAAA_0X5555},
     {"WORDS_ALT_0XFF00_0X00FF", WORDS_ALT_0XFF00_0X00FF},
     {"WORDS_ALT_0XFFFF_0X0000", WORDS_ALT_0XFFFF_0X0000},
     {"WORDS_ALT_4_OF_0X0000_4_OF_0XFFFF", WORDS_ALT_4_OF_0X0000_4_OF_0XFFFF},
     {"WORDS_ALT_4_OF_0XFFFF_4_OF_0X0000", WORDS_ALT_4_OF_0XFFFF_4_OF_0X0000},
     {"WORDS_ALT_8_OF_0X0000_8_OF_0XFFFF", WORDS_ALT_8_OF_0X0000_8_OF_0XFFFF},
     {"WORDS_ALT_8_OF_0XFFFF_8_OF_0X0000", WORDS_ALT_8_OF_0XFFFF_8_OF_0X0000},
     {"WORDS_ALT_8_OF_0XFF00_0X00FF_N_8_OF_0XFFFF", WORDS_ALT_8_OF_0XFF00_0X00FF_N_8_OF_0XFFFF},
     {"WORDS_ARE_ADDRESSES", WORDS_ARE_ADDRESSES},
     {"WORDS_ARE_ADDRESS_PLUS_1", WORDS_ARE_ADDRESS_PLUS_1},
     {"WORDS_ARE_ADDRESS_AND_0XFF", WORDS_ARE_ADDRESS_AND_0XFF},
     {"WORDS_ARE_RANDOM", WORDS_ARE_RANDOM},
     {"WORDS_ARE_CKBD", WORDS_ARE_CKBD},
     {0,0}
};
*/
//Buffers for RPC
#define RPC_BUF_SIZE 2048
#define GPMC_BURST_LEN 16

WORD die0_readbuf[RPC_BUF_SIZE];//read data when IWSR selects lane0
WORD die1_readbuf[RPC_BUF_SIZE]; //read data when IWSR selects lane1
WORD die2_readbuf[RPC_BUF_SIZE]; //read data when IWSR selects lane2
WORD die3_readbuf[RPC_BUF_SIZE]; //read data when IWSR selects lane3
// 4K each

//User should be able to read this buffer from TC

WORD die0_wrbuf[RPC_BUF_SIZE];//read data when IWSR selects lane0
WORD die1_wrbuf[RPC_BUF_SIZE]; //read data when IWSR selects lane1
WORD die2_wrbuf[RPC_BUF_SIZE]; //read data when IWSR selects lane2
WORD die3_wrbuf[RPC_BUF_SIZE]; //read data when IWSR selects lane3
// 4K each

//User should be able to read this buffer from TC

//Use of pbuf from G2 is only for Programming Data

DWORD rpc_mode_init(int slt_mode, int direct_mode, int loopbk_mode, int burst_mode);
DWORD rpc_flash_init(int latency, int rpc_flash_burst_len, int drive_strength);
DWORD rpc_ctrl_init(void);
DWORD rpc_ctrl_init_4die(void);
DWORD test_config(void);
#endif /* ifndef RPC_HEADER */
