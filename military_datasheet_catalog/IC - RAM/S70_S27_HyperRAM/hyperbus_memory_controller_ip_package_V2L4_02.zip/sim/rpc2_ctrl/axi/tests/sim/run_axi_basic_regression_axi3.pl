#!/usr/bin/perl

$data_pattern = "";
#$data_pattern = "-DPATTERN=2";

$log_dir = "logs";
$log_axi_reg_file   = "rpc2_ctrl_axi3_reg";
$log_axi_file   = "rpc2_ctrl_axi3_mem";
$log_basic_file = "rpc2_ctrl_basic_axi3";
$log_dev_type_flash[0] = "_2cs_flash";
$log_dev_type_psram[0] = "_2cs_psram";
$log_dev_type_psram[1] = "_cs0_psram";
$log_dev_type_psram[2] = "_cs1_psram";
$log_axi_basic_result_file = "rpc2_ctrl_axi3_basic_test_result";

if (!(-d $log_dir)) {
  system "mkdir $log_dir";
  printf "Create $log_dir directory\n";
}
else {
  # Delete log files
  system "rm $log_dir/*";
  printf "Delete log files\n";
}

$arg_axi_reg_file[0]     = "rpc2_ctrl_axi3_reg_sysw.f";
$arg_axi_file_flash[0]   = "rpc2_ctrl_axi3_sysw.f";
$arg_axi_file_psram[0]   = "rpc2_ctrl_axi3_psram_sysw.f";
$arg_basic_file_flash[0] = "rpc2_ctrl_basic_axi3_sysw.f";
$arg_basic_file_psram[0] = "rpc2_ctrl_basic_axi3_psram_sysw.f";
$arg_basic_file_psram[1] = "rpc2_ctrl_basic_axi3_psram_cs0_sysw_2cs.f";
$arg_basic_file_psram[2] = "rpc2_ctrl_basic_axi3_psram_cs1_sysw_2cs.f";
if (@ARGV[0] eq "-cdn") {
  $arg_axi_reg_file[0]     = "rpc2_ctrl_axi3_reg_cdn.f";
  $arg_axi_file_flash[0]   = "rpc2_ctrl_axi3_cdn.f";
  $arg_axi_file_psram[0]   = "rpc2_ctrl_axi3_psram_cdn.f";
  $arg_basic_file_flash[0] = "rpc2_ctrl_basic_axi3_cdn.f";
  $arg_basic_file_psram[0] = "rpc2_ctrl_basic_axi3_psram_cdn.f";
  $arg_basic_file_psram[1] = "rpc2_ctrl_basic_axi3_psram_cs0_cdn_2cs.f";
  $arg_basic_file_psram[2] = "rpc2_ctrl_basic_axi3_psram_cs1_cdn_2cs.f";
}

@axi_aclk_period_reg = (4);

@axi_ck_period_flash = (6);
@axi_ck_period_psram = (6);
@axi_ck2_period_flash = (7.5);
@axi_ck2_period_psram = (7.5);
@axi_aclk_period_flash_ck = ([4]);
@axi_aclk_period_psram_ck = ([4]);
@axi_aclk_period_flash_ck2 = ([5]);
@axi_aclk_period_psram_ck2 = ([5]);

@basic_ck_period_flash = (6, 166);
@basic_ck_period_psram = (6, 12);
@basic_ck2_period_flash = (7.5, 166);
@basic_ck2_period_psram = (7.5, 12);
@basic_aclk_period_flash_ck = (
                        [2.5, 4, 10], 
                        [62.5, 100, 250],
                              );
@basic_aclk_period_flash_ck2 = (
                        [3, 5, 12], 
                        [62.5, 100, 250],
                               );
@basic_aclk_period_psram_ck = (
                        [2.5, 4, 10], 
                        [5, 10, 20],
                              );
@basic_aclk_period_psram_ck2 = (
                        [3, 5, 12], 
                        [5, 10, 20],
                              );
@axi_id_width = (4, 8, 14);
@cs_sel = (0, 1);

$option_axi_reg[0] = "";

$option_axi[0] = "";

$option_basic_flash[0] = "";
$option_basic_flash[1] = "-DRSTO -define RSTO";
$option_basic_psram[0] = "";

# AXI REGISTER TEST
$i = 0;
foreach $axi (@arg_axi_reg_file) {
  foreach $axi_id (@axi_id_width) {
    foreach $aclk (@axi_aclk_period_reg) {
      foreach $opt (@option_axi_reg) {
        $command  = "irun -f $axi $opt $data_pattern ";
        $command .= "-DAXI_ID_WIDTH=$axi_id ";
        $command .= "-define AXI_ID_WIDTH=$axi_id ";
        $command .= "-l $log_dir/" . $log_axi_reg_file . "_AXI_ID=$axi_id";
        $command .= "_ACLK=$aclk" . "_$i" . ".log";
        print $command . "\n";
        system $command;
      }
    }
  }
  $i++;
}

# AXI TEST (Flash)
for ( $ck_sel = 0; $ck_sel < 2; $ck_sel++ ) {
  $i = 0;
  foreach $axi (@arg_axi_file_flash) {
    if ($ck_sel == 0) {
      $ck_period = \@axi_ck_period_flash;
      $aclk_period = \@axi_aclk_period_flash_ck;
    } elsif ($ck_sel == 1) {
      $ck_period = \@axi_ck2_period_flash;
      $aclk_period = \@axi_aclk_period_flash_ck2;
    }
    $ck_pattern = @{$ck_period};
    foreach $cs (@cs_sel) {
      foreach $axi_id (@axi_id_width) {
        for ( $ck = 0; $ck < $ck_pattern; $ck++ ) {
          foreach $aclk (@{$aclk_period->[$ck]}) {
            $j = 0;
            foreach $opt (@option_axi) {
              $command  = "irun -f $axi $opt $data_pattern ";
              if ($ck_sel == 1) {
                $command .= "-define CK2 ";
              }
              $command .= "-DCS$cs" . "_ENABLED ";
              $command .= "-DAXI_ID_WIDTH=$axi_id ";
              $command .= "-define AXI_ID_WIDTH=$axi_id ";
              $command .= "-define CLK_PERIOD=$ck_period->[$ck] ";
              $command .= "-define ACLK_PERIOD=$aclk ";
              $command .= "-l $log_dir/" . $log_axi_file . $log_dev_type_flash[$i];
              if ($ck_sel == 1) {
                $command .= "_CK2";
              }
              $command .= "_CS=$cs" . "_AXI_ID=$axi_id";
              $command .= "_CK=$ck_period->[$ck]" . "_ACLK=$aclk";
              $command .= "_$j" . ".log";
              print $command . "\n";
              system $command;
              $j++;
            }
          }
        }
      }
    }
    $i++;
  }
}

# AXI TEST (PSRAM)
for ( $ck_sel = 0; $ck_sel < 2; $ck_sel++ ) {
  $i = 0;
  foreach $axi (@arg_axi_file_psram) {
    if ($ck_sel == 0) {
      $ck_period = \@axi_ck_period_psram;
      $aclk_period = \@axi_aclk_period_psram_ck;
    } elsif ($ck_sel == 1) {
      $ck_period = \@axi_ck2_period_psram;
      $aclk_period = \@axi_aclk_period_psram_ck2;
    }
    $ck_pattern = @{$ck_period};
    foreach $cs (@cs_sel) {
      foreach $axi_id (@axi_id_width) {
        for ( $ck = 0; $ck < $ck_pattern; $ck++ ) {
          foreach $aclk (@{$aclk_period->[$ck]}) {
            $j = 0;
            foreach $opt (@option_axi) {
              $command  = "irun -f $axi $opt $data_pattern ";
              if ($ck_sel == 1) {
                $command .= "-define CK2 ";
              }
              $command .= "-DCS$cs" . "_ENABLED ";
              $command .= "-DAXI_ID_WIDTH=$axi_id ";
              $command .= "-define AXI_ID_WIDTH=$axi_id ";
              $command .= "-define CLK_PERIOD=$ck_period->[$ck] ";
              $command .= "-define ACLK_PERIOD=$aclk ";
              $command .= "-l $log_dir/" . $log_axi_file . $log_dev_type_psram[$i];
              if ($ck_sel == 1) {
                $command .= "_CK2";
              }
              $command .= "_CS=$cs" . "_AXI_ID=$axi_id";
              $command .= "_CK=$ck_period->[$ck]" . "_ACLK=$aclk";
              $command .= "_$j" . ".log";
              print $command . "\n";
              system $command;
              $j++;
            }
          }
        }
      }
    }
    $i++;
  }
}

# BASIC TEST (Flash)
for ( $ck_sel = 0; $ck_sel < 2; $ck_sel++ ) {
  $i = 0;
  foreach $basic (@arg_basic_file_flash) {
    if ($ck_sel == 0) {
      $ck_period = \@basic_ck_period_flash;
      $aclk_period = \@basic_aclk_period_flash_ck;
    } elsif ($ck_sel == 1) {
      $ck_period = \@basic_ck2_period_flash;
      $aclk_period = \@basic_aclk_period_flash_ck2;
    }
    $ck_pattern = @{$ck_period};
    foreach $cs (@cs_sel) {
      foreach $axi_id (@axi_id_width) {
        for ( $ck = 0; $ck < $ck_pattern; $ck++ ) {
          foreach $aclk (@{$aclk_period->[$ck]}) {
            $j = 0;
            foreach $opt (@option_basic_flash) {
              if (($j == 1) && ($aclk >= 166)) {
                next;
              }
              $command  = "irun -f $basic $opt $data_pattern ";
              if ($ck_sel == 1) {
                $command .= "-define CK2 ";
              }
              $command .= "-DCS$cs" . "_ENABLED ";
              $command .= "-DAXI_ID_WIDTH=$axi_id ";
              $command .= "-define AXI_ID_WIDTH=$axi_id ";
              $command .= "-define CLK_PERIOD=$ck_period->[$ck] ";
              $command .= "-define ACLK_PERIOD=$aclk ";
              $command .= "-l $log_dir/" . $log_basic_file . $log_dev_type_flash[$i];
              if ($ck_sel == 1) {
                $command .= "_CK2";
              }
              $command .= "_CS=$cs" . "_AXI_ID=$axi_id";
              $command .= "_CK=$ck_period->[$ck]" . "_ACLK=$aclk";
              $command .= "_$j" . ".log";
              print $command . "\n";
              system $command;
              $j++;
            }
          }
        }
      }
    }
    $i++;
  }
}

# BASIC TEST (PSRAM)
for ( $ck_sel = 0; $ck_sel < 2; $ck_sel++ ) {
  $i = 0;
  foreach $basic (@arg_basic_file_psram) {
    if ($ck_sel == 0) {
      $ck_period = \@basic_ck_period_psram;
      $aclk_period = \@basic_aclk_period_psram_ck;
    } elsif ($ck_sel == 1) {
      $ck_period = \@basic_ck2_period_psram;
      $aclk_period = \@basic_aclk_period_psram_ck2;
    }
    $ck_pattern = @{$ck_period};
    foreach $cs (@cs_sel) {
      foreach $axi_id (@axi_id_width) {
        for ( $ck = 0; $ck < $ck_pattern; $ck++ ) {
          foreach $aclk (@{$aclk_period->[$ck]}) {
            $j = 0;
            foreach $opt (@option_basic_psram) {
              $command  = "irun -f $basic $opt $data_pattern ";
              if ($ck_sel == 1) {
                $command .= "-define CK2 ";
              }
              $command .= "-DCS$cs" . "_ENABLED ";
              $command .= "-DAXI_ID_WIDTH=$axi_id ";
              if ($i > 0) {
                $command .= "-DONLY_2CS_TC ";
              }
              $command .= "-define AXI_ID_WIDTH=$axi_id ";
              $command .= "-define CLK_PERIOD=$ck_period->[$ck] ";
              $command .= "-define ACLK_PERIOD=$aclk ";
              $command .= "-l $log_dir/" . $log_basic_file . $log_dev_type_psram[$i];
              if ($ck_sel == 1) {
                $command .= "_CK2";
              }
              $command .= "_CS=$cs" . "_AXI_ID=$axi_id";
              $command .= "_CK=$ck_period->[$ck]" . "_ACLK=$aclk";
              $command .= "_$j" . ".log";
              print $command . "\n";
              system $command;
              $j++;
            }
          }
        }
      }
    }
    $i++;
  }
}

# DISPLAY
open (log_result_handle, ">$log_dir/$log_axi_basic_result_file" . ".log");
$i = 0;
foreach $axi (@arg_axi_reg_file) {
  foreach $axi_id (@axi_id_width) {
    foreach $aclk (@axi_aclk_period_reg) {
      foreach $opt (@option_axi_reg) {
        $log_name = $log_axi_reg_file . "_AXI_ID=$axi_id";
        $log_name .= "_ACLK=$aclk" . "_$i" . ".log";
        open(log_handle, "$log_dir/" . $log_name);
        $result = "UNDO";
        while (<log_handle>) {
          if ($_ =~ "FAIL") {
            $result = "FAIL"; last;
          }
          if ($_ =~ "PASS") {
            $result = "PASS";
          }
        }
        close(log_handle);
        print $log_name . " => " . $result . "\n";
        print log_result_handle $log_name . " => " . $result . "\n";
      }
    }
  }
  $i++;
}

for ( $ck_sel = 0; $ck_sel < 2; $ck_sel++ ) {
  $i = 0;
  foreach $axi (@arg_axi_file_flash) {
    if ($ck_sel == 0) {
      $ck_period = \@axi_ck_period_flash;
      $aclk_period = \@axi_aclk_period_flash_ck;
    } elsif ($ck_sel == 1) {
      $ck_period = \@axi_ck2_period_flash;
      $aclk_period = \@axi_aclk_period_flash_ck2;
    }
    $ck_pattern = @{$ck_period};
    foreach $cs (@cs_sel) {
      foreach $axi_id (@axi_id_width) {
        for ( $ck = 0; $ck < $ck_pattern; $ck++ ) {
          foreach $aclk (@{$aclk_period->[$ck]}) {
            $j = 0;
            foreach $opt (@option_axi) {
              $log_name = $log_axi_file . $log_dev_type_flash[$i];
              if ($ck_sel == 1) {
                $log_name .= "_CK2";
              }
              $log_name .= "_CS=$cs" . "_AXI_ID=$axi_id";
              $log_name .= "_CK=$ck_period->[$ck]" . "_ACLK=$aclk";
              $log_name .= "_$j" . ".log";
              open(log_handle, "$log_dir/" . $log_name);
              $result = "UNDO";
              while (<log_handle>) {
                if ($_ =~ "FAIL") {
                  $result = "FAIL"; last;
                }
                if ($_ =~ "PASS") {
                  $result = "PASS";
                }
              }
              close(log_handle);
              print $log_name . " => " . $result . "\n";
              print log_result_handle $log_name . " => " . $result . "\n";
            }
          }
        }
      }
    }
    $i++;
  }
}

for ( $ck_sel = 0; $ck_sel < 2; $ck_sel++ ) {
  $i = 0;
  foreach $axi (@arg_axi_file_psram) {
    if ($ck_sel == 0) {
      $ck_period = \@axi_ck_period_psram;
      $aclk_period = \@axi_aclk_period_psram_ck;
    } elsif ($ck_sel == 1) {
      $ck_period = \@axi_ck2_period_psram;
      $aclk_period = \@axi_aclk_period_psram_ck2;
    }
    $ck_pattern = @{$ck_period};
    foreach $cs (@cs_sel) {
      foreach $axi_id (@axi_id_width) {
        for ( $ck = 0; $ck < $ck_pattern; $ck++ ) {
          foreach $aclk (@{$aclk_period->[$ck]}) {
            $j = 0;
            foreach $opt (@option_axi) {
              $log_name = $log_axi_file . $log_dev_type_psram[$i];
              if ($ck_sel == 1) {
                $log_name .= "_CK2";
              }
              $log_name .= "_CS=$cs" . "_AXI_ID=$axi_id";
              $log_name .= "_CK=$ck_period->[$ck]" . "_ACLK=$aclk";
              $log_name .= "_$j" . ".log";
              open(log_handle, "$log_dir/" . $log_name);
              $result = "UNDO";
              while (<log_handle>) {
                if ($_ =~ "FAIL") {
                  $result = "FAIL"; last;
                }
                if ($_ =~ "PASS") {
                  $result = "PASS";
                }
              }
              close(log_handle);
              print $log_name . " => " . $result . "\n";
              print log_result_handle $log_name . " => " . $result . "\n";
            }
          }
        }
      }
    }
    $i++;
  }
}

for ( $ck_sel = 0; $ck_sel < 2; $ck_sel++ ) {
  $i = 0;
  foreach $basic (@arg_basic_file_flash) {
    if ($ck_sel == 0) {
      $ck_period = \@basic_ck_period_flash;
      $aclk_period = \@basic_aclk_period_flash_ck;
    } elsif ($ck_sel == 1) {
      $ck_period = \@basic_ck2_period_flash;
      $aclk_period = \@basic_aclk_period_flash_ck2;
    }
    $ck_pattern = @{$ck_period};
    foreach $cs (@cs_sel) {
      foreach $axi_id (@axi_id_width) {
        for ( $ck = 0; $ck < $ck_pattern; $ck++ ) {
          foreach $aclk (@{$aclk_period->[$ck]}) {
            $j = 0;
            foreach $opt (@option_basic_flash) {
              if (($j == 1) && ($aclk >= 166)) {
                next;
              }
              $log_name = $log_basic_file . $log_dev_type_flash[$i];
              if ($ck_sel == 1) {
                $log_name .= "_CK2";
              }
              $log_name .= "_CS=$cs" . "_AXI_ID=$axi_id";
              $log_name .= "_CK=$ck_period->[$ck]" . "_ACLK=$aclk";
              $log_name .= "_$j" . ".log";
              open(log_handle, "$log_dir/" . $log_name);
              $result = "UNDO";
              while (<log_handle>) {
                if ($_ =~ "FAIL") {
                  $result = "FAIL"; last;
                }
                if ($_ =~ "PASS") {
                  $result = "PASS";
                }
              }
              close(log_handle);
              print $log_name . " => " . $result . "\n";
              print log_result_handle $log_name . " => " . $result . "\n";
              $j++;
            }
          }
        }
      }
    }
    $i++;
  }
}

for ( $ck_sel = 0; $ck_sel < 2; $ck_sel++ ) {
  $i = 0;
  foreach $basic (@arg_basic_file_psram) {
    if ($ck_sel == 0) {
      $ck_period = \@basic_ck_period_psram;
      $aclk_period = \@basic_aclk_period_psram_ck;
    } elsif ($ck_sel == 1) {
      $ck_period = \@basic_ck2_period_psram;
      $aclk_period = \@basic_aclk_period_psram_ck2;
    }
    $ck_pattern = @{$ck_period};
    foreach $cs (@cs_sel) {
      foreach $axi_id (@axi_id_width) {
        for ( $ck = 0; $ck < $ck_pattern; $ck++ ) {
          foreach $aclk (@{$aclk_period->[$ck]}) {
            $j = 0;
            foreach $opt (@option_basic_psram) {
              $log_name = $log_basic_file . $log_dev_type_psram[$i];
              if ($ck_sel == 1) {
                $log_name .= "_CK2";
              }
              $log_name .= "_CS=$cs" . "_AXI_ID=$axi_id";
              $log_name .= "_CK=$ck_period->[$ck]" . "_ACLK=$aclk";
              $log_name .= "_$j" . ".log";
              open(log_handle, "$log_dir/" . $log_name);
              $result = "UNDO";
              while (<log_handle>) {
                if ($_ =~ "FAIL") {
                  $result = "FAIL"; last;
                }
                if ($_ =~ "PASS") {
                  $result = "PASS";
                }
              }
              close(log_handle);
              print $log_name . " => " . $result . "\n";
              print log_result_handle $log_name . " => " . $result . "\n";
              $j++;
            }
          }
        }
      }
    }
    $i++;
  }
}
close (log_result_handle);
