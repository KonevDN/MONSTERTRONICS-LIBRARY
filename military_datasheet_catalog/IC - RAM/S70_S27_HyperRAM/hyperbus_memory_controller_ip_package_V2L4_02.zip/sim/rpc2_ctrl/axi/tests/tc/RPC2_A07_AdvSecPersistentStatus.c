#ifdef SIMULATION
#include "sltapi_sim.h"
#include "svdpi.h"
#include "dpiheader.h"
#include <math.h>
#include "rpc2_vlld.h"
#include "rpc2_llops.h"
#else
#include <sltapi.h>
#endif
#include "rpc2.h"
#ifdef NCSC
extern int io_printf(const char *fmt, ...);
#define printf io_printf
#endif

//----------------------------------------------------------------------------------
// 	Script: Advanced Sector Persistent Protection Status test
//  Before running this script, the Include.scp needs to be downloaded first.
//----------------------------------------------------------------------------------

enum
{
	CLEARPPBL,
	SETPPBL,
	SCRPPAGESIZE = 8
};

PDEV pDevice;

DWORD SendTestPassword ( PDEV dev)
{
	DWORD   i, errCode, bitPPBL;
	WORD    testPwd [4];

    for (i = 0; i < 4; i++)
        testPwd[i] = 0;
    testPwd[0] = 0x1111;
    testPwd[1] = 0x2222;
    testPwd[2] = 0x3333;
    testPwd[3] = 0x4444;

    printf("Send password clears PPBL\n");
	errCode = SCRPSendPassword( dev, testPwd);

        /* If PPB Lock bit still set, the password did not work.    */
	if ( errCode == EC_NONE )
	{
		SCRPGetASPFunc( dev, ASP_PPBL, 0, &bitPPBL );
		if ( bitPPBL )
			errCode = EC_PPBLSET;
		else
            printf("PPBL is cleared\n");
	}

	return( errCode );
}

DWORD tVerifyProtectionOff(PDEV dev, DWORD chkPPBL)
{
    DWORD errCode, errCode1, errCode2, errCode3, i;
	DWORD secAddr, totalSectors, ASPBit;
	
	totalSectors = SCRPGetFAPIInfo(dev, SECTOR_COUNT);
    errCode1 = EC_NONE;
    for (i = 0; i < totalSectors; i++)
    {
        secAddr = SCRPGetFAPIGeometry(dev, ADDRESS_OF_SECTOR, i);
        SCRPGetASPFunc(dev, ASP_DYB, secAddr, &ASPBit);
        if (ASPBit)
        {
            printf("DYB ON in sector %d\n", i);
            errCode1 = EC_DYBSTATE;
            //break;
        }
    }
    if (errCode1)
        printf("Error: %s\n", GetErrorText(errCode1));
    else
        printf("DYB OFF in all sectors\n");

    errCode2 = EC_NONE;
	for (i = 0; i < totalSectors; i++)
	{
		secAddr = SCRPGetFAPIGeometry(dev, ADDRESS_OF_SECTOR, i);
		SCRPGetASPFunc(dev, ASP_PPB, secAddr, &ASPBit);
		if (ASPBit)
		{
			printf("PPB ON in sector %d\n", i);
            errCode2 = EC_PPBERASEVERIFY;
            //break;
        }
    }
    if (errCode2)
        printf("Error: %s\n", GetErrorText(errCode2));
    else
        printf("PPB OFF in all sectors\n");

    errCode3 = EC_NONE;
    if (chkPPBL)
    {
        SCRPGetASPFunc(dev, ASP_PPBL, 0, &ASPBit);
        if (ASPBit)
            errCode3 = EC_PPBLSET;
        if (errCode3)
            printf("Error: %s\n", GetErrorText(errCode3));
        else
            printf("PPB Lock Bit OFF\n");
    }

    if (errCode1)
        errCode = errCode1;
    else if (errCode2)
        errCode = errCode2;
    else if (errCode3)
        errCode = errCode3;
    else
        errCode = EC_NONE;

    return errCode;
}


DWORD test_exit(DWORD exit_val)
{
    if (exit_val)
    {
        SetGlobalVar("SKIP", 1);
	printf("<TC> Test =========================== Fail\n");
    }
    else {
      printf("<TC> Test =========================== Pass\n");
    }
    return (exit_val);
}

#ifdef SIMULATION
int c_test()
#else
int main(int argc, char* argv[])
#endif
{
	DWORD bitPWD, bitPPBL, errCode;

#ifndef SIMULATION
    SKIP = GetGlobalVar("SKIP");
#endif
    if (SKIP)
    {
        line_space(2);
        printf("Test is skipped\n");
        return test_exit(__LINE__);
    }

#ifdef SIMULATION
    pDevice = NewDeviceObject(0, RPC);
#endif
	pDevice = Find_Device(RPC);
	
	//if (!(FS_PERSISTENTSECTOR & SCRPSupport(pDevice)))
    if (!(FS_SECTORPROTECT & SCRPSupport(pDevice)))
    {
        printf("Error: Advanced Sector Protection not supported\n");
        return test_exit(__LINE__);
    }

    errCode = EC_NONE;

    printf("Advanced Sector Protection Status Test\n");

    errCode = SCRPGetASPFunc( pDevice, ASP_PWD, 0, &bitPWD );
    if (errCode)
    {
        printf("Error: STATUS: %s\n", GetErrorText(EC_PWDDPWDESET));
        return test_exit(__LINE__);
    }

    SCRPGetASPFunc( pDevice, ASP_PPBL, 0, &bitPPBL);

    switch(bitPWD)
    {
        case PROT_PASSWORD:
            if (bitPPBL == 0)
            {
                printf("Error: %s\n", GetErrorText(EC_PPBL));
                printf("PPBL not active after POWER ON in Password Protection Mode\n");
                return test_exit(__LINE__);
            }
            else
                printf("Password is enabled and PPBL is set\n");

            errCode = SendTestPassword(pDevice);
            break;
        case PROT_PERSISTENT:
            if (bitPPBL)
            {
                printf("Error: PPB Lock after POR is enabled on a PPB mode device\n");
                return test_exit(__LINE__);
            }
            else
                printf("Persistent Protection is enabled and PPBL is not set\n");
            break;
        case PROT_NONE:
        default:
                printf("No Password and no Persistent Protection setting\n");
                break;
    }

   errCode = tVerifyProtectionOff(pDevice, TRUE);

    if (errCode)
        return test_exit(__LINE__);

    printf("Test complete\n");
    return test_exit(0);
}

