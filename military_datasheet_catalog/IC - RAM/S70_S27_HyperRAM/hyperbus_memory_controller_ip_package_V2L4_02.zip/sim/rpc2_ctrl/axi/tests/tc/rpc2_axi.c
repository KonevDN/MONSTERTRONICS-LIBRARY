//===========================================================================
//
//  rpc2_axi.c
//
//   @author  Yuichi Ise (yuichi.ise@spansion.com)
//   @version 0.1
//   @since   06/24/2013
//
//===========================================================================
#include <stdlib.h>
#include "rpc2_common.h"
#include "dpiheader.h"

//=============================================================================
//  DEFINITIONS
//=============================================================================
#define CT_MSG(fmt, args ...)     printf("[IT]"); printf(fmt, ## args)
#define CT_ERR_MSG(fmt, args ...) printf("[IT]<ERR>"); printf(fmt, ## args)

#define MAX_ADDR_LOOP   12
#define RDS_STALL_LEN   15

#if (RPC2_CTRL_IP_VER >= 240)
#define PSRAM_IR0_OFFSET        0x0000
#define PSRAM_IR1_OFFSET        0x0001
#define PSRAM_CR0_OFFSET        0x1000
#define PSRAM_CR1_OFFSET        0x1001
#endif

#define PSRAM_CS_INIT   0x8F17
#define FLASH_CS_INIT   0x8FB7

#define WRAP2INCR_ON    (0x0)
#define WRAP2INCR_OFF   (0x1)

#define FIXED_BYTE_1_MAX_LEN	(FIXED_MAX_LEN)
#define FIXED_BYTE_2_MAX_LEN	(FIXED_MAX_LEN)
#define FIXED_BYTE_4_MAX_LEN	(FIXED_MAX_LEN)

DWORD test_status = 3;

DWORD FIXED_LEN_SUPPORT[3] = {FIXED_BYTE_1_MAX_LEN, FIXED_BYTE_2_MAX_LEN, FIXED_BYTE_4_MAX_LEN};

DWORD WRAP_BURST[2][3][3] = {{{WRAP_16B,WRAPSIZE_16B,FLASH_WRAPSIZE_16B},  \
                              {WRAP_32B,WRAPSIZE_32B,FLASH_WRAPSIZE_32B},  \
                              {WRAP_64B,WRAPSIZE_64B,FLASH_WRAPSIZE_64B}}, \
                             {{WRAP_16B,WRAPSIZE_16B,PSRAM_WRAPSIZE_16B},  \
                              {WRAP_32B,WRAPSIZE_32B,PSRAM_WRAPSIZE_32B},  \
                              {WRAP_64B,WRAPSIZE_64B,PSRAM_WRAPSIZE_64B}}};

DWORD WRITE_BURST_SUPPORT[3] = {MEM_WRITE_FIXED, MEM_WRITE_INCR, MEM_WRITE_WRAP};
DWORD READ_BURST_SUPPORT[3]  = {MEM_READ_FIXED, MEM_READ_INCR, MEM_READ_WRAP};

//=============================================================================
//  FUNCTIONS
//=============================================================================
static int wr_rd(int target, DWORD addr, DWORD wlen, DWORD wburst, 
		 DWORD wsize, BYTE* wbuf, DWORD rburst, DWORD rsize)
{
  int i;
  int ret = NO_ERROR;

  DWORD rlen;
  DWORD rlenHold;
  BYTE* rbuf;
  BYTE rresp[MAX_LEN];

  DWORD waddr;
  BYTE wresp;

  int wxferByte;
  int rxferByte;

  BYTE* expData;
  DWORD raddr;
  DWORD len16;
  DWORD len8;
  DWORD burstLen;
  DWORD bufPtr;
  DWORD wlen8;
  DWORD rlen8;
#ifndef STRESS_TEST
  DWORD cs;
#endif
  DWORD devtype;
  int rcntLoop;
  int rcnt;

  wxferByte = 1 << wsize;
  rxferByte = 1 << rsize;

  len16 = ((wxferByte*wlen)+sizeof(WORD)-1)/sizeof(WORD);
  len8 = (wxferByte*wlen) - addr%wxferByte;

  if (rburst == FIXED) {
    rlen = FIXED_LEN_SUPPORT[rsize];
  } else {
    rlen = (len8 + (rxferByte-1)) / rxferByte;
    rlenHold = rlen;
  }

  rbuf = (BYTE*)malloc(len16*sizeof(WORD));
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_wr_rd;
  }
  expData = (BYTE*)malloc(len16*sizeof(WORD));
  if (!expData) {
    CT_ERR_MSG("Can't allocate memory for expected data\n");
    ret = ALLOC_ERROR;
    goto end_wr_rd;
  }

  waddr = addr;
  bufPtr = 0;
  CT_MSG("Write: addr=0x%08X len=0x%03X burst=%1d size=%1d\n", waddr, wlen, wburst, wsize);

#ifdef STRESS_TEST
  if (addr >= CS1_MEM_BASE) {
    devtype = CS1_DEVTYPE;
  } else {
    devtype = CS0_DEVTYPE;
  }
#else
  getCsNum(addr, &cs);
  getDevType(&devtype, cs);
#endif

  if ((wburst == FIXED) && (wlen > FIXED_MAX_LEN)) {
    ret = NOT_SUPPORT;
    goto end_wr_rd;
  }

  while (wlen) {
    if (wlen > MAX_LEN) {
      burstLen = MAX_LEN;
    }
    else {
      burstLen = wlen;
    }
    writeBurst(target, waddr, burstLen, wburst, wsize, &wbuf[bufPtr]);
    getWriteResp(target, &wresp);
    if (wresp) {
      CT_ERR_MSG("Write Response 0x%x\n", wresp);
      ret = RESP_ERROR;
      goto end_wr_rd;
    }
    
    if (wburst == FIXED) {
      if (addr%wxferByte + wxferByte*wlen > (1 << MAX_AXI_BURST_SIZE)) {
        wlen8 = (1 << MAX_AXI_BURST_SIZE) - addr%wxferByte;
      } else {
        wlen8 = wxferByte*wlen8 - addr%rxferByte;
      }
      wrapMemCopy8(&expData[bufPtr], &wbuf[bufPtr], wlen8, (burstLen-1)*wxferByte + waddr%wxferByte);
    } else {
      wrapMemCopy8(&expData[bufPtr], &wbuf[bufPtr], burstLen*wxferByte, 0);
      if ((bufPtr) && (wsize == BYTE_1) && (waddr%sizeof(WORD)) && (devtype==FLASH)) {
        expData[bufPtr-1] = 0xFF;
      }
    }
    wlen -= burstLen;
    bufPtr += ((wxferByte*burstLen) - (waddr%wxferByte));
    waddr += ((wxferByte*burstLen) - (waddr%wxferByte));
  }

  if (rburst == FIXED) {
    rcntLoop = rlen;
    rlen = 1;
  } else if ((rburst == WRAP) && (wburst != WRAP)) {
    rcntLoop = rlenHold;
  }
  else {
    rcntLoop = 1;
  }

  for (rcnt = 0; rcnt < rcntLoop; rcnt++) {
    ret = NO_ERROR;
    if (rburst == FIXED) {
      raddr = addr;
    } else if ((rburst == INCR) && (wburst == WRAP)) {
      raddr = addr - (addr % (wxferByte*burstLen));
    } else {
      raddr = addr + rcnt * rxferByte;
    }

    bufPtr = 0;
    if (rburst != FIXED) {
      rlen = rlenHold;
    }
    CT_MSG("Read : addr=0x%08X len=0x%03X burst=%1d size=%1d\n", raddr, rlen, rburst, rsize);
    while (rlen) {
      if (rlen > MAX_LEN) {
	burstLen = MAX_LEN;
      }
      else {
	burstLen = rlen;
      }
      readBurst(target, raddr, burstLen, rburst, rsize);
#ifdef STRESS_TEST
      getReadDataRespStress(target, raddr, burstLen, rsize, &rbuf[bufPtr], rresp);
#else
      getReadDataResp(target, burstLen, rsize, &rbuf[bufPtr], rresp);
#endif
      for (i = 0; i < burstLen; i++) {
	if (rresp[i]) {
	  CT_ERR_MSG("Read Response %d: 0x%x\n", i, rresp[i]);
	  ret = RESP_ERROR;
	  goto end_wr_rd;
	}
      }

      rlen -= burstLen;
      bufPtr += ((rxferByte*burstLen) - (raddr%rxferByte));
      raddr += ((rxferByte*burstLen) - (raddr%rxferByte));
    }

    if (rburst == FIXED) {
      if (addr%rxferByte + rxferByte*rcnt > (1 << MAX_AXI_BURST_SIZE)) {
        rlen8 = (1 << MAX_AXI_BURST_SIZE) - addr%rxferByte;
      } else {
        rlen8 = rxferByte*rcnt - addr%rxferByte;
      }
      if (verifyData8(rbuf, expData, rlen8)) {
        ret = VERIFY_ERROR;
        CT_ERR_MSG("VerifyData8\n");
        goto end_wr_rd;
      }
      rlen++;
    } else if ((rburst == WRAP) || (wburst == WRAP)) {
      rlen8 = (rxferByte*burstLen);

      for (i=0; i < sizeof(WRAP_BURST[devtype])/sizeof(WRAP_BURST[devtype][0]); i++) {
        if (rlen8 == WRAP_BURST[devtype][i][0]) {
          if (rburst == WRAP) {
            wrapMemCopy8(expData, wbuf, rlen8, rcnt*rxferByte);
          } else {
            wrapMemCopy8(expData, wbuf, rlen8, addr%rlen8);
          }
          if (verifyData8(rbuf, expData, rlen8)) {
            ret = VERIFY_ERROR;
            CT_ERR_MSG("VerifyData8\n");
            goto end_wr_rd;
          }
          break;
        }
      }
    } else {
      rlen8 = (rxferByte*burstLen) - addr%rxferByte;
      if (len8 < rlen8) {
        rlen8 = len8;
      }
      if (verifyData8(rbuf, expData, rlen8)) {
        ret = VERIFY_ERROR;
        CT_ERR_MSG("VerifyData8\n");
        goto end_wr_rd;
      }
    }      
  }
 end_wr_rd:
  if (expData) {
    free(expData);
  }
  if (rbuf) {
    free(rbuf);
  }
  return ret;
}

static int check_wraplen_support (DWORD wraplen)
{
  int ret = NOT_SUPPORT;

  switch (wraplen) {
  case WRAP_LEN_2:
  case WRAP_LEN_4:
  case WRAP_LEN_8:
  case WRAP_LEN_16:
    ret = NO_ERROR;
  default:
    break;
  }
  return ret;
}

static int sub_outstanding_wr_rd(DWORD *waddr, DWORD *wlen, DWORD *wburst, DWORD *wsize, BYTE** wbuf,
                                 DWORD *raddr, DWORD *rburst, DWORD outstanding_cnt, DWORD concurrent_enable)
{
  int i, j;
  int ret = NO_ERROR;
  int target = MEM;

  BYTE* expData;
  BYTE wresp;
  BYTE* rbuf[MAX_OUTSTANDING_TRANS];
  DWORD rlen[MAX_OUTSTANDING_TRANS];
  DWORD rsize[MAX_OUTSTANDING_TRANS];
  BYTE rresp[MAX_LEN];

  int rXferByte[MAX_OUTSTANDING_TRANS];
  int wXferByte[MAX_OUTSTANDING_TRANS];

  expData = (BYTE*)malloc(MAX_LEN*(1 << MAX_AXI_BURST_SIZE));
  if (!expData) {
    CT_ERR_MSG("Can't allocate memory for expected data\n");
    goto end_wr_rd;
  }

  for (i=0 ; i<outstanding_cnt ; i++) {
    rlen[i] = wlen[i];
    rsize[i] = wsize[i];
    rXferByte[i] = 1 << rsize[i];
    wXferByte[i] = 1 << wsize[i];

    rbuf[i] = (BYTE*)malloc(MAX_LEN*(1 << MAX_AXI_BURST_SIZE));
    if (!rbuf[i]) {
      CT_ERR_MSG("Can't allocate memory for read data\n");
      goto end_wr_rd;
    }
    if (rburst[i] == INCR) {
      if (raddr[i] != waddr[i]) {
        CT_ERR_MSG("Mismatch Write/Read Address\n");
        ret = NOT_SUPPORT;
        goto end_wr_rd;
      }
    } else if (rburst[i] == WRAP) {
      if ((raddr[i] % rXferByte[i])                             || \
          (raddr[i] < waddr[i])                                 || \
          (raddr[i] >= waddr[i]+wXferByte[i]*wlen[i])           || \
          (check_wraplen_support(rlen[i]) == NOT_SUPPORT))
      {
        CT_ERR_MSG("Mismatch Write/Read Address2\n");
        ret = NOT_SUPPORT;
        goto end_wr_rd;
      }
    }
  }

  if (concurrent_enable) {
    CT_MSG("Concurrent Outstanding Write/Read %2d\n", outstanding_cnt);
    for (i = 0; i < outstanding_cnt; i++) {
      CT_MSG(" #%2d: waddr=0x%08X wlen=0x%03X wburst=%1d wsize=%1d\n", i, waddr[i], wlen[i], wburst[i], wsize[i]);
      CT_MSG(" #%2d: raddr=0x%08X rlen=0x%03X rburst=%1d rsize=%1d\n", i, raddr[i], rlen[i], rburst[i], rsize[i]);

      writeBurst(target, waddr[i], wlen[i], wburst[i], wsize[i], wbuf[i]);
      readBurst(target, raddr[i], rlen[i], rburst[i], rsize[i]);
    }
    for (i = 0; i < outstanding_cnt; i++) {
      getWriteResp(target, &wresp);
      if (wresp) {
        CT_ERR_MSG("Write Response 0x%x\n", wresp);
        ret = RESP_ERROR;
      }

#ifdef STRESS_TEST
      getReadDataRespStress(target, raddr[i], rlen[i], rsize[i], rbuf[i], rresp);
#else
      getReadDataResp(target, rlen[i], rsize[i], rbuf[i], rresp);
#endif
      for (j = 0; j < rlen[i]; j++) {
        if (rresp[j]) {
	  CT_ERR_MSG("Read Response %d - %d: 0x%x\n", i, j, rresp[j]);
	  ret = RESP_ERROR;
        }
      }
    }

#if (RPC2_CTRL_IP_VER >= 240)
    for (i = 0; i < outstanding_cnt; i++) {
      readBurst(target, raddr[i], rlen[i], rburst[i], rsize[i]);
    }
    for (i = 0; i < outstanding_cnt; i++) {
#ifdef STRESS_TEST
      getReadDataRespStress(target, raddr[i], rlen[i], rsize[i], rbuf[i], rresp);
#else
      getReadDataResp(target, rlen[i], rsize[i], rbuf[i], rresp);
#endif
      for (j = 0; j < rlen[i]; j++) {
        if (rresp[j]) {
	  CT_ERR_MSG("Read Response %d - %d: 0x%x\n", i, j, rresp[j]);
	  ret = RESP_ERROR;
        }
      }
    }
#endif
  } else {
    CT_MSG("Outstanding Write %2d\n", outstanding_cnt);
    for (i = 0; i < outstanding_cnt; i++) {
      CT_MSG(" #%2d: addr=0x%08X len=0x%03X burst=%1d size=%1d\n", i, waddr[i], wlen[i], wburst[i], wsize[i]);
      writeBurst(target, waddr[i], wlen[i], wburst[i], wsize[i], wbuf[i]);
    }
    for (i = 0; i < outstanding_cnt; i++) {
      getWriteResp(target, &wresp);
      if (wresp) {
        CT_ERR_MSG("Write Response 0x%x\n", wresp);
        ret = RESP_ERROR;
      }
    }

    CT_MSG("Outstanding Read %2d\n", outstanding_cnt);
    for (i = 0; i < outstanding_cnt; i++) {
      CT_MSG(" #%2d: addr=0x%08X len=0x%03X burst=%1d size=%1d\n", i, raddr[i], rlen[i], rburst[i], rsize[i]);
      readBurst(target, raddr[i], rlen[i], rburst[i], rsize[i]);
    }
    for (i = 0; i < outstanding_cnt; i++) {
#ifdef STRESS_TEST
      getReadDataRespStress(target, raddr[i], rlen[i], rsize[i], rbuf[i], rresp);
#else
      getReadDataResp(target, rlen[i], rsize[i], rbuf[i], rresp);
#endif
      for (j = 0; j < rlen[i]; j++) {
        if (rresp[j]) {
	  CT_ERR_MSG("Read Response %d - %d: 0x%x\n", i, j, rresp[j]);
	  ret = RESP_ERROR;
        }
      }
    }
  }

  for (i = 0; i < outstanding_cnt; i++) {
    if (rburst[i] == WRAP) {
      wrapMemCopy8(expData, wbuf[i], rXferByte[i]*rlen[i], raddr[i]%(rXferByte[i]*rlen[i]));
    } else {
      wrapMemCopy8(expData, wbuf[i], rXferByte[i]*rlen[i], 0);
    }
    if (verifyData8(rbuf[i], expData, (wXferByte[i]*wlen[i] - waddr[i]%wXferByte[i]))) {
      ret = VERIFY_ERROR;
      CT_ERR_MSG("VerifyData8 %d\n", i);
      goto end_wr_rd;
    }
  }
 end_wr_rd:
  if (expData) {
    free(expData);
  }
  for (i = 0; i < outstanding_cnt; i++) {
    if (rbuf[i]) {
      free(rbuf[i]);
    }
  }
  return ret;
}

static int sub_continous_wr_rd(DWORD addr, DWORD len, DWORD size, DWORD transNum, WORD* wbuf)
{
  int i, j;
  int ret = NO_ERROR;
  int target = MEM;

  DWORD waddr;
  DWORD wburst = INCR;
  DWORD wlen  = len;
  DWORD wsize = size;
  BYTE wresp;

  WORD* rbuf;
  DWORD raddr;
  DWORD rburst = INCR;
  DWORD rlen  = len;
  DWORD rsize = size;
  BYTE rresp[MAX_LEN];

  int len16;
  int rXferByte;
  int wXferByte;

  rXferByte = 1 << rsize;
  wXferByte = 1 << wsize;
  len16 = (wXferByte*wlen)/sizeof(WORD);

  rbuf = (WORD*)malloc(rXferByte*rlen*transNum);
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_wr_rd;
  }

  CT_MSG("Write/Read: len=0x%03X burst=%1d size=%1d x 0x%08X\n", wlen, wburst, wsize, transNum);

  for (i = 0; i < transNum; i++) {
    waddr = addr + wXferByte*wlen*i;
    writeBurst(target, waddr, wlen, wburst, wsize, &wbuf[len16*i]);
    getWriteResp(target, &wresp);
    if (wresp) {
      CT_ERR_MSG("Write Response 0x%x\n", wresp);
      ret = RESP_ERROR;
      goto end_wr_rd;
    }

    raddr = addr + rXferByte*rlen*i;
    readBurst(target, raddr, rlen, rburst, rsize);
#ifdef STRESS_TEST
    getReadDataRespStress(target, raddr, rlen, rsize, &rbuf[len16*i], rresp);
#else
    getReadDataResp(target, rlen, rsize, &rbuf[len16*i], rresp);
#endif
    for (j = 0; j < rlen; j++) {
      if (rresp[j]) {
	CT_ERR_MSG("Read Response %d - %d: 0x%x\n", i, j, rresp[j]);
	ret = RESP_ERROR;
        goto end_wr_rd;
      }
    }

    if (verifyData(&rbuf[len16*i], &wbuf[len16*i], len16)) {
      ret = VERIFY_ERROR;
      CT_ERR_MSG("VerifyData\n");
      goto end_wr_rd;
    }
  }
 end_wr_rd:
  if (rbuf) {
    free(rbuf);
  }
  
  return ret;
}

static int sub_concurrent_wr_rd (int target, DWORD waddr, DWORD wlen, DWORD wburst, DWORD wsize,
                                 BYTE* wbuf, DWORD raddr, DWORD rburst, DWORD rsize)
{
  int i;
  int ret = NO_ERROR;

  DWORD rlen;
  BYTE* rbuf;
  BYTE rresp[MAX_LEN];
  BYTE* expData;

  DWORD len8;
  DWORD rlen8;
  BYTE wresp;

  int wXferByte;
  int rXferByte;
  wXferByte = 1 << wsize;
  rXferByte = 1 << rsize;

  if (wlen > MAX_LEN) {
    CT_ERR_MSG("Can't support the burst length 0x%X\n", wlen);
    ret = NOT_SUPPORT;
    return ret;
  }

  rlen = ((wXferByte*wlen)+(rXferByte-1))/rXferByte;
  len8 = (wXferByte*wlen)-waddr%wXferByte;

  rbuf = (BYTE*)malloc(rXferByte*rlen);
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_wr_rd;
  }
  expData = (BYTE*)malloc(wXferByte*wlen);
  if (!expData) {
    CT_ERR_MSG("Can't allocate memory for expected data\n");
    goto end_wr_rd;
  }

  CT_MSG("Concurrent Write: addr=0x%08X len=0x%03X burst=%1d size=%1d\n", waddr, wlen, wburst, wsize);
  CT_MSG("           Read : addr=0x%08X len=0x%03X burst=%1d size=%1d\n", raddr, rlen, rburst, rsize);
  writeBurst(target, waddr, wlen, wburst, wsize, wbuf);
  readBurst(target, raddr, rlen, rburst, rsize);

  getWriteResp(target, &wresp);
#ifdef STRESS_TEST
  getReadDataRespStress(target, raddr, rlen, rsize, rbuf, rresp);
  // Re-read for verify data
  readBurst(target, raddr, rlen, rburst, rsize);
  getReadDataRespStress(target, raddr, rlen, rsize, rbuf, rresp);
#else
  getReadDataResp(target, rlen, rsize, rbuf, rresp);
#endif
  if (wresp) {
    CT_ERR_MSG("Write Response 0x%x\n", wresp);
    ret = RESP_ERROR;
    goto end_wr_rd;
  }
  for (i = 0; i < rlen; i++) {
    if (rresp[i]) {
      CT_ERR_MSG("Read Response %d: 0x%x\n", i, rresp[i]);
      ret = RESP_ERROR;
      goto end_wr_rd;
    }
  }

#if (RPC2_CTRL_IP_VER >= 240)
  readBurst(target, raddr, rlen, rburst, rsize);
  getReadDataResp(target, rlen, rsize, rbuf, rresp);
  for (i = 0; i < rlen; i++) {
    if (rresp[i]) {
      CT_ERR_MSG("Read Response %d: 0x%x\n", i, rresp[i]);
      ret = RESP_ERROR;
      goto end_wr_rd;
    }
  }
#endif

  if (rburst == WRAP) {
    wrapMemCopy8(expData, wbuf, len8, raddr%(rXferByte*rlen));
  } else {
    wrapMemCopy8(expData, wbuf, len8, 0);
  }

  rlen8 = rXferByte*rlen-raddr%rXferByte;
  if (len8 < rlen8) {
    rlen8 = len8;
  }

  if (verifyData8(rbuf, expData, rlen8)) {
    ret = VERIFY_ERROR;
    CT_ERR_MSG("VerifyData8\n");
    goto end_wr_rd;
  }
 end_wr_rd:
  if (expData) {
    free(expData);
  }
  if (rbuf) {
    free(rbuf);
  }
  return ret;
}

static int rd_slave_error(int target, DWORD addr, DWORD rlen, DWORD rburst,
			      DWORD rsize, WORD* rbuf)
{
  int i;
  int ret = NO_ERROR;
  BYTE rresp[MAX_LEN];

  CT_MSG("Read : addr=0x%08X len=0x%03X burst=%1d size=%1d\n", addr, rlen, rburst, rsize);
  readBurst(target, addr, rlen, rburst, rsize);
#ifdef STRESS_TEST
  getReadDataRespStress(target, addr, rlen, rsize, rbuf, rresp);
#else
  getReadDataResp(target, rlen, rsize, rbuf, rresp);
#endif
  for (i = 0; i < rlen; i++) {
    if (rresp[i] != SLVERR) {
      ret = RESP_ERROR;
      CT_ERR_MSG("Unexpected Read response %d\n", rresp[i]);
      break;
    }
  }
  return ret;
}

static int wr_slave_error(int target, DWORD addr, DWORD wlen, DWORD wburst,
			      DWORD wsize, WORD* wbuf)
{
  int ret = NO_ERROR;
  BYTE wresp;

  CT_MSG("Write: addr=0x%08X len=0x%03X burst=%1d size=%1d\n", addr, wlen, wburst, wsize);
  writeBurst(target, addr, wlen, wburst, wsize, wbuf);
  getWriteResp(target, &wresp);
  if (wresp != SLVERR) {
    ret = RESP_ERROR;
    CT_ERR_MSG("Unexpected Write response %d\n", wresp);
  }
  return ret;
}

void mask_ws(DWORD wlen, DWORD wsize, BYTE* strb)
{
  int i, j;
  BYTE wstrb;
  BYTE validStrb;
  int wXferByte;

  wXferByte = 1 << wsize;

  for(i = 0; i < wlen; i++) {
    if(i % 2) {
      wstrb = strb[i/2];
    } else {
      wstrb = strb[i/2] >> 4;
    }

    validStrb = 0x00;
    for (j = 0; j < wXferByte; j++) {
      validStrb |= (BIT0 << ((i*wXferByte)%4+j));
    }
    wstrb &= validStrb;

    if(i % 2) {
      strb[i/2] &= 0xF0;
      strb[i/2] |= wstrb;
    } else {
      if (i == wlen - 1) {
        strb[i/2] &= 0x00;
      } else {
        strb[i/2] &= 0x0F;
      }
      strb[i/2] |= (wstrb << 4);
    }
  }
}

void calc_expdata(DWORD wlen, DWORD wsize, BYTE* strb, BYTE* wbuf, BYTE* expbuf) 
{
  int i;
  BYTE wstrb;
  int wXferByte;
  int wlen32;

  wXferByte = 1 << wsize;

  wlen32 = wXferByte*wlen;
  for (i = 0; i < wlen32; i++) {
    if ((i%8) < 4) {
      wstrb = strb[i/8] >> (4+(i%8));
    }
    else {
      wstrb = strb[i/8] >> ((i%8)-4);
    }
    wstrb &= 0x1;
    expbuf[i] = (wstrb) ? wbuf[i]: 0xFF;
  }
}

static int sub_wr_rd_rand_ws(DWORD addr, DWORD len, DWORD size, DWORD strbPattern)
{
  int i;
  int ret = NO_ERROR;
  int target = MEM;

  WORD* wbuf;
  WORD* strb;
  DWORD waddr = addr;
  DWORD wburst = INCR;
  DWORD wlen  = len;
  DWORD wsize = size;
  BYTE wresp;

  WORD* rbuf;
  DWORD raddr = addr;
  DWORD rburst = INCR;
  DWORD rlen  = len;
  DWORD rsize = size;
  BYTE rresp[MAX_LEN];

  WORD* expData;
  DWORD pattern;

  int wxferByte;
  int rxferByte;

  DWORD wlen16;
  DWORD wlen8;
  DWORD len16;
  DWORD len8;
  DWORD strbLen16;
  DWORD strbLen8;

  wxferByte = sizeof(DWORD);
  rxferByte = 1 << rsize;

  wlen16 = (wxferByte*wlen)/sizeof(WORD);
  wlen8 = (wxferByte*wlen);
  len16 = ((rxferByte*rlen)+sizeof(WORD)-1)/sizeof(WORD);
  len8 = (rxferByte*rlen) - addr%rxferByte;
  strbLen8 = len8+1/2;
  strbLen16 = (strbLen8 + sizeof(WORD)-1)/sizeof(WORD);

  wbuf = (WORD*)malloc(wlen16*sizeof(WORD));
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_wr_rd;
  }

  rbuf = (WORD*)malloc(len16*sizeof(WORD));
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_wr_rd;
  }

  expData = (WORD*)malloc(wlen16*sizeof(WORD));
  if (!expData) {
    CT_ERR_MSG("Can't allocate memory for expected data\n");
    ret = ALLOC_ERROR;
    goto end_wr_rd;
  }

  strb = (WORD*)malloc(strbLen16*sizeof(WORD));
  if (!strb) {
    CT_ERR_MSG("Can't allocate memory for strobe data\n");
    ret = ALLOC_ERROR;
    goto end_wr_rd;
  }

  CT_MSG("Write: addr=0x%08X len=0x%03X size=%1d\n", addr, wlen, wsize);
  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, wlen16);
  CT_MSG("Write Data Pattern");
  printBuffer(wbuf, wlen16);

  fillBuffer(strbPattern, strb, strbLen16);
  mask_ws(wlen, wsize, (BYTE*)strb);
  printBuffer(strb, strbLen16);

  calc_expdata(len, wsize, (BYTE*)strb, (BYTE*)wbuf, (BYTE*)expData);
  CT_MSG("Expected Data Pattern");
  printBuffer(expData, len16);

  writeBurstStrobe(target, waddr, wlen, wburst, wsize, (void *)wbuf, (void *)strb);
  getWriteResp(target, &wresp);
  if (wresp) {
    CT_ERR_MSG("Write Response 0x%x\n", wresp);
    ret = RESP_ERROR;
    goto end_wr_rd;
  }

  CT_MSG("Read : addr=0x%08X len=0x%03X burst=%1d size=%1d\n", raddr, rlen, rburst, rsize);
  readBurst(target, raddr, rlen, rburst, rsize);
#ifdef STRESS_TEST
  getReadDataRespStress(target, raddr, rlen, rsize, (BYTE*)rbuf, rresp);
#else
  getReadDataResp(target, rlen, rsize, (BYTE*)rbuf, rresp);
#endif
  for (i = 0; i < rlen; i++) {
    if (rresp[i]) {
      CT_ERR_MSG("Read Response %d: 0x%x\n", i, rresp[i]);
      ret = RESP_ERROR;
      goto end_wr_rd;
    }
  }

  if (verifyData8((BYTE*)rbuf, (BYTE*)expData, len8)) {
    ret = VERIFY_ERROR;
    CT_ERR_MSG("VerifyData8\n");
    goto end_wr_rd;
  }
 end_wr_rd:
  if (strb) {
    free(strb);
  }
  if (expData) {
    free(expData);
  }
  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
  return ret;
}

static int set_cr_wrapsize (DWORD wrapSize, DWORD wrap2incr, DWORD cs)
{
  int i;
  int ret = NO_ERROR;
  DWORD mbrReg;
  DWORD devtype;
  WORD  crData, crwData, cr2;
  BYTE  rresp, wresp;

  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    return ret;
  }
#ifdef STRESS_TEST
  if (cs == CS1_SEL) {
    devtype = CS1_DEVTYPE;
  } else {
    devtype = CS0_DEVTYPE;
  }
#else
  getDevType(&devtype, cs);
#endif
  if (devtype == PSRAM) {
    cr2 = 1;
  } else {
    cr2 = wrap2incr & 0x00000001;
  }

  ret = NOT_SUPPORT;
  for (i=0; i < sizeof(WRAP_BURST[devtype])/sizeof(WRAP_BURST[devtype][0]); i++) {
    if (wrapSize == WRAP_BURST[devtype][i][0]) {
      ret = NO_ERROR;
      setWrapSize (WRAP_BURST[devtype][i][1], cs);

      CT_MSG("Set CRT=1 --------------------------------\n");
      setConfigRegTarget(1, cs);

#if (RPC2_CTRL_IP_VER >= 240)
      readBurst(MEM, mbrReg+PSRAM_CR0_OFFSET, 1, INCR, BYTE_2);
#else
      readBurst(MEM, mbrReg, 1, INCR, BYTE_2);
#endif

#ifdef STRESS_TEST
#if (RPC2_CTRL_IP_VER >= 240)
      getReadDataRespStress(MEM, mbrReg+PSRAM_CR0_OFFSET, 1, BYTE_2, &crData, &rresp);
#else
      getReadDataRespStress(MEM, mbrReg, 1, BYTE_2, &crData, &rresp);
#endif
#else
      getReadDataResp(MEM, 1, BYTE_2, &crData, &rresp);
#endif
      if (rresp) {
        CT_ERR_MSG("Read Response: 0x%x\n", rresp);
        ret = RESP_ERROR;
        break;
      }

      crwData = ((crData & 0xFFF8) | (WRAP_BURST[devtype][i][2] & 0x0007) | (cr2 << 2));
      MSG("Write CR Reg = 0x%04X\n", crwData);
#if (RPC2_CTRL_IP_VER >= 240)
      writeBurst(MEM, mbrReg+PSRAM_CR0_OFFSET, 1, INCR, BYTE_2, &crwData);
#else
      writeBurst(MEM, mbrReg, 1, INCR, BYTE_2, &crwData);
#endif
      getWriteResp(MEM, &wresp);
      if (wresp) {
        CT_ERR_MSG("Write Response 0x%x\n", wresp);
        ret = RESP_ERROR;
        break;
      }

#if (RPC2_CTRL_IP_VER >= 240)
      readBurst(MEM, mbrReg+PSRAM_CR0_OFFSET, 1, INCR, BYTE_2);
#else
      readBurst(MEM, mbrReg, 1, INCR, BYTE_2);
#endif

#ifdef STRESS_TEST
#if (RPC2_CTRL_IP_VER >= 240)
      getReadDataRespStress(MEM, mbrReg+PSRAM_CR0_OFFSET, 1, BYTE_2, &crData, &rresp);
#else
      getReadDataRespStress(MEM, mbrReg, 1, BYTE_2, &crData, &rresp);
#endif
#else
      getReadDataResp(MEM, 1, BYTE_2, &crData, &rresp);
#endif
      if (rresp) {
        CT_ERR_MSG("Read Response: 0x%x\n", rresp);
        ret = RESP_ERROR;
        break;
      }

      if (verifyData8((BYTE *)&crData, (BYTE *)&crwData, 2)) {
        CT_ERR_MSG("VerifyData8\n");
        ret = VERIFY_ERROR;
      }
      break;
    }
  }
  if (ret == NOT_SUPPORT) {
    CT_MSG("Can't support the wrap burst size %dB\n", wrapSize);
    return ret;
  }

  CT_MSG("Set CRT=0 --------------------------------\n");
  setConfigRegTarget(0, cs);
  return ret;
}

static int set_cr_reg (WORD crwData, DWORD cs)
{
  int ret = NO_ERROR;
  DWORD mbrReg;
  WORD  crData;
  BYTE  rresp, wresp;

  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    return ret;
  }

  CT_MSG("Set CRT=1 --------------------------------\n");
  setConfigRegTarget(1, cs);

  MSG("Write CR Reg = 0x%04X\n", crwData);
#if (RPC2_CTRL_IP_VER >= 240)
  writeBurst(MEM, mbrReg+PSRAM_CR0_OFFSET, 1, INCR, BYTE_2, &crwData);
#else
  writeBurst(MEM, mbrReg, 1, INCR, BYTE_2, &crwData);
#endif
  getWriteResp(MEM, &wresp);
  if (wresp) {
    CT_ERR_MSG("Write Response 0x%x\n", wresp);
    ret = RESP_ERROR;
    goto end_set_cr_reg;
  }

#if (RPC2_CTRL_IP_VER >= 240)
  readBurst(MEM, mbrReg+PSRAM_CR0_OFFSET, 1, INCR, BYTE_2);
#else
  readBurst(MEM, mbrReg, 1, INCR, BYTE_2);
#endif

#ifdef STRESS_TEST
#if (RPC2_CTRL_IP_VER >= 240)
  getReadDataRespStress(MEM, mbrReg+PSRAM_CR0_OFFSET, 1, BYTE_2, &crData, &rresp);
#else
  getReadDataRespStress(MEM, mbrReg, 1, BYTE_2, &crData, &rresp);
#endif
#else
  getReadDataResp(MEM, 1, BYTE_2, &crData, &rresp);
#endif
  if (rresp) {
    CT_ERR_MSG("Read Response: 0x%x\n", rresp);
    ret = RESP_ERROR;
    goto end_set_cr_reg;
  }

  if (verifyData8((BYTE *)&crData, (BYTE *)&crwData, 2)) {
    ret = VERIFY_ERROR;
    CT_ERR_MSG("VerifyData8\n");
  }

 end_set_cr_reg:
  CT_MSG("Set CRT=0 --------------------------------\n");
  setConfigRegTarget(0, cs);
  return ret;
}

int sub_wr_rd_wrap (DWORD cs, DWORD wrapsize)
{
  int i;
  int ret;
  int expWwrapret = NO_ERROR;
  int expRwrapret = NO_ERROR;

  DWORD addr;
  DWORD wlen;
  DWORD wburst;
  DWORD wsize;
  DWORD rlen;
  DWORD rburst;
  DWORD rsize;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  WORD* rbuf;
  int wxferByte;
  int rxferByte;
  DWORD mbrReg;

  CT_MSG("%dB WRAP\n", wrapsize);
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    return ret;
  }
  ret = set_cr_wrapsize (wrapsize, WRAP2INCR_OFF, cs);
  if (MEM_WRITE_WRAP == INVALID) {
    expWwrapret = SLVERR;
  }
  if (MEM_READ_WRAP == INVALID) {
    expRwrapret = SLVERR;
  }

  len16 = wrapsize/sizeof(WORD);

  wbuf = (WORD*)malloc(wrapsize);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    return ALLOC_ERROR;
  }

  rbuf = (WORD*)malloc(wrapsize);
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    return ALLOC_ERROR;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  CT_MSG("Wrap Write/Wrap Read\n");
  addr = mbrReg;
  wburst = WRAP;
  rburst = WRAP;

  for (wsize = 0; wsize <= MAX_AXI_BURST_SIZE; wsize++) {
    wxferByte = 1 << wsize;
    wlen = wrapsize/wxferByte;
    if ((wrapsize%wxferByte) || (check_wraplen_support(wlen) == NOT_SUPPORT)) continue;

    for (rsize = 0; rsize <= MAX_AXI_BURST_SIZE; rsize++) {
      rxferByte = 1 << rsize;
      rlen = wrapsize/rxferByte;
      if ((wrapsize%rxferByte) || (check_wraplen_support(rlen) == NOT_SUPPORT)) continue;

      for (i=0; i<wlen; i++) {
        if ((expWwrapret == NO_ERROR) && (expRwrapret == NO_ERROR)) {
          ret = wr_rd(MEM, addr+i*wxferByte, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);
          if (ret != NO_ERROR) {
            goto end_wr_rd;
          }
        }
        if (expWwrapret == SLVERR) {
          ret = wr_slave_error(MEM, addr+i*wxferByte, wlen, wburst, wsize, wbuf); if (ret != NO_ERROR) goto end_wr_rd;
        }
        if (expRwrapret == SLVERR) {
          ret = rd_slave_error(MEM, addr+i*wxferByte, rlen, rburst, rsize, rbuf); if (ret != NO_ERROR) goto end_wr_rd;
        }
      }
    }
  }

  if (expWwrapret == NO_ERROR) {
    CT_MSG("WRAP Write/INCR Read\n");

    addr = mbrReg;
    wburst = WRAP;
    rburst = INCR;

    for (wsize = 0; wsize <= MAX_AXI_BURST_SIZE; wsize++) {
      wxferByte = 1 << wsize;
      wlen = wrapsize/wxferByte;
      if ((wrapsize%wxferByte) || (check_wraplen_support(wlen) == NOT_SUPPORT)) continue;

      for (rsize = 0; rsize <= MAX_AXI_BURST_SIZE; rsize++) {
        rxferByte = 1 << rsize;
        rlen = wrapsize/rxferByte;
        if (wrapsize%rxferByte) continue;

        for (i=0; i<wlen; i++) {
          ret = wr_rd(MEM, addr+i*wxferByte, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);
          if (ret != NO_ERROR) {
            goto end_wr_rd;
          }
        }
      }
    }
  }

  if (expRwrapret == NO_ERROR) {
    CT_MSG("Incr Write/Wrap Read\n");

    addr = mbrReg;
    wburst = INCR;
    rburst = WRAP;

    for (wsize = 0; wsize <= MAX_AXI_BURST_SIZE; wsize++) {
      wxferByte = 1 << wsize;
      wlen = wrapsize/wxferByte;
      if (wrapsize%wxferByte) continue;

      for (rsize = 0; rsize <= MAX_AXI_BURST_SIZE; rsize++) {
        rxferByte = 1 << rsize;
        rlen = wrapsize/rxferByte;
        if ((wrapsize%rxferByte) || (check_wraplen_support(rlen) == NOT_SUPPORT)) continue;

        ret = wr_rd(MEM, addr, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);
        if (ret != NO_ERROR) {
          goto end_wr_rd;
        }
      }
    }
  }

 end_wr_rd:
  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
  return ret;
}

//=============================================================================
//  MEMORY
//=============================================================================
int axi_wr16_rd16_len1 (DWORD cs)
{
  int ret;
  int i;

  DWORD wlen = 1;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_2;
  DWORD rburst = INCR;
  DWORD rsize  = BYTE_2;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wxferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI WRITE/READ 2B\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    return ret;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif
  wxferByte = 1 << wsize;
  len16 = (wxferByte*wlen)/sizeof(WORD);

  wbuf = (WORD*)malloc(wxferByte*wlen);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    return ALLOC_ERROR;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  for (i = 0; i < MAX_ADDR_LOOP; i++) {
    ret = wr_rd(MEM, i+mbrReg, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);
    if (ret != NO_ERROR) {
      break;
    }
  }
  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI WRITE/READ 2B");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr16_rd32_len1 (DWORD cs)
{
  int ret;
  int i;

  DWORD addr;
  DWORD wlen = 2;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_2;
  DWORD rburst = INCR;
  DWORD rsize  = BYTE_4;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wxferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI WRITE/READ 4B\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    return ret;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif
  wxferByte = 1 << wsize;
  len16 = (wxferByte*wlen)/sizeof(WORD);

  wbuf = (WORD*)malloc(wxferByte*wlen);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    return ALLOC_ERROR;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  for (i = 0; i < MAX_ADDR_LOOP; i++) {
    addr = i+mbrReg;
    ret = wr_rd(MEM, addr, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);
    if (ret != NO_ERROR) {
      break;
    }
  }
  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI WRITE/READ 4B");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr16_rd16_lenmax (DWORD cs)
{
  int ret;
  int i;

  DWORD wlen = MAX_LEN;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_2;
  DWORD rburst = INCR;
  DWORD rsize  = BYTE_2;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wxferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI WRITE/READ 512B\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    return ret;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif
  wxferByte = 1 << wsize;
  len16 = (wxferByte*wlen)/sizeof(WORD);

  wbuf = (WORD*)malloc(wxferByte*wlen);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    return ALLOC_ERROR;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  for (i = 0; i < MAX_ADDR_LOOP; i++) {
    ret = wr_rd(MEM, i+mbrReg, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);
    if (ret != NO_ERROR) {
      break;
    }
  }
  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI WRITE/READ 512B");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr16_rd32_lenmax (DWORD cs)
{
  int ret;
  int i;

  DWORD addr;
  DWORD wlen = MAX_LEN*2;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_2;
  DWORD rburst = INCR;
  DWORD rsize  = BYTE_4;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wxferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI WRITE/READ 1024B\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    return ret;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif
  wxferByte = 1 << wsize;
  len16 = (wxferByte*wlen)/sizeof(WORD);

  wbuf = (WORD*)malloc(wxferByte*wlen);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    return ALLOC_ERROR;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  for (i = 0; i < MAX_ADDR_LOOP; i++) {
    addr = i+mbrReg;
    ret = wr_rd(MEM, addr, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);
    if (ret != NO_ERROR) {
      break;
    }
  }
  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI WRITE/READ 1024B");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr16_rd16_rand (DWORD cs)
{
  int ret;
  int i;

  DWORD addr;
  DWORD wlen = MAX_LEN;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_2;
  DWORD rburst = INCR;
  DWORD rsize  = BYTE_2;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wxferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI WRITE/READ RANDOM 16-bit\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    return ret;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif
  wxferByte = 1 << wsize;
  len16 = (wxferByte*wlen)/sizeof(WORD);

  wbuf = (WORD*)malloc(wxferByte*wlen);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    return ALLOC_ERROR;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  for (i = 0; i < MAX_ADDR_LOOP; i++) {
    addr = 0;
    while (addr <= mbrReg) {
      addr = genRndAddr();
    }
#ifdef STRESS_TEST
    if(!cs) addr &= (CS1_MEM_BASE-1);
#endif
    wlen = genRndLen();
    ret = wr_rd(MEM, addr, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);
    if (ret != NO_ERROR) {
      break;
    }
  }
  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI WRITE/READ RANDOM 16-bit");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr16_rd32_rand (DWORD cs)
{
  int ret;
  int i;

  DWORD addr;
  DWORD wlen = 512;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_2;
  DWORD rburst = INCR;
  DWORD rsize  = BYTE_4;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wxferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI WRITE/READ RANDOM\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    return ret;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif
  wxferByte = 1 << wsize;
  len16 = (wxferByte*wlen)/sizeof(WORD);

  wbuf = (WORD*)malloc(wxferByte*wlen);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    return ALLOC_ERROR;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  for (i = 0; i < MAX_ADDR_LOOP; i++) {
    addr = 0;
    while (addr <= mbrReg) {
      addr = genRndAddr();
    }
#ifdef STRESS_TEST
    if(!cs) addr &= (CS1_MEM_BASE-1);
#endif
    wlen = genRndLen();
    ret = wr_rd(MEM, addr, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);
    if (ret != NO_ERROR) {
      break;
    }
  }
  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI WRITE/READ RANDOM");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr16_rd16_wrap_16B (DWORD cs)
{
  int ret;

  DWORD addr;
  DWORD wlen   = 8;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_2;
  DWORD rburst = WRAP;
  DWORD rsize  = BYTE_2;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wxferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI WRITE/READ 16B WRAP 16-bit\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    return ret;
  }
  setWrapSize (WRAP_16B, cs);
  ret = set_cr_wrapsize (WRAP_16B, WRAP2INCR_OFF, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't set CR reg wrap size\n");
    return ret;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif
  wxferByte = 1 << wsize;
  len16 = (wxferByte*wlen)/sizeof(WORD);

  wbuf = (WORD*)malloc(wxferByte*wlen);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    return ALLOC_ERROR;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  wlen = 8;
  addr = mbrReg;
  ret = wr_rd(MEM, addr, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);

  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI WRITE/READ 16B WRAP 16-bit");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr16_rd32_wrap_16B (DWORD cs)
{
  int ret;

  DWORD addr;
  DWORD wlen = 8;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_2;
  DWORD rburst = WRAP;
  DWORD rsize  = BYTE_4;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wxferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI WRITE/READ 16B WRAP\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    return ret;
  }
  setWrapSize (WRAP_16B, cs);
  ret = set_cr_wrapsize (WRAP_16B, WRAP2INCR_OFF, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't set CR reg wrap size\n");
    return ret;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif

  wxferByte = 1 << wsize;
  len16 = (wxferByte*wlen)/sizeof(WORD);

  wbuf = (WORD*)malloc(wxferByte*wlen);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    return ALLOC_ERROR;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  wlen = 8;
  addr = mbrReg;
  ret = wr_rd(MEM, addr, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);

  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI WRITE/READ 16B WRAP");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr16_rd16_wrap_32B (DWORD cs)
{
  int ret;

  DWORD addr;
  DWORD wlen = 16;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_2;
  DWORD rburst = WRAP;
  DWORD rsize  = BYTE_2;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wxferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI WRITE/READ 32B WRAP 16-bit\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    return ret;
  }
  setWrapSize (WRAP_32B, cs);
  ret = set_cr_wrapsize (WRAP_32B, WRAP2INCR_OFF, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't set CR reg wrap size\n");
    return ret;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif
  wxferByte = 1 << wsize;
  len16 = (wxferByte*wlen)/sizeof(WORD);

  wbuf = (WORD*)malloc(wxferByte*wlen);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    return ALLOC_ERROR;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  wlen = 16;
  addr = mbrReg;
  ret = wr_rd(MEM, addr, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);

  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI WRITE/READ 32B WRAP 16-bit");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr16_rd32_wrap_32B (DWORD cs)
{
  int ret;

  DWORD addr;
  DWORD wlen = 16;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_2;
  DWORD rburst = WRAP;
  DWORD rsize  = BYTE_4;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wxferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI WRITE/READ 32B WRAP\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    return ret;
  }
  setWrapSize (WRAP_32B, cs);
  ret = set_cr_wrapsize (WRAP_32B, WRAP2INCR_OFF, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't set CR reg wrap size\n");
    return ret;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif
  wxferByte = 1 << wsize;
  len16 = (wxferByte*wlen)/sizeof(WORD);

  wbuf = (WORD*)malloc(wxferByte*wlen);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    return ALLOC_ERROR;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  wlen = 16;
  addr = mbrReg;
  ret = wr_rd(MEM, addr, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);

  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI WRITE/READ 32B WRAP");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr16_rd32_wrap_64B (DWORD cs)
{
  int ret;

  DWORD addr;
  DWORD wlen = 32;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_2;
  DWORD rburst = WRAP;
  DWORD rsize  = BYTE_4;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wxferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI WRITE/READ 64B WRAP\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    return ret;
  }
  setWrapSize (WRAP_64B, cs);
  ret = set_cr_wrapsize (WRAP_64B, WRAP2INCR_OFF, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't set CR reg wrap size\n");
    return ret;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif
  wxferByte = 1 << wsize;
  len16 = (wxferByte*wlen)/sizeof(WORD);

  wbuf = (WORD*)malloc(wxferByte*wlen);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    return ALLOC_ERROR;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  wlen = 32;
  addr = mbrReg;
  ret = wr_rd(MEM, addr, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);

  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI WRITE/READ 64B WRAP");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_outstanding_wr_rd (DWORD cs)
{
  int i, j, k;
  int ret;
  DWORD waddr[MAX_OUTSTANDING_TRANS];
  DWORD wburst[MAX_OUTSTANDING_TRANS];
  DWORD wlen[MAX_OUTSTANDING_TRANS];
  DWORD wsize[MAX_OUTSTANDING_TRANS];
  BYTE* wbuf[MAX_OUTSTANDING_TRANS];
  DWORD raddr[MAX_OUTSTANDING_TRANS];
  DWORD rburst[MAX_OUTSTANDING_TRANS];

  DWORD addr;
  DWORD size;
  DWORD pattern;
  DWORD len[] = {1, MAX_LEN};
  DWORD len16;
  DWORD wrapsize = WRAP_32B;
  DWORD wraplen;

  int xferByte;
  int xferByteMax;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI OUTSTANDING WRITE/READ\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    return ret;
  }
  setWrapSize (WRAP_32B, cs);
  ret = set_cr_wrapsize (WRAP_32B, WRAP2INCR_OFF, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't set CR reg wrap size\n");
    return ret;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif
  xferByteMax = 1 << MAX_AXI_BURST_SIZE;
  len16 = (xferByteMax*MAX_LEN)/sizeof(WORD);
  getDataPattern(&pattern);

  for (i=0; i < MAX_OUTSTANDING_TRANS; i++) {
    wbuf[i] = (BYTE*)malloc(xferByteMax*MAX_LEN);
    if (!wbuf[i]) {
      CT_ERR_MSG("Can't allocate memory for write data\n");
      return ALLOC_ERROR;
    }

    fillBuffer(pattern, (WORD*)wbuf[i], len16);
    CT_MSG("Data Pattern %d\n", i);
    printBuffer((WORD*)wbuf[i], len16);

    wburst[i] = INCR;
  }

  addr = mbrReg;
  CT_MSG("INCR Write/INCR Read ----------------------------------------\n");
  for (i = 0; i < MAX_OUTSTANDING_TRANS; i++) {
    rburst[i] = INCR;
  }

  for (k = 0; k < (sizeof(len)/sizeof(len[0])); k++) {
    CT_MSG("LEN=0x%03X --------------------------------------------------\n", len[k]);
    for (j = 0; j < MAX_OUTSTANDING_TRANS; j++) {
      wlen[j] = len[k];
    }

    for (size = 0; size <= MAX_AXI_BURST_SIZE; size++) {
      xferByte = 1 << size;

      for (i = 0; i < MAX_OUTSTANDING_TRANS; i++) {
        waddr[i] = addr + i;
        wsize[i] = size;
        raddr[i] = waddr[i];
        addr += (xferByteMax*2*MAX_LEN);
      }

      ret = sub_outstanding_wr_rd(waddr, wlen, wburst, wsize, wbuf,
                                  raddr, rburst, MAX_OUTSTANDING_TRANS, 0);

      if (ret != NO_ERROR) goto end_test;

      for (i = 0; i < MAX_OUTSTANDING_TRANS; i++) {
        waddr[i] = addr + i;
        raddr[i] = waddr[i];
        addr += (xferByteMax*2*MAX_LEN);
      }

      ret = sub_outstanding_wr_rd(waddr, wlen, wburst, wsize, wbuf,
                                  raddr, rburst, MAX_OUTSTANDING_TRANS, 1);

      if (ret != NO_ERROR) goto end_test;
    }
  }

  CT_MSG("INCR Write/WRAP Read ----------------------------------------\n");
  CT_MSG("wrapsize=0x%08X ---------------------------------------------\n", wrapsize);
  for (i = 0; i < MAX_OUTSTANDING_TRANS; i++) {
    rburst[i] = WRAP;
  }

  for (size = 0; size <= MAX_AXI_BURST_SIZE; size++) {
    xferByte = 1 << size;
    wraplen = wrapsize/xferByte;

    if ((wrapsize%xferByte) || (check_wraplen_support(wraplen) == NOT_SUPPORT)) continue;

    for (i = 0; i < MAX_OUTSTANDING_TRANS; i++) {
      waddr[i] = addr;
      wlen[i] = wraplen;
      wsize[i] = size;
      raddr[i] = waddr[i] + (i*xferByte)%wrapsize;
      addr += wrapsize*2;
    }

    ret = sub_outstanding_wr_rd(waddr, wlen, wburst, wsize, wbuf,
                                raddr, rburst, MAX_OUTSTANDING_TRANS, 0);

    if (ret != NO_ERROR) goto end_test;

    for (i = 0; i < MAX_OUTSTANDING_TRANS; i++) {
      waddr[i] = addr;
      raddr[i] = waddr[i] + (i*xferByte)%wrapsize;
      addr += wrapsize*2;
    }

    ret = sub_outstanding_wr_rd(waddr, wlen, wburst, wsize, wbuf,
                                raddr, rburst, MAX_OUTSTANDING_TRANS, 1);

    if (ret != NO_ERROR) goto end_test;
  }

  addr += (xferByteMax*2*MAX_LEN - addr%(xferByteMax*2*MAX_LEN));

  CT_MSG("INCR Write/INCR&WRAP Alternative Read -----------------------\n");
  for (size = 0; size <= MAX_AXI_BURST_SIZE; size++) {
    xferByte = 1 << size;
    wraplen = wrapsize/xferByte;

    if ((wrapsize%xferByte) || (check_wraplen_support(wraplen) == NOT_SUPPORT)) continue;

    for (i = 0; i < MAX_OUTSTANDING_TRANS; i++) {
      wsize[i] = size;
      if (i%2) {
        waddr[i] = addr + i/2;
        wlen[i] = MAX_LEN;
        raddr[i] = waddr[i];
        rburst[i] = INCR;
        addr += (xferByteMax*2*MAX_LEN);
      } else {
        waddr[i] = addr;
        wlen[i] = wraplen;
        raddr[i] = waddr[i] + ((i-1)*xferByte)%wrapsize;
        rburst[i] = WRAP;
        addr += (xferByteMax*2*MAX_LEN);
      }
    }

    ret = sub_outstanding_wr_rd(waddr, wlen, wburst, wsize, wbuf,
                                raddr, rburst, MAX_OUTSTANDING_TRANS, 0);

    if (ret != NO_ERROR) goto end_test;

    for (i = 0; i < MAX_OUTSTANDING_TRANS; i++) {
      if (i%2) {
        waddr[i] = addr + i/2;
        raddr[i] = waddr[i];
        addr += (xferByteMax*2*MAX_LEN);
      } else {
        waddr[i] = addr;
        raddr[i] = waddr[i] + ((i-1)*xferByte)%wrapsize;
        addr += (xferByteMax*2*MAX_LEN);
      }
    }

    ret = sub_outstanding_wr_rd(waddr, wlen, wburst, wsize, wbuf,
                                raddr, rburst, MAX_OUTSTANDING_TRANS, 1);

    if (ret != NO_ERROR) goto end_test;
  }

 end_test:
  for (i = 0; i < MAX_OUTSTANDING_TRANS; i++) {
    if (wbuf[i]) {
      free(wbuf[i]);
    }
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI OUTSTANDING WRITE/READ");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_outstanding_wr_rd_rand (DWORD cs)
{
  int i, j, k;
  int ret;
  DWORD waddr[MAX_OUTSTANDING_TRANS];
  DWORD wburst[MAX_OUTSTANDING_TRANS];
  DWORD wlen[MAX_OUTSTANDING_TRANS];
  DWORD wsize[MAX_OUTSTANDING_TRANS];
  BYTE* wbuf[MAX_OUTSTANDING_TRANS];
  DWORD raddr[MAX_OUTSTANDING_TRANS];
  DWORD rburst[MAX_OUTSTANDING_TRANS];
  DWORD outstanding_cnt;

  DWORD pattern;
  DWORD len16;
  DWORD wrapsize;
  DWORD wrappattern;
  DWORD wrapnum;

  int xferByte;
  int xferByteMax;
  DWORD mbrReg;
  DWORD devtype;
  DWORD devlower, devupper;
  BYTE gen = 0;
  DWORD adrc, upper, lower;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI OUTSTANDING RANDOM WRITE/READ\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    return ret;
  }
#ifdef STRESS_TEST
  if (cs == CS1_SEL) {
    devtype = CS1_DEVTYPE;
  } else {
    devtype = CS0_DEVTYPE;
  }
#else
  getDevType(&devtype, cs);
#endif
  wrapnum = sizeof(WRAP_BURST[devtype])/sizeof(WRAP_BURST[devtype][0]);
  if (devtype == PSRAM) {
    devlower = 0;
    devupper = PSRAM_SIZE - 1;
  } else {
    devlower = mbrReg;
    devupper = FLASH_SIZE - 1;
#ifdef STRESS_TEST
    if(!cs) devupper = (CS1_MEM_BASE-1);
#endif
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif
  xferByteMax = 1 << MAX_AXI_BURST_SIZE;
  len16 = (xferByteMax*MAX_LEN)/sizeof(WORD);
  getDataPattern(&pattern);

  for (i=0; i < MAX_OUTSTANDING_TRANS; i++) {
    wbuf[i] = (BYTE*)malloc(xferByteMax*MAX_LEN);
    if (!wbuf[i]) {
      CT_ERR_MSG("Can't allocate memory for write data\n");
      return ALLOC_ERROR;
    }

    fillBuffer(pattern, (WORD*)wbuf[i], len16);
    CT_MSG("Data Pattern %d\n", i);
    printBuffer((WORD*)wbuf[i], len16);

    wburst[i] = INCR;
  }

  for (j=0; j<500; j++) {
    CT_MSG("Count %d\n", j);
    wrappattern = genRndDataLimit(wrapnum-1);
    wrapsize = WRAP_BURST[devtype][wrappattern][0];
    setWrapSize (wrapsize, cs);
    ret = set_cr_wrapsize (wrapsize, WRAP2INCR_OFF, cs);
    if (ret != NO_ERROR) {
      CT_ERR_MSG("Can't set CR reg wrap size\n");
      goto end_test;
    }
    outstanding_cnt = 0;
    while (outstanding_cnt < 2) outstanding_cnt = genRndDataLimit(MAX_OUTSTANDING_TRANS);

    for (i = 0; i < MAX_OUTSTANDING_TRANS; i++) {
      rburst[i] = FIXED;
      while (rburst[i] == FIXED) rburst[i] = genRndDataLimit(WRAP);
      if (rburst[i] == INCR) {
        wsize[i] = genRndDataLimit(MAX_AXI_BURST_SIZE);
        wlen[i] = genRndLen();
      } else {
        do {
          wsize[i] = genRndDataLimit(MAX_AXI_BURST_SIZE);
          xferByte = 1 << wsize[i];
          wlen[i] = wrapsize/xferByte;
        } while ((wrapsize%xferByte) || (check_wraplen_support(wlen[i]) == NOT_SUPPORT));
      }
      do {
        waddr[i] = 0;
        while (waddr[i] <= mbrReg) {
          waddr[i] = genRndAddr();
          if (rburst[i] == WRAP) {
            waddr[i] -= waddr[i]%wrapsize;
          }
        }
#ifdef STRESS_TEST
        if(!cs) waddr[i] &= (CS1_MEM_BASE-1);
#endif
        for(adrc = 0; adrc < i; adrc++) {
          if((waddr[adrc] & devupper) - devlower >= (xferByteMax * MAX_LEN)) {
            lower = (waddr[adrc] & devupper) - (xferByteMax * MAX_LEN);
          } else {
            lower = devlower;
          }
          if((waddr[adrc] & devupper) <= (devupper - (xferByteMax * MAX_LEN))) {
            upper = (waddr[adrc] & devupper) + (xferByteMax * MAX_LEN);
          } else {
            upper = devupper;
          }
          if(((waddr[i] & devupper) > lower) && ((waddr[i] & devupper) < upper)) {
            gen = 1;
            break;
          } else {
            gen = 0;
          }
        }
      } while(gen == 1);
      if (rburst[i] == WRAP) {
        k = genRndDataLimit(wlen[i]-1);
        raddr[i] = waddr[i] + k*xferByte;
//        CT_MSG("r 0x%08x w 0x%08X len 0x%08X\n", raddr[i], waddr[i], wlen[i]);
      } else {
        raddr[i] = waddr[i];
      }
    }
    ret = sub_outstanding_wr_rd(waddr, wlen, wburst, wsize, wbuf,
                                raddr, rburst, outstanding_cnt, 0);
    if (ret != NO_ERROR) goto end_test;
  }
 end_test:
  for (i = 0; i < MAX_OUTSTANDING_TRANS; i++) {
    if (wbuf[i]) {
      free(wbuf[i]);
    }
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI OUTSTANDING RANDOM WRITE/READ");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_unsupporetd_wr_rd (DWORD cs)
{
  int ret = NO_ERROR;
  int i;

  DWORD waddr;
  DWORD wlen   = 512;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_2;
  DWORD raddr;
  DWORD rburst = INCR;
  DWORD rsize;
  
  DWORD wlenHold;
  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wXferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI UNSUPPORTED WRITE/READ\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif
  wXferByte = 1 << wsize;
  len16 = (wXferByte*wlen)/sizeof(WORD);

  wbuf = (WORD*)malloc(wXferByte*wlen);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    return ALLOC_ERROR;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  CT_MSG("ADDR[0] w/ AWSIZE=1 ARSIZE=1 --------------------------\n");
  wsize = BYTE_2;
  rsize = BYTE_2;
  wlen = 1;
  for (i = 1; i < 2; i++) {
    waddr = i + mbrReg;
    raddr = waddr;
    ret = wr_rd(MEM, waddr, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);
    if (ret != NO_ERROR) {
      goto end_test;
    }
    ret = sub_concurrent_wr_rd(MEM, waddr, wlen, wburst, wsize, (BYTE*)wbuf, raddr, rburst, rsize);
    if (ret != NO_ERROR) {
      goto end_test;
    }
  }

  CT_MSG("ADDR[0],ADDR[1] w/ AWSIZE=1 ARSIZE=2 ------------------\n");
  wsize = BYTE_2;
  rsize = BYTE_4;
  wlenHold = 2;
  for (i = 1; i < 4; i++) {
    waddr = i + mbrReg;
    raddr = waddr;
    if ((waddr%4 >= 2) && (wlenHold%2 == 0)) {
      wlen = wlenHold - 1;
    }
    else {
      wlen = wlenHold;
    }
    ret = wr_rd(MEM, waddr, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);
    if (ret != NO_ERROR) {
      goto end_test;
    }
    ret = sub_concurrent_wr_rd(MEM, waddr, wlen, wburst, wsize, (BYTE*)wbuf, raddr, rburst, rsize);
    if (ret != NO_ERROR) {
      goto end_test;
    }
  }

 end_test:
  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI UNSUPPORTED WRITE/READ");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_slave_error (DWORD cs)
{
  int ret = NO_ERROR;
  DWORD addr;
  DWORD wlen = 16;
  DWORD wburst;
  DWORD wsize  = BYTE_4;
  DWORD rlen = wlen;
  DWORD rburst;
  DWORD rsize  = BYTE_4;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  WORD* rbuf;
  int wXferByte;
  int rXferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI ERROR WRITE/READ\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif
  wXferByte = 1 << wsize;
  rXferByte = 1 << rsize;

  len16 = (wXferByte*wlen)/sizeof(WORD);

  wbuf = (WORD*)malloc(wXferByte*wlen);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    return ALLOC_ERROR;
  }
  rbuf = (WORD*)malloc(rXferByte*rlen);
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  rburst = FIXED;
  wburst = FIXED;
  rsize = BYTE_2;
  wsize = BYTE_2;
  addr = mbrReg;
  ret = rd_slave_error(MEM, addr, rlen, rburst, rsize, rbuf); if (ret != NO_ERROR) goto end_test;
  ret = wr_slave_error(MEM, addr, wlen, wburst, wsize, wbuf); if (ret != NO_ERROR) goto end_test;

  wburst = WRAP;
  ret = wr_slave_error(MEM, addr, wlen, wburst, wsize, wbuf); if (ret != NO_ERROR) goto end_test;

  rburst = INCR;
  wburst = INCR;

#ifdef BURST_SIZE_4
  rlen = 1;
  wlen = 1;
  rsize = BYTE_16;
  wsize = BYTE_16;
  ret = rd_slave_error(MEM, addr, rlen, rburst, rsize, rbuf); if (ret != NO_ERROR) goto end_test;
  ret = wr_slave_error(MEM, addr, wlen, wburst, wsize, wbuf); if (ret != NO_ERROR) goto end_test;
#endif

 end_test:
  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI ERROR WRITE/READ");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_concurrent_wr_rd (DWORD cs)
{
  int ret;
  int i, j;

  DWORD waddr;
  DWORD wlen;
  DWORD wburst = INCR;
  DWORD wsize;
  DWORD raddr;
  DWORD rlen;
  DWORD rburst;
  DWORD rsize;
  DWORD wrapsize = WRAP_32B;

  DWORD pattern;
  DWORD len[] = {1, MAX_LEN};
  DWORD len16;
  BYTE* wbuf;
  int xferByteMax;
  int wxferByte;
  int rxferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop, mbrReg1;
#endif

  CT_MSG(">> AXI CONCURRENT WRITE/READ\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
  setWrapSize (wrapsize, cs);
  ret = set_cr_wrapsize (WRAP_32B, WRAP2INCR_OFF, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't set CR reg wrap size\n");
    return ret;
  }
#ifdef STRESS_TEST
  ret = getMemBaseAddress (&mbrReg1, 1);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif
  xferByteMax = 1 << MAX_AXI_BURST_SIZE;
  len16 = (xferByteMax*MAX_LEN)/sizeof(WORD);

  wbuf = (BYTE*)malloc(xferByteMax*MAX_LEN);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    return ALLOC_ERROR;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, (WORD*)wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer((WORD*)wbuf, len16);

  CT_MSG("Concurrent INCR Write/INCR Read ----------------------------------------\n");
  rburst = INCR;

  for (j = 0; j < (sizeof(len)/sizeof(len[0])); j++) {
    CT_MSG("LEN=0x%03X --------------------------------------------------\n", len[j]);

    for (wsize = 0; wsize <= MAX_AXI_BURST_SIZE; wsize++) {
      wxferByte = 1 << wsize;
      for (rsize = 0; rsize <= MAX_AXI_BURST_SIZE; rsize++) {
        rxferByte = 1 << rsize;
        CT_MSG("INCR WSIZE=%d RSIZE=%d---------------------------------------\n", wsize, rsize);

        if (wxferByte < rxferByte) {
          wlen = len[j] * (rxferByte / wxferByte);
          if (wlen > MAX_LEN) wlen = MAX_LEN;
        } else {
          if (len[j] == 1) wlen = 1;
          else wlen = len[j] / (wxferByte / rxferByte);
        }

        for (i = 0; i < MAX_ADDR_LOOP; i++) {
          waddr = mbrReg + i;
          raddr = waddr;

          ret = sub_concurrent_wr_rd(MEM, waddr, wlen, wburst, wsize, (BYTE*)wbuf, raddr, rburst, rsize);
          if (ret != NO_ERROR) goto end_test;
        }
      }
    }
  }

  CT_MSG("Concurrent INCR Write/WRAP Read ----------------------------------------\n");
  rburst = WRAP;

  for (wsize = 0; wsize <= MAX_AXI_BURST_SIZE; wsize++) {
    wxferByte = 1 << wsize;
    wlen = wrapsize/wxferByte;
    if ((wlen > MAX_LEN) || (wrapsize%wxferByte)) continue;

    for (rsize = 0; rsize <= MAX_AXI_BURST_SIZE; rsize++) {
      rxferByte = 1 << rsize;
      rlen = wrapsize/rxferByte;
      if ((check_wraplen_support(rlen) == NOT_SUPPORT) || (wrapsize%rxferByte)) continue;
      CT_MSG("INCR WSIZE=%d WRAP RSIZE=%d----------------------------------\n", wsize, rsize);

      for (i=0; i<rlen; i++) {
        waddr = mbrReg + i*wrapsize;
        raddr = waddr+i*rxferByte;

        ret = sub_concurrent_wr_rd(MEM, waddr, wlen, wburst, wsize, (BYTE*)wbuf, raddr, rburst, rsize);
        if (ret != NO_ERROR) goto end_test;
      }
    }
  }

  ///------
  CT_MSG("Concurrent INCR Write/INCR Read TOP ------------------------------------\n");
  rburst = INCR;

  for (wsize = 0; wsize <= MAX_AXI_BURST_SIZE; wsize++) {
    wxferByte = 1 << wsize;
    wlen = 1;
    rsize = wsize;

#ifdef STRESS_TEST
    if(!cs) waddr = mbrReg1 - wxferByte;
    else    waddr = 0 - wxferByte;
#else
    waddr = 0 - wxferByte;
#endif
    raddr = waddr;

    CT_MSG("INCR LEN=%3d SIZE=%d ----------------------------------------\n", wlen, rsize);
    ret = sub_concurrent_wr_rd(MEM, waddr, wlen, wburst, wsize, (BYTE*)wbuf, raddr, rburst, rsize);
    if (ret != NO_ERROR) goto end_test;

    waddr = mbrReg;
    raddr = waddr;

    ret = sub_concurrent_wr_rd(MEM, waddr, wlen, wburst, wsize, (BYTE*)wbuf, raddr, rburst, rsize);
    if (ret != NO_ERROR) goto end_test;
  }
  ///------
 end_test:
  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI CONCURRENT WRITE/READ");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_concurrent_wr_rd_rand (DWORD cs)
{
  int ret;
  int tc;

  DWORD waddr;
  DWORD wlen;
  DWORD wburst = INCR;
  DWORD wsize;
  DWORD raddr;
  DWORD rlen;
  DWORD rburst;
  DWORD rsize;
  DWORD wrapsize;
  DWORD wrappattern;
  DWORD wrapnum;

  DWORD pattern;
  DWORD len16;
  BYTE* wbuf;
  int xferByteMax;
  int wxferByte;
  int rxferByte;
  DWORD mbrReg;
  DWORD devtype;
#ifdef STRESS_TEST
  DWORD end_loop, mbrReg1;
#endif

  CT_MSG(">> AXI CONCURRENT RANDOM WRITE/READ\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
#ifdef STRESS_TEST
  if (cs == CS1_SEL) {
    devtype = CS1_DEVTYPE;
  } else {
    devtype = CS0_DEVTYPE;
  }
#else
  getDevType(&devtype, cs);
#endif
  wrapnum = sizeof(WRAP_BURST[devtype])/sizeof(WRAP_BURST[devtype][0]);
#ifdef STRESS_TEST
  ret = getMemBaseAddress (&mbrReg1, 1);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif
  xferByteMax = 1 << MAX_AXI_BURST_SIZE;
  len16 = (xferByteMax*MAX_LEN)/sizeof(WORD);

  wbuf = (BYTE*)malloc(xferByteMax*MAX_LEN);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    return ALLOC_ERROR;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, (WORD*)wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer((WORD*)wbuf, len16);

  for (tc=0; tc<500; tc++) {
    CT_MSG("Test Count %d\n", tc);

    rburst = FIXED;
    while (rburst == FIXED) rburst = genRndDataLimit(WRAP);

    if (rburst == WRAP) {
      wrappattern = genRndDataLimit(wrapnum-1);
      wrapsize = WRAP_BURST[devtype][wrappattern][0];
      setWrapSize (wrapsize, cs);
      ret = set_cr_wrapsize (wrapsize, WRAP2INCR_OFF, cs);
      if (ret != NO_ERROR) {
        CT_ERR_MSG("Can't set CR reg wrap size\n");
        goto end_test;
      }
      do {
        wsize = genRndDataLimit(MAX_AXI_BURST_SIZE);
        wxferByte = 1 << wsize;
        wlen = wrapsize/wxferByte;
      } while ((wrapsize%wxferByte) || (wlen > MAX_LEN));
      do {
        rsize = genRndDataLimit(MAX_AXI_BURST_SIZE);
        rxferByte = 1 << rsize;
        rlen = wrapsize/rxferByte;
      } while ((wrapsize%rxferByte) || (check_wraplen_support(rlen) == NOT_SUPPORT));

      waddr = 0;
      while (waddr <= mbrReg) {
        waddr = genRndAddr();
        waddr -= waddr%wrapsize;
      }
#ifdef STRESS_TEST
      if(!cs) waddr &= (CS1_MEM_BASE-1);
#endif
      raddr = genRndDataLimit(rlen-1);
      raddr = waddr + raddr*rxferByte;
    } else {
      wsize = genRndDataLimit(MAX_AXI_BURST_SIZE);
      wxferByte = 1 << wsize;
      rsize = genRndDataLimit(MAX_AXI_BURST_SIZE);
      rxferByte = 1 << rsize;

      if (wxferByte < rxferByte) {
        wlen = genRndLen();
      } else {
        do {
          wlen = genRndLen();
        } while (wlen*wxferByte > MAX_LEN*rxferByte);
      }

      waddr = 0;
      while (waddr <= mbrReg) {
        waddr = genRndAddr();
      }
#ifdef STRESS_TEST
      if(!cs) waddr &= (CS1_MEM_BASE-1);
#endif
      raddr = waddr;
    }

    ret = sub_concurrent_wr_rd(MEM, waddr, wlen, wburst, wsize, (BYTE*)wbuf, raddr, rburst, rsize);
    if (ret != NO_ERROR) goto end_test;
  }
 end_test:
  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI CONCURRENT RANDOM WRITE/READ");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

DWORD rwds_stall_rburst[3][3] = {{INCR,INCR,INCR},{FIXED,INCR,INCR},{INCR,FIXED,FIXED}};

int axi_rd_timeout (DWORD cs)
{
  int ret = NO_ERROR;
  int i, j, k;

  DWORD addr;
  DWORD wlen = 16;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_2;
  DWORD rburst[3];
  DWORD rsize  = BYTE_2;
  DWORD trans = 3;
  DWORD devtype;
  DWORD rburstPattern = 0;

  BYTE wresp;
  BYTE rresp[MAX_LEN];
  DWORD waddr;
  DWORD raddr;
  DWORD rlen;
  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  WORD* rbuf;
  int wXferByte;
  int rXferByte;
  DWORD mbrReg;
  WORD crData, crwData;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI READ TIMEOUT\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
  CT_MSG("Set CRT=1 --------------------------------\n");
  setConfigRegTarget(1, cs);
  RPC2_READ(mbrReg, 1, &crData);
  CT_MSG("Read CR Reg = 0x%04X\n", crData);
  crwData = (crData & 0x7FFF);
  CT_MSG("Write CR Reg = 0x%04X\n", crwData);
  RPC2_WRITE(mbrReg, 1, &crwData);
  CT_MSG("Enter Deep Power Down --------------------\n");
  CT_MSG("Set CRT=0 --------------------------------\n");
  setConfigRegTarget(0, cs);

#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif
  wXferByte = 1 << wsize;
  rXferByte = 1 << rsize;

  rlen = ((wXferByte*wlen)+(rXferByte-1))/rXferByte;
  len16 = (wXferByte*wlen)/sizeof(WORD);

  wbuf = (WORD*)malloc(wXferByte*wlen*trans);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  rbuf = (WORD*)malloc(rXferByte*rlen*trans);
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16*trans);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16*trans);

  addr = mbrReg;
  rburst[0] = rwds_stall_rburst[rburstPattern][0];
  rburst[1] = rwds_stall_rburst[rburstPattern][1];
  rburst[2] = rwds_stall_rburst[rburstPattern][2];

#ifdef STRESS_TEST
  if (cs == CS1_SEL) {
    devtype = CS1_DEVTYPE;
  } else {
    devtype = CS0_DEVTYPE;
  }
#else
  getDevType(&devtype, cs);
#endif

  for (i = 0; i < trans; i++) {
    waddr = addr + wXferByte*len16*i*i;
    CT_MSG("Outstanding Write: addr=0x%08X len=0x%03X burst=%1d size=%1d\n", waddr, wlen, wburst, wsize);
    writeBurst(MEM, waddr, wlen, wburst, wsize, &wbuf[len16*i]);
  }
  for (i = 0; i < trans; i++) {
    getWriteResp(MEM, &wresp);
    if (wresp) {
      CT_ERR_MSG("Write Response 0x%x\n", wresp);
      ret = RESP_ERROR;
    }
  }

  CT_MSG("Read : addr=0x%08X len=0x%03X burst=%1d size=%1d\n", addr, rlen, rburst[0], rsize);
  readBurst(MEM, addr, rlen, rburst[0], rsize);
#ifdef STRESS_TEST
  getReadDataRespStress(MEM, addr, rlen, rsize, rbuf, rresp);
#else
  getReadDataResp(MEM, rlen, rsize, rbuf, rresp);
#endif
  for (i = 0; i < RDS_STALL_LEN; i++) {
    if (devtype == 0) {
      if (rresp[i]) {
        CT_ERR_MSG("Read Response %d: 0x%x\n", i, rresp[i]);
        ret = RESP_ERROR;
      }
    } else {
      if (rresp[i] != SLVERR) {
        CT_ERR_MSG("Read Response %d: 0x%x\n", i, rresp[i]);
        ret = RESP_ERROR;
      }
    }
  }

  for (i = RDS_STALL_LEN; i < rlen; i++) {
    if (rresp[i] != SLVERR) {
      CT_ERR_MSG("Read Response %d: 0x%x\n", i, rresp[i]);
      ret = RESP_ERROR;
    }
  }

  rsize  = BYTE_4;
  rlen /= 2;
  CT_MSG("Read : addr=0x%08X len=0x%03X burst=%1d size=%1d\n", addr, rlen, rburst[0], rsize);
  readBurst(MEM, addr, rlen, rburst[0], rsize);
#ifdef STRESS_TEST
  getReadDataRespStress(MEM, addr, rlen, rsize, rbuf, rresp);
#else
  getReadDataResp(MEM, rlen, rsize, rbuf, rresp);
#endif
  for (i = 0; i < RDS_STALL_LEN/2; i++) {
    if (devtype == 0) {
      if (rresp[i]) {
        CT_ERR_MSG("Read Response %d: 0x%x\n", i, rresp[i]);
        ret = RESP_ERROR;
      }
    } else {
      if (rresp[i] != SLVERR) {
        CT_ERR_MSG("Read Response %d: 0x%x\n", i, rresp[i]);
        ret = RESP_ERROR;
      }
    }
  }
  for (i = RDS_STALL_LEN/2; i < rlen; i++) {
    if (rresp[i] != SLVERR) {
      CT_ERR_MSG("Read Response %d: 0x%x\n", i, rresp[i]);
      ret = RESP_ERROR;
    }
  }

  rsize  = BYTE_2;
  rlen = ((wXferByte*wlen)+(rXferByte-1))/rXferByte;

  do {
    k = 0;
    for (i = 0; i < trans; i++) {
      raddr = addr + rXferByte*rlen*i*i;
      CT_MSG("Outstanding Read : addr=0x%08X len=0x%03X burst=%1d size=%1d\n", raddr, rlen, rburst[i], rsize);
      readBurst(MEM, raddr, rlen, rburst[i], rsize);
    }
    for (i = 0; i < trans; i++) {
#ifdef STRESS_TEST
      getReadDataRespStress(MEM, raddr, rlen, rsize, &rbuf[len16*i], rresp);
#else
      getReadDataResp(MEM, rlen, rsize, &rbuf[len16*i], rresp);
#endif
      for (j = 0; j < rlen; j++) {

#if (RPC2_CTRL_IP_VER >= 230)
        if ((devtype == 0) && (rburst[i] == INCR) && (j < RDS_STALL_LEN)) {
#else
        if ((devtype == 0) && (rburst[i] == INCR) && (k < RDS_STALL_LEN)) {
#endif
          if (rresp[j]) {
            CT_ERR_MSG("Read Response %d: 0x%x\n", j, rresp[j]);
            ret = RESP_ERROR;
          }
        } else {
          if (rresp[j] != SLVERR) {
            CT_ERR_MSG("Read Response %d: 0x%x\n", j, rresp[j]);
            ret = RESP_ERROR;
          }
        }
        if (rburst[i] == INCR) {
          k++;
        } else {
          k = 0;
        }
      }
    }
    rburstPattern ++;
    if (rburstPattern > 2) {
      rburstPattern = 0;
    }
    for (i = 0; i < 3; i++) {
      rburst[i] = rwds_stall_rburst[rburstPattern][i];
    }
  } while (rburstPattern);

 end_test:
  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  if (devtype == PSRAM) {
    waitUs(150);
  }
  CT_MSG("Set CRT=1 --------------------------------\n");
  setConfigRegTarget(1, cs);
  CT_MSG("Write CR Reg = 0x%04X\n", crData);
  RPC2_WRITE(mbrReg, 1, &crData);
  CT_MSG("Return from Deep Power Down --------------------\n");
  CT_MSG("Set CRT=0 --------------------------------\n");
  setConfigRegTarget(0, cs);

  CT_MSG("<< AXI READ TIMEOUT");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

/// spec v1.7
int axi_slave_error_rsto (DWORD cs)
{
  int ret = NO_ERROR;
  DWORD wlen = 1;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_2;
  DWORD rlen = wlen;
  DWORD rburst = INCR;
  DWORD rsize  = BYTE_2;

  DWORD addr;
  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  WORD* rbuf;
  int wxferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI ERROR RSTO#\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif
  wxferByte = 1 << wsize;
  len16 = ((wxferByte*wlen)+(sizeof(WORD)-1))/sizeof(WORD);

  wbuf = (WORD*)malloc(len16*sizeof(WORD));
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  rbuf = (WORD*)malloc(len16*sizeof(WORD));
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  addr = mbrReg;
  ret = rd_slave_error(MEM, addr, rlen, rburst, rsize, rbuf); if (ret != NO_ERROR) goto end_test;
  ret = wr_slave_error(MEM, addr, wlen, wburst, wsize, wbuf); if (ret != NO_ERROR) goto end_test;

end_test:
  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI ERROR RSTO#");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr8_rd8_len1 (DWORD cs)
{
  int ret;
  int i;

  DWORD wlen = 1;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_1;
  DWORD rburst = INCR;
  DWORD rsize  = BYTE_1;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wxferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI WRITE/READ 1B\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }

#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif
  wxferByte = 1 << wsize;
  len16 = ((wxferByte*wlen)+(sizeof(WORD)-1))/sizeof(WORD);

  wbuf = (WORD*)malloc(len16*sizeof(WORD));
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  for (i = 0; i < MAX_ADDR_LOOP; i++) {
    ret = wr_rd(MEM, i+mbrReg, wlen, wburst, wsize, (BYTE *)wbuf, rburst, rsize);
    if (ret != NO_ERROR) {
      break;
    }
  }

 end_test:
  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI WRITE/READ 1B");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr8_rd8_lenmax (DWORD cs)
{
  int ret;
  int i;

  DWORD wlen = MAX_LEN;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_1;
  DWORD rburst = INCR;
  DWORD rsize  = BYTE_1;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wxferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI WRITE/READ 256B\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }

#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif
  wxferByte = 1 << wsize;
  len16 = ((wxferByte*wlen)+(sizeof(WORD)-1))/sizeof(WORD);

  wbuf = (WORD*)malloc(len16*sizeof(WORD));
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  for (i = 0; i < MAX_ADDR_LOOP; i++) {
    ret = wr_rd(MEM, i+mbrReg, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);
    if (ret != NO_ERROR) {
      break;
    }
  }

 end_test:
  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI WRITE/READ 256B");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr8_rd8_rand (DWORD cs)
{
  int ret;
  int i;

  DWORD addr;
  DWORD wlen = MAX_LEN;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_1;
  DWORD rburst = INCR;
  DWORD rsize  = BYTE_1;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wxferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI WRITE/READ RANDOM 8-bit\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }

#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif
  wxferByte = 1 << wsize;
  len16 = ((wxferByte*wlen)+(sizeof(WORD)-1))/sizeof(WORD);

  wbuf = (WORD*)malloc(len16*sizeof(WORD));
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  for (i = 0; i < MAX_LEN; i++) {
    addr = 0;
    while (addr <= mbrReg) {
      addr = genRndAddr();
    }
#ifdef STRESS_TEST
    if(!cs) addr &= (CS1_MEM_BASE-1);
#endif
    wlen = genRndLen();
    ret = wr_rd(MEM, addr, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);
    if (ret != NO_ERROR) {
      break;
    }
  }

 end_test:
  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI WRITE/READ RANDOM 8-bit");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr8_rd8_wrap_16B (DWORD cs)
{
  int ret = NO_ERROR;

  DWORD wlen = 16;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_1;
  DWORD rburst = WRAP;
  DWORD rsize  = BYTE_1;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  WORD* expData;
  int wxferByte;

  DWORD addr;
  WORD* rbuf;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI WRITE/READ 16B WRAP 8-bit\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
  setWrapSize (WRAP_16B, cs);
  ret = set_cr_wrapsize (WRAP_16B, WRAP2INCR_OFF, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't set CR reg wrap size\n");
    return ret;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif

  wxferByte = 1 << wsize;
  len16 = ((wxferByte*wlen)+(sizeof(WORD)-1))/sizeof(WORD);

  wbuf = (WORD*)malloc(len16*sizeof(WORD));
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  rbuf = (WORD*)malloc(len16*sizeof(WORD));
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  expData = (WORD*)malloc(len16*sizeof(WORD));
  if (!expData) {
    CT_ERR_MSG("Can't allocate memory for expected data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }

  getDataPattern(&pattern);
  //  fillBuffer(pattern, wbuf, len16);
  fillBuffer(RANDOM, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  addr = mbrReg;
  ret = wr_rd(MEM, addr, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);
  if (ret != NO_ERROR) {
    goto end_test;
  }

 end_test:
  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI WRITE/READ 16B WRAP 8-bit");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr8_rd16_lenmax (DWORD cs)
{
  int ret;
  int i;

  DWORD wlen = 512;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_1;
  DWORD rburst = INCR;
  DWORD rsize  = BYTE_2;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wxferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI WRITE/READ 512B w/ AWSIZE=0 ARSIZE=1\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif

  wxferByte = 1 << wsize;
  len16 = ((wxferByte*wlen)+(sizeof(WORD)-1))/sizeof(WORD);

  wbuf = (WORD*)malloc(len16*sizeof(WORD));
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  for (i = 0; i < MAX_ADDR_LOOP; i++) {
    ret = wr_rd(MEM, i + mbrReg, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);
    if (ret != NO_ERROR) {
      break;
    }
  }

 end_test:
  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI WRITE/READ 512B /w AWSIZE=0 ARSIZE=1");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr8_rd32_lenmax (DWORD cs)
{
  int ret;
  int i;

  DWORD wlen = 1024;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_1;
  DWORD rburst = INCR;
  DWORD rsize  = BYTE_4;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wxferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI WRITE/READ 1024B w/ AWSIZE=0 ARSIZE=2\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif

  wxferByte = 1 << wsize;
  len16 = ((wxferByte*wlen)+(sizeof(WORD)-1))/sizeof(WORD);

  wbuf = (WORD*)malloc(len16*sizeof(WORD));
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  for (i = 0; i < MAX_ADDR_LOOP; i++) {
    ret = wr_rd(MEM, i + mbrReg, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);
    if (ret != NO_ERROR) {
      break;
    }
  }

 end_test:
  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI WRITE/READ 1024B w/ AWSIZE=0 ARSIZE=2");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr16_rd8_lenmax (DWORD cs)
{
  int ret;
  int i;

  DWORD wlen = MAX_LEN;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_2;
  DWORD rburst = INCR;
  DWORD rsize  = BYTE_1;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wxferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI WRITE/READ 512B w/ AWSIZE=1 ARSIZE=0\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif

  wxferByte = 1 << wsize;
  len16 = ((wxferByte*wlen)+(sizeof(WORD)-1))/sizeof(WORD);

  wbuf = (WORD*)malloc(len16*sizeof(WORD));
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  for (i = 0; i < MAX_ADDR_LOOP; i++) {
    ret = wr_rd(MEM, i + mbrReg, wlen, wburst, wsize, (BYTE *)wbuf, rburst, rsize);
    if (ret != NO_ERROR) {
      break;
    }
  }

 end_test:
  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI WRITE/READ 512B /w AWSIZE=1 ARSIZE=0");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr8_rd16_rand (DWORD cs)
{
  int ret;
  int i;

  DWORD addr;
  DWORD wlen = 512;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_1;
  DWORD rburst = INCR;
  DWORD rsize  = BYTE_2;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wxferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI WRITE/READ RANDOM /w AWSIZE=0 ARSIZE=1\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif

  wxferByte = 1 << wsize;
  len16 = ((wxferByte*wlen)+(sizeof(WORD)-1))/sizeof(WORD);

  wbuf = (WORD*)malloc(len16*sizeof(WORD));
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  for (i = 0; i < MAX_ADDR_LOOP; i++) {
    addr = 0;
    while (addr <= mbrReg) {
      addr = genRndAddr();
    }
#ifdef STRESS_TEST
    if(!cs) addr &= (CS1_MEM_BASE-1);
#endif
    wlen = genRndLen();
    ret = wr_rd(MEM, addr, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);
    if (ret != NO_ERROR) {
      break;
    }
  }

 end_test:
  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI WRITE/READ RANDOM /w AWSIZE=0 ARSIZE=1");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr8_rd32_rand (DWORD cs)
{
  int ret;
  int i;

  DWORD addr;
  DWORD wlen = 1024;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_1;
  DWORD rburst = INCR;
  DWORD rsize  = BYTE_4;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wxferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI WRITE/READ RANDOM /w AWSIZE=0 ARSIZE=2\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif

  wxferByte = 1 << wsize;
  len16 = ((wxferByte*wlen)+(sizeof(WORD)-1))/sizeof(WORD);

  wbuf = (WORD*)malloc(len16*sizeof(WORD));
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  for (i = 0; i < MAX_ADDR_LOOP; i++) {
    addr = 0;
    while (addr <= mbrReg) {
      addr = genRndAddr();
    }
#ifdef STRESS_TEST
    if(!cs) addr &= (CS1_MEM_BASE-1);
#endif
    wlen = genRndLen();
    ret = wr_rd(MEM, addr, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);
    if (ret != NO_ERROR) {
      break;
    }
  }

 end_test:
  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI WRITE/READ RANDOM /w AWSIZE=0 ARSIZE=2");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr16_rd8_rand (DWORD cs)
{
  int ret;
  int i;

  DWORD addr;
  DWORD wlen = MAX_LEN;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_2;
  DWORD rburst = INCR;
  DWORD rsize  = BYTE_1;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wxferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI WRITE/READ RANDOM /w AWSIZE=1 ARSIZE=0\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif

  wxferByte = 1 << wsize;
  len16 = ((wxferByte*wlen)+(sizeof(WORD)-1))/sizeof(WORD);

  wbuf = (WORD*)malloc(len16*sizeof(WORD));
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  for (i = 0; i < MAX_ADDR_LOOP; i++) {
    addr = 0;
    while (addr <= mbrReg) {
      addr = genRndAddr();
    }
#ifdef STRESS_TEST
    if(!cs) addr &= (CS1_MEM_BASE-1);
#endif
    wlen = genRndLen();
    ret = wr_rd(MEM, addr, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);
    if (ret != NO_ERROR) {
      break;
    }
  }

 end_test:
  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI WRITE/READ RANDOM /w AWSIZE=1 ARSIZE=0");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr32_rd32_len1 (DWORD cs)
{
  int ret;
  int i;

  DWORD wlen = 1;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_4;
  DWORD rburst = INCR;
  DWORD rsize  = BYTE_4;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wxferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI WRITE/READ 4B /w AWSIZE=2\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    return ret;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif
  wxferByte = 1 << wsize;
  len16 = (wxferByte*wlen)/sizeof(WORD);

  wbuf = (WORD*)malloc(wxferByte*wlen);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    return ALLOC_ERROR;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  for (i = 0; i < MAX_ADDR_LOOP; i++) {
    ret = wr_rd(MEM, i+mbrReg, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);
    if (ret != NO_ERROR) {
      break;
    }
  }
  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI WRITE/READ 4B /w AWSIZE=2");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr32_rd8_lenmax (DWORD cs)
{
  int ret;
  int i;

  DWORD wlen = MAX_LEN;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_4;
  DWORD rburst = INCR;
  DWORD rsize  = BYTE_1;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wxferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI WRITE/READ 1024B w/ AWSIZE=2 ARSIZE=0\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif

  wxferByte = 1 << wsize;
  len16 = (wxferByte*wlen)/sizeof(WORD);

  wbuf = (WORD*)malloc(wxferByte*wlen);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  for (i = 0; i < MAX_ADDR_LOOP; i++) {
    ret = wr_rd(MEM, i + mbrReg, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);
    if (ret != NO_ERROR) {
      break;
    }
  }

 end_test:
  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI WRITE/READ 1024B w/ AWSIZE=2 ARSIZE=0");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr32_rd16_lenmax (DWORD cs)
{
  int ret;
  int i;

  DWORD wlen = MAX_LEN;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_4;
  DWORD rburst = INCR;
  DWORD rsize  = BYTE_2;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wxferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI WRITE/READ 1024B w/ AWSIZE=2 ARSIZE=1\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif

  wxferByte = 1 << wsize;
  len16 = (wxferByte*wlen)/sizeof(WORD);

  wbuf = (WORD*)malloc(wxferByte*wlen);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  for (i = 0; i < MAX_ADDR_LOOP; i++) {
    ret = wr_rd(MEM, i + mbrReg, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);
    if (ret != NO_ERROR) {
      break;
    }
  }

 end_test:
  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI WRITE/READ 1024B w/ AWSIZE=2 ARSIZE=1");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr32_rd32_lenmax (DWORD cs)
{
  int ret;
  int i;

  DWORD wlen = MAX_LEN;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_4;
  DWORD rburst = INCR;
  DWORD rsize  = BYTE_4;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wxferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI WRITE/READ 1024B w/ AWSIZE=2 ARSIZE=2\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif

  wxferByte = 1 << wsize;
  len16 = (wxferByte*wlen)/sizeof(WORD);

  wbuf = (WORD*)malloc(wxferByte*wlen);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  for (i = 0; i < MAX_ADDR_LOOP; i++) {
    ret = wr_rd(MEM, i + mbrReg, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);
    if (ret != NO_ERROR) {
      break;
    }
  }

 end_test:
  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI WRITE/READ 1024B w/ AWSIZE=2 ARSIZE=2");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr32_rd8_rand (DWORD cs)
{
  int ret;
  int i;

  DWORD addr;
  DWORD wlen = MAX_LEN;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_4;
  DWORD rburst = INCR;
  DWORD rsize  = BYTE_1;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wxferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI WRITE/READ RANDOM /w AWSIZE=2 ARSIZE=0\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif

  wxferByte = 1 << wsize;
  len16 = (wxferByte*wlen)/sizeof(WORD);

  wbuf = (WORD*)malloc(wxferByte*wlen);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  for (i = 0; i < MAX_ADDR_LOOP; i++) {
    addr = 0;
    while (addr <= mbrReg) {
      addr = genRndAddr();
    }
#ifdef STRESS_TEST
    if(!cs) addr &= (CS1_MEM_BASE-1);
#endif
    wlen = genRndLen();
    ret = wr_rd(MEM, addr, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);
    if (ret != NO_ERROR) {
      break;
    }
  }

 end_test:
  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI WRITE/READ RANDOM /w AWSIZE=2 ARSIZE=0");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr32_rd16_rand (DWORD cs)
{
  int ret;
  int i;

  DWORD addr;
  DWORD wlen = MAX_LEN;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_4;
  DWORD rburst = INCR;
  DWORD rsize  = BYTE_2;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wxferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI WRITE/READ RANDOM /w AWSIZE=2 ARSIZE=1\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif

  wxferByte = 1 << wsize;
  len16 = (wxferByte*wlen)/sizeof(WORD);

  wbuf = (WORD*)malloc(wxferByte*wlen);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  for (i = 0; i < MAX_ADDR_LOOP; i++) {
    addr = 0;
    while (addr <= mbrReg) {
      addr = genRndAddr();
    }
#ifdef STRESS_TEST
    if(!cs) addr &= (CS1_MEM_BASE-1);
#endif
    wlen = genRndLen();
    ret = wr_rd(MEM, addr, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);
    if (ret != NO_ERROR) {
      break;
    }
  }

 end_test:
  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI WRITE/READ RANDOM /w AWSIZE=2 ARSIZE=1");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr32_rd32_rand (DWORD cs)
{
  int ret;
  int i;

  DWORD addr;
  DWORD wlen = MAX_LEN;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_4;
  DWORD rburst = INCR;
  DWORD rsize  = BYTE_4;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wxferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI WRITE/READ RANDOM /w AWSIZE=2 ARSIZE=2\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif

  wxferByte = 1 << wsize;
  len16 = (wxferByte*wlen)/sizeof(WORD);

  wbuf = (WORD*)malloc(wxferByte*wlen);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  for (i = 0; i < MAX_ADDR_LOOP; i++) {
    addr = 0;
    while (addr <= mbrReg) {
      addr = genRndAddr();
    }
#ifdef STRESS_TEST
    if(!cs) addr &= (CS1_MEM_BASE-1);
#endif
    wlen = genRndLen();
    ret = wr_rd(MEM, addr, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);
    if (ret != NO_ERROR) {
      break;
    }
  }

 end_test:
  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI WRITE/READ RANDOM /w AWSIZE=2 ARSIZE=2");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr32_rd8_wrap_16B (DWORD cs)
{
  int ret = NO_ERROR;

  DWORD wlen = 4;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_4;
  DWORD rburst = WRAP;
  DWORD rsize  = BYTE_1;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wxferByte;

  DWORD addr;
  WORD* rbuf;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI WRITE/READ 16B WRAP W32/R8-bit W/R\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
  setWrapSize (WRAP_16B, cs);
  ret = set_cr_wrapsize (WRAP_16B, WRAP2INCR_OFF, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't set CR reg wrap size\n");
    return ret;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif

  wxferByte = 1 << wsize;
  len16 = (wxferByte*wlen)/sizeof(WORD);

  wbuf = (WORD*)malloc(wxferByte*wlen);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  rbuf = (WORD*)malloc(wxferByte*wlen);
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  addr = mbrReg;
  ret = wr_rd(MEM, addr, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);
  if (ret != NO_ERROR) {
    goto end_test;
  }

 end_test:
  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI WRITE/READ 16B WRAP W32/R8-bit W/R\n");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr32_rd16_wrap_16B (DWORD cs)
{
  int ret = NO_ERROR;

  DWORD wlen = 4;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_4;
  DWORD rburst = WRAP;
  DWORD rsize  = BYTE_2;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wxferByte;

  DWORD addr;
  WORD* rbuf;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI WRITE/READ 16B WRAP W32/R16-bit W/R\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
  setWrapSize (WRAP_16B, cs);
  ret = set_cr_wrapsize (WRAP_16B, WRAP2INCR_OFF, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't set CR reg wrap size\n");
    return ret;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif

  wxferByte = 1 << wsize;
  len16 = (wxferByte*wlen)/sizeof(WORD);

  wbuf = (WORD*)malloc(wxferByte*wlen);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  rbuf = (WORD*)malloc(wxferByte*wlen);
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  addr = mbrReg;
  ret = wr_rd(MEM, addr, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);
  if (ret != NO_ERROR) {
    goto end_test;
  }

 end_test:
  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI WRITE/READ 16B WRAP W32/R16-bit W/R\n");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr32_rd32_wrap_16B (DWORD cs)
{
  int ret = NO_ERROR;

  DWORD wlen = 4;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_4;
  DWORD rburst = WRAP;
  DWORD rsize  = BYTE_4;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wxferByte;

  DWORD addr;
  WORD* rbuf;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI WRITE/READ 16B WRAP W32/R32-bit\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
  setWrapSize (WRAP_16B, cs);
  ret = set_cr_wrapsize (WRAP_16B, WRAP2INCR_OFF, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't set CR reg wrap size\n");
    return ret;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif

  wxferByte = 1 << wsize;
  len16 = (wxferByte*wlen)/sizeof(WORD);

  wbuf = (WORD*)malloc(wxferByte*wlen);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }
  rbuf = (WORD*)malloc(wxferByte*wlen);
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  addr = mbrReg;
  ret = wr_rd(MEM, addr, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);
  if (ret != NO_ERROR) {
    goto end_test;
  }

 end_test:
  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI WRITE/READ 16B WRAP W32/R32-bit\n");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr32_rd16_wrap_32B (DWORD cs)
{
  int ret;

  DWORD addr;
  DWORD wlen = 8;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_4;
  DWORD rburst = WRAP;
  DWORD rsize  = BYTE_2;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wxferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI WRITE/READ 32B WRAP W32/R16-bit\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    return ret;
  }
  setWrapSize (WRAP_32B, cs);
  ret = set_cr_wrapsize (WRAP_32B, WRAP2INCR_OFF, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't set CR reg wrap size\n");
    return ret;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif
  wxferByte = 1 << wsize;
  len16 = (wxferByte*wlen)/sizeof(WORD);

  wbuf = (WORD*)malloc(wxferByte*wlen);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    return ALLOC_ERROR;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  addr = mbrReg;
  wlen = 8;
  ret = wr_rd(MEM, addr, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);

  if (wbuf) {
    free(wbuf);
  }

#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI WRITE/READ 32B WRAP 16-bit");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr32_rd32_wrap_32B (DWORD cs)
{
  int ret;

  DWORD addr;
  DWORD wlen = 8;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_4;
  DWORD rburst = WRAP;
  DWORD rsize  = BYTE_4;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wxferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI WRITE/READ 32B WRAP W32/R32-bit\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    return ret;
  }
  setWrapSize (WRAP_32B, cs);
  ret = set_cr_wrapsize (WRAP_32B, WRAP2INCR_OFF, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't set CR reg wrap size\n");
    return ret;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif
  wxferByte = 1 << wsize;
  len16 = (wxferByte*wlen)/sizeof(WORD);

  wbuf = (WORD*)malloc(wxferByte*wlen);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    return ALLOC_ERROR;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  addr = mbrReg;
  wlen = 8;
  ret = wr_rd(MEM, addr, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);

  if (wbuf) {
    free(wbuf);
  }

#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI WRITE/READ 32B WRAP W32/R32-bit\n");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr32_rd32_wrap_64B (DWORD cs)
{
  int ret;

  DWORD addr;
  DWORD wlen = 16;
  DWORD wburst = INCR;
  DWORD wsize  = BYTE_4;
  DWORD rburst = WRAP;
  DWORD rsize  = BYTE_4;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wxferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI WRITE/READ 64B WRAP W32/R32-bit\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    return ret;
  }
  setWrapSize (WRAP_64B, cs);
  ret = set_cr_wrapsize (WRAP_64B, WRAP2INCR_OFF, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't set CR reg wrap size\n");
    return ret;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif
  wxferByte = 1 << wsize;
  len16 = (wxferByte*wlen)/sizeof(WORD);

  wbuf = (WORD*)malloc(wxferByte*wlen);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    return ALLOC_ERROR;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  addr = mbrReg;
  wlen = 16;
  ret = wr_rd(MEM, addr, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);

  if (wbuf) {
    free(wbuf);
  }

#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI WRITE/READ 64B WRAP W32/R32-bit");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr_id_max_inc (DWORD cs)
{
  int i;
  int ret;
  DWORD addr;
  DWORD len = 1;
  DWORD size = BYTE_2;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int xferByte;
  int idCnt = AXI_ID_WIDTH;
  DWORD transNum = 0;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI MAX ID COUNT WRITE/READ\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    return ret;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif

  xferByte = 1 << size;
  len16 = (xferByte*len)/sizeof(WORD);

  for (i = 0; i < idCnt; i++) {
    transNum |= (BIT0 << i);
  }
  CT_MSG("Supported ID Count = 0x%08X\n", transNum);

  wbuf = (WORD*)malloc(len*xferByte*(transNum+1));
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    return ALLOC_ERROR;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16*(transNum+1));
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  addr = mbrReg;
  CT_MSG("LEN=0x%03X --------------------------------------------------\n", len);
  ret = sub_continous_wr_rd(addr, len, size, (transNum+1), wbuf);
  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI MAX ID COUNT WRITE/READ");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr_random_strobe (DWORD cs)
{
  int i, j, k;
  int ret = NO_ERROR;
  DWORD addr;
  DWORD len;
  DWORD size;
  DWORD mbrReg;
  DWORD strbPattern;
  DWORD wlen[] = {1, MAX_LEN};
  DWORD pattern[] = {FIXED_0, RANDOM};
  BYTE* initbuf;
  int xferByte;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI RANDOM WRITE STROBE WRITE/READ\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif
  initbuf = (BYTE*)malloc(MAX_LEN*sizeof(DWORD));
  if (!initbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    return ALLOC_ERROR;
  }
  for (i=0; i<MAX_LEN*sizeof(DWORD); i++) {
    initbuf[i]=0xFF;
  }

  // RANDOM strobe
  for (size=BYTE_1; size<=BYTE_4; size++) {
    xferByte = 1 << size;

    for (k=0; k < (sizeof(wlen)/sizeof(DWORD)); k++) {
      len = wlen[k];

      for (j=0; j < (sizeof(pattern)/sizeof(DWORD)); j++) {
        strbPattern = pattern[j];

        for (i=0; i<(MAX_ADDR_LOOP*xferByte); i++) {
          addr = mbrReg + i;
          ret = wr_rd(MEM, addr, len, INCR, size, initbuf, INCR, size);
          if (ret != NO_ERROR) {
            goto end_test;
          }
          ret = sub_wr_rd_rand_ws(addr, len, size, strbPattern);
          if (ret != NO_ERROR) {
            goto end_test;
          }
        }
      }
    }
  }

  // Random Address/Size/Length
  strbPattern = RANDOM;
  for (i=0; i<500; i++) {
    CT_MSG("Count %d\n",i);
    len = genRndLen();
    size = genRndDataLimit(BYTE_4);
    xferByte = 1 << size;    
    addr = 0;
    while (addr <= mbrReg) {
      addr = genRndAddr();
    }
#ifdef STRESS_TEST
    if(!cs) addr &= (CS1_MEM_BASE-1);
#endif
    ret = wr_rd(MEM, addr, len, INCR, size, initbuf, INCR, size);
    if (ret != NO_ERROR) {
      goto end_test;
    }
    ret = sub_wr_rd_rand_ws(addr, len, size, strbPattern);
    if (ret != NO_ERROR) {
      goto end_test;
    }
  }
 end_test:
  if (initbuf) {
    free(initbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI RANDOM WRITE STROBE WRITE/READ\n");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr_out_of_order_rd (DWORD cs)
{
  int ret = NO_ERROR;
  int i, j, randidCase;
  DWORD mbrReg;
  DWORD addr[MAX_OUTSTANDING_TRANS-1];
  DWORD len[MAX_OUTSTANDING_TRANS-1];
  DWORD wrid[MAX_OUTSTANDING_TRANS-1];
  DWORD size, size0, size1;

  int wxferByte;
  int wOrder[MAX_OUTSTANDING_TRANS-1];

  DWORD* wbuf[MAX_OUTSTANDING_TRANS-1];
  DWORD* rbuf[MAX_OUTSTANDING_TRANS-1];
  DWORD pattern[MAX_OUTSTANDING_TRANS-1];
  DWORD wrPtr[MAX_OUTSTANDING_TRANS-1];
  BYTE wresp[MAX_OUTSTANDING_TRANS-1];
  BYTE rresp[MAX_OUTSTANDING_TRANS-1];
  BYTE randidPattern[][MAX_OUTSTANDING_TRANS-1] = {    \
    { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15}, \
    { 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, 7, 0, 8}, \
    { 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, 7, 0, 8, 0}, \
    { 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1}};
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI OUT OF ORDER WRITE/READ\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif

  for (i=0 ; i < MAX_OUTSTANDING_TRANS-1 ; i++) {
    wbuf[i] = (DWORD*)malloc(MAX_LEN*sizeof(DWORD));
    if (!wbuf[i]) {
      CT_ERR_MSG("Can't allocate memory for write data\n");
      goto end_test;
    }
    rbuf[i] = (DWORD*)malloc(MAX_LEN*sizeof(DWORD));
    if (!rbuf[i]) {
      CT_ERR_MSG("Can't allocate memory for read data\n");
      goto end_test;
    }
    getDataPattern(&pattern[i]);
    fillBuffer(pattern[i], (WORD*)wbuf[i], MAX_LEN*(sizeof(DWORD)/sizeof(WORD)));
    CT_MSG("Data Pattern #%2d\n", i);
    printBuffer((WORD*)wbuf[i], MAX_LEN*(sizeof(DWORD)/sizeof(WORD)));
  }

  for (randidCase = 0; randidCase < (sizeof(randidPattern)/sizeof(randidPattern[0])) ; randidCase++) {
    for (size0=BYTE_1 ; size0 <= BYTE_4 ; size0++) {

      for (size1=BYTE_1 ; size1 <= BYTE_4 ; size1++) {

      for (j=0 ; j < MAX_OUTSTANDING_TRANS-1 ; j++) {
        addr[j] = mbrReg+j*0x800 + j;
#ifdef STRESS_TEST
        if(!cs) wrid[j] = randidPattern[randidCase][j] & ~(BIT0 << (AXI_ID_WIDTH-1));
        else    wrid[j] = randidPattern[randidCase][j] | (BIT0 << (AXI_ID_WIDTH-1));
#else
        wrid[j] = randidPattern[randidCase][j];
#endif
        len[j] = j%MAX_LEN + 1;
        if (j%2) {
          wOrder[j] = j-1;
          size = size1;
        } else {
          wOrder[j] = j+1;
          size = size0;
        }
        CT_MSG("Write Request #%2d: wrID=0x%X, addr=0x%08X len=0x%03X size=%1d\n", j, wrid[j], addr[j], len[j], size);
        writeAddress (MEM, wrid[j], addr[j], len[j], INCR, size, &wrPtr[j]);
      }

      for (i=0 ; i < MAX_OUTSTANDING_TRANS-1 ; i++) {
        for (j=0 ; j < MAX_OUTSTANDING_TRANS-1 ; j++) {
          if (wOrder[j] == i) {
            if (j%2) {
              size = size1;
            } else {
              size = size0;
            }
            CT_MSG("Write Data #%2d: wrID=0x%X, addr=0x%08X len=0x%03X size=%1d\n", j, wrid[j], addr[j], len[j], size);
            writeBurstData (MEM, wrid[j], addr[j], len[j], INCR, size, wbuf[j], wrPtr[j]);
            break;
          }
        }
      }

      for (i=0 ; i < MAX_OUTSTANDING_TRANS-1 ; i++) {
        for (j=0 ; j < MAX_OUTSTANDING_TRANS-1 ; j++) {
          if (wOrder[j] == i) {
            getWriteRespIndex(MEM, &wresp[j], wrPtr[j]);
            if (wresp[j]) {
              CT_ERR_MSG("Write Response #%2d: 0x%x\n", j, wresp[j]);
              ret = RESP_ERROR;
              goto end_test;
            }
            break;
          }
        }
      }

      for (j=0 ; j < MAX_OUTSTANDING_TRANS-1 ; j++) {
        if (j%2) {
          size = size1;
        } else {
          size = size0;
        }
        wxferByte = 1 << size;
        CT_MSG("Read #%2d: addr=0x%08X len=0x%03X size=%1d\n", j, addr[j], len[j], size);
        readBurst(MEM, addr[j], len[j], INCR, size);
#ifdef STRESS_TEST
        getReadDataRespStress(MEM, addr[j], len[j], size, rbuf[j], &rresp[j]);
#else
        getReadDataResp(MEM, len[j], size, rbuf[j], &rresp[j]);
#endif
        if (rresp[j]) {
          CT_ERR_MSG("Read Response #%2d: 0x%x\n", j, rresp[j]);
          ret = RESP_ERROR;
          goto end_test;
        }

        if (verifyData8((BYTE*)rbuf[j], (BYTE*)wbuf[j], len[j]*wxferByte-(addr[j]%wxferByte))) {
          ret = VERIFY_ERROR;
          CT_ERR_MSG("VerifyData8 #%2d\n",j);
          goto end_test;
        }
      }

      }
    }
  }

 end_test:
  for (i=0 ; i < MAX_OUTSTANDING_TRANS-1 ; i++) {
    if (rbuf[i]) {
      free(rbuf[i]);
    }
    if (wbuf[i]) {
      free(wbuf[i]);
    }
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG(">> AXI OUT OF ORDER WRITE/READ\n");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr_rand_out_of_order_rd (DWORD cs)
{
  int ret = NO_ERROR;
  int i, j, k;
  DWORD mbrReg;
  DWORD addr[MAX_OUTSTANDING_TRANS-1];
  DWORD len[MAX_OUTSTANDING_TRANS-1];
  DWORD size[MAX_OUTSTANDING_TRANS-1];
  DWORD wrid[MAX_OUTSTANDING_TRANS-1];

  int wxferByte[MAX_OUTSTANDING_TRANS-1];

  DWORD* wbuf[MAX_OUTSTANDING_TRANS-1];
  DWORD* rbuf[MAX_OUTSTANDING_TRANS-1];
  DWORD pattern[MAX_OUTSTANDING_TRANS-1];
  DWORD wrPtr[MAX_OUTSTANDING_TRANS-1];
  DWORD wOrder[MAX_OUTSTANDING_TRANS-1];
  DWORD wInterleave;
  BYTE wresp[MAX_OUTSTANDING_TRANS-1];
  BYTE rresp[MAX_OUTSTANDING_TRANS-1];
  BYTE gen;
  DWORD adrc, upper, lower;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif
  DWORD devtype;
  DWORD devlower, devupper;

  CT_MSG(">> AXI OUT OF ORDER RANDOM WRITE/READ\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    goto end_test;
  }
#ifdef STRESS_TEST
  if (cs == CS1_SEL) {
    devtype = CS1_DEVTYPE;
  } else {
    devtype = CS0_DEVTYPE;
  }
#else
  getDevType(&devtype, cs);
#endif
  if (devtype == PSRAM) {
    devlower = 0;
    devupper = PSRAM_SIZE - 1;
  } else {
    devlower = mbrReg;
    devupper = FLASH_SIZE - 1;
#ifdef STRESS_TEST
    if(!cs) devupper = (CS1_MEM_BASE-1);
#endif
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif

  for (i=0 ; i<MAX_OUTSTANDING_TRANS-1 ; i++) {
    wbuf[i] = (DWORD*)malloc(MAX_LEN*sizeof(DWORD));
    if (!wbuf[i]) {
      CT_ERR_MSG("Can't allocate memory for write data\n");
      goto end_test;
    }
    rbuf[i] = (DWORD*)malloc(MAX_LEN*sizeof(DWORD));
    if (!rbuf[i]) {
      CT_ERR_MSG("Can't allocate memory for read data\n");
      goto end_test;
    }
    getDataPattern(&pattern[i]);
    fillBuffer(pattern[i], (WORD*)wbuf[i], MAX_LEN*(sizeof(DWORD)/sizeof(WORD)));
    CT_MSG("Data Pattern #%2d\n", i);
    printBuffer((WORD*)wbuf[i], MAX_LEN*(sizeof(DWORD)/sizeof(WORD)));
  }

  for (i=0; i<MAX_ADDR_LOOP; i++) {
    for (k=0 ; k<MAX_OUTSTANDING_TRANS-1 ; k++) {
      len[k] = genRndLen();
      size[k] = genRndDataLimit(BYTE_4);
      wxferByte[k] = 1 << size[k];
      
      if(k) {
        do {
          addr[k] = 0;
          while (addr[k] <= mbrReg) {
            addr[k] = genRndAddr();
            addr[k] = (addr[k] - addr[k]%wxferByte[k]);
          }
#ifdef STRESS_TEST
          if(!cs) addr[k] &= (CS1_MEM_BASE-1);
#endif
          for(adrc = 0; adrc < k; adrc++) {
#if 0
            if(addr[adrc] >= (4 * MAX_LEN)) lower = addr[adrc] - (4 * MAX_LEN);
            else                            lower = 0;
            if(addr[adrc] <= (0xFFFFFFFF - (4 * MAX_LEN))) upper = addr[adrc] + (4 * MAX_LEN);
            else                                           upper = 0xFFFFFFFF;
            if((addr[k] > lower) && (addr[k] < upper)) {
#endif
            if((addr[adrc] & devupper) - devlower >= (4 * MAX_LEN)) lower = (addr[adrc] & devupper) - (4 * MAX_LEN);
            else                            lower = devlower ;
            if((addr[adrc] & devupper) <= (devupper - (4 * MAX_LEN))) upper = (addr[adrc] & devupper) + (4 * MAX_LEN);
            else                                           upper = devupper;
            if(((addr[k] & devupper) > lower) && ((addr[k] & devupper) < upper)) {
              gen = 1;
              break;
            } else {
              gen = 0;
            }
          }
        } while(gen == 1);
      } else {
        addr[k] = 0;
        while (addr[k] <= mbrReg) {
          addr[k] = genRndAddr();
        }
        addr[k] = (addr[k] - addr[k]%wxferByte[k]);
#ifdef STRESS_TEST
        if(!cs) addr[k] &= (CS1_MEM_BASE-1);
#endif
      }
      
#ifdef STRESS_TEST
      if(!cs) wrid[k] = genRndDataLimit((((BIT0) << (AXI_ID_WIDTH-1))-1)) & ~(BIT0 << (AXI_ID_WIDTH-1));
      else    wrid[k] = genRndDataLimit((((BIT0) << (AXI_ID_WIDTH-1))-1)) | (BIT0 << (AXI_ID_WIDTH-1));
      if (k == 1) {
        while (wrid[k] == wrid[k-1]) {
          if(!cs) wrid[k] = genRndDataLimit((((BIT0) << (AXI_ID_WIDTH-1))-1)) & ~(BIT0 << (AXI_ID_WIDTH-1));
          else    wrid[k] = genRndDataLimit((((BIT0) << (AXI_ID_WIDTH-1))-1)) | (BIT0 << (AXI_ID_WIDTH-1));
        }
      } else if (k == 2) {
        while ((wrid[k] == wrid[k-1]) || (wrid[k] == wrid[k-2])) {
          if(!cs) wrid[k] = genRndDataLimit((((BIT0) << (AXI_ID_WIDTH-1))-1)) & ~(BIT0 << (AXI_ID_WIDTH-1));
          else    wrid[k] = genRndDataLimit((((BIT0) << (AXI_ID_WIDTH-1))-1)) | (BIT0 << (AXI_ID_WIDTH-1));
        }
      } else if (k > 2) {
        while ((wrid[k] == wrid[k-1]) || (wrid[k] == wrid[k-2]) || (wrid[k] == wrid[k-3])) {
          if(!cs) wrid[k] = genRndDataLimit((((BIT0) << (AXI_ID_WIDTH-1))-1)) & ~(BIT0 << (AXI_ID_WIDTH-1));
          else    wrid[k] = genRndDataLimit((((BIT0) << (AXI_ID_WIDTH-1))-1)) | (BIT0 << (AXI_ID_WIDTH-1));
        }
      }
#else
      wrid[k] = genRndDataLimit((((BIT0) << AXI_ID_WIDTH)-1));
      if (k == 1) {
        while (wrid[k] == wrid[k-1]) {
          wrid[k] = genRndDataLimit((((BIT0) << AXI_ID_WIDTH)-1));
        }
      } else if (k == 2) {
        while ((wrid[k] == wrid[k-1]) || (wrid[k] == wrid[k-2])) {
          wrid[k] = genRndDataLimit((((BIT0) << AXI_ID_WIDTH)-1));
        }
      } else if (k > 2) {
        while ((wrid[k] == wrid[k-1]) || (wrid[k] == wrid[k-2]) || (wrid[k] == wrid[k-3])) {
          wrid[k] = genRndDataLimit((((BIT0) << AXI_ID_WIDTH)-1));
        }
      }
#endif
      wOrder[k] = k;
    }

    for (j=0 ; j<MAX_OUTSTANDING_TRANS-2 ; j++) {
      if ((j%2 == 0) && (wOrder[j] == j) && (wrid[j] != wrid[j+1])) {
        wInterleave = genRndDataLimit(1);
        if (wInterleave) {
          wOrder[j] = j+1;
          wOrder[j+1] = j;
        }
      }
    }

    for (k=0 ; k<MAX_OUTSTANDING_TRANS-1 ; k++) {
      CT_MSG("Write Request #%2d: wrID=0x%X, addr=0x%08X len=0x%03X size=%1d\n", k, wrid[k], addr[k], len[k], size[k]);
      writeAddress (MEM, wrid[k], addr[k], len[k], INCR, size[k], &wrPtr[k]);
    }

    for (j=0 ; j < MAX_OUTSTANDING_TRANS-1 ; j++) {
      for (k=0 ; k < MAX_OUTSTANDING_TRANS-1 ; k++) {
        if (wOrder[k] == j) {
          CT_MSG("Write Data #%2d: wrID=0x%X, addr=0x%08X len=0x%03X size=%1d\n", k, wrid[k], addr[k], len[k], size[k]);
          writeBurstData (MEM, wrid[k], addr[k], len[k], INCR, size[k], wbuf[k], wrPtr[k]);
          break;
        }
      }
    }

    for (j=0 ; j < MAX_OUTSTANDING_TRANS-1 ; j++) {
      for (k=0 ; k < MAX_OUTSTANDING_TRANS-1 ; k++) {
        if (wOrder[k] == j) {
          getWriteRespIndex(MEM, &wresp[k], wrPtr[k]);
          if (wresp[k]) {
            CT_ERR_MSG("Write Response #%2d: 0x%x\n", k, wresp[k]);
            ret = RESP_ERROR;
            goto end_test;
          }
          break;
        }
      }
    }

    for (k=0 ; k<MAX_OUTSTANDING_TRANS-1 ; k++) {
      CT_MSG("Read #%2d: addr=0x%08X len=0x%03X size=%1d\n", k, addr[k], len[k], size[k]);
      readBurst(MEM, addr[k], len[k], INCR, size[k]);
#ifdef STRESS_TEST
      getReadDataRespStress(MEM, addr[k], len[k], size[k], rbuf[k], &rresp[k]);
#else
      getReadDataResp(MEM, len[k], size[k], rbuf[k], &rresp[k]);
#endif
      if (rresp[k]) {
        CT_ERR_MSG("Read Response #%2d: 0x%x\n", k, rresp[k]);
        ret = RESP_ERROR;
        goto end_test;
      }

      if (verifyData8((BYTE*)rbuf[k], (BYTE*)wbuf[k], len[k]*wxferByte[k])) {
        ret = VERIFY_ERROR;
        CT_ERR_MSG("VerifyData8 %d\n",k);
        goto end_test;
      }
    }
  }
 end_test:
  for (i=0 ; i<MAX_OUTSTANDING_TRANS-1 ; i++) {
    if (rbuf[i]) {
      free(rbuf[i]);
    }
    if (wbuf[i]) {
      free(wbuf[i]);
    }
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG(">> AXI OUT OF ORDER RANDOM WRITE/READ\n");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_incr_wr_rd_len_min (DWORD cs)
{
  int ret;
  int i;

  DWORD wlen = 1;
  DWORD wburst = INCR;
  DWORD wsize  = MAX_AXI_BURST_SIZE;
  DWORD rburst = INCR;
  DWORD rsize  = MAX_AXI_BURST_SIZE;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wxferByte;
  int rxferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI INCR WRITE/READ Length=1\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    return ret;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif
  wxferByte = 1 << wsize;
  len16 = (wxferByte*wlen)/sizeof(WORD);

  wbuf = (WORD*)malloc(wxferByte*wlen);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    return ALLOC_ERROR;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  for (wsize = 0; wsize <= MAX_AXI_BURST_SIZE; wsize++) {
    wxferByte = 1 << wsize;
    for (rsize = 0; rsize <= MAX_AXI_BURST_SIZE; rsize++) {
      rxferByte = 1 << rsize;
      if (wxferByte < rxferByte) {
        wlen = rxferByte / wxferByte;
      } else {
        wlen = 1;
      }

      for (i = 0; i < MAX_ADDR_LOOP; i++) {
        ret = wr_rd(MEM, i+mbrReg, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);
        if (ret != NO_ERROR) {
          break;
        }
      }
    }
  }

  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI INCR WRITE/READ Length=1");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_incr_wr_rd_len_max (DWORD cs)
{
  int ret;
  int i;

  DWORD wlen = MAX_LEN;
  DWORD wburst = INCR;
  DWORD wsize  = MAX_AXI_BURST_SIZE;
  DWORD rburst = INCR;
  DWORD rsize  = MAX_AXI_BURST_SIZE;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wxferByte;
  int rxferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI INCR WRITE/READ Length=max\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    return ret;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif
  wxferByte = 1 << wsize;
  len16 = (wxferByte*wlen)/sizeof(WORD);

  wbuf = (WORD*)malloc(wxferByte*wlen);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    return ALLOC_ERROR;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  for (wsize = 0; wsize <= MAX_AXI_BURST_SIZE; wsize++) {
    wxferByte = 1 << wsize;
    for (rsize = 0; rsize <= MAX_AXI_BURST_SIZE; rsize++) {
      rxferByte = 1 << rsize;
      if (wxferByte < rxferByte) {
        wlen = MAX_LEN * (rxferByte / wxferByte);
      } else {
        wlen = MAX_LEN;
      }

      for (i = 0; i < MAX_ADDR_LOOP; i++) {
        ret = wr_rd(MEM, i+mbrReg, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);
        if (ret != NO_ERROR) {
          break;
        }
      }
    }
  }

  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI INCR WRITE/READ Length=max");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_incr_wr_rd_rand (DWORD cs)
{
  int ret;
  int i;

  DWORD addr;
  DWORD wlen = MAX_LEN;
  DWORD wburst = INCR;
  DWORD wsize  = MAX_AXI_BURST_SIZE;
  DWORD rburst = INCR;
  DWORD rsize  = MAX_AXI_BURST_SIZE;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wxferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI INCR WRITE/READ Random\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    return ret;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif
  wxferByte = 1 << wsize;
  len16 = (wxferByte*wlen)/sizeof(WORD);

  wbuf = (WORD*)malloc(wxferByte*wlen);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    return ALLOC_ERROR;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  for (i = 0; i < 500; i++) {
    CT_MSG("Count %d\n",i);
    wlen = genRndLen();
    wsize = genRndDataLimit(MAX_AXI_BURST_SIZE);
    rsize = genRndDataLimit(MAX_AXI_BURST_SIZE);
    addr = 0;
    while (addr <= mbrReg) {
      addr = genRndAddr();
    }
#ifdef STRESS_TEST
    if(!cs) addr &= (CS1_MEM_BASE-1);
#endif
    ret = wr_rd(MEM, addr, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);
    if (ret != NO_ERROR) {
      break;
    }
  }

  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI INCR WRITE/READ Random");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr_rd_wrap (DWORD cs)
{
  int ret;

  DWORD wrapsize;

#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI WRITE/READ WRAP\n");

#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif

  for (wrapsize = MIN_WRAP_SIZE ; wrapsize <= MAX_WRAP_SIZE; wrapsize=wrapsize<<1) {
    ret = sub_wr_rd_wrap (cs, wrapsize);
    if (ret != NO_ERROR) {
      goto end_test;
    }
  }
 end_test:
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI WRITE/READ WRAP");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_wr_rd_fixed (DWORD cs)
{
  int i;
  int ret;
  int expWfixedret = NO_ERROR;
  int expRfixedret = NO_ERROR;

  DWORD addr;
  DWORD wlen = FIXED_MAX_LEN;
  DWORD wburst = FIXED;
  DWORD wsize  = MAX_AXI_BURST_SIZE;
  DWORD rlen = FIXED_MAX_LEN;
  DWORD rburst = FIXED;
  DWORD rsize  = MAX_AXI_BURST_SIZE;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  WORD* rbuf;
  int wxferByte;
  int rxferByte;
  DWORD mbrReg;
#ifdef STRESS_TEST
  DWORD end_loop;
#endif

  CT_MSG(">> AXI WRITE/READ FIXED\n");
  ret = getMemBaseAddress (&mbrReg, cs);
  if (ret != NO_ERROR) {
    CT_ERR_MSG("Can't get memory base address\n");
    return ret;
  }
  if (MEM_WRITE_FIXED == INVALID) {
    expWfixedret = SLVERR;
  }
  if (MEM_READ_FIXED == INVALID) {
    expRfixedret = SLVERR;
  }
#ifdef STRESS_TEST
  test_status &= ~(1 << cs);
  for(end_loop = 0; end_loop < 10000; end_loop++) {
    if(test_status == 0) break;
    DPI_waitNs(1);
  }
#endif

  wxferByte = 1 << wsize;
  rxferByte = 1 << rsize;
  len16 = (wxferByte*wlen)/sizeof(WORD);

  wbuf = (WORD*)malloc(wxferByte*wlen);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    return ALLOC_ERROR;
  }
  rbuf = (WORD*)malloc(rxferByte*rlen);
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    return ALLOC_ERROR;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  CT_MSG("Fixed Write/Fixed Read\n");
  addr = mbrReg;
  wburst = FIXED;
  rburst = FIXED;

  for (wsize = 0; wsize <= MAX_AXI_BURST_SIZE; wsize++) {
    wxferByte = 1 << wsize;

    for (rsize = 0; rsize <= MAX_AXI_BURST_SIZE; rsize++) {
      rxferByte = 1 << rsize;

      for (i = 0; i < (1 << MAX_AXI_BURST_SIZE) ; i++) {
        for (wlen = 1; wlen <= FIXED_MAX_LEN; wlen++) {
          if (wlen <= FIXED_LEN_SUPPORT[wsize]) {
            if ((expWfixedret == NO_ERROR) && (expRfixedret == NO_ERROR)) {
              ret = wr_rd(MEM, addr+i, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);
              if (ret != NO_ERROR) {
                goto end_test;
              }
            }
          }

          rlen = wlen;
          if ((expWfixedret == SLVERR) || (wlen > FIXED_LEN_SUPPORT[wsize])) {
            ret = wr_slave_error(MEM, addr+i, wlen, wburst, wsize, wbuf); if (ret != NO_ERROR) goto end_test;
          }
          if ((expRfixedret == SLVERR) || (rlen > FIXED_LEN_SUPPORT[rsize])) {
            ret = rd_slave_error(MEM, addr+i, rlen, rburst, rsize, rbuf); if (ret != NO_ERROR) goto end_test;
          }
        }
      }
    }
  }

  if (expWfixedret == NO_ERROR) {
    CT_MSG("FIXED Write/INCR Read\n");

    addr = mbrReg;
    wburst = FIXED;
    rburst = INCR;

    for (wsize = 0; wsize <= MAX_AXI_BURST_SIZE; wsize++) {
      wxferByte = 1 << wsize;

      for (rsize = 0; rsize <= MAX_AXI_BURST_SIZE; rsize++) {
        rxferByte = 1 << rsize;

        for (i = 0; i < (1 << MAX_AXI_BURST_SIZE) ; i++) {
          wlen = 1;

          while (i+wlen*wxferByte < MAX_AXI_BURST_SIZE+(wxferByte-1)) {
            ret = wr_rd(MEM, addr+i, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);
            if (ret != NO_ERROR) {
              goto end_test;
            }
            wlen++;
          }
        }
      }
    }
  }

  if (expRfixedret == NO_ERROR) {
    CT_MSG("Incr Write/Fixed Read\n");

    addr = mbrReg;
    wburst = INCR;
    rburst = FIXED;

    for (wsize = 0; wsize <= MAX_AXI_BURST_SIZE; wsize++) {
      wxferByte = 1 << wsize;

      for (rsize = 0; rsize <= MAX_AXI_BURST_SIZE; rsize++) {
        rxferByte = 1 << rsize;

        for (i = 0; i < (1 << MAX_AXI_BURST_SIZE); i++) {
          wlen = 1;

          while (i+wlen*wxferByte < MAX_AXI_BURST_SIZE+(wxferByte-1)) {
            ret = wr_rd(MEM, addr+i, wlen, wburst, wsize, (BYTE*)wbuf, rburst, rsize);
            if (ret != NO_ERROR) {
              goto end_test;
            }
            wlen++;
          }
        }
      }
    }
  }
 end_test:
  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
#ifdef STRESS_TEST
  test_status |= 1 << cs;
  for(end_loop = 0; end_loop < 1000000000; end_loop++) {
    if(test_status == 3) break;
    DPI_waitNs(1);
  }
#endif
  CT_MSG("<< AXI WRITE/READ FIXED");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}
///

//=============================================================================
//  MAIN
//=============================================================================
#if 0
#define IT_W8R8_LEN1            0x00000001
#define IT_W16R16_LEN1          0x00000002
#define IT_W16R32_LEN1          0x00000004
#define IT_W32R32_LEN1          0x00000008
#define IT_W8R8_LENMAX          0x00000010
#define IT_W8R16_LENMAX         0x00000020
#define IT_W8R32_LENMAX         0x00000040
#define IT_W16R8_LENMAX         0x00000080
#define IT_W16R16_LENMAX        0x00000100
#define IT_W16R32_LENMAX        0x00000200
#define IT_W32R8_LENMAX         0x00000400
#define IT_W32R16_LENMAX        0x00000800
#define IT_W32R32_LENMAX        0x00001000
#define IT_W8R8_RND             0x00002000
#define IT_W8R16_RND            0x00004000
#define IT_W8R32_RND            0x00008000
#define IT_W16R8_RND            0x00010000
#define IT_W16R16_RND           0x00020000
#define IT_W16R32_RND           0x00040000
#define IT_W32R8_RND            0x00080000
#define IT_W32R16_RND           0x00100000
#define IT_W32R32_RND           0x00200000
#define IT_W8R8_WRAP_16B        0x00400000
#define IT_W16R16_WRAP_16B      0x00800000
#define IT_W16R32_WRAP_16B      0x01000000
#define IT_W32R8_WRAP_16B       0x02000000
#define IT_W32R16_WRAP_16B      0x04000000
#define IT_W32R32_WRAP_16B      0x08000000
#define IT_W16R16_WRAP_32B      0x10000000
#define IT_W16R32_WRAP_32B      0x20000000
#define IT_W32R16_WRAP_32B      0x40000000
#define IT_W32R32_WRAP_32B      0x80000000
#define IT2_W16R32_WRAP_64B     0x00000001
#define IT2_W32R32_WRAP_64B     0x00000002
#define IT2_WR_OUTSTANDING      0x00000004
#define IT2_WR_UNSUPPORT        0x00000008
#define IT2_WR_SLVERR           0x00000010
#define IT2_WR_CONCURRENT       0x00000020
#define IT2_WR_ID_MAX_INC       0x00000040
#define IT2_WR_RAND_WSTROBE     0x00000080
#define IT2_RD_TIMEOUT          0x00000100
#define IT2_WR_OUT_OF_ORDER     0x00000200
#define IT2_WR_OUT_OF_ORDER_RND 0x00000400
#define IT2_INCR_WR_RD_LEN_MIN  0x00000800
#define IT2_INCR_WR_RD_LEN_MAX  0x00001000
#define IT2_INCR_WR_RD_RND      0x00002000
#define IT2_WRAP_WR_RD_2B       0x00004000
#define IT2_WRAP_WR_RD_4B       0x00008000
#define IT2_WRAP_WR_RD_8B       0x00010000
#define IT2_WRAP_WR_RD_16B      0x00020000
#define IT2_WRAP_WR_RD_32B      0x00040000
#define IT2_WRAP_WR_RD_64B      0x00080000
#define IT2_FIXED_WR_RD         0x00100000
#define IT2_WR_OUTSTANDING_RND  0x00200000
#define IT2_WR_CONCURRENT_RND   0x00400000
//#define IT2_WR_SLVERR_RSTO      0x40000000
#define IT2_DEBUG               0x80000000

TTestCase IT[] = {
  {IT_W8R8_LEN1,            axi_wr8_rd8_len1,            "Length 1 W8/R8   bit"},
  {IT_W16R16_LEN1,          axi_wr16_rd16_len1,          "Length 1 W16/R16 bit"},
  {IT_W16R32_LEN1,          axi_wr16_rd32_len1,          "Length 1 W16/R32 bit"},
  {IT_W32R32_LEN1,          axi_wr32_rd32_len1,          "Length 1 W32/R32 bit"},
  {IT_W8R8_LENMAX,          axi_wr8_rd8_lenmax,          "Length MAX W8/R8   bit"},
  {IT_W8R16_LENMAX,         axi_wr8_rd16_lenmax,         "Length MAX W8/R16  bit"},
  {IT_W8R32_LENMAX,         axi_wr8_rd32_lenmax,         "Length MAX W8/R32  bit"},
  {IT_W16R8_LENMAX,         axi_wr16_rd8_lenmax,         "Length MAX W16/R8  bit"},
  {IT_W16R16_LENMAX,        axi_wr16_rd16_lenmax,        "Length MAX W16/R16 bit"},
  {IT_W16R32_LENMAX,        axi_wr16_rd32_lenmax,        "Length MAX W16/R32 bit"},
  {IT_W32R8_LENMAX,         axi_wr32_rd8_lenmax,         "Length MAX W32/R8  bit"},
  {IT_W32R16_LENMAX,        axi_wr32_rd16_lenmax,        "Length MAX W32/R16 bit"},
  {IT_W32R32_LENMAX,        axi_wr32_rd32_lenmax,        "Length MAX W32/R32 bit"},
  {IT_W8R8_RND,             axi_wr8_rd8_rand,            "Random Length/Address W8/R8   bit"},
  {IT_W8R16_RND,            axi_wr8_rd16_rand,           "Random Length/Address W8/R16  bit"},
  {IT_W8R32_RND,            axi_wr8_rd32_rand,           "Random Length/Address W8/R32  bit"},
  {IT_W16R8_RND,            axi_wr16_rd8_rand,           "Random Length/Address W16/R8  bit"},
  {IT_W16R16_RND,           axi_wr16_rd16_rand,          "Random Length/Address W16/R16 bit"},
  {IT_W16R32_RND,           axi_wr16_rd32_rand,          "Random Length/Address W16/R32 bit"},
  {IT_W32R8_RND,            axi_wr32_rd8_rand,           "Random Length/Address W32/R8  bit"},
  {IT_W32R16_RND,           axi_wr32_rd16_rand,          "Random Length/Address W32/R16 bit"},
  {IT_W32R32_RND,           axi_wr32_rd32_rand,          "Random Length/Address W32/R32 bit"},
  {IT_W8R8_WRAP_16B,        axi_wr8_rd8_wrap_16B,        "16B Wrapped W8/R8   bit"},
  {IT_W16R16_WRAP_16B,      axi_wr16_rd16_wrap_16B,      "16B Wrapped W16/R16 bit"},
  {IT_W16R32_WRAP_16B,      axi_wr16_rd32_wrap_16B,      "16B Wrapped W16/R32 bit"},
  {IT_W32R8_WRAP_16B,       axi_wr32_rd8_wrap_16B,       "16B Wrapped W32/R8  bit"},
  {IT_W32R16_WRAP_16B,      axi_wr32_rd16_wrap_16B,      "16B Wrapped W32/R16 bit"},
  {IT_W32R32_WRAP_16B,      axi_wr32_rd32_wrap_16B,      "16B Wrapped W32/R32 bit"},
  {IT_W16R16_WRAP_32B,      axi_wr16_rd16_wrap_32B,      "32B Wrapped W16/R16 bit"},
  {IT_W16R32_WRAP_32B,      axi_wr16_rd32_wrap_32B,      "32B Wrapped W16/R32 bit"},
  {IT_W32R16_WRAP_32B,      axi_wr32_rd16_wrap_32B,      "32B Wrapped W32/R16 bit"},
  {IT_W32R32_WRAP_32B,      axi_wr32_rd32_wrap_32B,      "32B Wrapped W32/R32 bit"},
  {IT2_W16R32_WRAP_64B,     axi_wr16_rd32_wrap_64B,      "64B Wrapped W16/R32 bit"},
  {IT2_W32R32_WRAP_64B,     axi_wr32_rd32_wrap_64B,      "64B Wrapped W32/R32 bit"},
  {IT2_WR_OUTSTANDING,      axi_outstanding_wr_rd,       "Outstanding W/R"},
  {IT2_WR_UNSUPPORT,        axi_unsupporetd_wr_rd,       "Unsupported W/R"},
  {IT2_WR_SLVERR,           axi_slave_error,             "Slave Error"},
  {IT2_WR_CONCURRENT,       axi_concurrent_wr_rd,        "Concurrent W/R"},
  {IT2_WR_ID_MAX_INC,       axi_wr_id_max_inc,           "AXI ID Count MAX W/R"},
  {IT2_WR_RAND_WSTROBE,     axi_wr_random_strobe,        "Random Write Strobe W/R"},
  {IT2_RD_TIMEOUT,          axi_rd_timeout,              "Read Timeout"},
  {IT2_WR_OUT_OF_ORDER,     axi_wr_out_of_order_rd,      "Out of order Write W/R"},
  {IT2_WR_OUT_OF_ORDER_RND, axi_wr_rand_out_of_order_rd, "Out of order Random Write W/R"},
  {IT2_INCR_WR_RD_LEN_MIN,  axi_incr_wr_rd_len_min,      "INCR W/R /w Length 1"},
  {IT2_INCR_WR_RD_LEN_MAX,  axi_incr_wr_rd_len_max,      "INCR W/R /w Length MAX"},
  {IT2_INCR_WR_RD_RND,      axi_incr_wr_rd_rand,         "INCR W/R /w Random"},
  {IT2_WRAP_WR_RD_2B,       axi_wr_rd_wrap_2B,           "WRAP2B W/R"},
  {IT2_WRAP_WR_RD_4B,       axi_wr_rd_wrap_4B,           "WRAP4B W/R"},
  {IT2_WRAP_WR_RD_8B,       axi_wr_rd_wrap_8B,           "WRAP8B W/R"},
  {IT2_WRAP_WR_RD_16B,      axi_wr_rd_wrap_16B,          "WRAP16B W/R"},
  {IT2_WRAP_WR_RD_32B,      axi_wr_rd_wrap_32B,          "WRAP32B W/R"},
  {IT2_WRAP_WR_RD_64B,      axi_wr_rd_wrap_64B,          "WRAP64B W/R"},
  {IT2_FIXED_WR_RD,         axi_wr_rd_fixed,             "FIXED W/R"},
  {IT2_WR_OUTSTANDING_RND,  axi_outstanding_wr_rd_rand,  "Outstanding Random W/R"},
  {IT2_WR_CONCURRENT_RND,   axi_concurrent_wr_rd_rand,   "Concurrent Random W/R"},
//  {IT2_WR_SLVERR_RSTO,      axi_slave_error_rsto,        "Slave Error RSTO#"},
  {IT2_DEBUG,               (void*)0,                    "For debug"}
};
#endif

#define IT_INCR_WR_RD_LEN_MIN  0x00000001
#define IT_INCR_WR_RD_LEN_MAX  0x00000002
#define IT_INCR_WR_RD_RND      0x00000004
#define IT_WRAP_WR_RD          0x00000008
#define IT_FIXED_WR_RD         0x00000010
#define IT_WR_CONCURRENT       0x00000020
#define IT_WR_CONCURRENT_RND   0x00000040
#define IT_WR_OUTSTANDING      0x00000080
#define IT_WR_OUTSTANDING_RND  0x00000100
#define IT_WR_ID_MAX_INC       0x00000200
#define IT_WR_RAND_WSTROBE     0x00000400
#define IT_RD_TIMEOUT          0x00000800
#define IT_WR_OUT_OF_ORDER     0x00001000
#define IT_WR_OUT_OF_ORDER_RND 0x00002000
#define IT2_DEBUG              0x80000000

TTestCase IT[] = {
  {IT_INCR_WR_RD_LEN_MIN,   axi_incr_wr_rd_len_min,      "INCR W/R /w Length 1"},
  {IT_INCR_WR_RD_LEN_MAX,   axi_incr_wr_rd_len_max,      "INCR W/R /w Length MAX"},
  {IT_INCR_WR_RD_RND,       axi_incr_wr_rd_rand,         "INCR W/R /w Random"},
  {IT_WRAP_WR_RD,           axi_wr_rd_wrap,              "WRAP W/R"},
  {IT_FIXED_WR_RD,          axi_wr_rd_fixed,             "FIXED W/R"},
  {IT_WR_CONCURRENT,        axi_concurrent_wr_rd,        "Concurrent W/R"},
  {IT_WR_CONCURRENT_RND,    axi_concurrent_wr_rd_rand,   "Concurrent Random W/R"},
  {IT_WR_OUTSTANDING,       axi_outstanding_wr_rd,       "Outstanding W/R"},
  {IT_WR_OUTSTANDING_RND,   axi_outstanding_wr_rd_rand,  "Outstanding Random W/R"},
  {IT_WR_ID_MAX_INC,        axi_wr_id_max_inc,           "AXI ID Count MAX W/R"},
  {IT_WR_RAND_WSTROBE,      axi_wr_random_strobe,        "Random Write Strobe W/R"},
  {IT_RD_TIMEOUT,           axi_rd_timeout,              "Read Timeout"},
  {IT_WR_OUT_OF_ORDER,      axi_wr_out_of_order_rd,      "Out of order Write W/R"},
  {IT_WR_OUT_OF_ORDER_RND,  axi_wr_rand_out_of_order_rd, "Out of order Random Write W/R"},
//  {IT2_WR_SLVERR_RSTO,      axi_slave_error_rsto,        "Slave Error RSTO#"},
  {IT2_DEBUG,               (void*)0,                    "For debug"}
};

#define NUM_IT (sizeof(IT)/sizeof(IT[0]))

#if 0
#define IT_WR_WRAP_16B  (IT_W8R8_WRAP_16B   | \
                         IT_W16R16_WRAP_16B | \
                         IT_W16R32_WRAP_16B | \
                         IT_W32R8_WRAP_16B  | \
                         IT_W32R16_WRAP_16B | \
                         IT_W32R32_WRAP_16B)

#define IT_WR_WRAP_32B  (IT_W16R16_WRAP_32B | \
                         IT_W16R32_WRAP_32B | \
                         IT_W32R16_WRAP_32B | \
                         IT_W32R32_WRAP_32B)

#define IT2_WR_WRAP_64B (IT2_W16R32_WRAP_64B | \
                         IT2_W32R32_WRAP_64B)
#endif

static int initialization (DWORD pattern)
{
  // Set data pattern
  setDataPattern(pattern);

  return NO_ERROR;
}

int c_test()
{
  int ret = NO_ERROR;

  int i, j;
  int itResult[NUM_IT];
  char *itStr[] = {"UNDO", "PASS", "FAIL"};
  DWORD ctFlag[2];
  DWORD pattern;
  DWORD cs = CS0_SEL;
  DWORD mbrReg =  CS0_MEM_BASE;
  WORD  crData;
  DWORD rpcClk;
  DWORD devtype;

  MSG("RPC2 AXI Test\n");

#ifdef PATTERN
  pattern = PATTERN;
#else
  pattern = WORD_ADDRESS;
#endif

#if defined CTFLAG
  ctFlag[0] = CTFLAG;
#else
////  ctFlag[0] = 0xFFFFFFFF;
  ctFlag[0] = 0x00000FFF;
//  ctFlag[0] = 0x000007FF;
#if (MAX_LEN == 16)
  ctFlag[0] |= (IT_WR_OUT_OF_ORDER_RND|IT_WR_OUT_OF_ORDER);
#endif
#endif

#if defined CTFLAG2
  ctFlag[1] = CTFLAG2;
#else
//  ctFlag[1] = 0x000001FF;
  ctFlag[1] = 0x00000000;
//#if (MAX_LEN == 16)
//  ctFlag[1] |= (IT2_WR_OUT_OF_ORDER_RND|IT2_WR_OUT_OF_ORDER);
//#endif
#endif

#ifdef CS1_ENABLED
  cs = CS1_SEL;
  mbrReg = CS1_MEM_BASE;
  devtype = CS1_DEVTYPE;
  MSG(" CS1 Selected\n");
#else
  cs = CS0_SEL;
  mbrReg = CS0_MEM_BASE;
  devtype = CS0_DEVTYPE;
  MSG(" CS0 Selected\n");
#endif
  ret = setMemBaseAddress(mbrReg, cs);

  MSG("Set DEVTYPE=%1d\n", devtype);
  setDevType (devtype, cs);

  if (devtype == PSRAM) {
    getRpcClkPeriod(&rpcClk);
    MSG(" RPC CLK = %d ps\n", rpcClk);
    if (rpcClk < 10000) {
      setRCSHIcycle(1, cs);
      setWCSHIcycle(1, cs);
    }
    if (rpcClk < 7500) {
      setRCSScycle(1, cs);
      setWCSScycle(1, cs);
    }
    crData = PSRAM_CS_INIT;
  } else {
    crData = FLASH_CS_INIT;
  }

  setWrapSize (WRAPSIZE_32B, cs);
  set_cr_reg (crData, cs);

  for (i = 0; i < NUM_IT; i++) {
    itResult[i] = UNDO;
  }
  ret = initialization(pattern);

#if (RPC2_CTRL_IP_VER >= 230)
  if (devtype == PSRAM) {
    setMAXEN(MAXEN_ENABLED, cs);
    setMAXLEN(MAXLEN_MAX, cs);
  }
#endif
  j = 0;
  for (i = 0; i < NUM_IT; i++) {
    if (i > 31) j=1;
    if (ctFlag[j] & IT[i].sig) {
      ctFlag[j] &= ~IT[i].sig;
      if (IT[i].func) {
        ret = IT[i].func(cs);
        if (ret != NO_ERROR) {
          itResult[i] = FAIL;
          break;
        }
        else itResult[i] = PASS;
      }
    }
  }

  MSG("\nTest Report ---------------------------------------------\n");
  for (i = 0; i < NUM_IT; i++) {
    MSG("  %2d: %-40s -- %s\n", i, IT[i].title, itStr[itResult[i]]);
  }
  MSG("---------------------------------------------------------\n");
  return 0;
}

int c_stress(int t_flag1, int t_flag2, int t_cs)
{
  int ret;

  int i, j;
  DWORD ctFlag[2];
  DWORD pattern;
  DWORD cs = CS0_SEL;
  DWORD mbrReg =  CS0_MEM_BASE;
  WORD  crData;
  DWORD rpcClk;
  DWORD devtype;

  MSG("Stress Test\n");

#ifdef PATTERN
  pattern = PATTERN;
#else
  pattern = WORD_ADDRESS;
#endif

  ctFlag[0] = t_flag1;
  ctFlag[1] = t_flag2;

  if(t_cs) {
    cs = CS1_SEL;
    mbrReg = CS1_MEM_BASE;
    devtype = CS1_DEVTYPE;
    MSG("Set CS1\n");
  } else {
    cs = CS0_SEL;
    mbrReg = CS0_MEM_BASE;
    devtype = CS0_DEVTYPE;
    MSG("Set CS0\n");
  }
  ret = setMemBaseAddress(mbrReg, cs);

  MSG("Set DEVTYPE=%1d\n", devtype);
  setDevType (devtype, cs);

  if (devtype == PSRAM) {
    getRpcClkPeriod(&rpcClk);
    MSG(" RPC CLK = %d ps\n", rpcClk);
    if (rpcClk < 10000) {
      setRCSHIcycle(1, cs);
      setWCSHIcycle(1, cs);
    }
    if (rpcClk < 7500) {
      setRCSScycle(1, cs);
      setWCSScycle(1, cs);
    }
    crData = PSRAM_CS_INIT;
  } else {
    crData = FLASH_CS_INIT;
  }

  setWrapSize (WRAPSIZE_32B, cs);
  set_cr_reg (crData, cs);

  ret = initialization(pattern);

  j = 0;
  for (i = 0; i < NUM_IT; i++) {
    if (i > 31) j=1;
    if (ctFlag[j] & IT[i].sig) {
      ctFlag[j] &= ~IT[i].sig;
      if (IT[i].func) {
        ret = IT[i].func(cs);
        DPI_response(cs, ret);
      }
    }
  }
/*
  MSG("\nTest Report ---------------------------------------------\n");
  for (i = 0; i < NUM_IT; i++) {
    MSG("  %2d: %-40s -- %s\n", i, IT[i].title, itStr[itResult[i]]);
  }
  MSG("---------------------------------------------------------\n");
*/
  return 0;
}

void result_message(int cs0pat1, int cs0pat2, int msk1, int msk2, int cs0_res1, int cs0_res2, int cs1_res1, int cs1_res2)
{
  int cs0loop, cs1loop, j;
  int ctFlag[2];
  
  MSG("\nTest Report -----------------------------------------------------------------------------------------------\n");
  MSG("                                      Test Combination                                          Result\n");
  MSG("                      CS0                                          CS1                        CS0    CS1\n");
  ctFlag[0] = cs0pat1;
  ctFlag[1] = cs0pat2;
  j = 0;
  for(cs0loop = 0; cs0loop < NUM_IT; cs0loop++) {
    if(cs0loop > 31) j = 1;
    if(ctFlag[j] & IT[cs0loop].sig) break;
  }
  ctFlag[0] = msk1;
  ctFlag[1] = msk2;
  j = 0;
  for(cs1loop = 0; cs1loop < NUM_IT; cs1loop++) {
    if(cs1loop > 31) j = 1;
    if(ctFlag[j] & IT[cs1loop].sig) {
        if(cs1loop < 32) {
          if(cs0_res1 & (1 << cs1loop))
            MSG("  %2d: %-40s%2d: %-40s -- FAIL", cs0loop, IT[cs0loop].title, cs1loop, IT[cs1loop].title);
          else
            MSG("  %2d: %-40s%2d: %-40s -- PASS", cs0loop, IT[cs0loop].title, cs1loop, IT[cs1loop].title);
          if(cs1_res1 & (1 << cs1loop))
            MSG(" , FAIL\n");
          else
            MSG(" , PASS\n");
        } else {
          if(cs0_res2 & (1 << (cs1loop - 32)))
            MSG("  %2d: %-40s%2d: %-40s -- FAIL", cs0loop, IT[cs0loop].title, cs1loop, IT[cs1loop].title);
          else
            MSG("  %2d: %-40s%2d: %-40s -- PASS", cs0loop, IT[cs0loop].title, cs1loop, IT[cs1loop].title);
          if(cs1_res2 & (1 << (cs1loop - 32)))
            MSG(" , FAIL\n");
          else
            MSG(" , PASS\n");
        }
    } else {
      MSG("  %2d: %-40s%2d: %-40s -- UNDO , UNDO\n", cs0loop, IT[cs0loop].title, cs1loop, IT[cs1loop].title);
    }
  }
  MSG("-----------------------------------------------------------------------------------------------------------\n");
  return;
}

int getIT2_stbFlag(void)
{
//  return(IT2_WR_RAND_WSTROBE);
  return(IT_WR_RAND_WSTROBE);
}

int getIT2_oooFlag(void)
{
//  return(IT2_WR_OUT_OF_ORDER | IT2_WR_OUT_OF_ORDER_RND);
  return(IT_WR_OUT_OF_ORDER | IT_WR_OUT_OF_ORDER_RND);
}
