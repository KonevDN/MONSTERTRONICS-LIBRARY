#ifdef SIMULATION
#include "sltapi_sim.h"
#include "svdpi.h"
#include "dpiheader.h"
#include <math.h>
#include "rpc2_vlld.h"
#include "rpc2_llops.h"
#else
#include <sltapi.h>
#endif
#include "rpc2.h"
#ifdef NCSC
extern int io_printf(const char *fmt, ...);
#define printf io_printf
#endif

//----------------------------------------------------------------------------------
// 	Script: Advanced Sector Dynamic Protection Bit test
//  Before running this script, the Include.scp needs to be downloaded first.
//----------------------------------------------------------------------------------

enum
{
	CLEARDYBL,
	SETDYBL,
	SCRPPAGESIZE = 8
};

enum
{
	CLEARPPBL,
	SETPPBL
};

PDEV pDevice;

DWORD tVerifyProtectionOff(PDEV dev, DWORD totalSectors, DWORD chkPPBL)
{
	DWORD errCode, i;
	DWORD secAddr, Data;
	
	errCode = EC_NONE;
	for (i = 0; i < totalSectors; i++)
	{
		secAddr = SCRPGetFAPIGeometry(dev, ADDRESS_OF_SECTOR, i);
		SCRPGetASPFunc(dev, ASP_DYB, secAddr, &Data);
		if (Data)
		{
            printf("DYB ON in sector %d\n", i);
			errCode = EC_DYBSTATE;
			break;
		}
	}
	if (errCode) return errCode;

	for (i = 0; i < totalSectors; i++)
	{
		secAddr = SCRPGetFAPIGeometry(dev, ADDRESS_OF_SECTOR, i);
		SCRPGetASPFunc(dev, ASP_PPB, secAddr, &Data);
		if (Data)
		{
            printf("PPB ON in sector %d\n", i);
			errCode = EC_PPBERASEVERIFY;
			break;
		}
	}
	if (errCode) return errCode;

	SCRPGetASPFunc(dev, ASP_PPBL, 0, &Data);
	if (chkPPBL && Data)
		errCode = EC_PPBLSET;

	return errCode;
}

DWORD VerifyProtectedSector(PDEV dev, DWORD vSec, DWORD vSecAddr, DWORD sectorTestAddr)
{
	DWORD i;
	
	if (SCRPSProg(dev, vSecAddr+sectorTestAddr, 0) == EC_NONE)
	{
        printf("Error: [0x%x] Protected Sector Program succeeded\n", vSecAddr+sectorTestAddr);
		return EC_PROGSUCCEEDED;
	}
	else
		SCRPClrDeviceStatus(dev, vSecAddr+sectorTestAddr);
		
	if (SCRPEraseSector(dev, vSec, TRUE) == EC_NONE)
	{
        printf("Error: [0x%x] Protected Sector Erase succeeded\n", vSecAddr);
		return EC_ERASESUCCEEDED;
	}
	else
		SCRPClrDeviceStatus(dev, vSec);
	return EC_NONE;
}

DWORD VerifyUnprotectedSector(PDEV dev, DWORD vSecAddr, DWORD sectorTestAddr)
{
	DWORD errCode, Data;
	WORD rdData;
	
	errCode = EC_NONE;
	SCRPGetASPFunc(dev, ASP_DYB, vSecAddr, &Data);
	if (Data)
	{
        printf("Error: [0x%x] DYB is SET (and should NOT be)\n", vSecAddr);
		return EC_DYBSET;
	}
	if (errCode = SCRPSProg(dev, vSecAddr+sectorTestAddr, 0))
	{
		rdData = SCRPRead(dev, vSecAddr+sectorTestAddr);
        printf("Error: [0x%x] %x, W:0x0000: Program error\n", vSecAddr+sectorTestAddr, rdData);
	}
	return errCode;
}

DWORD test_exit(DWORD exit_val)
{
    if (exit_val)
    {
        SetGlobalVar("SKIP", 1);
	printf("<TC> Test =========================== Fail\n");
    }
    else {
      printf("<TC> Test =========================== Pass\n");
    }
    return (exit_val);
}

#ifdef SIMULATION
int c_test()
#else
int main(int argc, char* argv[])
#endif
{
	DWORD tSector, tSecAddr, vSecAddr, sectorTestAddr;
	DWORD errCode, totalSectors, i, bitPPBL, logStat, Data;
	DWORD ProtectedSecErrCount, UnprotectedSecErrCount;
	
#ifndef SIMULATION
    SKIP = GetGlobalVar("SKIP");
#endif
    if (SKIP)
    {
        line_space(2);
        printf("Test is skipped\n");
        return (__LINE__);
    }
    
#ifdef SIMULATION
    pDevice = NewDeviceObject(0, RPC);
#endif
	pDevice = Find_Device(RPC);
	
	//if (!(FS_PERSISTENTSECTOR & SCRPSupport(pDevice)))
    if (!(FS_SECTORPROTECT & SCRPSupport(pDevice)))
	{
        printf("Error: Advanced Sector Protection not supported\n");
        return test_exit(__LINE__);
	}

    if ((errCode = SCRPASPUnlock(pDevice)) != EC_NONE)
    {
        printf("Error: %s\n", GetErrorText(errCode));
        return test_exit(__LINE__);
    }

	errCode = EC_NONE;
	// Start at address 1, address 0 is reserved for erase test.
	sectorTestAddr = 1;
	totalSectors = SCRPGetFAPIInfo(pDevice, SECTOR_COUNT);
	printf("Advanced Sector Dynamic Protection Bit Test\n");
	
	if (errCode = tVerifyProtectionOff(pDevice, totalSectors, FALSE))
	{
        printf("Error: Verify DYB/PPB OFF: %s\n", GetErrorText(errCode));
        return test_exit(__LINE__);
	}

#ifndef SIMULATION
	logStat = SaveDevLogState(pDevice);
	SetLogDevice(pDevice, LOG_NONE);
#endif
	printf("Erasing Sectors ...\n");
	for (tSector = 0; tSector < totalSectors; tSector++)
	{
		if ((errCode = SCRPEraseSector(pDevice, tSector, TRUE)) != EC_NONE)
		{
            printf("Error: Failed to Erase Sector %d\n", tSector);
            return test_exit(__LINE__);
		}
		else
			printf("Sector %d Erased\n", tSector);
	}
#ifndef SIMULATION
	RestoreDevLogState(pDevice, logStat);
#endif
	for (tSector = 0; (tSector < totalSectors) && (errCode == EC_NONE); tSector++)
	{

		tSecAddr  = SCRPGetFAPIGeometry(pDevice, ADDRESS_OF_SECTOR, tSector );
		SCRPGetASPFunc(pDevice, ASP_DYB, tSecAddr, &Data);
		if (Data)
		{
			errCode = EC_DYBSTATE;
            printf("Error: Verify DYB OFF [0x%08X]: %s\n", tSecAddr, GetErrorText(errCode));
			break;
		}
		if ((errCode = SCRPSProg(pDevice, tSecAddr+0x700, 0x4321)) != EC_NONE)
		{
            printf("Error: Program [0x%08X] ERROR\n", tSecAddr);
			break;
		}
		if ((errCode = SCRPSProg(pDevice, tSecAddr+0x555, 0xAA57)) != EC_NONE)
		{
            printf("Error: Program [0x%08X] failed\n", tSecAddr);
			break;
		}
//        printf("Secotr %d [%08X] set DYB\n",tSector, tSecAddr);
		if ((errCode = SCRPSetASPFunc(pDevice, ASP_DYB, tSecAddr, TRUE)) != EC_NONE)
		{
            printf("Error: [0x%08X] Setting DYB: %s\n", tSecAddr, GetErrorText(errCode));
			break;
		}
		SCRPGetASPFunc(pDevice, ASP_DYB, tSecAddr, &Data);
		if (!Data)
		{
			errCode = EC_DYBNOTSET;
            printf("Error: DYB NOT SET [0x%08X]: %s\n", tSecAddr, GetErrorText(errCode));
			break;
		}

		ProtectedSecErrCount=0;
		UnprotectedSecErrCount=0;
		for (i = 0; i < totalSectors; i++)
		{
			vSecAddr  = SCRPGetFAPIGeometry(pDevice, ADDRESS_OF_SECTOR, i );
			if (i == tSector)
			{
				if ((errCode = VerifyProtectedSector(pDevice, i, vSecAddr, sectorTestAddr)) != EC_NONE)
				{
                    printf("Error: [0x%08X] Protect Sector %d %s\n", vSecAddr, i, GetErrorText(errCode));
					ProtectedSecErrCount++;
					//break;
				}
			}
			else
			{
				if ((errCode = VerifyUnprotectedSector(pDevice, vSecAddr, sectorTestAddr)) != EC_NONE)
				{
                    printf("Error: [0x%08X] Unprotect Sector %s\n", vSecAddr, GetErrorText(errCode));
					UnprotectedSecErrCount++;
					//break;
				}
			}
			if (SYS_CheckUserBreak())
			{
				errCode = EC_USERBREAK;
				break;
			}
		}

		//if (errCode) break;
		printf("ProtectedSecErrCount = %d, UnprotectedSecErrCount = %d\n", ProtectedSecErrCount, UnprotectedSecErrCount);
		if (errCode = SCRPSetASPFunc(pDevice, ASP_DYB, tSecAddr, FALSE))
		{
            printf("Error: Clearing DYB: %s\n", GetErrorText(errCode));
			break;
		}
		else
		{
			SCRPGetASPFunc(pDevice, ASP_DYB, tSecAddr, &Data);
			if (Data)
			{
				errCode = EC_DYBNOTCLEAR;
                printf("Error: [0x%08X] DYB not cleared: %s\n", tSecAddr, GetErrorText(errCode));
				break;
			}
		}
		printf("Dynamic Protection Bit SET/CLEAR OK on sector %d\n", tSector);
		sectorTestAddr += SCRPPAGESIZE;
		if (SYS_CheckUserBreak())
		{
			errCode = EC_USERBREAK;
			break;
		}
	}

	if (errCode)
    {
        if (errCode == EC_USERBREAK)
		printf("%s\n", GetErrorText(errCode));
        return test_exit(__LINE__);
    }

	printf("Test complete\n");
	//printf("The system needs to do power cycle to unlock the PPB Lock Bit\n");
    return test_exit(0);
} //main()

