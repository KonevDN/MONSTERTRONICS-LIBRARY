#ifdef SIMULATION
#include "sltapi_sim.h"
#include "svdpi.h"
#include "dpiheader.h"
#include <math.h>
#include "rpc2_vlld.h"
#include "rpc2_llops.h"
#else
#include <sltapi.h>
#endif
#include "rpc2.h"
#ifdef NCSC
extern int io_printf(const char *fmt, ...);
#define printf io_printf
#endif

char Script[] = "C04_ProgBitClearOtp 1";
char TestTitle[] = "Program bit clear OTP area";

int PROGRAM       = 1;
int READ_VER      = 1;
int R_V_LOOP      = 1;
int PreRead       = YES;

PDEV pDevice;
BYTE *pSrcData = (BYTE *)NULL;
BYTE *pDestData = (BYTE *)NULL;
STS t0, t1;
char s[81];

DWORD ProgOtpRegion(PDEV pDevice, int region, BYTE * src, int size_byte);
void print_buf(DWORD base, BYTE * buff, DWORD count);
DWORD test_exit(DWORD exit_val);

#ifdef SIMULATION
int c_test()
#else
int main(int argc, char* argv[])
#endif
{
    DWORD errCode;

    printf("Test: %s\n", Script);
    printf("%s\n", TestTitle);

#ifndef SIMULATION
    LOOP_COUNT      = GetGlobalVar("LOOP_COUNT");
    SOE             = GetGlobalVar("SOE");
    SKIP            = GetGlobalVar("SKIP");
    TOTALSECTORS    = GetGlobalVar("TOTALSECTORS");
    BUFSIZE         = GetGlobalVar("BUFSIZE"); 
    LARGESECSIZE    = GetGlobalVar("LARGESECSIZE"); 
    OTP_LR1         = GetGlobalVar("OTP_LR1");
    OTP_LR2         = GetGlobalVar("OTP_LR2");
    OTP_LR3         = GetGlobalVar("OTP_LR3");
    OTP_PR1         = GetGlobalVar("OTP_PR1");
    OTP_PR2         = GetGlobalVar("OTP_PR2");
    OTP_PR3         = GetGlobalVar("OTP_PR3");

    printf("OTP_LR1         = %d\n", GetGlobalVar("OTP_LR1"));
    printf("OTP_LR2         = %d\n", GetGlobalVar("OTP_LR2"));
    printf("OTP_LR3         = %d\n", GetGlobalVar("OTP_LR3"));
    printf("OTP_PR1         = %d\n", GetGlobalVar("OTP_PR1"));
    printf("OTP_PR2         = %d\n", GetGlobalVar("OTP_PR2"));
    printf("OTP_PR3         = %d\n", GetGlobalVar("OTP_PR3"));
#else
    LOOP_COUNT      = 1;
    SOE             = SOE_SETTING;
    SKIP            = 0;
    TOTALSECTORS    = 2;
    BUFSIZE         = 256; 
    LARGESECSIZE    = 256; 
    OTP_LR1         = 1;
    OTP_LR2         = 2;
    OTP_LR3         = 3;
    OTP_PR1         = 1;
    OTP_PR2         = 2;
    OTP_PR3         = 3;

    printf("OTP_LR1         = %d\n", OTP_LR1);
    printf("OTP_LR2         = %d\n", OTP_LR2);
    printf("OTP_LR3         = %d\n", OTP_LR3);
    printf("OTP_PR1         = %d\n", OTP_PR1);
    printf("OTP_PR2         = %d\n", OTP_PR2);
    printf("OTP_PR3         = %d\n", OTP_PR3);
#endif
    line_space(2);
    printf("PROGRAM  = %d\n", PROGRAM);
    printf("READ_VER = %d (loop count = %d)\n", READ_VER, R_V_LOOP);
    line_space(2);

    if (SKIP)
    {
        line_space(2);
        printf("Test is skipped\n");
        return __LINE__;
    }

#ifdef SIMULATION
    pDevice = NewDeviceObject(0, RPC);
#endif
	pDevice = Find_Device(RPC);

    if (!pDevice)
    {
        line_space(2);
        printf("Error: RPC device not found\n");
        return __LINE__;
    }
    printf("Device: %s\n", (char *) SCRPGetFAPIInfo(pDevice, DEVICE_NAME));

    SYS_GetTimestamp(&t0);
    pSrcData  = (BYTE *) malloc(OTP_SIZE);
    pDestData  = (BYTE *) malloc(OTP_SIZE);
    if (!pDestData || !pSrcData)
    {
        printf("Error: Malloc error\n");
        return test_exit(__LINE__);
    }

    FillBuffer(BYTES_ARE_0X00, pSrcData, OTP_SIZE);
    print_buf(0, pSrcData, 256);
    line_space(2);

    // programm the first selected OTP region
    //errCode = ProgOtpRegion(pDevice, OTP_PR1, pSrcData, OTP_REG_SIZE/128);
    errCode = ProgOtpRegion(pDevice, OTP_PR1, pSrcData, 1);
    if ((errCode != EC_NONE) && SOE)
        return test_exit(__LINE__);

    // programm the second selected OTP region
    //errCode = ProgOtpRegion(pDevice, OTP_PR2, pSrcData, OTP_REG_SIZE/32);
    if ((errCode != EC_NONE) && SOE)
        return test_exit(__LINE__);

    // programm the third selected OTP region
    //errCode = ProgOtpRegion(pDevice, OTP_PR3, pSrcData, OTP_REG_SIZE/32);
    if ((errCode != EC_NONE) && SOE)
        return test_exit(__LINE__);

    line_space(2);
    printf("Test complete\n");
    #ifndef SIMULATION
    if (TASK_DELAY)
        SYS_OSTickDelay(TASK_DELAY);
    #endif
    return test_exit(0);
} // main()

DWORD ProgOtpRegion(PDEV pDevice, int region, BYTE * src, int size_byte)
{
    int i, j, loop;
    DWORD otp_addr;
    DWORD status = EC_NONE;
    DWORD dev_register;
    unsigned char data;

    if (region == 0)
    {
        //printf("Error: program region 0\n");
        return EC_NONE;
    }

    //otp_addr = region * size_byte;
    otp_addr = region * 32;
    if (PROGRAM)
    {
        line_space(2);
        printf("Programming OTP region %d", region);
        for (i = 0; i < (size_byte/2+size_byte%2); i++)
        {
            // bit clear program a byte
            for (j = 0; j < 8; j++)
            {
                data = (0xFE << j);
                SCRPQSPIPgmOTP(pDevice, (WORD *) &data, otp_addr + 2*i, 1);
                do
                {
                    SCRPGetStatusReg(pDevice, 0, &dev_register);
                }
                while (dev_register == 0x0000);

                if (dev_register & 0x0010)
                {
                    printf("\nError: OTP program failed, addr 0x%08X\n", (unsigned int)(otp_addr + i));
                    status = EC_PROGDATA;
                    #ifndef SIMULATION
                    OutputLog(pDevice, LOG_DISP_NORM, 0, -30);
                    #endif
                    if (SOE)
                        return status;
                }
            }

        }
        if (status == EC_NONE)
            printf("... OK\n");
    }

    if (READ_VER)
    {
        // read-verify after programming
        printf("Read-verify OTP region %d", region);
        for (loop = 1;  loop <= R_V_LOOP; loop++)
        {
            SCRPQSPIReadOTP(pDevice, (WORD *) pDestData, otp_addr, size_byte);
            if (memcmp(src, pDestData, size_byte))
            {
                printf("\n");
                status = EC_READDATA;
                printf("Error: OTP program failed, region %d\n", region);
                for (i = 0; i < size_byte; i++)
                {
                    if (src[i] != pDestData[i])
                    {
                        printf("Error: addr 0x%08X, read 0x%02X, expect 0x%02X ", (unsigned int)(otp_addr + i), (unsigned int)pDestData[i], (unsigned int)src[i]);
                        printf("read count = %d\n", loop);
                    }
                }
                if (SOE)
                    return status;
            }
        }
        if (status == EC_NONE)
            printf("... OK\n");

    } // if (READ_VER)

    return status;
} // ProgOtpRegion()

void print_buf(DWORD base, BYTE * buff, DWORD count)
{
    unsigned int i;

    for (i = 0; i < count; i++)
    {
        if ((i % 8) == 0)
        {
            printf("\n0x%08X ", (unsigned int)(i + base));
            #ifndef SIMULATION
            SYS_WaitUSec(1000);
            #endif
        }
        printf("%02X ", buff[i]);
    }
    printf("\n");
} // printf_buf()

DWORD test_exit(DWORD exit_val)
{
    if (pSrcData)
        free(pSrcData);

    if (pDestData)
        free(pDestData);

    SYS_GetTimestamp(&t1);
    FormatDeltaTime(s, &t0, &t1);
    printf("Test time: %s\n", s);

    if (exit_val)
    {
        SetGlobalVar("SKIP", 1);
	printf("<TC> Test =========================== Fail\n");
    }
    else {
      printf("<TC> Test =========================== Pass\n");
    }

    return(exit_val);
} // test_exit()


