#ifdef SIMULATION
#include "sltapi_sim.h"
#include "svdpi.h"
#include "dpiheader.h"
#include <math.h>
#include "rpc2_vlld.h"
#include "rpc2_llops.h"

#else
#include <sltapi.h>
#endif

#include "rpc2.h"

#ifdef NCSC
extern int io_printf(const char *fmt, ...);
#define printf io_printf
#endif

//
//----------------------------------------------------------------------------------
//  Script: Buffer Write with XX&YY Word Program test
//----------------------------------------------------------------------------------
char Script[] = "408_BufferWriteXXYYWordProg";
char TestTitle[] = "Buffer Write with XX&YY Word Program test";

// Command line arguments and their default values
DWORD help_only = NO;                 // display help only (NO), execute test (YES)
DWORD PreRead = NO;         // Blank check before buffer write: enabled(YES), disabled(NO)

// Test Configuration
SOE       = SOE_SETTING;        // Stop on Error flag
SKIP = 0;
LOOP_COUNT = 1;//LOOPS;
DWORD ERASE = 1;
burst_mode = 1;
PDEV pDevice;

// Global variables
WORD *pSrcData = (WORD *)NULL;
WORD *pDestData = (WORD *)NULL;
STS t0, t1;
char s[81];

DWORD DATAP      =  WORDS_ARE_RANDOM;
char DATAP_str[] = "WORDS_ARE_RANDOM";

// Functions prototyping
DWORD BufferWriteRandWordProgram(PDEV, DWORD, DWORD, WORD *, DWORD);
DWORD test_exit(DWORD exit_val);
DWORD GetDataPattern(DWORD * dpvar);
DWORD EraseSector(PDEV dev, DWORD sector);
void linespace(DWORD n);
void help(void);
void print_buf(WORD * buff, DWORD count);
DWORD rpc_ctrl_init(void);

//----------------------------------------------------------------------------------
//RPC Test script begin
//----------------------------------------------------------------------------------
#ifdef SIMULATION
int c_test()
#else
int main(int argc, char* argv[])
#endif
{
    DWORD tSector, tSecAddr, tSecSize;
    DWORD logStat, errCode;
    DWORD totalSectors, bufSize, largeSecSize;
    DWORD i;
    DWORD loop;
    int voltage, temperature;
    DWORD data_p;
    DWORD bwsize;

	  
    linespace(2);
    printf("<TC> Test: %s\n", Script);
    printf("%s\n", TestTitle);
    
	#ifndef SIMULATION
    SKIP = GetGlobalVar("SKIP");
    #endif
    
    if (SKIP)
    {
        line_space(2);
        printf("<TC> Test is skipped\n");
        return __LINE__;
    }
#ifndef SIMULATION    
    GetArgEnum("help", &help_only, "YES_NO");
    if (help_only == YES)
    {
        help();
        return 0;
    }
#endif

	#ifdef SIMULATION    
    pDevice = NewDeviceObject(0, RPC);
	#endif	
	  
	pDevice = Find_Device(RPC); 
	  
    if (!pDevice)
    {
        printf("<TC> Error: RPC device not found\n");
        return __LINE__;
    }
    printf("Device: %s\n", SCRPGetFAPIInfo(pDevice, DEVICE_NAME));


	SCRPQSPISetWP(pDevice, FALSE);
	printf("<TC> Enable write\n");
	SYS_WaitUSec(1);
	    
    SYS_GetTimestamp(&t0);
    errCode = EC_NONE;
    totalSectors = SCRPGetFAPIInfo(pDevice, SECTOR_COUNT);
    bufSize = SCRPGetFAPIInfo(pDevice, WRITE_BUFFER_SIZE);
    largeSecSize = SCRPGetFAPIInfo(pDevice, LARGEST_SECTOR);
    pSrcData = (WORD *) malloc(sizeof(WORD) * largeSecSize);
    pDestData = (WORD *) malloc(sizeof(WORD) * largeSecSize * 4);
    if (!pSrcData || !pDestData)
    {
        printf("<TC> malloc error!\n");
        return test_exit(__LINE__);
    }

    linespace(2);
#ifndef SIMULATION    
    GetArgEnum("pr", &PreRead, "YES_NO");
#endif     
    printf("<TC> Initializing Buffers %d words\n", largeSecSize);
    data_p = DATAP;
    GetDataPattern(&data_p);
    FillBuffer(data_p, pSrcData, largeSecSize);
    linespace(1);
    printf("<TC> Data pattern\n");
    if (1) // display first 128 words data pattern
    {
        for (i = 0; i < 128; i++)
        {
            if ((i % 8) == 0)
                printf("\n%04X ", i);
            printf("%04X ", pSrcData[i]);
        }
        printf("\n");
        printf("...\n...\n");
    }

    bwsize = rand() % 32 + 1;
#ifndef SIMULATION    
    GetArg("bs", &bwsize);
#endif 

#ifdef SIMULATION
    #ifdef DEF_BUFSIZE
    if(DEF_BUFSIZE==0)
        bwsize = bufSize;
    else
    bwsize = DEF_BUFSIZE;
    #endif
#endif

    if(bwsize > bufSize)
    {
       printf("<TC> Warning: Exceeding Buffer Size\n");
       printf("<TC> Use max buffer size %d words\n", bufSize);
       bwsize = bufSize;
    }

    linespace(2);
    printf("<TC> Buffer Write %d & %d Program Test\n", bwsize, bufSize - bwsize);
#ifndef SIMULATION     
    SYS_GetVoltage(VOLT_18, &voltage);
    SYS_GetTemperature(0, &temperature);
    printf("<TC> Temperature = %dC\n", temperature);
    printf("<TC> Voltage = %d.%dV\n", voltage/1000, voltage%1000);
#endif 

    linespace(2);
    
    for (loop = 0; loop < LOOP_COUNT; loop++)
    {
	#ifndef SIMULATION         
        ClearDevLog(pDevice);
	#endif  
        for (tSector = 0; tSector < totalSectors; tSector++)
        {
            tSecAddr  = SCRPGetFAPIGeometry(pDevice, ADDRESS_OF_SECTOR, tSector);
            tSecSize = SCRPGetFAPIGeometry(pDevice, WORD_COUNT_OF_SECTOR, tSector);
            printf("\n<TC> Erasing Sector %d ... \n", tSector);
            if (SYS_CheckUserBreak())
            {
                printf("\n\n<TC> User Break\n");
                return test_exit(0);
            }

            errCode = EraseSector(pDevice, tSector);
            if (errCode != EC_NONE)
            {
                if (SOE)
                {
                    printf("\n\n<TC> Stop on Error\n");
                    return test_exit(__LINE__);
                }
                continue;   // move on to next sector
            }
#ifndef SIMULATION 
            logStat = SaveDevLogState(pDevice);
            SetLogDevice(pDevice, LOG_RW_ALL);
 #endif           
            printf("<TC> Buffer Write Rand Word Program on sector %d\n", tSector);
            errCode = BufferWriteRandWordProgram(pDevice, tSecAddr, tSecSize, pSrcData, bwsize);
            if (errCode != EC_NONE)
            {
                printf("<TC> Error: %s", GetErrorText(errCode));
                if (SOE)
                {
                    printf("\n\n<TC> Stop on Error\n");
                    return test_exit(__LINE__);
                }
                continue;   // move on to next sector
            }

            errCode = EC_NONE;
            memset(pDestData, 0, sizeof(WORD) * tSecSize * 4);
            printf("<TC> Read Verify on address 0x%08X with length of %d words\n", tSecAddr, tSecSize);

            errCode = SCRPReadArray(pDevice, pDestData, tSecAddr, tSecSize);
            if (errCode != EC_NONE)
            {
                printf("<TC> Error: %s", GetErrorText(errCode));
                if (SOE)
                {
                    printf("\n\n<TC> Stop on Error\n");
                    return test_exit(__LINE__);
                }
                continue;   // move on to next sector
            }

	#ifndef SIMULATION
                RestoreDevLogState(pDevice, logStat);
   	#endif     
            for (i = 0; i < tSecSize; i++)
            {
                if (pSrcData[i] != pDestData[i])
                {
                    printf("<TC> Written: 0x%04X, Read: 0x%04X, Offset: 0x%04X\n", pSrcData[i], pDestData[i], i);
                    if (SOE)
                    {
                        printf("\n\n<TC> Stop on Error\n");
                        return test_exit(__LINE__);
                    }
                    break;
                }
            }
        } // for (tSector = 0; tSector < totalSectors; tSector++)
    } // for (loop = 0; loop < LOOP_COUNT; loop++)
// } //FOR tCS

    printf("<TC> Test complete\n");
#ifndef SIMULATION        
    if (TASK_DELAY)
        SYS_OSTickDelay(TASK_DELAY);
#endif 
    return test_exit(0);
} // main()

DWORD BufferWriteRandWordProgram(PDEV pDevice, DWORD secAddr, DWORD progSize, WORD *pData,
                                 DWORD bwsize)
{
    DWORD errCode;
    DWORD i;
    DWORD timeoutCount;
    DWORD randnumber;
    DWORD bufSize;
    DWORD signal;

    errCode = EC_NONE;
    timeoutCount = 0;
    signal = 1;
    randnumber = 0;
    bufSize = SCRPGetFAPIInfo(pDevice, WRITE_BUFFER_SIZE);
    for (i = 0; i < progSize; )//i++, secAddr++
    {
        if(signal)
        {
            randnumber = rand() % bufSize + 1;
            if(randnumber != bufSize)
                signal = 0;
        }
        else
        {
            randnumber = bufSize - randnumber;
            signal = 1;
        }

        if (PreRead == YES)
            errCode = SCRPBufferWriteBlankCheck(pDevice, &pData[i], secAddr, randnumber, TRUE);
        else
            errCode = SCRPBufferWrite(pDevice, &pData[i], secAddr, randnumber, TRUE);
        if (errCode != EC_NONE)
        {
            if (errCode != EC_PROGTIMEOUT)
                break;
            else
            {
                printf("<TC> [%08X] %x, Timeout error \n", secAddr, pData[i]);
                timeoutCount++;
            }
        }

        i = i + randnumber;
        secAddr = secAddr + randnumber;
    }
    if (errCode)
        printf("<TC> [%08X] %x, WordProgram error \n", secAddr, pData[i]);
    if (timeoutCount)
        printf("<TC> Timeout Error count = %d\n", timeoutCount);

    return(errCode);
} // BufferWriteRandWordProgram()

DWORD test_exit(DWORD exit_val)
{
    if (pSrcData) free(pSrcData);
    if (pDestData) free(pDestData);

    SYS_GetTimestamp(&t1);
    FormatDeltaTime(s, &t0, &t1);
    printf("<TC> Test time: %s\n", s);
    if (exit_val)
    {
        SetGlobalVar("SKIP", 1);
	printf("<TC> Test =========================== Fail\n");
    }
    else {
      printf("<TC> Test =========================== Pass\n");
    }
    return exit_val;
} // test_exit()

DWORD GetDataPattern(DWORD * dpvar)
{
    DWORD adata_p;
    DWORD status;

#ifndef SIMULATION
    status = GetArgEnum("dp", &adata_p, "FILL_TYPES");
#endif     
    if (status == TRUE)
        *dpvar = adata_p;
    else
    {
        printf("<TC> Warning: dp argument missing or wrong\n");
        printf("<TC> Use default data pattern\n");
        *dpvar = WORDS_ARE_RANDOM;
    }
    printf("<TC> data pattern = ");
    switch (*dpvar)
    {
        case BYTES_ARE_0X00:
            printf("BYTES_ARE_0X00\n");
            break;
        case BYTES_ARE_0X55:
            printf("BYTES_ARE_0X55\n");
            break;
        case BYTES_ARE_0XFF:
            printf("BYTES_ARE_0XFF\n");
            break;
        case BYTES_ALT_0X00_0XFF:
            printf("BYTES_ALT_0X00_0XFF\n");
            break;
        case BYTES_ALT_0X55_0XAA:
            printf("BYTES_ALT_0X55_0XAA\n");
            break;
        case BYTES_ARE_ADDRESSES:
            printf("BYTES_ARE_ADDRESSES\n");
            break;
        case BYTES_ARE_RANDOM:
            printf("BYTES_ARE_RANDOM\n");
            break;
        case WORDS_ARE_0X0000:
            printf("WORDS_ARE_0X0000\n");
            break;
        case WORDS_ARE_0X5555:
            printf("WORDS_ARE_0X5555\n");
            break;
        case WORDS_ARE_0XFFFF:
            printf("WORDS_ARE_0XFFFF\n");
            break;
        case WORDS_ALT_0X0000_0XFFFF:
            printf("WORDS_ALT_0X0000_0XFFFF\n");
            break;
        case WORDS_ALT_0X5555_0XAAAA:
            printf("WORDS_ALT_0X5555_0XAAAA\n");
            break;
        case WORDS_ALT_0X55AA_0XAA55:
            printf("WORDS_ALT_0X55AA_0XAA55\n");
            break;
        case WORDS_ALT_4_OF_0X0000_4_OF_0XFFFF:
            printf("WORDS_ALT_4_OF_0X0000_4_OF_0XFFFF\n");
            break;
        case WORDS_ARE_ADDRESSES:
            printf("WORDS_ARE_ADDRESSES\n");
            break;
        case WORDS_ARE_RANDOM:
            printf("WORDS_ARE_RANDOM\n");
            break;
    } // switch

    return status;
} // GetDataPattern()

DWORD EraseSector(PDEV dev, DWORD sector)
{
    DWORD errCode;
    DWORD logStat;
    DWORD secSize;
    DWORD secAddr;
    DWORD i;

    secSize = SCRPGetFAPIGeometry(dev, WORD_COUNT_OF_SECTOR, sector);
    secAddr  = SCRPGetFAPIGeometry(dev, ADDRESS_OF_SECTOR, sector);

    errCode = SCRPEraseSector(dev, sector, TRUE);
    if (errCode != EC_NONE)
    {
        printf("<TC> Error: %s\n", GetErrorText(errCode));
        return errCode;
    }

    errCode = EC_NONE;
    memset(pDestData, 0, sizeof(WORD) * secSize * 4);
#ifndef SIMULATION       
    logStat = SaveDevLogState(dev);
    SetLogDevice(dev, LOG_RW_ALL);
#endif        
    SCRPReadArray(dev, pDestData, secAddr, secSize);
#ifndef SIMULATION    
    RestoreDevLogState(dev, logStat);
 #endif       
    for (i = 0; i < secSize; i++)
    {
        if (pDestData[i] != 0xFFFF)
        {
            printf("<TC> Error: Blank Check\n");
            return EC_ERASEVERIFY;
        }
    }

    printf("<TC> OK\n");
    return EC_NONE;
} // EraseSector()

void linespace(DWORD n)
{
    DWORD i;

    for (i = 0; i < n; i++)
        printf("\n");
    printf("<TC> ****************************\n");
} // linespace()

void help(void)
{
    linespace(2);
    printf("<TC> %s command line arguments\n", Script);
    printf("<TC> dp: data pattern, default BYTES_ALT_0X55_0XAA\n");
    printf("<TC> bs: buffer-write size, default max write buffer size\n");
    printf("<TC> pr: pre-read blank check, default NO\n");
    printf("<TC> example:\n");
    printf("<TC> Tgt1=>- dp=BYTES_ALT_0X55_0XAA bs=32 pr=YES\n");
    linespace(0);
} // help()

