#ifdef SIMULATION
#include "sltapi_sim.h"
#include "svdpi.h"
#include "dpiheader.h"
#include <math.h>
#include "rpc2_vlld.h"
#include "rpc2_llops.h"

#else
#include <sltapi.h>
#endif
#include "rpc2.h"

#ifdef NCSC
extern int io_printf(const char *fmt, ...);
#define printf io_printf
#endif

//
//----------------------------------------------------------------------------------
//  Script: Word Program test
//  Before running this script, the Include.scp needs to be downloaded first.
//----------------------------------------------------------------------------------
char Script[] = "420_SingleWordProg_AA55";
char TestTitle[] = "Single Word Programming Test";

/* Test Configuration */


#ifdef SIMULATION
SOE       = SOE_SETTING;        // Stop on Error flag
SKIP = 0;
LOOP_COUNT = 1;
#else
DWORD LOOP_COUNT = 1;
DWORD SOE = SOE_SETTING;        // Stop on Error flag
DWORD SKIP = 0;
#endif

DWORD ERASE = 1;
//----------------------------------------------------------------------------------
//NOR Test script begin
//----------------------------------------------------------------------------------

PDEV pDevice;

//DWORD DATAP      =  WORDS_ALT_0X5555_0XAAAA;
//char DATAP_str[] = "WORDS_ALT_0X5555_0XAAAA";

//DWORD DATAP      =  WORDS_ARE_ADDRESS_PLUS_1;
//char DATAP_str[] = "WORDS_ARE_ADDRESS_PLUS_1";

DWORD DATAP      =  WORDS_ALT_0X55AA_0XAA55;
char DATAP_str[] = "WORDS_ALT_0X55AA_0XAA55";

//DWORD DATAP      =  WORDS_ARE_0XFFFF;
//char DATAP_str[] = "WORDS_ARE_0XFFFF";

//DWORD DATAP      =  WORDS_ARE_RANDOM;
//char DATAP_str[] = "WORDS_ARE_RANDOM";

WORD *pSrcData   = (WORD *)NULL;
WORD *pDestData  = (WORD *)NULL;
WORD *pEraseData = (WORD *)NULL;

STS t0, t1;
char s[81];


DWORD Program(DWORD secAddr, DWORD progSize, WORD *pData);
DWORD ReadVerify(DWORD SecAddr, DWORD SecSize, WORD *pSrcData, WORD *pDestData);
void print_buf(WORD * buff, DWORD count);
DWORD rpc_ctrl_init(void);
DWORD Read_RPC_CTRL_Regs(void);
DWORD test_exit(DWORD exit_val);

#ifdef SIMULATION
int c_test()
#else
int main(int argc, char* argv[])
#endif
{
    DWORD tBank, tSector, tSecAddr, tSecSize;
    DWORD errCode, totalSectors, bufSize, largeSecSize;
    DWORD loop;
    int voltage, temperature;
	

    printf("Test: %s\n", Script);
    printf("%s\n", TestTitle);

	#ifndef SIMULATION
    SKIP = GetGlobalVar("SKIP");
	#endif
	//printf("1\n");
    if (SKIP)
    {
        line_space(2);
        printf("Test is skipped\n");
        return __LINE__;
    }
	
	#ifdef SIMULATION
    pDevice = NewDeviceObject(0, RPC);
	#endif
	
    pDevice = Find_Device(RPC);
    if (!pDevice)
    {
        printf("Error: No device found\n");
        return (__LINE__);
    }
    else
        printf("Device: %s\n", SCRPGetFAPIInfo(pDevice, DEVICE_NAME));
	
	
	SCRPQSPISetWP(pDevice, FALSE);
	printf("Enable write\n");
	SYS_WaitUSec(300);
	
	
    SYS_GetTimestamp(&t0);
	
	
    errCode = EC_NONE;
    totalSectors = SCRPGetFAPIInfo(pDevice, SECTOR_COUNT);
    bufSize = SCRPGetFAPIInfo(pDevice, WRITE_BUFFER_SIZE);
    largeSecSize = SCRPGetFAPIInfo(pDevice, LARGEST_SECTOR);
	printf("totalSectors = %d, bufSize = %d, largeSecSize = 0x%08X\n",totalSectors,bufSize,largeSecSize);

    pSrcData = (WORD *) malloc(sizeof(WORD) * largeSecSize);
    pDestData = (WORD *) malloc(sizeof(WORD) * largeSecSize);
    pEraseData = (WORD *) malloc(sizeof(WORD) * largeSecSize);

    if (!pSrcData || !pDestData || !pEraseData)
    {
        printf("Error: Malloc error\n");
        return test_exit(__LINE__);
    }

    if (DATAP == WORDS_ARE_RANDOM)
    {
        srand(100);
        printf("Random Seed = 100\n");
    }
    FillBuffer(DATAP, pSrcData, largeSecSize);
    print_buf(pSrcData, 256);

    memset(pEraseData, 0xFFFF, sizeof(WORD) * largeSecSize);

    printf("Word Program Test\n");

	#ifndef SIMULATION
    SYS_GetVoltage(VOLT_18, &voltage);
    printf("%d.%dV\n", voltage/1000, voltage%1000);
    SYS_GetVoltage(VOLT_3, &voltage);
    printf("%d.%dV\n", voltage/1000, voltage%1000);
    SYS_GetTemperature(0, &temperature);
    printf("%dC\n", temperature);
	#endif

    for (loop = 0; loop < LOOP_COUNT; loop++)
    {
        if (SYS_CheckUserBreak())
        {
            errCode = EC_USERBREAK;
            break;
        }

        for (tSector = 0; (tSector < totalSectors); tSector++)
        {
            if (SYS_CheckUserBreak())
            {
                errCode = EC_USERBREAK;
                break;
            }

            tSecAddr  = SCRPGetFAPIGeometry(pDevice, ADDRESS_OF_SECTOR, tSector );
            tSecSize = SCRPGetFAPIGeometry(pDevice, WORD_COUNT_OF_SECTOR, tSector );
            tBank = SCRPGetFAPIGeometry(pDevice, BANK_FROM_SECTOR, tSector);
            printf("loop=%d, tBank=%d, tSector=%d \n", loop, tBank, tSector);

            if (ERASE)
            {
                printf("Erasing Sector %d ...\n", tSector);
                errCode = SCRPEraseSector(pDevice, tSector, TRUE);
                if (errCode != EC_NONE)
                {
                    printf("loop=%d, tBank=%d, tSector=%d, tSecAddr=0x%08X \n", loop, tBank, tSector, tSecAddr);
                    printf("Error: %s\n", GetErrorText(errCode));
                    #ifndef SIMULATION
                	OutputLog(pDevice, LOG_DISP_NORM, 0, -30);
					#endif

                    if (SOE)
                        return test_exit(__LINE__);
                    continue;
                }

                errCode = ReadVerify(tSecAddr, tSecSize, pEraseData, pDestData);
                if (errCode != EC_NONE)
                {
                    printf("loop=%d, tBank=%d, tSector=%d, tSecAddr=0x%08X \n", loop, tBank, tSector, tSecAddr);
                    printf("Error: %s\n", GetErrorText(errCode));
                    #ifndef SIMULATION
                	OutputLog(pDevice, LOG_DISP_NORM, 0, -30);
					#endif

                    if (SOE)
                        return test_exit(__LINE__);
                    continue;
                }
            } // Erase

            printf("Word Program on sector %d\n", tSector);
            errCode = Program(tSecAddr, tSecSize, pSrcData);
            if (errCode != EC_NONE)
            {
                printf("loop=%d, tBank=%d, tSector=%d, tSecAddr=0x%08X \n", loop, tBank, tSector, tSecAddr);
                printf("Error: %s\n", GetErrorText(errCode));
                #ifndef SIMULATION
                OutputLog(pDevice, LOG_DISP_NORM, 0, -30);
				#endif

                if (SOE)
                    return test_exit(__LINE__);
                continue;
            }

            errCode = ReadVerify(tSecAddr, tSecSize, pSrcData, pDestData);
            if (errCode != EC_NONE)
            {
                printf("loop=%d, tBank=%d, tSector=%d, tSecAddr=0x%08X \n", loop, tBank, tSector, tSecAddr);
                printf("Error: %s\n", GetErrorText(errCode));
				#ifndef SIMULATION
                OutputLog(pDevice, LOG_DISP_NORM, 0, -30);
				#endif

                if (SOE)
                    return test_exit(__LINE__);
                continue;
            }
        } //for (tSector = 0; (tSector < totalSectors); tSector++)
    } //for (loop = 0; loop < LOOP_COUNT; loop++)
	#ifndef SIMULATION
    if (TASK_DELAY)
        SYS_OSTickDelay(TASK_DELAY);
	#endif
    return test_exit(0);
} //main()

DWORD Program(DWORD secAddr, DWORD progSize, WORD *pData)
{
    DWORD errCode, i, timeoutCount;

    errCode = EC_NONE;
    timeoutCount = 0;
	
    for (i = 0; i < progSize; i++, secAddr++)
        if ((errCode = SCRPSProg(pDevice, secAddr, (DWORD) pData[i])) != EC_NONE)
        {
            if (errCode != EC_PROGTIMEOUT)
                break;
            else
            {
                printf("[%08X] %x, Timeout error \n", secAddr, pData[i]);
                timeoutCount++;
            }
        }
       
    if (errCode)
        printf("Error: WordProgram addr 0x%08X expect 0x%04X\n", secAddr, pData[i]);
    if (timeoutCount)
        printf("Timeout Error count = %d\n", timeoutCount);

    return(errCode);
}

DWORD ReadVerify(DWORD SecAddr, DWORD SecSize, WORD *pSrcData, WORD *pDestData)
{
    DWORD errCode, i, j, logStat;

    errCode = EC_NONE;
    printf("Read Verify on address 0x%x with length of 0x%x\n", SecAddr, SecSize);

    memset(pDestData, 0, sizeof(WORD) * SecSize);
	#ifndef SIMULATION	
    logStat = SaveDevLogState(pDevice);
    SetLogDevice(pDevice, LOG_NONE);
	#endif
    if ((errCode = SCRPReadArray(pDevice, pDestData, SecAddr, SecSize)) != EC_NONE)
    {
		#ifndef SIMULATION
		RestoreDevLogState(pDevice, logStat);
		#endif
        return(errCode);
    }
	#ifndef SIMULATION
    RestoreDevLogState(pDevice, logStat);
	#endif
    if (memcmp(pSrcData, pDestData, sizeof(WORD) * SecSize))
    {
        for (i = 0, j = 0; i < SecSize; i++)
        {
            if (pSrcData[i] != pDestData[i])
            {
                printf("Error: addr 0x%08X, read 0x%04X, expect 0x%04X\n", SecAddr + i, pDestData[i], pSrcData[i]);
                j++;
                if (errCode = SYS_CheckUserBreak())
                {
                    return errCode;
                }
				errCode = EC_READDATA;
            }

            // Remove the following codes to show all errors
            if (j > 20)
            {
                printf("too many errors...\n");
                break;
            }
        } // for (i = 0, j = 0; i < SecSize; i++)
    } //if (memcmp(pSrcData, pDestData, sizeof(WORD) * SecSize))

    memset(pDestData, 0, sizeof(WORD) * SecSize);

    if (errCode == EC_NONE)
        printf("Read Verify on Address 0x%08X, Size 0x%08X OK\n", SecAddr, SecSize);

    return(errCode);
}

void print_buf(WORD * buff, DWORD count)
{
    DWORD i;

    for (i = 0; i < count; i++)
    {
        if ((i % 8) == 0) printf("\n0x%08X ", i);
        printf("%04X ", buff[i]);
    }
    printf("\n");
} // printf_buf()

DWORD test_exit(DWORD exit_val)
{
    if (pSrcData) free(pSrcData);
    if (pDestData) free(pDestData);
    if (pEraseData) free(pEraseData);

    SYS_GetTimestamp(&t1);
    FormatDeltaTime(s, &t0, &t1);
    printf("Test time: %s\n", s);

    if (exit_val)
    {
        SetGlobalVar("SKIP", 1);
	printf("<TC> Test =========================== Fail\n");
    }
    else {
      printf("<TC> Test =========================== Pass\n");
    }

    return (exit_val);
} // test_exit()

