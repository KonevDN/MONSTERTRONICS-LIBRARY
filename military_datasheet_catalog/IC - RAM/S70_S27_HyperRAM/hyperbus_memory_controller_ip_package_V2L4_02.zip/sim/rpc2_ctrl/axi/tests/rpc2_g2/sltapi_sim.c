#include "sltapi_sim.h"


extern PDEV pDevice;   // global flash device

extern PDEV FAPIGetDevice(DWORD index);

/**<SCRPGetCSControl>**************************************************
DESCRIPTION:  Get cs control information
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        DWORD   type            type of information to get
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Values: DWORD           value of cs control information
**********************************************************************/
DWORD SCRPGetCSControl(PDEV pDevice, DWORD type)
{
    return SYS_GetCSControl(type);
}

/**<SCRPSetCSControl>**************************************************
DESCRIPTION:  Set cs control information
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        DWORD   type            type of information to set
        DWORD   value           value to set in cs control
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Type:   DWORD           operation status
        Values: TRUE            no error
                FALSE           error
**********************************************************************/
DWORD SCRPSetCSControl(PDEV pDevice, DWORD type, DWORD value)
{
    return SYS_SetCSControl(type, value);
}

/**<SCRPGetFAPIInfo>***************************************************
DESCRIPTION:  Get configuration information
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        DWORD   type            type of information to get
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Values: DWORD           value of configuration information
**********************************************************************/
DWORD SCRPGetFAPIInfo(PDEV pDevice, DWORD type)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.dwType = type;
    pDevice->pGetFAPIInfo(&Arg);
    return Arg.dwResult;
}


/**<SCRPGetFAPIGeometry>***********************************************
DESCRIPTION:  Get geometry information
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        DWORD   type            type of geometry information to get
        DWORD   select          subtype selection
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Values: DWORD           value of geometry information
**********************************************************************/
DWORD SCRPGetFAPIGeometry(PDEV pDevice, DWORD type, DWORD select)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.dwType = type;
    Arg.dwSelect = select;
    pDevice->pGetFAPIGeometry(&Arg);
    return Arg.dwResult;
}

/**<SCRPCmd>***********************************************************
DESCRIPTION:  Write a WORD to NOR device
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        WORD    *dest           pointer to destination WORD or BYTE
                                buffer
        DWORD   addr            starting WORD address to write
        DWORD   data            data to write to device
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
**********************************************************************/
DWORD SCRPCmd(PDEV pDevice, DWORD addr, DWORD data)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.fl_addr = addr;
    Arg.fl_data = data;
    return pDevice->pWriteNORData(&Arg);
}

/**<SCRPSupport>*******************************************************
DESCRIPTION:  Get supprting features of device
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Type:   DWORD          supporting features
**********************************************************************/
DWORD SCRPSupport(PDEV pDevice)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.dwType = FEATURES;
    pDevice->pGetFAPIInfo(&Arg);
    return Arg.dwResult;
}

/**<SCRPRead>**********************************************************
DESCRIPTION:  Read a WORD from NOR device or a BYTE from SPI device
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        DWORD   addr            starting WORD address on NOR device or
                                BYTE address on SPI device to read
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Values: DWORD           data read from device
**********************************************************************/
DWORD SCRPRead(PDEV pDevice, DWORD addr)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.fl_addr = addr;
    pDevice->pReadNORData(&Arg);
    return (DWORD)Arg.fl_data;
}

/**<SCRPCFIRead>*******************************************************
DESCRIPTION:  Read AutoSelect data from NOR device or SPI device
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        DWORD   bank            bank address(NOR device only)
OUTPUTS:
    PARAMETERS:
        WORD    *dest           pointer to destination WORD(NOR) or
                                BYTE(SPI) buffer
    RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
            EC_DEVICEERROR      device generic error
**********************************************************************/
DWORD SCRPCFIRead(PDEV pDevice, DWORD bank, WORD *dest)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    //Arg.st_addr = SCRPGetFAPIGeometry(pDevice, ADDRESS_OF_BANK, bank);
    Arg.st_addr = 0;
    Arg.pDest = dest;
    return pDevice->pReadCFI(&Arg);
}

/**<SCRPWriteArray>****************************************************
DESCRIPTION:  Program a quantity of WORDs to NOR device or BYTEs to SPI
              device from a buffer
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        WORD    *src            pointer to source WORD or BYTE buffer
        DWORD   addr            starting WORD address on NOR device or
                                BYTE address on SPI device to write
        DWORD   count           number of WORDs or BYTEs to write
        BOOL    useBW           use buffered write if available
        BOOL    cont            continue writing past errors
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
            EC_PARAMETER        parameter error
            EC_NOTSUPPORTED     function not supported by device
            EC_READDATANOTBLANK read data not 0xFFFF
            EC_BWINTTO          internal programming timeout
            EC_BWABORT          write buffer abort
            EC_BWTIMEOUT        exceeded maximum program timeout
            EC_BWVERIFY         data verify failure
            EC_DEVICEERROR      device generic error
**********************************************************************/
DWORD SCRPWriteArray(PDEV pDevice, WORD *src, DWORD addr, DWORD count, BOOL useBW, BOOL cont)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.pSrc = src;
    Arg.st_addr = addr;
    Arg.dwCount = count;
    if (useBW) Arg.dwOptNOR |= NOR_WRITE_BUFFER;
    if (cont) Arg.dwOptNOR |= NOR_PBUFF_ERROR_GO;
    return pDevice->pProgNORBuffer(&Arg);
}

/**<SCRPSProg>*********************************************************
DESCRIPTION:  Program one data word to NOR device
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        DWORD   addr            flash address to program
        DWORD   value           value to program
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
            EC_OPFAILURE        device operation failed
            EC_OPTIMEOUT        operation timeout
            EC_PROGTIMEOUT      program operation did not complete in
                                specified max time
            EC_PROGFAILURE      programming failed
            EC_READDATA         read data not correct
            EC_STATUSERROR      device status error
            EC_NOTSUPPORTED     function not supported by device
**********************************************************************/
DWORD SCRPSProg(PDEV pDevice, DWORD addr, DWORD value)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.st_addr = addr;
    Arg.dwValue = (WORD)value;
    return pDevice->pSingleProg(&Arg);
}

/**<SCRPBProgAbortReset>***********************************************
DESCRIPTION:  Send buffered write abort reset command to NOR device
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
            EC_NOTSUPPORTED     function not supported by device
**********************************************************************/
DWORD SCRPBProgAbortReset(PDEV pDevice)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.dwValue = 3;
    return pDevice->pCmdResetFlash(&Arg);
}

/**<SCRPBufferWriteLoad>***********************************************
DESCRIPTION:  Send buffer write and word count commandto NOR device
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        DWORD   addr            load address
        DWORD   count           number of WORDS to load
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
            EC_NOTSUPPORTED     function not supported by device
**********************************************************************/
DWORD SCRPBufferWriteLoad(PDEV pDevice, DWORD addr, DWORD count)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.st_addr = addr;
    Arg.dwCount = count;
    return pDevice->pBufferWriteLoad(&Arg);
}

/**<SCRPBufferWriteStore>***********************************************
DESCRIPTION:  Store buffered write data to buffer on NOR device
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        WORD    *src            pointer to WORD buffer of data to store
        DWORD   addr            address to begin store
        DWORD   count           number of WORDS to load
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
            EC_NOTSUPPORTED     function not supported by device
**********************************************************************/
DWORD SCRPBufferWriteStore(PDEV pDevice, WORD *src, DWORD addr, DWORD count)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.st_addr = addr;
    Arg.pSrc = src;
    Arg.dwCount = count;
    return pDevice->pBufferWriteStore(&Arg);
}

/**<SCRPBufferWriteProgram>********************************************
DESCRIPTION:  Send program buffer to flash (confirm) command to NOR
              device
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        DWORD   addr            address to send confirm command
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
            EC_PARAMETER        parameter error
            EC_NOTSUPPORTED     function not supported by device
**********************************************************************/
DWORD SCRPBufferWriteProgram(PDEV pDevice, DWORD addr)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.st_addr = addr;
    return pDevice->pBufferWriteCommit(&Arg);
}

/**<SCRPBufferWrite>***************************************************
DESCRIPTION:  Write buffer programming to program NOR device or page
              program to program SPI device
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        WORD    *src            pointer to WORD(NOR) or BYTE(SPI)
                                buffer of data to store
        DWORD   addr            starting address to write
        DWORD   count           number of WORDS(NOR) BYTES(SPI) to
                                write
        BOOL    wait            wait until complete
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
            EC_PARAMETER        parameter error
            EC_BWINTTO          internal programming timeout
            EC_BWABORT          write buffer abort
            EC_BWTIMEOUT        exceeded maximum program timeout
            EC_BWVERIFY         data verify failure
            EC_DEVICEERROR      device generic error
            EC_NOTSUPPORTED     function not supported by device
**********************************************************************/
DWORD SCRPBufferWrite(PDEV pDevice, WORD *src, DWORD addr, DWORD count, BOOL wait)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.st_addr = addr;
    Arg.pSrc = src;
    Arg.dwCount = count;
    if (wait) Arg.dwOptNOR |= NOR_BW_WAIT;
    return pDevice->pBufferWrite(&Arg);
}

/**<SCRPBufferWriteBlankCheck>*****************************************
DESCRIPTION:  Write buffer programming to program NOR device or page
              program to program SPI device after blank check memory
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        WORD    *src            pointer to WORD(NOR) or BYTE(SPI)
                                buffer of data to store
        DWORD   addr            starting address to write
        DWORD   count           number of WORDS(NOR) BYTES(SPI) to
                                write
        BOOL    wait            wait until complete
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
            EC_PARAMETER        parameter error
            EC_READDATANOTBLANK Read data not 0xFFFF
            EC_BWINTTO          internal programming timeout
            EC_BWABORT          write buffer abort
            EC_BWTIMEOUT        exceeded maximum program timeout
            EC_BWVERIFY         data verify failure
            EC_NOTSUPPORTED     function not supported by device
            EC_DEVICEERROR      device generic error
**********************************************************************/
DWORD SCRPBufferWriteBlankCheck(PDEV pDevice, WORD *src, DWORD addr, DWORD count, BOOL wait)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.st_addr = addr;
    Arg.pSrc = src;
    Arg.dwCount = count;
    Arg.dwOptNOR |= NOR_PGM_BLANK_CHECK;
    if (wait) Arg.dwOptNOR |= NOR_BW_WAIT;
    return pDevice->pBufferWrite(&Arg);
}


/**<SCRPProgSuspend>***************************************************
DESCRIPTION:  Send a program suspend command to NOR or SPI device
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        DWORD   addr            address to send suspend
        BOOL    wait            wait 40us before exit
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
**********************************************************************/
DWORD SCRPProgSuspend(PDEV pDevice, DWORD addr, BOOL wait)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.st_addr = addr;
    if (wait) Arg.dwOptNOR |= NOR_SUSP_WAIT;
    return pDevice->pProgSuspend(&Arg);
}

/**<SCRPProgResume>****************************************************
DESCRIPTION:  Send a program resume command to NOR or SPI device
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        DWORD   addr            address to send resume
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
**********************************************************************/
DWORD SCRPProgResume(PDEV pDevice, DWORD addr)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.st_addr = addr;
    return pDevice->pProgResume(&Arg);
}

/**<SCRPEraseSuspend>***************************************************
DESCRIPTION:  Send an erase suspend command to NOR or SPI device
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        DWORD   sector          sector number to suspend
        BOOL    wait            wait until complete
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
            EC_SUSPENDTIMEOUT   suspend timeout
**********************************************************************/
DWORD SCRPEraseSuspend(PDEV pDevice, DWORD sector, BOOL wait)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.fl_sect = sector;
    if (wait) Arg.dwOptNOR |= NOR_SUSP_WAIT;
    return pDevice->pEraseSuspend(&Arg);
}

/**<SCRPEraseResume>***************************************************
DESCRIPTION:  Send an erase resume command to NOR or SPI device
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        DWORD   sector          sector number to resume erasing
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
**********************************************************************/
DWORD SCRPEraseResume(PDEV pDevice, DWORD sector)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.fl_sect = sector;
    return pDevice->pEraseResume(&Arg);
}

/**<SCRPDeviceStatus>**************************************************
DESCRIPTION:  Obtain the current status of NOR or SPI device
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        DWORD   addr            address of status check
        DWORD   timeout         status time control:
               zero = determine current status and exit immediately
               non-zero = timeout, wait for operation to complete
OUTPUTS:
    PARAMETERS:
        DWORD   *dstat          status flags
    RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
            EC_OPFAILURE        device operation failed
            EC_STATUSERROR      device status error
            EC_OPTIMEOUT        operation timeout
            EC_DEVICEERROR      device generic error
**********************************************************************/
DWORD SCRPDeviceStatus(PDEV pDevice, DWORD addr, DWORD timeout, DWORD *dstat)
{
    DWORD opstat;
    DARGS Arg;
    Arg.pDevice = pDevice;
    Arg.fl_addr = addr;
    Arg.dwTimeout = timeout;
    Arg.dwOptNOR = 0;
    opstat = pDevice->pGetNORStatus(&Arg);
    *dstat = Arg.dwStatus;
    return opstat;
}

/**<SCRPClrDeviceStatus>***********************************************
DESCRIPTION:  Clear status register of NOR or SPI device
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        DWORD   addr            address to send to device
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
            EC_DEVICEERROR      device generic error
**********************************************************************/
DWORD SCRPClrDeviceStatus(PDEV pDevice, DWORD addr)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.fl_addr = addr;
    return pDevice->pClearNORStatus(&Arg);
}

/**<SCRPGetStatusReg>**************************************************
DESCRIPTION:  Obtain the status register of NOR or SPI device
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        DWORD   num             sector or register number
                    NOR: num is sector number
                    SPI: num is status register number
OUTPUTS:
    PARAMETERS:
        DWORD   *dstat          value of status register
    RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
            EC_DEVICEERROR      device generic error
**********************************************************************/
DWORD SCRPGetStatusReg(PDEV pDevice, DWORD num, DWORD *dstat)     //NOR: num is sector number, SPI: num is status register number
{
    DWORD opstat;
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.dwSelect = num;
	Arg.pFmt1 = dstat;
	if(num==0) {
    opstat = pDevice->pGetStatusReg(&Arg);
    *dstat = Arg.dwStatus;
	}
	else if(num==1) {
	opstat = pDevice->pGetStatusReg(&Arg);
    //dstat = Arg.pFmt1;
	}
    return opstat;
}

/**<SCRPSetConfigReg>**************************************************
DESCRIPTION:  Set the configuration register of NOR or SPI device
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        DWORD   addr            bank address (NOR only)
        DWORD   value           value to put in the configuration
                                register
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
            EC_CFGREGNOTSET     device configuration register not set
                                correctly
            EC_DEVICEERROR      device generic error
            EC_NOTSUPPORTED     function not supported by device
**********************************************************************/
DWORD SCRPSetConfigReg(PDEV pDevice, DWORD addr, DWORD value)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.st_addr = addr;
    Arg.dwValue = value;
    return pDevice->pSetConfigReg(&Arg);
}

/**<SCRPGetConfigReg>**************************************************
DESCRIPTION:  Get the configuration register of NOR or SPI device
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        DWORD   addr            bank address (NOR only)
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Type:   DWORD           value read from the configuration
                                register
**********************************************************************/
DWORD SCRPGetConfigReg(PDEV pDevice, DWORD addr)
{
	DWORD opstat;
	DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.st_addr = addr;
	//DWORD *buf = Arg.pFmt1;
    opstat = pDevice->pGetConfigReg(&Arg);
    return (DWORD)Arg.dwResult;
}

/**<SCRPGetConfigReg_4DIE>**************************************************
DESCRIPTION:  Get the configuration register of NOR or SPI device
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        DWORD   addr            0 - RPC_RD_VCR
        						1 - RPC_RD_NVCR
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Type:   DWORD           value read from the configuration
                                register
**********************************************************************/
DWORD SCRPGetConfigReg_4DIE(PDEV pDevice, DWORD addr, DWORD *pCfg)
{
	DWORD opstat;
	DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.st_addr = addr + 2;
	//Arg.st_addr += 2;
	Arg.pFmt1 = pCfg;
    opstat = pDevice->pGetConfigReg(&Arg);
    return (DWORD)Arg.dwResult;
}

/**<SCRPReadPassword>**************************************************
DESCRIPTION:  Reads the NOR device and fills a buffer with four
              words password register
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
OUTPUTS:
    PARAMETERS:
        DWORD   *dest           pointer to WORD buffer to receive
                                password data
    RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
            EC_NOTSUPPORTED     function not supported by device
**********************************************************************/
DWORD SCRPReadPassword(PDEV pDevice, WORD *dest)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.pDest = dest;
    return pDevice->pReadPassword(&Arg);
}

/**<SCRPSendPassword>**************************************************
DESCRIPTION:  Sends the passed four words of array values to the
              password registers on NOR device
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        WORD    *src            pointer to WORD buffer providing
                                password data
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
            EC_NOTSUPPORTED     function not supported by device
**********************************************************************/
DWORD SCRPSendPassword(PDEV pDevice, WORD *src)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.pSrc = src;
    return pDevice->pSendPassword(&Arg);
}

/**<SCRPProgPassword>**************************************************
DESCRIPTION:  Program specified password register of NOR device with
              passed value
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        DWORD   addr            register address
        DWORD   value           value to program
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
            EC_BADPWDINDEX      dad register number passed
            EC_OPFAILURE        device operation failed
            EC_STATUSERROR      device status error
            EC_OPTIMEOUT        operation timeout
            EC_PWDTIMEOUT       timeout programming a Password register
            EC_READDATA         read data not correct
            EC_NOTSUPPORTED     function not supported by device
**********************************************************************/
DWORD SCRPProgPassword(PDEV pDevice, DWORD addr, DWORD value)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.st_addr = addr;
    Arg.dwValue = value;
    return pDevice->pProgPassword(&Arg);
}

/**<SCRPGetASPFunc>****************************************************
DESCRIPTION:  Read Advanced Sector Protection register state from
              Nor or SPI device
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        DWORD   select          type of ASP to read:
                    ASP_PPB = persistent protection
                    ASP_DYB = dynamic protection
                    ASP_PPBL = PPB lock
                    ASP_PWD = lock register
                    ASP_SECSI_CUST = customer lock bit
        DWORD   addr            PPB, DYB sector address, PPBL bank
                                address
OUTPUTS:
    PARAMETERS:
        DWORD   *dest           pointer to store the result
                    status of bit(s):
                        TRUE if set
                        FALSE if clear for PPB, DYB, PPBL
                    setting status for lock register bits:
                        PROT_NONE = no protection
                        PROT_PERSISTENT = persistent
                        PROT_PASSWORD = password
                        PROT_RDPASSWORD = read password
    RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
            EC_PARAMETER        parameter error
            EC_DEVICEERROR      device generic error
            EC_NOTSUPPORTED     function not supported by device
**********************************************************************/
DWORD SCRPGetASPFunc(PDEV pDevice, DWORD select, DWORD addr, DWORD *dest)
{
    DWORD status;
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.st_addr = addr;
    Arg.dwSelect = select;
    status = pDevice->pGetASPState(&Arg);
    *dest = (DWORD) Arg.dwResult;
    return status;
}

/**<SCRPSetASPFunc>****************************************************
DESCRIPTION:  Set Advanced Sector Protection state on NOR or SPI device
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        DWORD   select          type of ASP to read:
                    ASP_PPB = persistent protection
                    ASP_PPBERASEALL = erase all PPB
                    ASP_DYB = dynamic protection
                    ASP_PPBL = PPB lock
                    ASP_PWD = lock register
                    ASP_SECSI_CUST = customer lock bit
        DWORD   addr            PPB (set), DYB sector address
        BOOL    set             state to set:
                                    TRUE if set
                                    FALSE if clear for DYB, PPBL
                                    TRUE to set PPB (use erase all to
                                    clear)
                                state to set for lock register bits:
                                    PROT_NONE = no protection
                                    PROT_PERSISTENT = persistent
                                    PROT_PASSWORD = password
                                    PROT_RDPASSWORD = read password
OUTPUTS:
    PARAMETERS:
        None
RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
            EC_PARAMETER        parameter error
            EC_PPBTIMEOUT       timeout programming PPB
            EC_READDATA         read data not correct
            EC_ERASETIMEOUT     erase operation did not complete in
                                specified max time
            EC_PWDETIMEOUT      timeout programming PWDE bit
            EC_DEVICEERROR      device generic error
            EC_NOTSUPPORTED     function not supported by device
**********************************************************************/
DWORD SCRPSetASPFunc(PDEV pDevice, DWORD select, DWORD addr, BOOL set)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.dwSelect = select;
    Arg.st_addr = addr;
    Arg.dwValue = set;
    return pDevice->pSetASPState(&Arg);
}

/**<SCRPASPUnlock>*****************************************************
DESCRIPTION:  Unlock all possible protection on NOR device
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
OUTPUTS:
    PARAMETERS:
        None
RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
            EC_PARAMETER        parameter error
            EC_PPBTIMEOUT       timeout programming PPB
            EC_READDATA         read data not correct
            EC_ERASETIMEOUT     erase operation did not complete in
                                specified max time
            EC_PWDETIMEOUT      timeout programming PWDE bit
            EC_DEVICEERROR      device generic error
            EC_NOTSUPPORTED     function not supported by device
**********************************************************************/
DWORD SCRPASPUnlock(PDEV pDevice)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    return pDevice->pASPUnlock(&Arg);
}

/**<SCRPSectorLockUnlock>**********************************************
DESCRIPTION:  Lock or unlock an individual sector on NOR device
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        DWORD   secAddr         sector to lock or unlock
        BOOL    locked          lock selection:
                                    FALSE = unlock sector
                                    TRUE = lock sector
OUTPUTS:
    PARAMETERS:
        None
RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
            EC_PARAMETER        parameter error
            EC_NOTSUPPORTED     function not supported by device
**********************************************************************/
DWORD SCRPSectorLockUnlock(PDEV pDevice, DWORD secAddr, BOOL locked)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.fl_sect = SCRPGetFAPIGeometry(pDevice, SECTOR_FROM_ADDRESS, secAddr);
    Arg.dwOptNOR = NOR_CMD_SEC_MASK;
    if (locked)
        Arg.dwSelect = TRUE;
    else
        Arg.dwSelect = FALSE;
    return pDevice->pSectorLockUnlock(&Arg);
}

/**<SCRPSectorLockRange>***********************************************
DESCRIPTION:  Lock all sectors and specify a range that cannot be
              unlocked on NOR device
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        DWORD   secLow          beginning sector
        DWORD   secHigh         ending sector
OUTPUTS:
    PARAMETERS:
        None
RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
            EC_PARAMETER        parameter error
            EC_NOTSUPPORTED     function not supported by device
**********************************************************************/
DWORD SCRPSectorLockRange(PDEV pDevice, DWORD secLow, DWORD secHigh)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.fl_sect = secLow;
    Arg.dwSelect = secHigh;
    return pDevice->pSectorLockRange(&Arg);
}
/**<SCRPEraseSector>***************************************************
DESCRIPTION:  Erase a single sector on NOR or SPI device
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        DWORD   sector          sector number to erase
        BOOL    waitVerify      verify sector is blank
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
            EC_PARAMETER        parameter error
            EC_MALLOC           malloc failed
            EC_OPFAILURE        device operation failed
            EC_OPTIMEOUT        operation timeout
            EC_STATUSERROR      device status error
            EC_ERASEVERIFY      non-blank sector or segment
            EC_DEVICEERROR      device generic error
            EC_NOTSUPPORTED     function not supported by device
**********************************************************************/
DWORD SCRPEraseSector(PDEV pDevice, DWORD sector, BOOL waitVerify)
{
    DWORD status;
    DARGS Arg;
//    WORD *buf;
    FAPIInitArgs(&Arg, pDevice);
    Arg.fl_sect = sector;
    if (waitVerify)
    {
		
		Arg.dwOptNOR |= NOR_ERASE_WAIT | NOR_ERASE_VER | NOR_ERASE_SLOW_POLL;
        /*
        buf = (WORD *)malloc(pDevice->pAddrSize[sector].SecSize * sizeof(WORD));
        if (!buf) return EC_MALLOC;
        Arg.pDest = buf;
        */
        status = pDevice->pEraseSector(&Arg);
        //free((char*)buf);
    }
    else
    	{

			status = pDevice->pEraseSector(&Arg);

    	}
    return status;
}

/**<SCRPEraseSectorsVerify>********************************************
DESCRIPTION:  Verify sectors are blank on NOR or SPI device
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        DWORD   sector          starting sector number to verfiy
        DWORD   count           number of setctor to verify
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
            EC_PARAMETER        parameter error
            EC_MALLOC           malloc failed
            EC_ERASEVERIFY      non-blank sector or segment
            EC_DEVICEERROR      device generic error
            EC_NOTSUPPORTED     function not supported by device
**********************************************************************/
DWORD SCRPEraseSectorsVerify(PDEV pDevice, DWORD sector, DWORD count)
{
    DWORD i, j, status = EC_NONE;
    DARGS Arg;
    WORD *buf;
    Arg.pDevice = pDevice;
    buf = (WORD *)malloc(pDevice->LargestSectorSize * sizeof(WORD));
    if (!buf) return EC_MALLOC;
    Arg.pDest = buf;
    Arg.dwOptNOR = NOR_READ_FAST;
    for (i = 0; i < count; i++)
    {
        j = sector + i;
        Arg.fl_sect = j;
        status = pDevice->pVerifySectorBlank(&Arg);
        if (status) break;
    }
    free((char*)buf);
    return status;
}

/**<SCRPSectorBlankCheck>**********************************************
DESCRIPTION:  Verify sector is blank on NOR or SPI device
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        DWORD   sector          sector number to verfiy
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
            EC_PARAMETER        parameter error
            EC_MALLOC           malloc failed
            EC_ERASEVERIFY      non-blank sector or segment
            EC_DEVICEERROR      device generic error
            EC_NOTSUPPORTED     function not supported by device
**********************************************************************/
DWORD SCRPSectorBlankCheck(PDEV pDevice, DWORD sector)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.fl_sect = sector;
    return pDevice->pBlankCheck(&Arg);
}

/**<SCRPReadArray>*****************************************************
DESCRIPTION:  Read a quantity of WORDs or BYTEs in ascending address
              order from NOR or SPI device into a buffer
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        DWORD   addr            starting WORD address on NOR device or
                                BYTE address on SPI device to read
        DWORD   count           number of WORDs or BYTEs to read
OUTPUTS:
    PARAMETERS:
        WORD    *dest           pointer to destination WORD or BYTE
                                buffer
    RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
            EC_PARAMETER        parameter error
            EC_ERASEVERIFY      non-blank sector or segment
**********************************************************************/
DWORD SCRPReadArray(PDEV pDevice, WORD *dest, DWORD addr, DWORD count)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.pDest = dest;
    Arg.st_addr = addr;
    Arg.dwCount = count;
    Arg.dwOptNOR = NOR_READ_FAST;
    return pDevice->pReadNORBuffer(&Arg);
}

/**<SCRPCmdResetFlash>*************************************************
DESCRIPTION:  Sends a flash reset command to NOR device
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
**********************************************************************/
DWORD SCRPCmdResetFlash(PDEV pDevice)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
	Arg.dwValue = 3;
    return pDevice->pCmdResetFlash(&Arg);

}


/**<SCRPQSPISetWP>*****************************************************
DESCRIPTION:  Set the output Write Protect(WP#) pin on SPI controller
              for the SPI device
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        BOOL    nOnOff          true or false
                true: enable WP
                false: disable WP
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
            EC_DEVICEERROR      device generic error
            EC_NOTSUPPORTED     function not supported by device
**********************************************************************/
DWORD SCRPQSPISetWP(PDEV pDevice, BOOL nOnOff)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.dwSelect = nOnOff;
    return pDevice->pSetWP(&Arg);
}

/**<SCRPQSPIPgmOTP>****************************************************
DESCRIPTION:  Page program the OTP address space of SPI device
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        WORD    *src            pointer to BYTE buffer of data to store
        DWORD   addr            starting OTP address to write
        DWORD   count           number of BYTES to program
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
            EC_PARAMETER        parameter error
            EC_BWINTTO          internal programming timeout
            EC_BWABORT          write buffer abort
            EC_BWTIMEOUT        exceeded maximum program timeout
            EC_BWVERIFY         data verify failure
            EC_DEVICEERROR      device generic error
            EC_NOTSUPPORTED     function not supported by device
**********************************************************************/
DWORD SCRPQSPIPgmOTP(PDEV pDevice, WORD *src, DWORD addr, DWORD count)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.pSrc = src;
    Arg.st_addr = addr;
    Arg.dwCount = count;
    return pDevice->pProgOTP(&Arg);
}

/**<SCRPQSPIReadOTP>*****************************************************
DESCRIPTION:  Read a quantity of BYTEs in ascending address order from
              the OTP address space of SPI device into a buffer
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        DWORD   addr            starting BYTE address on SPI device to
                                read
        DWORD   count           number of BYTEs to read
OUTPUTS:
    PARAMETERS:
        WORD    *dest           pointer to destination BYTE buffer
    RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
            EC_DEVICEERROR      device generic error
            EC_NOTSUPPORTED     function not supported by device
**********************************************************************/
DWORD SCRPQSPIReadOTP(PDEV pDevice, WORD *dest, DWORD addr, DWORD count)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.pDest = dest;
    Arg.st_addr = addr;
    Arg.dwCount = count;
    return pDevice->pReadOTP(&Arg);
}

/**<SCRPQSPISetClock>**************************************************
DESCRIPTION:  Set the current SCK clock frequency for the SPI device
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        DWORD   nMhz            SCK clock frequency in Mhz
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
            EC_DEVICEERROR      device generic error
            EC_NOTSUPPORTED     function not supported by device
**********************************************************************/
DWORD SCRPQSPISetClock(PDEV pDevice, DWORD nMhz)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.dwValue = nMhz;
    return pDevice->pSetClock(&Arg);
}

/**<SCRPQSPIGetClock>**************************************************
DESCRIPTION:  Get the current SCK clock frequency for the SPI device
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        DWORD   *nMhz           SCK clock frequency in Mhz
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
            EC_DEVICEERROR      device generic error
            EC_NOTSUPPORTED     function not supported by device
**********************************************************************/
DWORD SCRPQSPIGetClock(PDEV pDevice, DWORD* nMhz)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.pDest = nMhz;
    return pDevice->pGetClock(&Arg);
}

/**<SCRPRPCReset>*****************************************************
DESCRIPTION:  Sends a flash reset command to RPC device
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        DWORD   nResetType      type of reset
                0: Software Reset
                1: Hardware Reset
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
            EC_NOTSUPPORTED     function not supported by device
**********************************************************************/
DWORD SCRPRPCReset(PDEV pDevice, DWORD nResetType)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.dwValue = nResetType;   //0:Software Reset, 1:Hardware Reset
    return pDevice->pCmdResetFlash(&Arg);
}

/**<SCRPQSPIFPGARegRd>*************************************************
DESCRIPTION:  Read FPGA register
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        DWORD   regAddr         register address
OUTPUTS:
    PARAMETERS:
        WORD    *value          pointer to destination WORD buffer
    RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
            EC_NOTSUPPORTED     function not supported by device
**********************************************************************/
DWORD SCRPQSPIFPGARegRd(PDEV pDevice, DWORD regAddr, DWORD* value)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.dwSelect = regAddr;
    Arg.pDest = value;
    return pDevice->pFPGARegRd(&Arg);
}

/**<SCRPQSPIFPGARegWr>*************************************************
DESCRIPTION:  Writ value to FPGA register
INPUTS:
    PARAMETERS:
        PDEV    pDevice         pointer to target device object
        DWORD   regAddr         register address
        WORD    value           value to write
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Type:   DWORD           operation status
        Values:
            EC_NONE             no error
            EC_NOTSUPPORTED     function not supported by device
**********************************************************************/
DWORD SCRPQSPIFPGARegWr(PDEV pDevice, DWORD regAddr, DWORD value)
{
    DARGS Arg;
    FAPIInitArgs(&Arg, pDevice);
    Arg.dwSelect = regAddr;
    Arg.dwValue = (DWORD)value;
    return pDevice->pFPGARegWr(&Arg);
}

/**<Find_Device>*******************************************************
DESCRIPTION:  Find device from the platform
INPUTS:
    PARAMETERS:
        DWORD   target          technology type (NOR, SPI or NAND)
OUTPUTS:
    PARAMETERS:
        None
    RETURN:
        Type:   PDEV            pointer to target device object
                    NULL if not found
**********************************************************************/
PDEV Find_Device(DWORD target)
{
    PDEV dev;
    DWORD tech;
    DARGS Arg;
		
		FAPIInitArgs(&Arg, pDevice);
    dev = FAPIGetDevice(target);
    if (0 != dev)
    {
    	//printf("    1\n");
    	dev->pConfigure(&Arg);
    	//printf("    2\n");
        tech = SCRPGetFAPIInfo(dev, TECHNOLOGY);
		//printf("    3\n");
        if (tech == target)
        	{
        		
            return dev;
          }
    }
		
    return (PDEV)0;
}

// ********************************************************************
//  sltsys.c
// ********************************************************************
DWORD SYS_CheckUserBreak(void)
{
    return EC_NONE;
}

void SYS_GetTimestamp(PSTS pSts) 
{
	
//	pSts->timeL32 = _SYS_GetTimestamp(gpmc) * 12;
//	pSts->timeH16 = 0;
}


// ********************************************************************
//  start.c
// ********************************************************************
void line_space(DWORD n)
{
    DWORD i;

    for (i = 0; i < n; i++)
        printf("\n");
    printf("*******************************************\n");
} // line_space()

void FormatDeltaTime(char *s, PSTS t0, PSTS t1) 
{ 
	SYS_FormatDeltaTime(s, t1->timeL32, t1->timeH16, t0->timeL32, t0->timeH16);
}

void SetGlobalVar(char* name, int value) {}

void SYS_WaitUSec(DWORD dTime) 
{
    waitUs(dTime);
}


WORD complexData[16];

void ComplexPatternInit(void)
{
    DWORD i;
    DWORD value = 0xFF00;
    for (i = 0; i < 8; i++)
        complexData[i] = value, value = ~value;
    for (value = 0xFFFF; i < 16; i++)
        complexData[i] = value;
}

// simple buffer fill function
// count: number of WORDS in buffer (caller must guarantee space)
DWORD FillBuffer(DWORD type, void *dest, DWORD count)
{
    DWORD value = 0, bCount, i, big = FALSE, tgl = 1;
    WORD *wDest;
    BYTE *bDest;
    if (!dest || !count) return EC_PARAMETER;
    wDest = (WORD *)dest;
    bDest = (BYTE *)dest;
    bCount = count;
    if (type >= WORDS_ARE_0X0000)
        bCount = count * 2, big = TRUE;
    switch (type)
    {
    // handle fixed values
    case BYTES_ARE_0X00:
    case WORDS_ARE_0X0000:
        memset(bDest, 0, bCount);
        return EC_NONE;
    case BYTES_ARE_0XFE:
        memset(bDest, 0XFE, bCount);
        return EC_NONE;         //added for program 1 bit.scp
    case BYTES_ARE_0X55:
    case WORDS_ARE_0X5555:
        memset(bDest, 0x55, bCount);
        return EC_NONE;
    case BYTES_ARE_0XAA:
    case WORDS_ARE_0XAAAA:
        memset(bDest, 0xAA, bCount);
        return EC_NONE;
    case BYTES_ARE_0XFF:
    case WORDS_ARE_0XFFFF:
        memset(bDest, 0xFF, bCount);
        return EC_NONE;
    // handle value equals address
    case BYTES_ARE_ADDRESSES:
        for (i = 0; i < bCount; i++)
            bDest[i] = i;
        return EC_NONE;
    case BYTES_ARE_ADDRESSES_PLUS_1:
        for (i = 0; i < count; i++)
            bDest[i] = i + 1;
        return EC_NONE;
    case WORDS_ARE_ADDRESSES:
        for (i = 0; i < count; i++)
            wDest[i] = i;
        return EC_NONE;
    case WORDS_ARE_ADDRESS_PLUS_1:
        for (i = 0; i < count; i++)
            wDest[i] = i + 1;
        return EC_NONE;
    case WORDS_ARE_ADDRESS_AND_0XFF:
        for (i = 0; i < count; i++)
            wDest[i] = i & 0xFF;
        return EC_NONE;
    // handle alternating values
    case BYTES_ALT_0X00_0XFF: break;
    case WORDS_ALT_0X0000_0XFFFF: break;
    case WORDS_ALT_0X00FF_0XFF00: value = 0x00FF; break;
    case BYTES_ALT_0X55_0XAA: value = 0x55; break;
    case WORDS_ALT_0X5555_0XAAAA: value = 0x5555; break;
    case WORDS_ARE_0XFFFE: value = 0xFFFE; break;     //added for program 1 bit.scp
    case WORDS_ARE_0XEFFF: value = 0xEFFF; break; 
    case WORDS_ALT_0X55AA_0XAA55: value = 0x55AA; break;
    case BYTES_ALT_0XAA_0X55: value = 0xAA; break;
    case WORDS_ARE_CKBD:
    case WORDS_ALT_0XAA55_0X55AA: value = 0xAA55; break;
    case WORDS_ALT_0XAAAA_0X5555: value = 0xAAAA; break;
    case BYTES_ALT_0XFF_0X00: value = 0xFF; break;
    case WORDS_ALT_0XFF00_0X00FF: value = 0xFF00; break;
    case WORDS_ALT_0XFFFF_0X0000: value = 0xFFFF; break;
    // handle CBD values
    case WORDS_ALT_4_OF_0XFFFF_4_OF_0X0000: value = 0xFFFF;
    case WORDS_ALT_4_OF_0X0000_4_OF_0XFFFF: tgl = 4; break;
    case WORDS_ALT_8_OF_0XFFFF_8_OF_0X0000: value = 0xFFFF;
    case WORDS_ALT_8_OF_0X0000_8_OF_0XFFFF: tgl = 8; break;
    // handle complex patterns
    case WORDS_ALT_8_OF_0XFF00_0X00FF_N_8_OF_0XFFFF:
        for (i = 0; i < count; i++)
            wDest[i] = complexData[i % 16];
        return EC_NONE;
    // handle random values (user can call srand(1), 2, etc. before calling this)
    case BYTES_ARE_RANDOM:
    case WORDS_ARE_RANDOM:
        for (i = 0; i < bCount; i++)
            bDest[i] = rand() % 256;
        return EC_NONE;
    // fail all else
    default:
        return EC_PARAMETER;
    }
    // process alternating WORD values
    if (big)
    {
        for (i = 0; i < count; i++)
            wDest[i] = i & tgl ? value ^ 0xFFFF : value;
        return EC_NONE;
    }
    // process alternating BYTE values
    for (i = 0; i < count; i++)
        bDest[i] = i & tgl ? value ^ 0xFF : value;
    return EC_NONE;
}

DWORD GetDeviceCbdPattern(PDEV dev, DWORD *pattern, BOOL cmp)
{
    DWORD p;
    if (!dev || !pattern) return EC_PARAMETER;

    p = cmp ? WORDS_ALT_4_OF_0XFFFF_4_OF_0X0000 : WORDS_ALT_4_OF_0X0000_4_OF_0XFFFF;
/*andy
    switch (SCRPGetFAPIInfo(dev, FLASH_TYPE))
    {
    case NS128RT:
    case NS256RT:
    case NS512RU:
    case NS01GRU:
    case WS128RB:
    case WS128RT:
    case WS128RUB:
    case WS128RUT:
    case WS256RB:
    case WS256RT:
    case WS256RUB:
    case WS256RUT:
    case WS512RB:
    case WS512RT:
    case WS512RUB:
    case WS512RUT:
    case WS01GRB:
    case WS01GRT:
    case WS01GRUB:
    case WS01GRUT:
    case GL01GP:
    case GL01GR:
    case GL512S:
    case GL01GS:
            p = cmp ? WORDS_ALT_4_OF_0XFFFF_4_OF_0X0000 : WORDS_ALT_4_OF_0X0000_4_OF_0XFFFF; break;
    case XDS512RB:
    case XDS512RT:
    case XDS512RUB:
    case XDS01GRB:
    case XDS01GRT:
    case XDS01GRUB:
    case XDS02GRB:
    case XDS02GRT:
    case XDS02GRUB:
    case VS064RT:
        p = cmp ? WORDS_ALT_8_OF_0XFFFF_8_OF_0X0000 : WORDS_ALT_8_OF_0X0000_8_OF_0XFFFF; break;
    // handle default this way for now
    default: return EC_PARAMETER;
    }
*/
    *pattern = p;
    return EC_NONE;
}

// NOR linear buffer fill
// 0x0001, 0xFFFF, 0xFFFF, ..., 0xFFFF (instance 0)
// 0x0001, 0x0002, 0xFFFF, ..., 0xFFFF (instance 1)
// ...
// 0x0001, 0x0002, 0x0003, ..., LENGTH (instance length - 1)
// count: number of WORDS in buffer (caller must guarantee space)

DWORD LinearFillBuffer(DWORD instance, WORD *dest, DWORD count)
{
    DWORD i;
    if (!dest || !count) return EC_PARAMETER;
    if (++instance > count) return EC_PARAMETER;
    for (i = 0; i < instance; i++)
        dest[i] = i + 1;
    for ( ; i < count; i++)
        dest[i] = 0xFFFF; // or use memset
    return EC_NONE;
}

// NOR walking bit fill ("Sharp test patterns")
//
// "Normal" patterns
// 0x0000, 0x0001, 0x0002, 0x0004, ... (instance 0)
// 0x0001, 0x0002, 0x0004, 0x0008, ... (instance 1)
// ...
// 0x8000, 0x0000, 0x0001, 0x0002, ... (instance 16)
//
// "Reverse" patterns
// 0xFFFF, 0xFFFE, 0xFFFD, 0xFFFB, ... (instance 0)
// 0xFFFE, 0xFFFD, 0xFFFB, 0xFFF7, ... (instance 1)
// ...
// 0x7FFF, 0xFFFF, 0xFFFE, 0xFFFD, ... (instance 16)
//
WORD normalData[17];
WORD reverseData[17];

void WalkingBitInit(void)
{
    DWORD i, j = 1, value = 0;
    for (i = 0; i < 17; i++)
    {
        normalData[i] = value, reverseData[i] = ~value;
        value = j, j <<= 1;
    }
}

DWORD WalkingBitFill(DWORD instance, WORD *dest, DWORD count, BOOL reverse)
{
    DWORD i, j = 1;
    if (!dest || !count) return EC_PARAMETER;
    if (instance > 16) return EC_PARAMETER;
    if (reverse)
        for (i = 0, j = instance; i < count; i++, j++)
            dest[i] = reverseData[j % 17];
    else
        for (i = 0, j = instance; i < count; i++, j++)
            dest[i] = normalData[j % 17];
    return EC_NONE;
}

DWORD SharpPatternFill(DWORD type, WORD *dest, DWORD count)
{
    BOOL reverse = FALSE;
    if (type > B17) return EC_PARAMETER;
    if (type >= B1) reverse = TRUE, type -= 17;
    return WalkingBitFill(type, dest, count, reverse);
}

// ********************************************************************
//  slterr.c
// ********************************************************************
// Return error text
char *GetErrorText(DWORD number)
{
    return "ERROR";
}

// ********************************************************************
//  start.c
// ********************************************************************
#ifndef RAND_MAX			/* added in v1.11 */
#define RAND_MAX	32767
#endif
int GetRAND_MAX(void)
{
    return RAND_MAX;
}
