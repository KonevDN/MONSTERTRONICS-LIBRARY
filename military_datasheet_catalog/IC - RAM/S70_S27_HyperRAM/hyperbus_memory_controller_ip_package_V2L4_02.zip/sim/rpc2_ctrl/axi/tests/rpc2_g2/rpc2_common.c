//===========================================================================
//
//  rpc2_common.c
//
//   @author  Yuichi Ise (yuichi.ise@spansion.com)
//   @version 0.1
//   @since   06/21/2013
//
//===========================================================================
#include "rpc2_common.h"

//=============================================================================
//  COMMON FUNCTIONS
//=============================================================================
static DWORD dPattern = WORD_ADDRESS;
void setDataPattern (DWORD pattern)
{
  dPattern = pattern;
}

void getDataPattern (DWORD* pattern)
{
  *pattern = dPattern;
}

void genFixData (WORD* genData, WORD initData, DWORD len16)
{
  DWORD i;
  for (i = 0; i < len16; i++) {
    genData[i] = initData;
  }
}

void genIncData (WORD* genData, WORD initData, DWORD len16)
{
  DWORD i;
  for (i = 0; i < len16; i++) {
    genData[i] = initData + i;
  }
}

void fillBuffer (DWORD pattern, WORD* buf, DWORD len16)
{
  switch (pattern) {
  case WORD_ADDRESS:
    genIncData(buf, 0x0, len16);
    break;
  case WORD_ADDRESS_PLUS_1:
    genIncData(buf, 0x1, len16);
    break;
  case RANDOM:
    genRndData(buf, len16*2);
    break;
  default:
    genFixData(buf, 0x0, len16);
  }
}

void printBuffer (WORD* buf, DWORD len16)
{
  int i;

  for (i = 0; i < len16; i++) {
    if ((i%8) == 0) {
      MSG("\n0x%08X:", i);
    }
    MSG(" %04X", buf[i]);
    if (i >= 100) {
      MSG(" .....\n");
      break;
    }
  }
  MSG("\n");
}

int verifyData (WORD* act, WORD* exp, DWORD len16)
{
  int mismatch = 0;
  int i;
  int num;

  num = 0;
  for (i = 0; i < len16; i++) {
    if (act[i] != exp[i]) {
      mismatch = 1;
      ERR_MSG("0x%08X: exp 0x%04X, act 0x%04X\n", i, exp[i], act[i]);
      num++;
    }
    if (num > 10) {
      ERR_MSG("Too many errors...\n");
      break;
    }
  }
  return mismatch;
}

int verifyData8 (BYTE* act, BYTE* exp, DWORD len8)
{
  int mismatch = 0;
  int i;
  int num;

  num = 0;
  for (i = 0; i < len8; i++) {
    if (act[i] != exp[i]) {
      mismatch = 1;
      ERR_MSG("0x%08X: exp 0x%02X, act 0x%02X\n", i, exp[i], act[i]);
      num++;
    }
    if (num > 10) {
      ERR_MSG("Too many errors...\n");
      break;
    }
  }
  return mismatch;
}

int verifyData32 (DWORD* act, DWORD* exp, DWORD len)
{
  int mismatch = 0;
  int i;
  int num;

  num = 0;
  for (i = 0; i < len; i++) {
    if (act[i] != exp[i]) {
      mismatch = 1;
      ERR_MSG("0x%08X: exp 0x%08X, act 0x%08X\n", i, exp[i], act[i]);
      num++;
    }
    if (num > 10) {
      ERR_MSG("Too many errors...\n");
      break;
    }
  }
  return mismatch;
}

void wrapMemCopy (WORD *dist,
		  WORD *src,
		  DWORD len16,
		  DWORD start_pos)
{
  DWORD i,j;
  DWORD next_pos;

  for (i = 0; i < (len16-start_pos); i++) {
    dist[i] = src[start_pos+i];
  }
  next_pos = i;
  j = 0;
  for (i = next_pos; i < len16; i++) {
    dist[i] = src[j];
    j++;
  }
}

void wrapMemCopy8 (BYTE *dist,
		  BYTE *src,
		  DWORD len8,
		  DWORD start_pos)
{
  DWORD i,j;
  DWORD next_pos;

  for (i = 0; i < (len8-start_pos); i++) {
    dist[i] = src[start_pos+i];
  }
  next_pos = i;
  j = 0;
  for (i = next_pos; i < len8; i++) {
    dist[i] = src[j];
    j++;
  }
}

void wrapMemCopy32 (DWORD *dist,
		    DWORD *src,
		    DWORD len,
		    DWORD start_pos)
{
  DWORD i,j;
  DWORD next_pos;

  for (i = 0; i < (len-start_pos); i++) {
    dist[i] = src[start_pos+i];
  }
  next_pos = i;
  j = 0;
  for (i = next_pos; i < len; i++) {
    dist[i] = src[j];
    j++;
  }
}

//=============================================================================
//  REGISTER FUNCTIONS
//=============================================================================
int setLoopbackMode (DWORD loopback)
{
  int ret = NO_ERROR;
  int status;
  DWORD lbrReg;

  status = RPC2_WRITE_REG(REG_LBR_ADDR, &loopback); if (status != 0) ret = ERROR;
  status = RPC2_READ_REG(REG_LBR_ADDR, &lbrReg); if (status != 0) ret = ERROR;
  MSG("Loop-back: %d\n", (lbrReg & LOOPBACK_BIT));
  return ret;
}

int setMemBaseAddress (DWORD address, DWORD cs)
{
  int ret = NO_ERROR;
  int status;
  DWORD mbrReg;
  DWORD mbrRegAddr = REG_MBR_ADDR;

#if (RPC2_CTRL_IP_VER >= 200)
  if (cs==CS1_SEL) {
    mbrRegAddr = REG_MBR1_ADDR;
  }
#endif
  if (cs > CS1_SEL) {
    cs = 0;
  }

  mbrReg = address;
  status = RPC2_WRITE_REG(mbrRegAddr, &mbrReg); if (status != 0) ret = ERROR;
  status = RPC2_READ_REG(mbrRegAddr, &mbrReg); if (status != 0) ret = ERROR;
  MSG("CS%d MBR Reg: 0x%08X\n", cs, mbrReg);
  return ret;
}

int getMemBaseAddress (DWORD* address, DWORD cs)
{
  int ret = NO_ERROR;
  int status;
  DWORD mbrRegAddr = REG_MBR_ADDR;

#if (RPC2_CTRL_IP_VER >= 200)
  if (cs==CS1_SEL) {
    mbrRegAddr = REG_MBR1_ADDR;
  }
#endif
  if (cs > CS1_SEL) {
    cs = 0;
  }

  status = RPC2_READ_REG(mbrRegAddr, address); if (status != 0) ret = ERROR;
  MSG("CS%d MBR Reg: 0x%08X\n", cs, *address);
  return ret;
}

int getCsNum (DWORD address, DWORD* cs)
{
  int ret = NO_ERROR;
  int status;
#if (RPC2_CTRL_IP_VER >= 200)
  DWORD mbr0Addr;
  DWORD mbr1Addr;
#endif

  *cs = 0;
#if (RPC2_CTRL_IP_VER >= 200)
  status = RPC2_READ_REG(REG_MBR_ADDR, &mbr0Addr); if (status != 0) ret = ERROR;
  status = RPC2_READ_REG(REG_MBR1_ADDR, &mbr1Addr); if (status != 0) ret = ERROR;

  if ((mbr1Addr > mbr0Addr) && (address >= mbr1Addr)) {
    *cs = 1;
  }
#endif
  return ret;
}

int setWaterMark (DWORD wm)
{
  int ret = NO_ERROR;
  int status;
  DWORD reg;

  status = RPC2_WRITE_REG(REG_RWM_ADDR, &wm); if (status != 0) ret = ERROR;
  status = RPC2_READ_REG(REG_RWM_ADDR, &reg); if (status != 0) ret = ERROR;
  MSG("Water Mark: %d\n", (reg & WM_BIT));
  return ret;
}

int setWriteProtect (DWORD wp)
{
  int ret = NO_ERROR;
  int status;
  DWORD reg;

  status = RPC2_WRITE_REG(REG_WPR_ADDR, &wp); if (status != 0) ret = ERROR;
  status = RPC2_READ_REG(REG_WPR_ADDR, &reg); if (status != 0) ret = ERROR;
  MSG("Write Protect: %d\n", GET_WP(reg));
  return ret;
}

int setInterruptEnable (DWORD ie)
{
  int ret = NO_ERROR;
  int status;
  DWORD reg;

  status = RPC2_WRITE_REG(REG_IEN_ADDR, &ie); if (status != 0) ret = ERROR;
  status = RPC2_READ_REG(REG_IEN_ADDR, &reg); if (status != 0) ret = ERROR;
  MSG("Interrupt Enable: polarity %d, enable %d\n",
      GET_INT_POLARITY(reg), GET_INT_EN(reg));
  return ret;
}

int getInterruptStatus (DWORD* interrupt)
{
  int ret = NO_ERROR;
  int status;
  DWORD reg;

  status = RPC2_READ_REG(REG_ISR_ADDR, &reg); if (status != 0) ret = ERROR;
  *interrupt = reg & BIT0;
  MSG("Interrupt Status: %1d\n", *interrupt);
  return ret;
}

int setTCOption (DWORD option, DWORD cs)
{
  int ret = NO_ERROR;
  int status;
  DWORD reg;
  DWORD regAddr = REG_TIR_ADDR;

#if (RPC2_CTRL_IP_VER >= 200)
  if (cs==CS1_SEL) {
    regAddr = REG_MCR1_ADDR;
  }
#endif
  if (cs > CS1_SEL) {
    cs = 0;
  }
  
  status = RPC2_READ_REG(regAddr, &reg); if (status != 0) ret = ERROR;
  reg &= CLR_TC_OPTION;
  reg |= SET_TC_OPTION(option);
  status = RPC2_WRITE_REG(regAddr, &reg); if (status != 0) ret = ERROR;
  status = RPC2_READ_REG(regAddr, &reg); if (status != 0) ret = ERROR;
  MSG("MCR%1d = 0x%08X\n", cs, reg);
  MSG("CS%d TC Option %d\n", cs, GET_TC_OPTION(reg));
  return ret;
}

int setWrapSize (DWORD size, DWORD cs)
{
  int ret = NO_ERROR;
  int status;
  DWORD reg;
  DWORD regAddr = REG_TIR_ADDR;

#if (RPC2_CTRL_IP_VER >= 200)
  if (cs==CS1_SEL) {
    regAddr = REG_MCR1_ADDR;
  }
#endif
  if (cs > CS1_SEL) {
    cs = 0;
  }
  
  status = RPC2_READ_REG(regAddr, &reg); if (status != 0) ret = ERROR;
  reg &= CLR_WRAP_SIZE;
  reg |= SET_WRAP_SIZE(size);
  status = RPC2_WRITE_REG(regAddr, &reg); if (status != 0) ret = ERROR;
  status = RPC2_READ_REG(regAddr, &reg); if (status != 0) ret = ERROR;
  MSG("CS%d Wrap Size %d\n", cs, GET_WRAP_SIZE(reg));
  return ret;
}

int setACacheSupport (DWORD support, DWORD cs)
{
  int ret = NO_ERROR;
  int status;
  DWORD reg;
  DWORD regAddr = REG_TIR_ADDR;

#if (RPC2_CTRL_IP_VER >= 200)
  if (cs==CS1_SEL) {
    regAddr = REG_MCR1_ADDR;
  }
#endif
  if (cs > CS1_SEL) {
    cs = 0;
  }

  status = RPC2_READ_REG(regAddr, &reg); if (status != 0) ret = ERROR;
  reg &= CLR_ACACHE;
  reg |= SET_ACACHE(support);
  status = RPC2_WRITE_REG(regAddr, &reg); if (status != 0) ret = ERROR;
  status = RPC2_READ_REG(regAddr, &reg); if (status != 0) ret = ERROR;
  MSG("CS%d Asymmetry Cache Support %d\n", cs, GET_ACACHE(reg));
  return ret;
}

int getNumTransaction(WORD* numWr, WORD* numRd)
{
  int ret = NO_ERROR;
  int status;
  DWORD reg;

  status = RPC2_READ_REG(REG_TCSR_ADDR, &reg); if (status != 0) ret = ERROR;
  *numWr = reg >> 16;
  *numRd = reg & 0x0000FFFF;
  return ret;
}

int setByteEnable (DWORD byteCtrl, DWORD cs)
{
  int ret = NO_ERROR;
  int status;
  DWORD reg;
  DWORD regAddr = REG_TIR_ADDR;

#if (RPC2_CTRL_IP_VER >= 200)
  if (cs==CS1_SEL) {
    regAddr = REG_MCR1_ADDR;
  }
#endif
  if (cs > CS1_SEL) {
    cs = 0;
  }

  status = RPC2_READ_REG(regAddr, &reg); if (status != 0) ret = ERROR;
  reg &= CLR_8BIT_CTRL;
  reg |= SET_8BIT_CTRL(byteCtrl);
  status = RPC2_WRITE_REG(regAddr, &reg); if (status != 0) ret = ERROR;
  status = RPC2_READ_REG(regAddr, &reg); if (status != 0) ret = ERROR;
  MSG("CS%d 8-bit Ctrl %d\n", cs, GET_8BIT_CTRL(reg));
  return ret;
}

int setDevType (DWORD devType, DWORD cs)
{
  int ret = NO_ERROR;
  int status;
  DWORD reg;
  DWORD regAddr = REG_MCR0_ADDR;

  if (cs==CS1_SEL) {
    regAddr = REG_MCR1_ADDR;
  } else if (cs > CS1_SEL) {
    cs = 0;
  }

  status = RPC2_READ_REG(regAddr, &reg); if (status != 0) ret = ERROR;
  reg &= CLR_DEVTYPE;
  reg |= SET_DEVTYPE(devType);
  status = RPC2_WRITE_REG(regAddr, &reg); if (status != 0) ret = ERROR;
  status = RPC2_READ_REG(regAddr, &reg); if (status != 0) ret = ERROR;
  MSG("MCR%1d = 0x%08X\n", cs, reg);
  MSG("CS%d DEVTYPE %d\n", cs, GET_DEVTYPE(reg));
  return ret;
}

int getDevType (DWORD* devType, DWORD cs)
{
  int ret = NO_ERROR;
  int status;
  DWORD reg;
  DWORD regAddr = REG_MCR0_ADDR;

  if (cs==CS1_SEL) {
    regAddr = REG_MCR1_ADDR;
  } else if (cs > CS1_SEL) {
    cs = 0;
  }

  status = RPC2_READ_REG(regAddr, &reg); if (status != 0) ret = ERROR;
  *devType = GET_DEVTYPE(reg);
//  MSG("CS%d DEVTYPE %d\n", cs, *devType);
  return ret;
}

int setConfigRegTarget(DWORD target, DWORD cs)
{
  int ret = NO_ERROR;
  int status;
  DWORD reg;
  DWORD addr = REG_MCR0_ADDR;

  if (cs == CS1_SEL) {
    addr = REG_MCR1_ADDR;
  }
  else if (cs > CS1_SEL) {
    cs = 0;
  }

  status = RPC2_READ_REG(addr, &reg); if (status != 0) ret = ERROR;
  reg &= CLR_CRT;
  reg |= SET_CRT(target);
  status = RPC2_WRITE_REG(addr, &reg); if (status != 0) ret = ERROR;
  status = RPC2_READ_REG(addr, &reg); if (status != 0) ret = ERROR;
  MSG("MCR%1d = 0x%08X\n", cs, reg);
  MSG("CS%d CRT %d\n", cs, GET_CRT(reg));
  return ret;
}

#if (RPC2_CTRL_IP_VER >= 230)
int setMAXEN (DWORD maxen, DWORD cs)
{
  int ret = NO_ERROR;
  int status;
  DWORD reg;
  DWORD regAddr = REG_MCR0_ADDR;

  if (cs==CS1_SEL) {
    regAddr = REG_MCR1_ADDR;
  } else if (cs > CS1_SEL) {
    cs = 0;
  }

  status = RPC2_READ_REG(regAddr, &reg); if (status != 0) ret = ERROR;
  reg &= CLR_MAXEN;
  reg |= SET_MAXEN(maxen);
  status = RPC2_WRITE_REG(regAddr, &reg); if (status != 0) ret = ERROR;
  status = RPC2_READ_REG(regAddr, &reg); if (status != 0) ret = ERROR;
  MSG("MCR%1d = 0x%08X\n", cs, reg);
  MSG("CS%d MAXEN %d\n", cs, GET_MAXEN(reg));
  return ret;
}

int setMAXLEN (DWORD maxlen, DWORD cs)
{
  int ret = NO_ERROR;
  int status;
  DWORD reg;
  DWORD regAddr = REG_MCR0_ADDR;

  if (cs==CS1_SEL) {
    regAddr = REG_MCR1_ADDR;
  } else if (cs > CS1_SEL) {
    cs = 0;
  }

  status = RPC2_READ_REG(regAddr, &reg); if (status != 0) ret = ERROR;
  reg &= CLR_MAXLEN(reg);
  reg |= SET_MAXLEN(maxlen);
  status = RPC2_WRITE_REG(regAddr, &reg); if (status != 0) ret = ERROR;
  status = RPC2_READ_REG(regAddr, &reg); if (status != 0) ret = ERROR;
  MSG("MCR%1d = 0x%08X\n", cs, reg);
  MSG("CS%d MAXLEN %d\n", cs, GET_MAXLEN(reg));
  return ret;
}

int getMAXEN (DWORD* maxen, DWORD cs)
{
  int ret = NO_ERROR;
  int status;
  DWORD reg;
  DWORD regAddr = REG_MCR0_ADDR;

  if (cs==CS1_SEL) {
    regAddr = REG_MCR1_ADDR;
  } else if (cs > CS1_SEL) {
    cs = 0;
  }

  status = RPC2_READ_REG(regAddr, &reg); if (status != 0) ret = ERROR;
  MSG("MCR%1d = 0x%08X\n", cs, reg);
  *maxen = GET_MAXEN(reg);
  MSG("CS%d MAXEN %d\n", cs, *maxen);
  return ret;
}

int getMAXLEN (DWORD* maxlen, DWORD cs)
{
  int ret = NO_ERROR;
  int status;
  DWORD reg;
  DWORD regAddr = REG_MCR0_ADDR;

  if (cs==CS1_SEL) {
    regAddr = REG_MCR1_ADDR;
  } else if (cs > CS1_SEL) {
    cs = 0;
  }

  status = RPC2_READ_REG(regAddr, &reg); if (status != 0) ret = ERROR;
  MSG("MCR%1d = 0x%08X\n", cs, reg);
  *maxlen = GET_MAXLEN(reg);
  MSG("CS%d MAXLEN %d\n", cs, *maxlen);
  return ret;
}
#endif

int setRCSHIcycle(DWORD target, DWORD cs)
{
  int ret = NO_ERROR;
  int status;
  DWORD reg;
  DWORD addr = REG_MTR0_ADDR;

  if (cs == CS1_SEL) {
    addr = REG_MTR1_ADDR;
  }
  else if (cs > CS1_SEL) {
    cs = 0;
  }

  status = RPC2_READ_REG(addr, &reg); if (status != 0) ret = ERROR;
  reg &= CLR_RCSHI(reg);
  reg |= SET_RCSHI(target);
  status = RPC2_WRITE_REG(addr, &reg); if (status != 0) ret = ERROR;
  status = RPC2_READ_REG(addr, &reg); if (status != 0) ret = ERROR;
  MSG("CS%d RCSHI %d\n", cs, GET_RCSHI(reg));
  return ret;
}

int setWCSHIcycle(DWORD target, DWORD cs)
{
  int ret = NO_ERROR;
  int status;
  DWORD reg;
  DWORD addr = REG_MTR0_ADDR;

  if (cs == CS1_SEL) {
    addr = REG_MTR1_ADDR;
  }
  else if (cs > CS1_SEL) {
    cs = 0;
  }

  status = RPC2_READ_REG(addr, &reg); if (status != 0) ret = ERROR;
  reg &= CLR_WCSHI(reg);
  reg |= SET_WCSHI(target);
  status = RPC2_WRITE_REG(addr, &reg); if (status != 0) ret = ERROR;
  status = RPC2_READ_REG(addr, &reg); if (status != 0) ret = ERROR;
  MSG("CS%d WCSHI %d\n", cs, GET_WCSHI(reg));
  return ret;
}

int setRCSScycle(DWORD target, DWORD cs)
{
  int ret = NO_ERROR;
  int status;
  DWORD reg;
  DWORD addr = REG_MTR0_ADDR;

  if (cs == CS1_SEL) {
    addr = REG_MTR1_ADDR;
  }
  else if (cs > CS1_SEL) {
    cs = 0;
  }

  status = RPC2_READ_REG(addr, &reg); if (status != 0) ret = ERROR;
  reg &= CLR_RCSS(reg);
  reg |= SET_RCSS(target);
  status = RPC2_WRITE_REG(addr, &reg); if (status != 0) ret = ERROR;
  status = RPC2_READ_REG(addr, &reg); if (status != 0) ret = ERROR;
  MSG("CS%d RCSS %d\n", cs, GET_RCSS(reg));
  return ret;
}

int setWCSScycle(DWORD target, DWORD cs)
{
  int ret = NO_ERROR;
  int status;
  DWORD reg;
  DWORD addr = REG_MTR0_ADDR;

  if (cs == CS1_SEL) {
    addr = REG_MTR1_ADDR;
  }
  else if (cs > CS1_SEL) {
    cs = 0;
  }

  status = RPC2_READ_REG(addr, &reg); if (status != 0) ret = ERROR;
  reg &= CLR_WCSS(reg);
  reg |= SET_WCSS(target);
  status = RPC2_WRITE_REG(addr, &reg); if (status != 0) ret = ERROR;
  status = RPC2_READ_REG(addr, &reg); if (status != 0) ret = ERROR;
  MSG("CS%d WCSS %d\n", cs, GET_WCSS(reg));
  return ret;
}

int setRCSHcycle(DWORD target, DWORD cs)
{
  int ret = NO_ERROR;
  int status;
  DWORD reg;
  DWORD addr = REG_MTR0_ADDR;

  if (cs == CS1_SEL) {
    addr = REG_MTR1_ADDR;
  }
  else if (cs > CS1_SEL) {
    cs = 0;
  }

  status = RPC2_READ_REG(addr, &reg); if (status != 0) ret = ERROR;
  reg &= CLR_RCSH(reg);
  reg |= SET_RCSH(target);
  status = RPC2_WRITE_REG(addr, &reg); if (status != 0) ret = ERROR;
  status = RPC2_READ_REG(addr, &reg); if (status != 0) ret = ERROR;
  MSG("CS%d RCSH %d\n", cs, GET_RCSH(reg));
  return ret;
}

int setWCSHcycle(DWORD target, DWORD cs)
{
  int ret = NO_ERROR;
  int status;
  DWORD reg;
  DWORD addr = REG_MTR0_ADDR;

  if (cs == CS1_SEL) {
    addr = REG_MTR1_ADDR;
  }
  else if (cs > CS1_SEL) {
    cs = 0;
  }

  status = RPC2_READ_REG(addr, &reg); if (status != 0) ret = ERROR;
  reg &= CLR_WCSH(reg);
  reg |= SET_WCSH(target);
  status = RPC2_WRITE_REG(addr, &reg); if (status != 0) ret = ERROR;
  status = RPC2_READ_REG(addr, &reg); if (status != 0) ret = ERROR;
  MSG("CS%d WCSH %d\n", cs, GET_WCSH(reg));
  return ret;
}

int setLTCYcycle(DWORD target, DWORD cs)
{
  int ret = NO_ERROR;
  int status;
  DWORD reg;
  DWORD addr = REG_MTR0_ADDR;

  if (cs == CS1_SEL) {
    addr = REG_MTR1_ADDR;
  }
  else if (cs > CS1_SEL) {
    cs = 0;
  }

  status = RPC2_READ_REG(addr, &reg); if (status != 0) ret = ERROR;
  reg &= CLR_LTCY(reg);
  reg |= SET_LTCY(target);
  status = RPC2_WRITE_REG(addr, &reg); if (status != 0) ret = ERROR;
  status = RPC2_READ_REG(addr, &reg); if (status != 0) ret = ERROR;
  MSG("CS%d LTCY %d\n", cs, GET_LTCY(reg));
  return ret;
}

int setGeneralPurposeOutput(DWORD target, DWORD bit)
{
  int ret = NO_ERROR;
  int status;
  DWORD reg;

  status = RPC2_READ_REG(REG_GPOR_ADDR, &reg); if (status != 0) ret = ERROR;
  reg &= CLR_GPO(bit);
  reg |= SET_GPO(target, bit);
  status = RPC2_WRITE_REG(REG_GPOR_ADDR, &reg); if (status != 0) ret = ERROR;
  status = RPC2_READ_REG(REG_GPOR_ADDR, &reg); if (status != 0) ret = ERROR;
  MSG("GPO%d: %d\n", (bit & 31), GET_GPO(reg, bit));
  return ret;
}

#if (RPC2_CTRL_IP_VER >= 240)
int setRTA (DWORD rta)
{
  int ret = NO_ERROR;
  int status;
  DWORD reg;
  DWORD regAddr = REG_TAR_ADDR;

  status = RPC2_READ_REG(regAddr, &reg); if (status != 0) ret = ERROR;
  reg &= CLR_RTA(reg);
  reg |= SET_RTA(rta);
  status = RPC2_WRITE_REG(regAddr, &reg); if (status != 0) ret = ERROR;
  status = RPC2_READ_REG(regAddr, &reg); if (status != 0) ret = ERROR;
  MSG("TAR = 0x%08X\n", reg);
  MSG("RTA %d\n", GET_RTA(reg));
  return ret;
}

int setWTA (DWORD wta)
{
  int ret = NO_ERROR;
  int status;
  DWORD reg;
  DWORD regAddr = REG_TAR_ADDR;

  status = RPC2_READ_REG(regAddr, &reg); if (status != 0) ret = ERROR;
  reg &= CLR_WTA(reg);
  reg |= SET_WTA(wta);
  status = RPC2_WRITE_REG(regAddr, &reg); if (status != 0) ret = ERROR;
  status = RPC2_READ_REG(regAddr, &reg); if (status != 0) ret = ERROR;
  MSG("TAR = 0x%08X\n", reg);
  MSG("WTA %d\n", GET_WTA(reg));
  return ret;
}

int getRTA (DWORD* rta)
{
  int ret = NO_ERROR;
  int status;
  DWORD reg;
  DWORD regAddr = REG_TAR_ADDR;

  status = RPC2_READ_REG(regAddr, &reg); if (status != 0) ret = ERROR;
  MSG("TAR = 0x%08X\n", reg);
  *rta = GET_RTA(reg);
  MSG("RTA %d\n", *rta);
  return ret;
}

int getWTA (DWORD* wta)
{
  int ret = NO_ERROR;
  int status;
  DWORD reg;
  DWORD regAddr = REG_TAR_ADDR;

  status = RPC2_READ_REG(regAddr, &reg); if (status != 0) ret = ERROR;
  MSG("TAR = 0x%08X\n", reg);
  *wta = GET_WTA(reg);
  MSG("WTA %d\n", *wta);
  return ret;
}
#endif
