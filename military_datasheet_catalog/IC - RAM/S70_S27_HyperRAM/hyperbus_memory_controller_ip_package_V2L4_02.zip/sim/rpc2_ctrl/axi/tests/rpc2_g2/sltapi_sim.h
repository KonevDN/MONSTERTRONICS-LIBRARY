// ***************************************************************************
//
//  Filename:       sltapi.h
//
//                  This file declares functions for querying application
//                  built-in version information.
//
//  Created:        Andy Chou (4/23/2010)
//
//  Modified:
//
// ***************************************************************************
//  Copyright (C) 2009, Spansion Inc. All rights reserved.
// ***************************************************************************


// ***************************************************************************
//  include file opening statements
// ***************************************************************************
#ifndef __SLTAPI_H
#define __SLTAPI_H
/*
#ifdef __cplusplus
extern "C" {
#endif
*/


// ***************************************************************************
//  pragmas
// ***************************************************************************


// ***************************************************************************
//  includes
// ***************************************************************************
#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sysver.h"

// ***************************************************************************
//  macros
// ***************************************************************************
#if !defined(u8)
typedef unsigned char   u8;
#endif
#if !defined(u16)
typedef unsigned short  u16;
#endif
#if !defined(u32)
typedef unsigned long   u32;
#endif
#if !defined(BOOL)
typedef unsigned long   BOOL;
#endif
#if !defined(CHAR)
typedef char            CHAR;
#endif
#if !defined(UCHAR)
typedef unsigned char   UCHAR;
#endif
#if !defined(BYTE)
typedef unsigned char   BYTE;
#endif
#if !defined(SHORT)
typedef short           SHORT;
#endif
#if !defined(USHORT)
typedef unsigned short  USHORT;
#endif

#if !defined(WORD)
typedef unsigned short  WORD;
#endif

#if !defined(LONG)
typedef long            LONG;
#endif

#if !defined(ULONG)
typedef unsigned long   ULONG;
#endif

#if !defined(DWORD)
typedef unsigned long   DWORD;
#endif

#if !defined(LONGLONG)
typedef double          LONGLONG;
#endif

#if !defined(DWORD_PTR)
typedef unsigned long   DWORD_PTR;
#endif
#if !defined(PVOID)
typedef void *          PVOID;
#endif

#if !defined(TRUE)
#define TRUE    1
#endif
#if !defined(FALSE)
#define FALSE   0
#endif

#if !defined(NULL)
#define NULL    0
#endif

#if !defined(MIN)
#define MIN(a,b)    (a<=b)?a:b
#endif
#if !defined(MAX)
#define MAX(a,b)    (a>=b)?a:b
#endif

enum YES_NO
{
    NO = 0,
    YES,
    no = 0,
    yes
};

#define MAX_CFI                 128     // Maximum number of CFI locations (WORD)
#define TASK_DELAY              100     // OS Ticks, 1 tick =~10msec.
#define SOE_SETTING     1       // 0 = don't stop on error, 1 = stop on error
#define __LINENO__      1


// basic operating info
enum
{
    INFO_COUNT,
    FLASH_TYPE,
    FLASH_BASE,
    WRITE_BUFFER_SIZE,
    MEMORY_WIDTH,
    MEMORY_SIZE,
    WORD_COUNT,
    BANK_COUNT,
    SECTOR_COUNT,
    LARGEST_SECTOR,
    REGION_COUNT,
    PROG_WORD_TIMEOUT,
    PROG_BUFFER_TIMEOUT,
    SEC_ERASE_TIMEOUT,
    CHIP_ERASE_TIMEOUT,
    SUSPEND_TIMEOUT,
    CFI_DATA,
    AUTOSELECT_DATA,
    REGION_OFFSETS,
    REGION_SECTOR_SIZES,
    REGION_SECTOR_COUNTS,
    BANK_OFFSETS,
    BANK_SECTOR_COUNTS,
    TECHNOLOGY,
    PAGE_SIZE,
    BLOCK_SIZE,
    SPARE_SIZE,
    PAGES_PER_BLOCK,
    BLOCK_COUNT,
    ID_LENGTH,
    SYS_CONFIG,
    ROW_ADD_COUNT,
    PAGE_SEGMENT_SIZE,
    SPARE_SEGMENT_SIZE,
    CS_CONTROL,
    MAX_FREQUENCY,
    FUNCTION_COUNT,
    OBJECT_SIZE,
    VOLUME_TYPE,
    VOLUME_NAME,
    READ_MODE_TABLE,
    COLUMN_BITS,
    PRIME_ADDRESS_BIT,
    SPEC_CFI_DATA,
    ARG_BLOCK_SIZE,
    DEVICE_TYPE_COUNT,
    BOOT_TYPE,
    FEATURES,
    DEVICE_NAME,
    CFG_COUNT,
    LUN_COUNT,
    PLANE_COUNT,
    BLOCKS_PER_LUN,
    MAX_PARAMETER
};

// bus interface types
enum
{
    INTF_NOR = 0,   // use 2420 values for now
    INTF_UNDEF1 = 1,
    INTF_NAND = 2,
    INTF_UNDEF2 = 3
};

// basic geometry info
enum
{
    SECTOR_COUNT_OF_BANK,
    ADDRESS_OF_BANK,
    ADDRESS_OF_REGION,
    BANK_FROM_SECTOR,
    REGION_FROM_SECTOR,
    ADDRESS_OF_SECTOR,
    SECTOR_FROM_ADDRESS,
    WORD_COUNT_OF_SECTOR,
    BYTE_COUNT_OF_SECTOR,
    SECTOR_SIZE_OF_REGION,
    SECTOR_COUNT_OF_REGION,
    START_SECTOR_OF_REGION,
    WORD_COUNT_OF_BANK,
    BYTE_COUNT_OF_BANK,
    MAX_GEOMETRY
};

enum
{
    SECSI_UNLOCKED,
    SECSI_LOCKED
};

enum
{
    PROT_NONE,
    PROT_PERSISTENT,
    PROT_PASSWORD,
    PROT_RDPASSWORD,
    PROT_PPBENABLE
};

enum
{
    ASP_PPB,
    ASP_DYB,
    ASP_PPBL,
    ASP_PWD,
    ASP_PWDED,
    ASP_PPBERASEALL,
    ASP_SECSI_CUST
};

enum
{
    FCA_SLA         = 0x00000040    // Lock/Unlock Sector
};

enum TechnologyTypes
{
    NONE,
    NOR,
    NAND,
    SPI,
    RPC,
    MAX_TECHNOLOGY
};

// system regulator circuits
enum
{
    VOLT_18,
    VOLT_3
};

// system functionality - support depends on platform
enum
{
    // configuration and runtime control modifiers
    READ_MODE,
    RETIMING_MODE,
    READ_WAIT_STATES,   // access time for OMAP2420
    WRITE_WAIT_STATES,
    PAGE_WAIT_STATES,
    PAGE_WS_CONTROL,
    IDLE_CS_HIGH,
    WE_PULSE_LENGTH,
    CS_CLOCK_DIVISOR,
    HANDSHAKE_CONTROL,
    DYNAMIC_WAIT_STATE,
    ADV_HOLD,
    OE_HOLD,
    OE_SETUP,
    WRITE_PROTECT,
    GET_VOLTAGE,
    SET_VOLTAGE,
    GET_TEMPERATURE,
    SET_LED,
    SET_DEVICE_SPEED,
    MULTI_TASKS,
    GPIO_CONTROL,
    WAIT_PIN_COUNT,
    CS_WAIT_POLARITY,
    WRAP_BURST,
    READ_MULTIPLE,
    READ_TYPE,
    WRITE_TYPE,
    CLOCK_START,
    DEV_PAGE_LENGTH,
    HANDSHAKE_READ,
    HANDSHAKE_WRITE,
    HANDSHAKE_TIMING,
    CS_WAIT_PIN,
    TIME_SCALE,
    CS_OFF_WRITE,
    CS_OFF_READ,
    CS_DELAY_HALF,
    CS_ON,
    ADV_OFF_WRITE,
    ADV_OFF_READ,
    ADV_DELAY_HALF,
    ADV_ON,
    WE_OFF,
    WE_DELAY_HALF,
    WE_ON,
    OE_OFF,
    OE_DELAY_HALF,
    OE_ON,
    PAGE_BURST_DELAY,
    WRITE_CYCLE_TIME,
    READ_CYCLE_TIME,
    IDLE_CS_SAME,
    IDLE_CS_DIFF,
    BUS_TURN_AROUND,
    // configuration time only control modifiers
    INTF_TYPE,
    BUS_WIDTH,
    MULTIPLEX_STATE,
    SOFT_NAND_CONTROL,
    NAND_ADDR_REMAP,
    SPLIT_STATE,
    CS_SIZE,
    CS_VALID,
    CS_BASE,
    MAX_SUPPORT
};

// device modes
enum DEV_MODES
{
    DEV_ASYNC,
    DEV_SYNC_CONT,
    DEV_SYNC_08,
    DEV_SYNC_08_WRAP,
    DEV_SYNC_16,
    DEV_SYNC_16_WRAP,
    DEV_SYNC_32,
    DEV_SYNC_32_WRAP,
    DEV_MODE_MAX
};

// system read modes - support depends on platform
enum
{
    SYS_ASYNC,
    SYS_PAGE_04,
    SYS_PAGE_08,
    SYS_PAGE_16,
    SYS_SYNC_CONT,
    SYS_SYNC_02,
    SYS_SYNC_04,
    SYS_SYNC_08,
    SYS_SYNC_16,
    SYS_SYNC_32,
    SYS_SYNC_08_WRAP,
    SYS_SYNC_16_WRAP,
    SYS_SYNC_32_WRAP,
    MAX_RMODE
};

// system information
enum
{
    MAX_FLASH_MHZ,  // maximum flash freq on platform
    RAM_SYNC_ALIGN,
    DEV_SYNC_ALIGN,
    GPIO_PINS,      // return bits supported as ones
    PLATFORM,
    ETHERNET_BASE,
    BUS_8_BIT_OK,   // system can split 16 bit requests into two 8 bit ones
    MAX_INFO
};

// platforms
enum
{
    UNKNOWN,
    OMAP_1610,
    OMAP_1610A,
    OMAP_1610D,
    OMAP_1610E,
    OMAP_1710,
    OMAP_1621,
    OMAP_242X_ES10,
    OMAP_242X_ES20,
    OMAP_242X_ES205,
    OMAP_242X_ES21,
    OMAP_242X_ES211,
    OMAP_242X_ES22
};

// RDY active timing
enum
{
    RDY_BEFORE_DATA,
    RDY_WITH_DATA
};

// flash available features
enum
{
    FS_SINGLEWRITE      = 1 << 0,
    FS_BUFFERWRITE      = 1 << 1,
    FS_BURSTMODE        = 1 << 2,
    FS_ERASECHIP        = 1 << 3,
    FS_ERASESUSPEND     = 1 << 4,
    FS_MIRRORBIT        = 1 << 5,
    FS_BITFIELDPGM      = 1 << 6,
    FS_PAGEMODE         = 1 << 7,
    FS_PASSWORDSECTOR   = 1 << 8,
    FS_PERSISTENTSECTOR = 1 << 9,
    FS_PROGSUSPEND      = 1 << 10,
    FS_SECURESILICON    = 1 << 11,
    FS_UNLOCKBYPASS     = 1 << 12,
    FS_READCONFIGREG    = 1 << 13,
    FS_SETCONFIGREG     = 1 << 14,
    FS_LOCKREGISTER     = 1 << 15,
    FS_GNVSECTPROTECT   = 1 << 16,
    FS_NVSECTPROTECT    = 1 << 17,
    FS_GVSECTPROT       = 1 << 18,
    FS_VSECTPROT        = 1 << 19,
    FS_BURSTSUSPEND     = 1 << 20,
    FS_SIMULOP          = 1 << 21,
    FS_SECTORPROTECT    = 1 << 22,
    FS_STATUSREGISTER   = 1 << 23,
    FS_SECTORLOCK       = 1 << 24,
    FS_SECTORLOCKRANGE  = 1 << 25,
    FS_BURSTCONT        = 1 << 26,
    FS_BURST08          = 1 << 27,
    FS_BURST16          = 1 << 28,
    FS_BURST32          = 1 << 29,
    FS_BURSTWRAP        = 1 << 30
};

/****************************************************************************/
/*                                                                          */
/*  Status codes                                                            */
/*                                                                          */
/****************************************************************************/

enum
{
    EC_NONE,                // 000 No Error
    EC_MALLOC,              // 001 Malloc failed
    EC_PARAMETER,           // 002 Parameter error
    EC_ERRCOUNT,            // 003 Error count
    EC_ERRMAX,              // 004 Reach error count limit
    EC_ALIGNMENT,           // 005 Memory alignment error
    EC_HWRESET,             // 006 Error during hardware reset
    EC_PWDDPWDESET,         // 007 Both PWDD and PWDE bits set
    EC_PPBL,                // 008 PPBL in wrong state after h/w reset
    EC_PWDDPWDEPROG,        // 009 No Error when programming PWDD and PWDE at the same time
    EC_USERBREAK,           // 010 User requested break
    EC_DYBSTATE,            // 011 DYB's not in correct state after h/w reset
    EC_STATUSERROR,         // 012 Device status error
    EC_DYBNOTSET,           // 013 DYB not set (and should be)
    EC_DYBNOTCLEAR,         // 014 DYB not clear (and should be)
    EC_MIRRORBITFAILURE,    // 015 Failure in mirror bit test
    EC_ERASEFAILURE,        // 016 Erase operation failed
    EC_ERASEVERIFY,         // 017 Non-blank sector or segment
    EC_PROGTIMEOUT,         // 018 Program operation did not complete in specified max time
    EC_ERASETIMEOUT,        // 019 Erase operation did not complete in specified max time
    EC_PROGDATA,            // 020 Program data did not verify
    EC_EXTENDEDTIMEOUT,     // 021 Erase exceeded extended timeout
    EC_ERASETOEXPIRED,      // 022 Erase start timeout expired before next erase cmd sent
    EC_ERASETONOTEXPIRED,   // 023 Erase start timeout did not expire
    EC_NOTERASING,          // 024 Erasing not in progress (and should be)
    EC_ERASESUSPENDCMD,     // 025 Error suspending erase
    EC_ERASESUSPENDED,      // 026 Erase is suspended (and should NOT be)
    EC_ERASENOTSUSPENDED,   // 027 Erase not suspended (and should be)
    EC_ERASEDQ2NOTTOGGLE,   // 028 DQ2 not toggling in erase sector
    EC_PROGSUCCEEDED,       // 029 Program operation succeeded (and should NOT have)
    EC_ERASESUCCEEDED,      // 030 Erase operation succeeded (and should NOT have)
    EC_READSUCCEEDED,       // 031 Read operation succeeded (and should NOT have)
    EC_READDATA,            // 032 Read data not correct
    EC_READDATAVALID,       // 033 Read data correct (and should NOT be)
    EC_READDATANOTBLANK,    // 034 Read data not 0xFFFF
    EC_35,                  // 035 Not used
    EC_36,                  // 036 Not used
    EC_37,                  // 037 Not used
    EC_BWVERIFY,            // 038 Buffer Write: Data verify failure
    EC_BWNOTEXPECTED,       // 039 Buffer Write: Unexpected status value
    EC_BWTIMEOUT,           // 040 Buffer Write: Exceeded maximum program timeout
    EC_BWABORT,             // 041 Buffer Write: DQ1 error - Write Buffer abort
    EC_BWINTTO,             // 042 Buffer Write: DQ5 error - internal programming timeout
    EC_CANTSETASYNC,        // 043 Failure setting Async mode
    EC_CANTSETBURST,        // 044 Failure setting Burst mode
    EC_CANTSETBURSTWRAP,    // 045 Failure setting Burst mode with wrap-around
    EC_NOSECTORBUFFER,      // 046 Sector buffer not allocated, unable to perform test
    EC_CONTBURSTREAD,       // 047 Failure in continuous burst read
    EC_NONCONTBURSTREAD,    // 048 Failure in non-consecutive address continuous burst read
    EC_CONTBURSTREADWRAP,   // 049 Failure in continuous burst read crossover to next sector
    EC_BURSTREADWRAP,       // 050 Failure in short burst read WITH wraparound
    EC_BURSTREAD,           // 051 Failure in short burst read WITHOUT wraparound
    EC_ASDEVICE,            // 052 AutoSelect device ID not compatible with FAPI
    EC_ASCONSISTENCY,       // 053 Autoselect data did not match between high and low devices
    EC_ASINVALID,           // 054 AutoSelect data invalid
    EC_ASMATCH,             // 055 AutoSelect data did not match startup data
    EC_ASBANKERROR,         // 056 AutoSelect read in non-active bank incorrect
    EC_ASSUCCEEDED,         // 057 AutoSelect read during program succeeded (and should NOT have)
    EC_INVALIDBOOTTYPE,     // 058 Invalid CFI boot sector information
    EC_CFIINVALID,          // 059 CFI data invalid
    EC_CFIMATCH,            // 060 CFI data did not match startup data
    EC_CFIBANKERROR,        // 061 CFI read in non-active bank incorrect
    EC_CFIVERIFY,           // 062 CFI data did not verify
    EC_PROGSUSPENDCMD,      // 063 Error suspending program
    EC_PROGSUSPENDED,       // 064 Program is suspended (and should NOT be)
    EC_PROGNOTSUSPENDED,    // 065 Program not suspended
    EC_INTTIMEOUT,          // 066 Internal timeout limit exceeded (DQ5)
    EC_PPBTIMEOUT,          // 067 Timeout programming PPB
    EC_PPBERASETIMEOUT,     // 068 Timeout erasing PPBs
    EC_PWDDTIMEOUT,         // 069 Timeout programming PWDD bit
    EC_PWDETIMEOUT,         // 070 Timeout programming PWDE bit
    EC_PPBERASEVERIFY,      // 071 PPB erase did not verify
    EC_PPBVERIFY,           // 072 PPB program did not verify
    EC_PPBSET,              // 073 PPB is set (and should NOT be)
    EC_DYBSET,              // 074 DYB is set (and should NOT be)
    EC_75,                  // 075 Not used
    EC_76,                  // 076 Not used
    EC_77,                  // 077 Not used
    EC_PWDTIMEOUT,          // 078 Timeout programming a Password register
    EC_BADPWDINDEX,         // 079 Bad register number passed to FAPIProgPassword
    EC_PPBLSET,             // 080 PPB Lock bit set (and should NOT be)
    EC_PPBLNOTSET,          // 081 PPB Lock bit NOT set (and should be)
    EC_PPBERASESUCCEEDED,   // 082 PPB Erase succeeded (and should not have)
    EC_PWDDC,               // 083 Password Disable Mode is already set, test cancelled
    EC_PWDEC,               // 084 Password Enable Mode is already set, test cancelled
    EC_PWDDM,               // 085 Password Disable Mode is already set, test modified
    EC_PWDEM,               // 086 Password Enable Mode is already set, test modified
    EC_PWDVERIFY,           // 087 Password verify failure
    EC_PWDENOTSET,          // 088 PWDE bit not set (and should be)
    EC_PWDDSUCCEEDED,       // 089 PWDD Program succeeded (and should NOT have)
    EC_PWDREADABLE,         // 090 PWD Registers readable (and should not be)
    EC_PWDPROGSUCCESS,      // 091 PWD Register program succeeded (and should NOT have)
    EC_PWDACCEPTTIMEOUT,    // 092 Timeout waiting for Password to be accepted
    EC_PWDBADGOOD,          // 093 An illegal password unlocked device
    EC_PWDGOODGOOD,         // 094 A good pwd entered with 1uS of bad pwd was successful
    EC_PWDDNOTSET,          // 095 PWDD bit not set (and should be)
    EC_PWDESUCCEEDED,       // 096 PWDE Program succeeded (and should NOT have)
    EC_CUSTMISMATCH,        // 097 CUST bit in AutoSelect did not match Lock Register bit
    EC_NOTINSECSI,          // 098 Device not in SecSi mode (and should be)
    EC_LRTIMEOUT,           // 099 Lock Register program timeout
    EC_SECSIPROGSUCCEEDED,  // 100 Locked Cust SecSi program succeeded (and should not have)
    EC_SIMOP,               // 101 Simultaneous Operation failure
    EC_TOOMANYBANKS,        // 102 FAPIConfigure found too many banks for FAPI structure
    EC_TOOMANYREGIONS,      // 103 FAPIConfigure found too many regions for FAPI structure
    EC_NOTSUPPORTED,        // 104 Function not supported by device
    EC_TOOMANYMASKS,        // 105 FAPIConfigure found too many masks for FAPI structure
    EC_PROGFAILURE,         // 106 Programming failed
    EC_TASKSTART,           // 107 Cannot start task
    EC_ERASEBLOCK,          // 108 Erase block failure (NAND)
    EC_PAGENOTERASED,       // 109 Page not erased (NAND)
    EC_WRITEPAGE,           // 110 Write page failure (NAND)
    EC_NOTBUSY,             // 111 Device did not go busy upon receiving command (NAND)
    EC_OPTIMEOUT,           // 112 Operation timeout
    EC_SUSPENDEDWODQ7,      // 113 DQ7 not set while suspended
    EC_DEVICEERROR,         // 114 Device generic error
    EC_SUSPENDTIMEOUT,      // 115 Suspend timeout
    EC_OPFAILURE,           // 116 Device operation failed
    EC_INVALIDDEVREADMODE,  // 117 Invalid device read mode
    EC_NOREADMODEOPTION,    // 118 Device read mode option not found
    EC_NODEVICE,            // 119 No device present
    EC_INVALIDSYSREADMODE,  // 120 Invalid system read mode
    EC_121,                 // 121 Not used
    EC_TASKTERMINATED,      // 122 Task terminated
    EC_FREQTOOLOW,          // 123 Requested frequency is too low
    EC_FREQTOOHIGH,         // 124 Requested frequency is too high
    EC_SYSNOSUPPORT,        // 125 Function not supported by platform
    EC_SYSNOFINISH,         // 126 System could not complete operation
    EC_CFGREGNOTSET,        // 127 Device configuration register not set correctly
    EC_BADPWDPROTECT,       // 128 Bad Password Protection Setting
    EC_FFSINIT,             // 129 Flash file system failed to initialize
    EC_NOTPARTITIONED,      // 130 Device is not partitioned for flash file system
    EC_FFSPART,             // 131 Device partitioning error
//
    EC_MAX                  // Counts number of error codes
};

// NOR device status function bit definitions
enum
{
    NOR_DS_READ_ARRAY       = 0x00000000,   // nothing else is happening
    NOR_DS_BUSY             = 0x00000001,
    NOR_DS_BUSY_THIS_BANK   = 0x00000002,
    NOR_DS_BUSY_OTHER_BANK  = 0x00000004,
    NOR_DS_ERASING          = 0x00000008,
    NOR_DS_PRE_ERASING      = 0x00000010,
    NOR_DS_PGM_FAIL         = 0x00000020,
    NOR_DS_TIMEOUT          = 0x00000040,   // old status DQ5
    NOR_DS_ERASE_FAIL       = 0x00000080,
    NOR_DS_SEC_LOCK_ERROR   = 0x00000100,
    NOR_DS_ERASE_SUSPENDED  = 0x00000200,
    NOR_DS_PGM_SUSPENDED    = 0x00000400,
    NOR_DS_UNKNOWN          = 0x00000800,
    NOR_DS_ERASE_PPGM_CORE  = 0x00001000,
    NOR_DS_ERASE_DCOL       = 0x00002000,
    NOR_DS_ERASE_ERIP       = 0x00004000,
    NOR_DS_ERASE_SOFT_PGM   = 0x00008000,
    NOR_DS_ERASE_PGM_DREF   = 0x00010000
};

// RPC device status function bit definitions
enum
{
    RPC_DS_IDLE             = 0x00000080,
    RPC_DS_PGM_FAIL         = 0x00000010,
    RPC_DS_ERASE_FAIL       = 0x00000020
};

// QSPI function option flags
enum
{
    // QSPI read mode
    QSPI_READ_SLOW          = 0x00000101,   // use 1-bit read
    QSPI_READ_FAST          = 0x00000102,   // use 1-bit fast read
    QSPI_READ_DUAL          = 0x00000103,   // use Dual Out read
    QSPI_READ_DUAL_IO       = 0x00000104,   // use Dual I/O read
    QSPI_READ_QUAD          = 0x00000105,   // use Quad Outread
    QSPI_READ_QUAD_IO       = 0x00000106,   // use Quad I/Oread
    QSPI_READ_PM            = 0x00000107,   // use 8 bits Parallel mode read
    QSPI_READ_DDR_FAST      = 0x00000108,   // use fast DDR read
    QSPI_READ_DDR_DUAL_IO   = 0x00000109,   // use dual I/O DDR read
    QSPI_READ_DDR_QUAD_IO   = 0x0000010A,   // use quad I/O DDR read

    // QSPI program mode
    QSPI_PGM_PAGE           = 0x00000201,   // use page program
    QSPI_PGM_QUAD_PAGE      = 0x00000202,   // use quad page program

    // QSPI erase mode
    QSPI_ERASE_SECTOR       = 0x00000301,   // use sector erase (64KB/256KB)
    QSPI_ERASE_4KPSECTOR    = 0x00000302,   // use 4KB parameter sector erase
    QSPI_ERASE_8KPSECTOR    = 0x00000303,   // use 8KB parameter sector erase
#if 0
    //QSPI High Performance Read mode
    QSPI_READ_ENTER_H_DUAL  = 0x10C00000,   // enter High Performance Dual Read
    QSPI_READ_H_DUAL        = 0x10D00000,   // continue High Performance Dual Read
    QSPI_READ_EXIT_H_DUAL   = 0x10E00000,   // exit High Performance Dual Read
    QSPI_READ_ENTER_H_QUAD  = 0x10F00000,   // enter High Performance Quad Read
    QSPI_READ_H_QUAD        = 0x11000000,   // continue High Performance Quad Read
    QSPI_READ_EXIT_H_QUAD   = 0x11100000,   // exit High Performance Quad Read
#endif
};

enum
{
    QSPI_CMD_A24_3B,        // old command 24 bit addr: send 24 bit addr
    QSPI_CMD_A32_3B_BA,     // old command 32 bit addr: send 24 bit addr + bank addr
    QSPI_CMD_A32_4B_EXT,    // old command 32 bit addr: send 32 bit addr + EXTADD=1
    QSPI_CMD_A32_4B_NEW     // new command 32 bit addr: send 32 bit addr
};

typedef struct addrsize_struct
{
    DWORD   SecAddr;
    DWORD   SecSize;
} *PASBK, ASBK;

typedef struct lookup_table_entry
{
    char *name;
    DWORD num;
} *PLTE, LTE;

typedef struct device *PDEV;
/*
struct device
{
    DWORD   Technology;         // device technology (NOR, NAND, etc.)
    DWORD   DevType;            // device type
    void    *FlashBase;         // pointer to base address of flash
//    PCS     SysConfig;          // pointer to system config structure for this chip select
    DWORD   DataWidth;          // data word width (8, 16)
    DWORD   MemSize;            // memory size in BYTES
    DWORD   VolType;            // volume (partition) type
    char    *VolName;           // volume name pointer (NULL means no volume partitioned)
    DWORD   OpFlags;            // operation flags
    //
    // NOR info
    DWORD   ProgWordTimeout;    // program one word timeout
    DWORD   ProgBufferTimeout;  // program full buffer timeout
    DWORD   SecEraseTimeout;    // Max Sector erase timeout in microseconds
    DWORD   ChipEraseTimeout;   // Max Chip erase timeout in microseconds
    DWORD   SuspendTimeout;
    DWORD   WRRTimeout;         // WRR write timeout of SPI device
    DWORD   BlkEraseTimeout;    // Max Block erase timeout of SPI device in microseconds
    DWORD   AddressMask;        // Address mask for WORD addresses
    DWORD   AddressShift;       // Address shift for WORD addresses
    DWORD   SectorCount;        // Total number of sectors of all sizes
    DWORD   BufferWriteSize;    // Number of WORDS (BYTES for SPI) in device write buffer or 0 if not supported
    DWORD   LargestSectorSize;  // Number of WORDS (BYTES for SPI) in largest sector
    DWORD   RegionCount;        // Number of CFI regions on device
    DWORD   MinRegionSize;      // Smallest region size
    DWORD   *RegionSecCount;    // Number of sectors in each region
    DWORD   *RegionSecSize;     // Size of sectors in BYTES in each region
    DWORD   *RegionOffsets;     // BYTE address of each region on device
    DWORD   BankCount;          // Number of banks on device
    DWORD   *BankSecCount;      // Number of sectors in each bank
    DWORD   *BankOffsets;       // BYTE address of each bank on device
    PASBK   pAddrSize;          // table of each sector WORD address and size
    DWORD   MaskCount;          // Number of entries in mask table
    DWORD   *BankSecMask;       // table of bank/sector masks for WORD addresses
    WORD    *ASData;
    WORD    *cfiData;
    WORD    *specCfiData;       // hardcoded CFI data from specification (NULL if none)
    DWORD   LkRegAdd;           // lock register address
    DWORD   Features;           // device support features
    DWORD   SpeedOption;        // maximum frequency for device
//    PNORV   pNorVol;            // FFS NOR volume info
    PLTE    pRMTable;           // Text lookup table for read modes
    DWORD   ColumnBits;         // number of bits in column address
    DWORD   PrimeAddressBit;    // bit position of address of prime mirror bit
    DWORD   readMode;           // current read mode
    DWORD   readWS;             // current read wait states for burst mode else unused
    DWORD   rdyAct;             // RDY with or before data else unused
//    PDEVWS  DevWSTab;           // device wait state table
    BYTE    *BadSectorArray;    // bad sector array
    DWORD   BootType;           // boot sector type
//    PCFG    CfgRegSettings;     // config register bit settings table
#if 0
    //
    // NOR command control blocks
    PCCBE   CCB_Reset;
    PCCBE   CCB_AutoSelEnter;
    PCCBE   CCB_ReadCfgReg;
    PCCBE   CCB_WriteCfgReg;
    PCCBE   CCB_EraseChip;
    PCCBE   CCB_EraseSector;
    PCCBE   CCB_EraseSuspend;
    PCCBE   CCB_EraseResume;
    PCCBE   CCB_UnBypassEnter;
    PCCBE   CCB_UnBypassExit;
    PCCBE   CCB_ReadStatReg;
    PCCBE   CCB_ClearStatReg;
    PCCBE   CCB_SingleWordPgm;
    PCCBE   CCB_WriteBufLoad;
    PCCBE   CCB_WriteBufConfirm;
    PCCBE   CCB_WriteBufReset;
    PCCBE   CCB_ProgramSuspend;
    PCCBE   CCB_ProgramResume;
    PCCBE   CCB_BlankCheck;
    PCCBE   CCB_SecSiEnter;
    PCCBE   CCB_SecSiExit;
    PCCBE   CCB_LockRegisterEnter;
    PCCBE   CCB_LockRegisterExit;
    PCCBE   CCB_PasswordEnter;
    PCCBE   CCB_PasswordExit;
    PCCBE   CCB_PPBEnter;
    PCCBE   CCB_PPBExit;
    PCCBE   CCB_PPBLockEnter;
    PCCBE   CCB_PPBLockExit;
    PCCBE   CCB_DYBEnter;
    PCCBE   CCB_DYBExit;
    //
    // NAND info
    BYTE    *idData;            // ID packet
    DWORD   IDLength;           // length of ID packet
    DWORD   CfgIndex;           // ID index of config byte
#endif
    DWORD   PageSize;
#if 0
    DWORD   PageSegmentSize;    // Partial page segment size
    DWORD   SpareSegmentSize;   // Partial spare segment size
    DWORD   BlockSize;
    DWORD   SpareAreaSize;      // spare data area size (bytes per page)
    DWORD   BlockCount;
    DWORD   RowCount;           // number of row address cycles (2 if <= 128MB, 3 if >= 256MB)
    BYTE    *BadBlockArray;     // bad block array
    PNANDV  pNandVol;           // FFS NAND volume info
    BOOL    HoldCS;             // use Hold CS interface
#endif
    DWORD   NAND_data;          // data R/W register
#if 0
    DWORD   NAND_cmd;           // command W register
    DWORD   NAND_add;           // address W register
    BYTE    *VerifyBuffer;      // available buffer for erase/data verify (size = page + spare)
    // Open NAND info
    DWORD   UniqueIDLength;     // length of Unique ID packet
    DWORD   LUNCount;
    DWORD   PlaneCount;
    DWORD   BlockPerLUN;
#endif
};
*/
typedef DWORD PTEST;

// simple buffer fill types (both NOR and NAND)
enum FILL_TYPES
{
    BYTES_ARE_0X00,
    BYTES_ARE_0X55,
    BYTES_ARE_0XAA,
    BYTES_ARE_0XFF,
    BYTES_ARE_0XFE,
    BYTES_ALT_0X00_0XFF,
    BYTES_ALT_0X55_0XAA,
    BYTES_ALT_0XAA_0X55,
    BYTES_ALT_0XFF_0X00,
    BYTES_ARE_ADDRESSES,
    BYTES_ARE_ADDRESSES_PLUS_1,
    BYTES_ARE_RANDOM,
    WORDS_ARE_0X0000,  // keep WORDS after BYTES
    WORDS_ARE_0X5555,
    WORDS_ARE_0XAAAA,
    WORDS_ARE_0XFFFF,
    WORDS_ARE_0XFFFE,       //added for program 1 bit.scp
    WORDS_ARE_0XEFFF,
    WORDS_ALT_0X0000_0XFFFF,
    WORDS_ALT_0X00FF_0XFF00,
    WORDS_ALT_0X5555_0XAAAA,
    WORDS_ALT_0X55AA_0XAA55,
    WORDS_ALT_0XAA55_0X55AA,
    WORDS_ALT_0XAAAA_0X5555,
    WORDS_ALT_0XFF00_0X00FF,
    WORDS_ALT_0XFFFF_0X0000,
    WORDS_ALT_4_OF_0X0000_4_OF_0XFFFF,
    WORDS_ALT_4_OF_0XFFFF_4_OF_0X0000,
    WORDS_ALT_8_OF_0X0000_8_OF_0XFFFF,
    WORDS_ALT_8_OF_0XFFFF_8_OF_0X0000,
    WORDS_ALT_8_OF_0XFF00_0X00FF_N_8_OF_0XFFFF,  // N short for THEN
    WORDS_ARE_ADDRESSES,
    WORDS_ARE_ADDRESS_PLUS_1,
    WORDS_ARE_ADDRESS_AND_0XFF,
    WORDS_ARE_RANDOM,
    WORDS_ARE_CKBD
};

typedef struct SysTimeStamp
{
    DWORD timeL32;
    WORD timeH16;
} STS, *PSTS;

enum SHARP_PATTERNS
{
    A1  =  0,
    A2  =  1,
    A3  =  2,
    A4  =  3,
    A5  =  4,
    A6  =  5,
    A7  =  6,
    A8  =  7,
    A9  =  8,
    A10 =  9,
    A11 = 10,
    A12 = 11,
    A13 = 12,
    A14 = 13,
    A15 = 14,
    A16 = 15,
    A17 = 16,
    B1  = 17,
    B2  = 18,
    B3  = 19,
    B4  = 20,
    B5  = 21,
    B6  = 22,
    B7  = 23,
    B8  = 24,
    B9  = 25,
    B10 = 26,
    B11 = 27,
    B12 = 28,
    B13 = 29,
    B14 = 30,
    B15 = 31,
    B16 = 32,
    B17 = 33
};
// logging control bit options
enum LOG_CONTROL_FLAGS
{
    LOG_NOTHING         = 0x0000,
    LOG_USER_TEXT       = 0x0001, // user text
    LOG_READ            = 0x0002, // single access read
    LOG_WRITE           = 0x0004, // single access write
    LOG_FAST_READ       = 0x0008, // fast CPU and DMA read
    LOG_FAST_WRITE      = 0x0010, // fast CPU and DMA write
    LOG_FUNCTION        = 0x0020, // function enter and exit
    LOG_INTERVAL        = 0x0040, // time interval, such as RDY_Wait
    LOG_RW_ALL = LOG_READ | LOG_WRITE | LOG_FAST_READ | LOG_FAST_WRITE
};

// keep compatibility for existing scripts
enum LOG_CONTROL
{
    LOG_NONE = LOG_USER_TEXT,
    LOG_FN_NO_DATA = LOG_USER_TEXT | LOG_FUNCTION | LOG_INTERVAL,
    LOG_FN_AND_DATA = LOG_USER_TEXT | LOG_FUNCTION | LOG_RW_ALL | LOG_INTERVAL,
    LOG_DATA = LOG_USER_TEXT | LOG_RW_ALL | LOG_INTERVAL
};

// log display options
enum
{
    LOG_DISP_NORM = 0x0000,  // no additional info
    LOG_DISP_TEXT = 0x0001,  // show ASCII data
    LOG_DISP_INFO = 0x0002   // show system info
};

enum SLTAPI
{
    E_SysIoGetArgc                      = 0x000,
    E_SysIoGetArgv,
    E_SysIoGetEnv,
    E_SysIoSetEnv,
    E_SysIoExit,
    E_SysIoWrite,
    E_Find_Device                       = 0x020,
    E_GetErrorText,
    E_ClearDevLog,
    E_DumpLog,
    E_OutputLog,
    E_SYS_CheckVersion                  = 0x030,
    E_SYS_WaitUSec,
    E_SYS_WaitNanoTics,
    E_SYS_FormatDeltaTime,
    E_SYS_GetDeltaTime,
    E_SYS_GetTimestamp,
    E_SYS_CheckUserBreak,
    E_SYS_GetVoltage,
    E_SYS_GetTemperature,
    E_SYS_WriteMem,
    E_SYS_ReadMem,
    E_SYS_GetGlobalDeviceMHz,
    E_SYS_GetReadModeSupport,
    E_SYS_GetSystemInfo,
    E_SCRPGetCSControl                  = 0x050,
    E_SCRPSetCSControl,
    E_SCRPGetFAPIInfo,
    E_SCRPGetFAPIGeometry,
    E_SCRPRead,
    E_SCRPReadArray,
    E_SCRPWriteArray,
    E_SCRPCmd,
    E_SCRPCmdResetFlash,
    E_SCRPSetReadMode,
    E_SCRPCmdAutoSelect,
    E_SCRPCFIRead,
    E_SCRPSupport,
    E_SCRPEraseSector,
    E_SCRPEraseSectorSIMOPRead,
    E_SCRPEraseSectorsVerify,
    E_SCRPSectorBlankCheck,
    E_SCRPEraseChip,
    E_SCRPSProg,
    E_SCRPSProgWait,
    E_SCRPBProgAbortReset,
    E_SCRPBufferWriteLoad,
    E_SCRPBufferWriteStore,
    E_SCRPBufferWriteProgram,
    E_SCRPBufferWrite,
    E_SCRPBufferWriteBlankCheck,
    E_SCRPBufferWriteSIMOPRead,
    E_SCRPProgSuspend,
    E_SCRPProgResume,
    E_SCRPEraseSuspend,
    E_SCRPEraseResume,
    E_SCRPDeviceStatus,
    E_SCRPClrDeviceStatus,
    E_SCRPGetStatusReg,
    E_SCRPGetECCStatusReg,
    E_SCRPSetConfigReg,
    E_SCRPGetConfigReg,
    E_SCRPReadPassword,
    E_SCRPSendPassword,
    E_SCRPProgPassword,
    E_SCRPGetASPFunc,
    E_SCRPSetASPFunc,
    E_SCRPASPUnlock,
    E_SCRPSectorLockUnlock,
    E_SCRPSectorLockRange,
    E_SCRPGetBadSector,
    E_SCRPSetBadSector,
    E_SCRPClearBadSector,
    E_SCRPClearAllBadSectors,
    E_SCRPQSPIEraseSector                   = 0x0A0,
    E_SCRPQSPIEraseBulk,
    E_SCRPQSPIReadArray,
    E_SCRPQSPIHighPerfReadRandom,
    E_SCRPQSPIPgmPage,
    E_SCRPQSPIPgmPageBlankCheck,
    E_SCRPQSPIEnableQuad,
    E_SCRPQSPIDisableQuad,
    E_SCRPQSPIEnableParallel,
    E_SCRPQSPIDisableParallel,
    E_SCRPQSPISetClock,
    E_SCRPQSPIGetClock,
    E_SCRPQSPISetVoltage,
    E_SCRPQSPIGetVoltage,
    E_SCRPQSPISetWP,
    E_SCRPQSPISetBlockProtect,
    E_SCRPQSPIDisableStatusRegWrite,
    E_SCRPQSPIClearWELBit,
    E_SCRPQSPIFreezeBPsTBs,
    E_SCRPQSPIConfigTBParm,
    E_SCRPQSPIConfigBPNV,
    E_SCRPQSPIConfigTBProt,
    E_SCRPQSPILockBPsCBs,
    E_SCRPQSPIPgmOTP,
    E_SCRPQSPIReadOTP,
    E_SCRPQSPIReadPassword,
    E_SCRPQSPISendPassword,
    E_SCRPQSPIProgPassword,
    E_SCRPQSPIAutoBootRegWrite,
    E_SCRPQSPIAutoBootRegRead,
    E_SCRPQSPIAutoBootReadData,
    E_SCRPQSPIAutoBootUpdateRT,
    E_SCRPQSPIEnterDP,
    E_SCRPQSPIExitDP,
    E_SCRPQSPISetReadCmdMode,
    E_SCRPQSPISetProgCmdMode,
    E_SCRPQSPISetAddrMode,
    E_SCRPQSPIEraseBlock,
    E_SCRPQSPISetClockNotLC,
    E_SCRPQSPIWriteOpcode                   = 0x0E0,
    E_SCRPQSPIWriteAddr,
    E_SCRPQSPIWriteModeBit,
    E_SCRPQSPIWriteCount,
    E_SCRPQSPIWriteDataBit,
    E_SCRPQSPIReadDataBit,
    E_SCRPQSPIEnableHold,
    E_SCRPQSPIDisableHold,
    E_SCRPQSPIHold,
    E_SCRPQSPIReset,
    E_SCRPQSPIFPGARegRd,
    E_SCRPQSPIFPGARegWr,
    E_SCRPQSPIFPGAReset,
    E_SCRPQSPIFPGAIdle,
    MAX_API
};
/*
BOOL  SYS_CheckVersion(DWORD major, DWORD minor, DWORD maxapi);
void  SYS_WaitUSec(DWORD);
void  SYS_WaitNanoTics(DWORD);
void  SYS_FormatDeltaTime(char *s, DWORD lTime1, WORD uTime1, DWORD lTime2, WORD uTime2);
DWORD SYS_GetDeltaTime(DWORD lTime1, WORD uTime1, DWORD lTime2, WORD uTime2);
void  SYS_GetTimestamp(PSTS pSts);
DWORD SYS_CheckUserBreak(void);
BOOL  SYS_GetVoltage(DWORD regulator, int *mvolts);
BOOL  SYS_GetTemperature(DWORD sensor, int *pTemp);
void  SYS_WriteMem(DWORD addr, DWORD value, DWORD size);
void  SYS_ReadMem(DWORD addr, DWORD *value, DWORD size);
DWORD SYS_GetGlobalDeviceMHz(void);
BOOL  SYS_GetReadModeSupport(DWORD type);
DWORD SYS_GetSystemInfo(DWORD type);
DWORD SCRPGetCSControl(PDEV pDevice, DWORD type);
DWORD SCRPSetCSControl(PDEV pDevice, DWORD type, DWORD value);
DWORD SCRPGetFAPIInfo(PDEV pDevice, DWORD type);
DWORD SCRPGetFAPIGeometry(PDEV pDevice, DWORD type, DWORD select);
DWORD SCRPRead(PDEV pDevice, DWORD addr);
DWORD SCRPReadArray(PDEV pDevice, WORD *dest, DWORD addr, DWORD count);
DWORD SCRPWriteArray(PDEV pDevice, WORD *src, DWORD addr, DWORD count, BOOL useBW, BOOL cont);
DWORD SCRPCmd(PDEV pDevice, DWORD addr, DWORD data);
DWORD SCRPCmdResetFlash(PDEV pDevice);
DWORD SCRPSetReadMode(PDEV pDevice, DWORD addr, DWORD dMode, DWORD dMHz, DWORD sMode);
DWORD SCRPCmdAutoSelect(PDEV pDevice, DWORD addr);
DWORD SCRPCFIRead(PDEV pDevice, DWORD bank, WORD *dest);
DWORD SCRPSupport(PDEV pDevice);
DWORD SCRPEraseSector(PDEV pDevice, DWORD sector, BOOL waitVerify);
DWORD SCRPEraseSectorSIMOPRead(PDEV pDevice, DWORD sector, WORD *pDest, DWORD rdAddr, DWORD rdCount, BOOL waitVerify);
DWORD SCRPEraseSectorsVerify(PDEV pDevice, DWORD sector, DWORD count);
DWORD SCRPSectorBlankCheck(PDEV pDevice, DWORD sector);
DWORD SCRPEraseChip(PDEV pDevice, BOOL wait);
DWORD SCRPSProg(PDEV pDevice, DWORD addr, DWORD value);
DWORD SCRPSProgWait(PDEV pDevice, DWORD addr, DWORD value);
DWORD SCRPBProgAbortReset(PDEV pDevice);
DWORD SCRPBufferWriteLoad(PDEV pDevice, DWORD addr, DWORD count);
DWORD SCRPBufferWriteStore(PDEV pDevice, WORD *src, DWORD addr, DWORD count);
DWORD SCRPBufferWriteProgram(PDEV pDevice, DWORD addr);
DWORD SCRPBufferWrite(PDEV pDevice, WORD *src, DWORD addr, DWORD count, BOOL wait);
DWORD SCRPBufferWriteBlankCheck(PDEV pDevice, WORD *src, DWORD addr, DWORD count, BOOL wait);
DWORD SCRPBufferWriteSIMOPRead(PDEV pDevice, WORD *src, DWORD addr, DWORD count, WORD *pDest, DWORD rdAddr, DWORD rdCount, BOOL wait);
DWORD SCRPProgSuspend(PDEV pDevice, DWORD addr, BOOL wait);
DWORD SCRPProgResume(PDEV pDevice, DWORD addr);
DWORD SCRPEraseSuspend(PDEV pDevice, DWORD sector, BOOL wait);
DWORD SCRPEraseResume(PDEV pDevice, DWORD sector);
DWORD SCRPDeviceStatus(PDEV pDevice, DWORD addr, DWORD timeout, DWORD *dstat);
DWORD SCRPClrDeviceStatus(PDEV pDevice, DWORD addr);
DWORD SCRPGetStatusReg(PDEV pDevice, DWORD num, DWORD *dstat);    //NOR: num is sector number, SPI: num is status register number
DWORD SCRPGetECCStatusReg(PDEV pDevice, DWORD addr, DWORD *dstat);
DWORD SCRPSetConfigReg(PDEV pDevice, DWORD addr, DWORD value);
DWORD SCRPGetConfigReg(PDEV pDevice, DWORD addr);
DWORD SCRPReadPassword(PDEV pDevice, WORD *dest);
DWORD SCRPSendPassword(PDEV pDevice, WORD *src);
DWORD SCRPProgPassword(PDEV pDevice, DWORD addr, DWORD value);
DWORD SCRPGetASPFunc(PDEV pDevice, DWORD select, DWORD addr, DWORD *dest);
DWORD SCRPSetASPFunc(PDEV pDevice, DWORD select, DWORD addr, BOOL set);
DWORD SCRPASPUnlock(PDEV pDevice);
DWORD SCRPSectorLockUnlock(PDEV pDevice, DWORD secAddr, BOOL locked);
DWORD SCRPSectorLockRange(PDEV pDevice, DWORD secLow, DWORD secHigh);
BOOL  SCRPGetBadSector(PDEV pDevice, DWORD sector);
void  SCRPSetBadSector(PDEV pDevice, DWORD sector);
void  SCRPClearBadSector(PDEV pDevice, DWORD sector);
void  SCRPClearAllBadSectors(PDEV pDevice);
DWORD SCRPQSPIEraseSector(PDEV pDevice, DWORD sector, BOOL waitVerify);
DWORD SCRPQSPIEraseBulk(PDEV pDevice, BOOL wait);
DWORD SCRPQSPIReadArray(PDEV pDevice, BYTE *dest, DWORD addr, DWORD count);
DWORD SCRPQSPIHighPerfReadRandom(PDEV pDevice, BYTE *dest, DWORD *pkt, DWORD count);
DWORD SCRPQSPIPgmPage(PDEV pDevice, BYTE *src, DWORD addr, DWORD count, BOOL wait);
DWORD SCRPQSPIPgmPageBlankCheck(PDEV pDevice, BYTE *src, DWORD addr, DWORD count, BOOL wait);
DWORD SCRPQSPIEnableQuad(PDEV pDevice);
DWORD SCRPQSPIDisableQuad(PDEV pDevice);
DWORD SCRPQSPIEnableParallel(PDEV pDevice);
DWORD SCRPQSPIDisableParallel(PDEV pDevice);
DWORD SCRPQSPISetClock(PDEV pDevice, DWORD nMhz);
DWORD SCRPQSPISetClockNotLC(PDEV pDevice, DWORD nMhz);
DWORD SCRPQSPIGetClock(PDEV pDevice, DWORD* nMhz);
DWORD SCRPQSPISetVoltage(PDEV pDevice, DWORD nVolgate);
DWORD SCRPQSPIGetVoltage(PDEV pDevice, DWORD *nVoltage);
DWORD SCRPQSPISetWP(PDEV pDevice, BOOL nOnOff);
DWORD SCRPQSPISetBlockProtect(PDEV pDevice, DWORD nBP);
DWORD SCRPQSPIDisableStatusRegWrite(PDEV pDevice, BOOL nOnOff);
DWORD SCRPQSPIClearWELBit(PDEV pDevice);
DWORD SCRPQSPIFreezeBPsTBs(PDEV pDevice);
DWORD SCRPQSPIConfigTBParm(PDEV pDevice, BOOL nTopBottom);
DWORD SCRPQSPIConfigBPNV(PDEV pDevice, BOOL nNV);
DWORD SCRPQSPIConfigTBProt(PDEV pDevice, BOOL nTopBottom);
DWORD SCRPQSPILockBPsCBs(PDEV pDevice);
DWORD SCRPQSPIPgmOTP(PDEV pDevice, WORD *src, DWORD addr, DWORD count);
DWORD SCRPQSPIReadOTP(PDEV pDevice, WORD *dest, DWORD addr, DWORD count);
DWORD SCRPQSPIAutoBootRegWrite(PDEV pDevice, DWORD sAddr, DWORD sDelay, BOOL enable);
DWORD SCRPQSPIAutoBootRegRead(PDEV pDevice, DWORD *reg);
DWORD SCRPQSPIAutoBootReadData(PDEV pDevice, BYTE *dest, DWORD count);
DWORD SCRPQSPIAutoBootUpdateRT(PDEV pDevice, DWORD asad, BOOL quad);
DWORD SCRPQSPIWriteOpcode(PDEV pDevice, DWORD opcode);
DWORD SCRPQSPIWriteAddr(PDEV pDevice, DWORD addr);
DWORD SCRPQSPIWriteModeBit(PDEV pDevice, BYTE *ModeBit);
DWORD SCRPQSPIWriteCount(PDEV pDevice, DWORD bitcount);
DWORD SCRPQSPIWriteDataBit(PDEV pDevice, BYTE *src, DWORD bitcount);
DWORD SCRPQSPIReadDataBit(PDEV pDevice, BYTE *dest, DWORD bitcount);
DWORD SCRPQSPIEnterDP(PDEV pDevice);
DWORD SCRPQSPIExitDP(PDEV pDevice);
DWORD SCRPQSPIEnableHold(PDEV pDevice, BOOL enableSCK);
DWORD SCRPQSPIDisableHold(PDEV pDevice);
DWORD SCRPQSPIHold(PDEV pDevice, DWORD startSCK, DWORD stopSCK);
DWORD SCRPQSPIReset(PDEV pDevice, DWORD nResetType);
DWORD SCRPQSPIFPGARegRd(PDEV pDevice, DWORD regAddr, WORD* value);
DWORD SCRPQSPIFPGARegWr(PDEV pDevice, DWORD regAddr, WORD value);
DWORD SCRPQSPIFPGAReset(PDEV pDevice);
DWORD SCRPQSPIFPGAIdle(PDEV pDevice);
DWORD SCRPQSPISetReadCmdMode(PDEV pDevice, DWORD cmdmode);
DWORD SCRPQSPISetProgCmdMode(PDEV pDevice, DWORD cmdmode);
DWORD SCRPQSPISetAddrMode(PDEV pDevice, DWORD addrmode);
DWORD SCRPQSPIReadPassword(PDEV pDevice, BYTE *dest);
DWORD SCRPQSPISendPassword(PDEV pDevice, BYTE *src);
DWORD SCRPQSPIProgPassword(PDEV pDevice, BYTE *src);
DWORD SCRPQSPIEraseBlock(PDEV pDevice, DWORD sector, BOOL waitVerify);
PDEV  Find_Device(DWORD target);
char* GetErrorText(DWORD number);
void  ClearDevLog(PDEV dev);
void  DumpLog(PDEV dev, DWORD dispOpt);
void  OutputLog(PDEV dev, DWORD dispOpt, DWORD val1, int val2);
int   SysIoGetArgcF(void);
char** SysIoGetArgvF(void);
char* SysIoGetEnvF(char* p);
void  SysIoSetEnvF(char* p, char* q);
void  SysIoExit(int status);
DWORD SysIoWrite(int filedes, const void *buf, DWORD nbyte);
*/

// ***************************************************************************
//  types
// ***************************************************************************


// ***************************************************************************
//  structures
// ***************************************************************************


// ***************************************************************************
//  data
// ***************************************************************************


// ***************************************************************************
//  function prototypes
// ***************************************************************************
extern BOOL  GetArgEnum(char *name, DWORD *value, char *set);
extern BOOL  GetArg(char *name, DWORD *value);
extern DWORD FillBuffer(DWORD type, void *dest, DWORD count);
extern void  GetDataPatternName(DWORD type);
extern DWORD GetDeviceCbdPattern(PDEV dev, DWORD *pattern, BOOL cmp);
extern void  SYS_OSTickDelay(DWORD count);
extern void  FormatDeltaTime(char *s, PSTS t0, PSTS t1);
extern DWORD GetDeltaTime(PSTS t0, PSTS t1);
extern void  line_space(DWORD n);
extern int   GetGlobalVar(char*);
extern void  SetGlobalVar(char*, int);
extern void  SetGlobalVars();
extern char* GetTestName();
extern BOOL  SYS_CheckVersion(DWORD major, DWORD minor, DWORD maxapi);
extern void  SYS_WaitUSec(DWORD);
extern void  SYS_WaitNanoTics(DWORD);
extern void  SYS_FormatDeltaTime(char *s, DWORD lTime1, WORD uTime1, DWORD lTime2, WORD uTime2);
extern DWORD SYS_GetDeltaTime(DWORD lTime1, WORD uTime1, DWORD lTime2, WORD uTime2);
extern void  SYS_GetTimestamp(PSTS pSts);
extern DWORD SYS_CheckUserBreak(void);
extern BOOL  SYS_GetVoltage(DWORD regulator, int *mvolts);
extern BOOL  SYS_GetTemperature(DWORD sensor, int *pTemp);
extern void  SYS_WriteMem(DWORD addr, WORD value, DWORD size);
extern void  SYS_ReadMem(DWORD addr, WORD *value, DWORD size);
extern void  SYS_WriteDPRAM(DWORD addr, WORD value, DWORD size);
extern void  SYS_ReadDPRAM(DWORD addr, WORD *value, DWORD size);
extern void  SYS_Burst_ReadMem(DWORD addr, WORD *value, DWORD count);
extern DWORD SYS_GetGlobalDeviceMHz(void);
extern BOOL  SYS_GetReadModeSupport(DWORD type);
extern DWORD SYS_GetSystemInfo(DWORD type);
extern DWORD SCRPGetCSControl(PDEV pDevice, DWORD type);
extern DWORD SCRPSetCSControl(PDEV pDevice, DWORD type, DWORD value);
extern DWORD SCRPGetFAPIInfo(PDEV pDevice, DWORD type);
extern DWORD SCRPGetFAPIGeometry(PDEV pDevice, DWORD type, DWORD select);
extern DWORD SCRPCmd(PDEV pDevice, DWORD addr, DWORD data);
extern DWORD SCRPRead(PDEV pDevice, DWORD addr);
extern DWORD SCRPReadArray(PDEV pDevice, WORD *dest, DWORD addr, DWORD count);
extern DWORD SCRPWriteArray(PDEV pDevice, WORD *src, DWORD addr, DWORD count, BOOL useBW, BOOL cont);
extern DWORD SCRPCmd(PDEV pDevice, DWORD addr, DWORD data);
extern DWORD SCRPCmdResetFlash(PDEV pDevice);
extern DWORD SCRPSetReadMode(PDEV pDevice, DWORD addr, DWORD dMode, DWORD dMHz, DWORD sMode);
extern DWORD SCRPCmdAutoSelect(PDEV pDevice, DWORD addr);
extern DWORD SCRPCFIRead(PDEV pDevice, DWORD bank, WORD *dest);
extern DWORD SCRPSupport(PDEV pDevice);
extern DWORD SCRPEraseSector(PDEV pDevice, DWORD sector, BOOL waitVerify);
extern DWORD SCRPEraseSectorSIMOPRead(PDEV pDevice, DWORD sector, WORD *pDest, DWORD rdAddr, DWORD rdCount, BOOL waitVerify);
extern DWORD SCRPEraseSectorsVerify(PDEV pDevice, DWORD sector, DWORD count);
extern DWORD SCRPSectorBlankCheck(PDEV pDevice, DWORD sector);
extern DWORD SCRPEraseChip(PDEV pDevice, BOOL wait);
extern DWORD SCRPSProg(PDEV pDevice, DWORD addr, DWORD value);
extern DWORD SCRPSProgWait(PDEV pDevice, DWORD addr, DWORD value);
extern DWORD SCRPBProgAbortReset(PDEV pDevice);
extern DWORD SCRPBufferWriteLoad(PDEV pDevice, DWORD addr, DWORD count);
extern DWORD SCRPBufferWriteStore(PDEV pDevice, WORD *src, DWORD addr, DWORD count);
extern DWORD SCRPBufferWriteProgram(PDEV pDevice, DWORD addr);
extern DWORD SCRPBufferWrite(PDEV pDevice, WORD *src, DWORD addr, DWORD count, BOOL wait);
extern DWORD SCRPBufferWriteBlankCheck(PDEV pDevice, WORD *src, DWORD addr, DWORD count, BOOL wait);
extern DWORD SCRPBufferWriteSIMOPRead(PDEV pDevice, WORD *src, DWORD addr, DWORD count, WORD *pDest, DWORD rdAddr, DWORD rdCount, BOOL wait);
extern DWORD SCRPProgSuspend(PDEV pDevice, DWORD addr, BOOL wait);
extern DWORD SCRPProgResume(PDEV pDevice, DWORD addr);
extern DWORD SCRPEraseSuspend(PDEV pDevice, DWORD sector, BOOL wait);
extern DWORD SCRPEraseResume(PDEV pDevice, DWORD sector);
extern DWORD SCRPDeviceStatus(PDEV pDevice, DWORD addr, DWORD timeout, DWORD *dstat);
extern DWORD SCRPClrDeviceStatus(PDEV pDevice, DWORD addr);
extern DWORD SCRPGetStatusReg(PDEV pDevice, DWORD num, DWORD *dstat);    //NOR: num is sector number, SPI: num is status register number
extern DWORD SCRPGetECCStatusReg(PDEV pDevice, DWORD addr, DWORD *dstat);
extern DWORD SCRPSetConfigReg(PDEV pDevice, DWORD addr, DWORD value);
extern DWORD SCRPGetConfigReg(PDEV pDevice, DWORD addr);
extern DWORD SCRPGetConfigReg_4DIE(PDEV pDevice, DWORD addr, DWORD *pCfg);
extern DWORD SCRPReadPassword(PDEV pDevice, WORD *dest);
extern DWORD SCRPSendPassword(PDEV pDevice, WORD *src);
extern DWORD SCRPProgPassword(PDEV pDevice, DWORD addr, DWORD value);
extern DWORD SCRPGetASPFunc(PDEV pDevice, DWORD select, DWORD addr, DWORD *dest);
extern DWORD SCRPSetASPFunc(PDEV pDevice, DWORD select, DWORD addr, BOOL set);
extern DWORD SCRPASPUnlock(PDEV pDevice);
extern DWORD SCRPSectorLockUnlock(PDEV pDevice, DWORD secAddr, BOOL locked);
extern DWORD SCRPSectorLockRange(PDEV pDevice, DWORD secLow, DWORD secHigh);
extern BOOL  SCRPGetBadSector(PDEV pDevice, DWORD sector);
extern void  SCRPSetBadSector(PDEV pDevice, DWORD sector);
extern void  SCRPClearBadSector(PDEV pDevice, DWORD sector);
extern void  SCRPClearAllBadSectors(PDEV pDevice);
extern DWORD SCRPQSPIEraseSector(PDEV pDevice, DWORD sector, BOOL waitVerify);
extern DWORD SCRPQSPIEraseBulk(PDEV pDevice, BOOL wait);
extern DWORD SCRPQSPIReadArray(PDEV pDevice, BYTE *dest, DWORD addr, DWORD count);
extern DWORD SCRPQSPIHighPerfReadRandom(PDEV pDevice, BYTE *dest, DWORD *pkt, DWORD count);
extern DWORD SCRPQSPIPgmPage(PDEV pDevice, BYTE *src, DWORD addr, DWORD count, BOOL wait);
extern DWORD SCRPQSPIPgmPageBlankCheck(PDEV pDevice, BYTE *src, DWORD addr, DWORD count, BOOL wait);
extern DWORD SCRPQSPIEnableQuad(PDEV pDevice);
extern DWORD SCRPQSPIDisableQuad(PDEV pDevice);
extern DWORD SCRPQSPIEnableParallel(PDEV pDevice);
extern DWORD SCRPQSPIDisableParallel(PDEV pDevice);
extern DWORD SCRPQSPISetClock(PDEV pDevice, DWORD nMhz);
extern DWORD SCRPQSPISetClockNotLC(PDEV pDevice, DWORD nMhz);
extern DWORD SCRPQSPIGetClock(PDEV pDevice, DWORD* nMhz);
extern DWORD SCRPQSPISetVoltage(PDEV pDevice, DWORD nVolgate);
extern DWORD SCRPQSPIGetVoltage(PDEV pDevice, DWORD *nVoltage);
extern DWORD SCRPQSPISetWP(PDEV pDevice, BOOL nOnOff);
extern DWORD SCRPQSPISetBlockProtect(PDEV pDevice, DWORD nBP);
extern DWORD SCRPQSPIDisableStatusRegWrite(PDEV pDevice, BOOL nOnOff);
extern DWORD SCRPQSPIClearWELBit(PDEV pDevice);
extern DWORD SCRPQSPIFreezeBPsTBs(PDEV pDevice);
extern DWORD SCRPQSPIConfigTBParm(PDEV pDevice, BOOL nTopBottom);
extern DWORD SCRPQSPIConfigBPNV(PDEV pDevice, BOOL nNV);
extern DWORD SCRPQSPIConfigTBProt(PDEV pDevice, BOOL nTopBottom);
extern DWORD SCRPQSPILockBPsCBs(PDEV pDevice);
extern DWORD SCRPQSPIPgmOTP(PDEV pDevice, WORD *src, DWORD addr, DWORD count);
extern DWORD SCRPQSPIReadOTP(PDEV pDevice, WORD *dest, DWORD addr, DWORD count);
extern DWORD SCRPQSPIAutoBootRegWrite(PDEV pDevice, DWORD sAddr, DWORD sDelay, BOOL enable);
extern DWORD SCRPQSPIAutoBootRegRead(PDEV pDevice, DWORD *reg);
extern DWORD SCRPQSPIAutoBootReadData(PDEV pDevice, BYTE *dest, DWORD count);
extern DWORD SCRPQSPIAutoBootUpdateRT(PDEV pDevice, DWORD asad, BOOL quad);
extern DWORD SCRPQSPIWriteOpcode(PDEV pDevice, DWORD opcode);
extern DWORD SCRPQSPIWriteAddr(PDEV pDevice, DWORD addr);
extern DWORD SCRPQSPIWriteModeBit(PDEV pDevice, BYTE *ModeBit);
extern DWORD SCRPQSPIWriteCount(PDEV pDevice, DWORD bitcount);
extern DWORD SCRPQSPIWriteDataBit(PDEV pDevice, BYTE *src, DWORD bitcount);
extern DWORD SCRPQSPIReadDataBit(PDEV pDevice, BYTE *dest, DWORD bitcount);
extern DWORD SCRPQSPIEnterDP(PDEV pDevice);
extern DWORD SCRPQSPIExitDP(PDEV pDevice);
extern DWORD SCRPQSPIEnableHold(PDEV pDevice, BOOL enableSCK);
extern DWORD SCRPQSPIDisableHold(PDEV pDevice);
extern DWORD SCRPQSPIHold(PDEV pDevice, DWORD startSCK, DWORD stopSCK);
extern DWORD SCRPQSPIReset(PDEV pDevice, DWORD nResetType); //0:Software Reset, 1:Mode Bit Reset, 2:Hardware Reset
extern DWORD SCRPQSPIFPGARegRd(PDEV pDevice, DWORD regAddr, DWORD *value);
extern DWORD SCRPQSPIFPGARegWr(PDEV pDevice, DWORD regAddr, DWORD value);
extern DWORD SCRPQSPIFPGAReset(PDEV pDevice);
extern DWORD SCRPQSPIFPGAIdle(PDEV pDevice);
extern DWORD SCRPQSPISetReadCmdMode(PDEV pDevice, DWORD cmdmode);
extern DWORD SCRPQSPISetProgCmdMode(PDEV pDevice, DWORD cmdmode);
extern DWORD SCRPQSPISetAddrMode(PDEV pDevice, DWORD addrmode);
extern DWORD SCRPQSPIReadPassword(PDEV pDevice, BYTE *dest);
extern DWORD SCRPQSPISendPassword(PDEV pDevice, BYTE *src);
extern DWORD SCRPQSPIProgPassword(PDEV pDevice, BYTE *src);
extern DWORD SCRPQSPIEraseBlock(PDEV pDevice, DWORD sector, BOOL waitVerify);
extern DWORD SCRPRPCReset(PDEV pDevice, DWORD nResetType); //0:Software Reset, 1:Hardware Reset
extern PDEV  Find_Device(DWORD target);
extern char* GetErrorText(DWORD number);
extern void  ClearDevLog(PDEV dev);
extern void  DumpLog(PDEV dev, DWORD dispOpt);
extern void  OutputLog(PDEV dev, DWORD dispOpt, DWORD val1, int val2);
extern DWORD SysIoWrite(int filedes, const void *buf, DWORD nbyte);
extern DWORD SYS_GetCSControl(DWORD type);
extern BOOL SYS_SetCSControl(DWORD type, DWORD value);
// ***************************************************************************
extern int GetRAND_MAX(void);

// ***************************************************************************
//  inline functions
// ***************************************************************************


// ***************************************************************************
//  include file closing statements
// ***************************************************************************
/*
#ifdef __cplusplus
}
#endif
*/

// ***************************************************************************
//  sltfapi.h
// ***************************************************************************
#define AS_MFGID        0x00
#define AS_ID0          0x01
#define AS_LOCK         0x02
#define AS_INDICATOR    0x03
#define AS_ID1          0x0E
#define AS_ID2          0x0F

#define DQ8_MASK        0x0100
#define DQ7_MASK        0x0080
#define DQ6_MASK        0x0040
#define DQ5_MASK        0x0020
#define DQ4_MASK        0x0010
#define DQ3_MASK        0x0008
#define DQ2_MASK        0x0004
#define DQ1_MASK        0x0002
#define DQ0_MASK        0x0001

#define CFI_SPROGTO         0x1F
#define CFI_BPROGTO         0x20
#define CFI_SECERASETO      0x21
#define CFI_CHIPERASETO     0x22
#define CFI_SPROGTOMAX      0x23
#define CFI_BPROGTOMAX      0x24
#define CFI_SECERASETOMAX   0x25
#define CFI_CHIPERASETOMAX  0x26

#define CFI_DEVSIZE         0x27
#define CFI_MULTIBYTEWRITE  0x2A
#define CFI_REGIONCOUNT     0x2C

#define CFI_PRIMARY         0x40
#define CFI_PRIVERMAJOR     0x43
#define CFI_PRIVERMINOR     0x44

#define CFI_ERASESUSPEND    0x46
#define CFI_SECTORPROTECT   0x47

#define CFI_ADVSECPROTECT   0x49

#define CFI_SIMULOP         0x4A
#define CFI_BURSTMODE       0x4B
#define CFI_PAGEMODE        0x4C
#define CFI_BOOTFLAG        0x4F
#define CFI_PROGSUSPEND     0x50

#define CFI_UNLOCKBYPASS    0x51

#define CFI_SECSISIZE       0x52    // Customer OTP size

#define CFI_ERASESUSPTO     0x55
#define CFI_PROGRAMSUSPTO   0x56
#define CFI_BANKCOUNT       0x57    // If 0, then consider as 1 bank

#define MAX_AUTOSELECT      0x10        // Maximum number of Auto-select locations
#define MAX_CFI             128         // Maximum number of CFI locations (WORD)
#define MAX_REGIONS         4           // Maximum number of regions allowed
#define MAX_BANKS           32          // Maximum number of banks allowed

enum BootTypes
{
    BT_UNIFORM_NONE     = 0,
    BT_SMALL_TOP_BOTTOM = 1,
    BT_SMALL_BOTTOM     = 2,
    BT_SMALL_TOP        = 3,
    BT_UNIFORM_BOTTOM   = 4,
    BT_UNIFORM_TOP      = 5,
    BT_UNIFORM_WP_ALL   = 6,
    BT_UNIFORM_WP_TOP_BOTTOM = 7,
    BT_LIMIT            = 8
};

// boot type and region count entry
typedef struct
{
    DWORD type;
    DWORD regions;
} BTRC;

// NOR function option flags
enum
{
    NOR_READ_FAST       = 0x00000001,   // use fast (CPU) reads for ReadNORBuffer
    NOR_READ_DMA        = 0x00000002,   // use DMA reads for ReadNORBuffer
    NOR_WRITE_FAST      = 0x00000004,   // use fast writes for buffer programming
    NOR_PBUFF_ERROR_GO  = 0x00000008,   // ignore buffer write errors in ProgNORBuffer
    NOR_WRITE_BUFFER    = 0x00000010,   // request buffer write command (if supported) for ProgNORBuffer
    NOR_BW_WAIT         = 0x00000020,   // wait for buffer write to complete
    NOR_ERASE_WAIT      = 0x00000040,   // wait for erase (sector or chip) to complete
    NOR_SUSP_WAIT       = 0x00000080,   // wait for erase or program suspend command to complete
    NOR_ERASE_VER       = 0x00000100,   // verify sector after erasing it (return on first verify error)
    NOR_CFG_VERIFY      = 0x00000200,   // verify configuration register when setting read mode
    NOR_CMD_THEN_READ   = 0x00000400,   // issue command then do fast array read (block SIMOP)
    NOR_CMD_SEC_MASK    = 0x00000800,   // NOR command processor will use sector mask on sector addresses
    NOR_CMD_SKIP_LAST   = 0x00001000,   // NOR command processor will skip last CCB entry (and return values)
    NOR_CMD_THEN_STATUS = 0x00002000,   // issue command then do fast status query
    NOR_PGM_BLANK_CHECK = 0x00004000,   // verify word(s) blank (0xFFFF) before programming
    NOR_BW_BIT_FIELD    = 0x00008000,   // use bit field buffer programming
    NOR_SEG_BLANK_CHECK = 0x00010000,   // verify segment of flash is blank (0xFFFF)
    NOR_ERASE_SLOW_POLL = 0x00020000,   // allow task blocking when checking erase status
    NOR_CMD_READ_RANDOM = 0x00040000,   // issue command then do random read (random SIMOP)
    NOR_CMD_READ_RAND16 = 0x00080000,   // issue command then do random reads of 16 word blocks (random SIMOP)
};



// ordinal number sequence of functions
enum FunctionTypes
{
    // internal operation
    FN_GetFAPIInfo,
    FN_GetFAPIGeometry,
    // initialization
    FN_Configure,
    // NOR
    FN_ReadNORData,
    FN_ReadNORBuffer,
    FN_ReadNORRandom,
  //FN_VerifyNORBuffer,
    FN_WriteNORData,
    FN_ProgNORBuffer,
  // NAND
  //FN_ReadNANDData,
  //FN_WriteNANDCmd,
  //FN_WriteNANDAdd,
  //FN_WriteNANDData,
  //FN_ReadPage,
  //FN_ReadSpare,
  //FN_ReadRandom,
  //FN_ReadPageSeg,
  //FN_ReadSpareSeg,
  //FN_ReadPipeline,
  //FN_ReadPageVar,
  //FN_ReadSpareVar,
  //FN_PageVerify,
  //FN_SpareVerify,
  //FN_EraseVerify,
  //FN_ProgPage,
  //FN_ProgPageFast,
  //FN_ProgRandom,
  //FN_ProgSpare,
  //FN_ProgSpareFast,
  //FN_ProgPageVar,
  //FN_ProgSpareVar,
  //FN_ProgPageExt,
  //FN_CacheProg,
  //FN_CacheProgFast,
  //FN_CopyPage,
  //FN_CopyPageFast,
  //FN_CopyPageRandom,
  //FN_XCopyPage,
  //FN_XPreProg,
  //FN_EraseBlock,
  //FN_EraseBlockSuspend,
  //FN_SetXtremeMode,
  //FN_OTPAreaOverlay,
  //FN_OTPAreaRemove,
  //FN_OTPPageProtStatus,
  //FN_OTPDfltAsOverlay,
  //FN_OTPDfltAsRemoved,
  //FN_OTPProtectPage,
  //FN_GetID,
  //FN_BlockLock,
  //FN_BlockUnlock,
  //FN_BlockLockdown,
  //FN_LockStatus,
    // Open NAND
  //FN_GetONFIID,
  //FN_GetUniqueID,
  //FN_OTPUnlock,
  //FN_OTPExit,
    FN_SetWP,
  //FN_GetStatusEnhanced,
  //FN_BlockProtection,
  //FN_OTPProtection,
  //FN_ReadParameterPage,
  //FN_InterleavedPgmPage,
  //FN_InterleavedPartialPgmPage,
  //FN_InterleavedCopyBack,
  //FN_InterleavedErase,
  //FN_MarketInterleavedPgmPage,
  //FN_MarketInterleavedPartialPgmPage,
  //FN_MarketInterleavedCopyBack,
  //FN_MarketInterleavedErase,
  //FN_GetIDPartial,
  //FN_UnlockUniqueID,
  //FN_ExitUniqueID,
    // Mircon NAND
  //FN_OTPRead,
  //FN_OTPProg,
  //FN_GetFeatures,
  //FN_SetFeatures,
  //FN_CacheRead,
  //FN_InterleavedReadPage,
  //FN_InterleavedReadRandom,
  //FN_InterleavedProgRandom,
  //FN_InterleavedCacheProg,
    // both
    FN_CmdResetFlash,
    // NOR
    FN_SetReadMode,
    FN_WriteAutoSelectCmd,
    FN_ReadAutoSelect,
  //FN_GetAutoSelectReg,
    FN_ReadCFI,
    // erasure
    FN_EraseSector,
  //FN_EraseSectors,
    FN_VerifySectorBlank,
    FN_WaitForSectorErase,
    FN_EraseChip,
  //FN_QueueEraseSector,
    FN_BlankCheck,
    // async access
    FN_SingleProg,
    FN_SingleProgWait,
  //FN_UnlockBypassProg,
    // buffered access
    FN_BProgAbortReset,
    FN_BufferWriteLoad,
    FN_BufferWriteStore,
    FN_BufferWriteCommit,
    FN_BufferWrite,
    // suspend/resume
    FN_ProgSuspend,
    FN_ProgResume,
    FN_EraseSuspend,
    FN_EraseResume,
    // status
    FN_GetNORStatus,
    FN_ClearNORStatus,
  //FN_GetNANDStatus,
    // special functionality
    FN_GetStatusReg,
    FN_GetECCStatusReg,
    FN_SetConfigReg,
    FN_GetConfigReg,
    FN_ReadPassword,
    FN_SendPassword,
    FN_ProgPassword,
    FN_ReadLockRegister,
    FN_ProgLockRegister,
    FN_GetASPState,
    FN_SetASPState,
  //FN_SecSi,
  //FN_ProgramSecSi,
  //FN_ReadSecSiBits,
    FN_SectorLockUnlock,
    FN_SectorLockRange,
  //FN_BadBlockInfo,
    FN_BadSectorInfo,
    FN_ASPUnlock,
  //FN_GetMBAddress,
    // QSPI
    FN_ReadID,
    FN_EnableQuad,
    FN_DisableQuad,
    FN_EnableParallel,
    FN_DisableParallel,
    FN_SetClock,
    FN_GetClock,
    FN_SetVoltage,
    FN_GetVoltage,
    FN_SetBlockProtect,
    FN_DisableStatusRegWrite,
    FN_ClearWELBit,
    FN_FreezeBPsTBs,
    FN_ConfigTBParm,
    FN_ConfigBPNV,
    FN_ConfigTBProt,
    FN_LockBPsCBs,
    FN_ProgOTP,
    FN_ReadOTP,
    FN_AutoBootRegWrite,
    FN_AutoBootRegRead,
    FN_AutoBootReadData,
    FN_AutoBootUpdateRT,
    FN_WriteOpcode,
    FN_WriteAddr,
    FN_WriteCount,
    FN_WriteModeBit,
    FN_WriteDataBit,
    FN_ReadDataBit,
    FN_EnterDP,
    FN_ExitDP,
    FN_EnableHold,
    FN_DisableHold,
    FN_Hold,
    FN_FPGARegRd,
    FN_FPGARegWr,
    FN_FPGARamRd,
    FN_FPGAReset,
    FN_FPGAIdle,
    FN_SetReadCmdMode,
    FN_SetProgCmdMode,
    FN_SetAddrMode,
    FN_GetReadCmdMode,
    FN_GetProgCmdMode,
    FN_GetAddrMode,
  // set enum length at end
  FN_MAX
};


// this structure is designed to be utilized by all levels of the flash hierarchy
// assume fields all will change except pDevice and pList when calling a function
typedef struct pdev_struct
{
    PDEV    pDevice;    // device object (basically the this pointer)
    DWORD   fl_addr;    // 32 bit flash address for single read/write NOR
    WORD    fl_data;    // 16 bit flash data for single read/write NAND and NOR
    WORD    resv_01;    // reserve for possible 32 bit support
    DWORD   st_addr;    // 32 bit start flash address for data transfer
    DWORD   fl_sect;    // sector number (not address)
    DWORD   fl_block;   // block number (not address)
    void    *pSrc;      // pointer to source data
    void    *pDest;     // pointer to destination data
    void    *pFmt;      // pointer to function specific formatted information
    void    *pFmt1;      // pointer to function specific formatted information
    DWORD   dwCount;    // function specific count
    DWORD   dwSize;     // currently used for NOR burst size
    DWORD   dwType;     // used for info and geometry
    DWORD   dwSelect;   // function specific selection
    DWORD   dwValue;    // function specific value
    DWORD   dwResult;   // returns function specific information
    DWORD   dwStatus;   // used for NAND and NOR status
    DWORD   dev_mode;   // device read mode
    DWORD   dev_MHz;    // device and system frequency
    DWORD   sys_mode;   // system read mode
    DWORD   dwRdyAct;   // RDY active select
    DWORD   dwTimeout;  // timeout value for status polling
    DWORD   dwOptNOR;   // NOR function option flags
    DWORD   dwOptNAND;  // NAND function option flags
    DWORD   dwIntNAND;  // internal NAND operation mode
    DWORD   dwFlgNAND;  // internal NAND operation flags
//    PCCBE   pCCB;       // pointer to command block array
//    PCTRL   pCmdXList;  // pointer to function list executed between commands
//    PCTRL   pList;      // pointer to function list for Process Control
} DARGS, *PDARGS;

struct logEntry
{
    DWORD tLow;     // lower 32 bits of timestamp (match system timestamp)
    WORD tHigh;     // upper 8 bits of timestamp (match system timestamp)
    BYTE type;      // type and depth of log record
    BYTE info1;     // info + text storage
    WORD info2;
    WORD data;      // read/write data
    DWORD addr;     // read/write address
};

typedef struct logEntry *PLOG;

#define LOG_SIZE 10000  // default startup log size, the max log size is 0x100000
#define LOG_DEFAULT 32  // internal log size if malloc fails

struct logParms
{
    PLOG pLog;
    DWORD logSize;
    DWORD logStart;
    DWORD logEnd;
};


typedef DWORD (*PFUN)(PDARGS);
// flash device object structure
// keep device member functions at front of structure
// note - declare all members to align, do not allow compiler to align them
struct device
{
    //
    // device member data ("private")
    // general info
    DWORD   Technology;         // device technology (NOR, NAND, etc.)
    DWORD   DevType;            // device type
    void    *FlashBase;         // pointer to base address of flash
//    PCS     SysConfig;          // pointer to system config structure for this chip select
    DWORD   DataWidth;          // data word width (8, 16)
    DWORD   MemSize;            // memory size in BYTES
    DWORD   VolType;            // volume (partition) type
    char    *VolName;           // volume name pointer (NULL means no volume partitioned)
    DWORD   OpFlags;            // operation flags
    //
    // NOR info
    DWORD   ProgWordTimeout;    // program one word timeout
    DWORD   ProgBufferTimeout;  // program full buffer timeout
    DWORD   SecEraseTimeout;    // Max Sector erase timeout in microseconds
    DWORD   ChipEraseTimeout;   // Max Chip erase timeout in microseconds
    DWORD   SuspendTimeout;
    DWORD   WRRTimeout;         // WRR write timeout of SPI device
    DWORD   AddressMask;        // Address mask for WORD addresses
    DWORD   AddressShift;       // Address shift for WORD addresses
    DWORD   SectorCount;        // Total number of sectors of all sizes
    DWORD   BufferWriteSize;    // Number of WORDS (BYTES for SPI) in device write buffer or 0 if not supported
    DWORD   LargestSectorSize;  // Number of WORDS (BYTES for SPI) in largest sector
    DWORD   RegionCount;        // Number of CFI regions on device
    DWORD   MinRegionSize;      // Smallest region size
    DWORD   *RegionSecCount;    // Number of sectors in each region
    DWORD   *RegionSecSize;     // Size of sectors in BYTES in each region
    DWORD   *RegionOffsets;     // BYTE address of each region on device
    DWORD   BankCount;          // Number of banks on device
    DWORD   *BankSecCount;      // Number of sectors in each bank
    DWORD   *BankOffsets;       // BYTE address of each bank on device
    PASBK   pAddrSize;          // table of each sector WORD address and size
    DWORD   MaskCount;          // Number of entries in mask table
    DWORD   *BankSecMask;       // table of bank/sector masks for WORD addresses
    WORD    *ASData;
    WORD    *cfiData;
    WORD    *specCfiData;       // hardcoded CFI data from specification (NULL if none)
    DWORD   LkRegAdd;           // lock register address
    DWORD   Features;           // device support features
    DWORD   SpeedOption;        // maximum frequency for device
//    PNORV   pNorVol;            // FFS NOR volume info
    PLTE    pRMTable;           // Text lookup table for read modes
    DWORD   ColumnBits;         // number of bits in column address
    DWORD   PrimeAddressBit;    // bit position of address of prime mirror bit
    DWORD   readMode;           // current read mode
    DWORD   readWS;             // current read wait states for burst mode else unused
    DWORD   rdyAct;             // RDY with or before data else unused
//    PDEVWS  DevWSTab;           // device wait state table
    BYTE    *BadSectorArray;    // bad sector array
    DWORD   BootType;           // boot sector type
//    PCFG    CfgRegSettings;     // config register bit settings table
	DWORD	RPC_CTRL_MODE;
	DWORD	RPC_LOOPBACK_MODE;
	DWORD	RPC_FLASH_MODE;
#if 0
    //
    // NOR command control blocks
    PCCBE   CCB_Reset;
    PCCBE   CCB_AutoSelEnter;
    PCCBE   CCB_ReadCfgReg;
    PCCBE   CCB_WriteCfgReg;
    PCCBE   CCB_EraseChip;
    PCCBE   CCB_EraseSector;
    PCCBE   CCB_EraseSuspend;
    PCCBE   CCB_EraseResume;
    PCCBE   CCB_UnBypassEnter;
    PCCBE   CCB_UnBypassExit;
    PCCBE   CCB_ReadStatReg;
    PCCBE   CCB_ClearStatReg;
    PCCBE   CCB_SingleWordPgm;
    PCCBE   CCB_WriteBufLoad;
    PCCBE   CCB_WriteBufConfirm;
    PCCBE   CCB_WriteBufReset;
    PCCBE   CCB_ProgramSuspend;
    PCCBE   CCB_ProgramResume;
    PCCBE   CCB_BlankCheck;
    PCCBE   CCB_SecSiEnter;
    PCCBE   CCB_SecSiExit;
    PCCBE   CCB_LockRegisterEnter;
    PCCBE   CCB_LockRegisterExit;
    PCCBE   CCB_PasswordEnter;
    PCCBE   CCB_PasswordExit;
    PCCBE   CCB_PPBEnter;
    PCCBE   CCB_PPBExit;
    PCCBE   CCB_PPBLockEnter;
    PCCBE   CCB_PPBLockExit;
    PCCBE   CCB_DYBEnter;
    PCCBE   CCB_DYBExit;
    //
    // NAND info
    BYTE    *idData;            // ID packet
    DWORD   IDLength;           // length of ID packet
    DWORD   CfgIndex;           // ID index of config byte
#endif
    DWORD   PageSize;
#if 0
    DWORD   PageSegmentSize;    // Partial page segment size
    DWORD   SpareSegmentSize;   // Partial spare segment size
    DWORD   BlockSize;
    DWORD   SpareAreaSize;      // spare data area size (bytes per page)
    DWORD   BlockCount;
    DWORD   RowCount;           // number of row address cycles (2 if <= 128MB, 3 if >= 256MB)
    BYTE    *BadBlockArray;     // bad block array
    PNANDV  pNandVol;           // FFS NAND volume info
    BOOL    HoldCS;             // use Hold CS interface
#endif
    DWORD   NAND_data;          // data R/W register
#if 0
    DWORD   NAND_cmd;           // command W register
    DWORD   NAND_add;           // address W register
    BYTE    *VerifyBuffer;      // available buffer for erase/data verify (size = page + spare)
    // Open NAND info
    DWORD   UniqueIDLength;     // length of Unique ID packet
    DWORD   LUNCount;
    DWORD   PlaneCount;
    DWORD   BlockPerLUN;
#endif

    // device member functions ("public")
    // internal operation
    PFUN    pGetFAPIInfo,           sGetFAPIInfo;
    PFUN    pGetFAPIGeometry,       sGetFAPIGeometry;
    // initialization
    PFUN    pConfigure,             sConfigure;
    // NOR
    PFUN    pReadNORData,           sReadNORData;
    PFUN    pReadNORBuffer,         sReadNORBuffer;
    PFUN    pReadNORRandom,         sReadNORRandom;
//    PFUN    pVerifyNORBuffer,       sVerifyNORBuffer;
    PFUN    pWriteNORData,          sWriteNORData;
    PFUN    pProgNORBuffer,         sProgNORBuffer;
    // NAND
//    PFUN    pReadNANDData,          sReadNANDData;
//    PFUN    pWriteNANDCmd,          sWriteNANDCmd;
//    PFUN    pWriteNANDAdd,          sWriteNANDAdd;
//    PFUN    pWriteNANDData,         sWriteNANDData;
//    PFUN    pReadPage,              sReadPage;
//    PFUN    pReadSpare,             sReadSpare;
//    PFUN    pReadRandom,            sReadRandom;
//    PFUN    pReadPageSeg,           sReadPageSeg;
//    PFUN    pReadSpareSeg,          sReadSpareSeg;
//    PFUN    pReadPipeline,          sReadPipeline;
//    PFUN    pReadPageVar,           sReadPageVar;
//    PFUN    pReadSpareVar,          sReadSpareVar;
//    PFUN    pPageVerify,            sPageVerify;
//    PFUN    pSpareVerify,           sSpareVerify;
//    PFUN    pEraseVerify,           sEraseVerify;
//    PFUN    pProgPage,              sProgPage;
//    PFUN    pProgPageFast,          sProgPageFast;
//    PFUN    pProgRandom,            sProgRandom;
//    PFUN    pProgSpare,             sProgSpare;
//    PFUN    pProgSpareFast,         sProgSpareFast;
//    PFUN    pProgPageVar,           sProgPageVar;
//    PFUN    pProgSpareVar,          sProgSpareVar;
//    PFUN    pProgPageExt,           sProgPageExt;
//    PFUN    pCacheProg,             sCacheProg;
//    PFUN    pCacheProgFast,         sCacheProgFast;
//    PFUN    pCopyPage,              sCopyPage;
//    PFUN    pCopyPageFast,          sCopyPageFast;
//    PFUN    pCopyPageRandom,        sCopyPageRandom;
//    PFUN    pXCopyPage,             sXCopyPage;
//    PFUN    pXPreProg,              sXPreProg;
//    PFUN    pEraseBlock,            sEraseBlock;
//    PFUN    pEraseBlockSuspend,     sEraseBlockSuspend;
//    PFUN    pSetXtremeMode,         sSetXtremeMode;
//    PFUN    pOTPAreaOverlay,        sOTPAreaOverlay;
//    PFUN    pOTPAreaRemove,         sOTPAreaRemove;
//    PFUN    pOTPPageProtStatus,     sOTPPageProtStatus;
//    PFUN    pOTPDfltAsOverlay,      sOTPDfltAsOverlay;
//    PFUN    pOTPDfltAsRemoved,      sOTPDfltAsRemoved;
//    PFUN    pOTPProtectPage,        sOTPProtectPage;
//    PFUN    pGetID,                 sGetID;
//    PFUN    pBlockLock,             sBlockLock;
//    PFUN    pBlockUnlock,           sBlockUnlock;
//    PFUN    pBlockLockdown,         sBlockLockdown;
//    PFUN    pLockStatus,            sLockStatus;
    // Open NAND
//    PFUN    pGetONFIID,             sGetONFIID;
//    PFUN    pGetUniqueID,           sGetUniqueID;
//    PFUN    pOTPUnlock,             sOTPUnlock;
//    PFUN    pOTPExit,               sOTPExit;
    PFUN    pSetWP,                 sSetWP;
//    PFUN    pGetStatusEnhanced,     sGetStatusEnhanced;
//    PFUN    pBlockProtection,       sBlockProtection;
//    PFUN    pOTPProtection,         sOTPProtection;
//    PFUN    pReadParameterPage,     sReadParameterPage;
//    PFUN    pInterleavedPgmPage,                 sInterleavedPgmPage;
//    PFUN    pInterleavedPartialPgmPage,          sInterleavedPartialPgmPage;
//    PFUN    pInterleavedCopyBack,                sInterleavedCopyBack;
//    PFUN    pInterleavedErase,                   sInterleavedErase;
//    PFUN    pMarketInterleavedPgmPage,           sMarketInterleavedPgmPage;
//    PFUN    pMarketInterleavedPartialPgmPage,    sMarketInterleavedPartialPgmPage;
//    PFUN    pMarketInterleavedCopyBack,          sMarketInterleavedCopyBack;
//    PFUN    pMarketInterleavedErase,             sMarketInterleavedErase;
//    PFUN    pGetIDPartial,          sGetIDPartial;
//    PFUN    pUnlockUniqueID,        sUnlockUniqueID;
//    PFUN    pExitUniqueID,          sExitUniqueID;
    // Mircon NAND
//    PFUN    pOTPRead,               sOTPRead;
//    PFUN    pOTPProg,               sOTPProg;
//    PFUN    pGetFeatures,           sGetFeatures;
//    PFUN    pSetFeatures,           sSetFeatures;
//    PFUN    pCacheRead,             sCacheRead;
//    PFUN    pInterleavedReadPage,                 sInterleavedReadPage;
//    PFUN    pInterleavedReadRandom,               sInterleavedReadRandom;
//    PFUN    pInterleavedProgRandom,               sInterleavedProgRandom;
//    PFUN    pInterleavedCacheProg,                sInterleavedCacheProg;
    // both
    PFUN    pCmdResetFlash,         sCmdResetFlash;
    // NOR
    PFUN    pSetReadMode,           sSetReadMode;
    PFUN    pWriteAutoSelectCmd,    sWriteAutoSelectCmd;
    PFUN    pReadAutoSelect,        sReadAutoSelect;
//    PFUN    pGetAutoSelectReg,      sGetAutoSelectReg;
    PFUN    pReadCFI,               sReadCFI;
    // erasure
    PFUN    pEraseSector,           sEraseSector;
//    PFUN    pEraseSectors,          sEraseSectors;
    PFUN    pVerifySectorBlank,     sVerifySectorBlank;
    PFUN    pWaitForSectorErase,    sWaitForSectorErase;
    PFUN    pEraseChip,             sEraseChip;
//    PFUN    pQueueEraseSector,      sQueueEraseSector;
    PFUN    pBlankCheck,            sBlankCheck;
    // async access
    PFUN    pSingleProg,            sSingleProg;
    PFUN    pSingleProgWait,        sSingleProgWait;
//    PFUN    pUnlockBypassProg,      sUnlockBypassProg;
    // buffered access
    PFUN    pBProgAbortReset,       sBProgAbortReset;
    PFUN    pBufferWriteLoad,       sBufferWriteLoad;
    PFUN    pBufferWriteStore,      sBufferWriteStore;
    PFUN    pBufferWriteCommit,     sBufferWriteCommit;
    PFUN    pBufferWrite,           sBufferWrite;
    // suspend/resume
    PFUN    pProgSuspend,           sProgSuspend;
    PFUN    pProgResume,            sProgResume;
    PFUN    pEraseSuspend,          sEraseSuspend;
    PFUN    pEraseResume,           sEraseResume;
    // status
    PFUN    pGetNORStatus,          sGetNORStatus;
    PFUN    pClearNORStatus,        sClearNORStatus;
//    PFUN    pGetNANDStatus,         sGetNANDStatus;
    // special functionality
    PFUN    pGetStatusReg,          sGetStatusReg;
    PFUN    pGetECCStatusReg,       sGetECCStatusReg;
    PFUN    pSetConfigReg,          sSetConfigReg;
    PFUN    pGetConfigReg,          sGetConfigReg;
    PFUN    pReadPassword,          sReadPassword;
    PFUN    pSendPassword,          sSendPassword;
    PFUN    pProgPassword,          sProgPassword;
    PFUN    pReadLockRegister,      sReadLockRegister;
    PFUN    pProgLockRegister,      sProgLockRegister;
    PFUN    pGetASPState,           sGetASPState;
    PFUN    pSetASPState,           sSetASPState;
//    PFUN    pSecSi,                 sSecSi;
//    PFUN    pProgramSecSi,          sProgramSecSi;
//    PFUN    pReadSecSiBits,         sReadSecSiBits;
    PFUN    pSectorLockUnlock,      sSectorLockUnlock;
    PFUN    pSectorLockRange,       sSectorLockRange;
//    PFUN    pBadBlockInfo,          sBadBlockInfo;
    PFUN    pBadSectorInfo,         sBadSectorInfo;
    PFUN    pASPUnlock,             sASPUnlock;
//    PFUN    pGetMBAddress,          sGetMBAddress;
    // QSPI
    PFUN    pReadID,                sReadID;
    PFUN    pEnableQuad,            sEnableQuad;
    PFUN    pDisableQuad,           sDisableQuad;
    PFUN    pEnableParallel,        sEnableParallel;
    PFUN    pDisableParallel,       sDisableParallel;
    PFUN    pSetClock,              sSetClock;
    PFUN    pGetClock,              sGetClock;
    PFUN    pSetVoltage,            sSetVoltage;
    PFUN    pGetVoltage,            sGetVoltage;
    PFUN    pSetBlockProtect,       sSetBlockProtect;
    PFUN    pDisableStatusRegWrite, sDisableStatusRegWrite;
    PFUN    pClearWELBit,           sClearWELBit;
    PFUN    pFreezeBPsTBs,          sFreezeBPsTBs;
    PFUN    pConfigTBParm,          sConfigTBParm;
    PFUN    pConfigBPNV,            sConfigBPNV;
    PFUN    pConfigTBProt,          sConfigTBProt;
    PFUN    pLockBPsCBs,            sLockBPsCBs;
    PFUN    pProgOTP,               sProgOTP;
    PFUN    pReadOTP,               sReadOTP;
    PFUN    pAutoBootRegWrite,      sAutoBootRegWrite;
    PFUN    pAutoBootRegRead,       sAutoBootRegRead;
    PFUN    pAutoBootReadData,      sAutoBootReadData;
    PFUN    pAutoBootUpdateRT,      sAutoBootUpdateRT;
    PFUN    pWriteOpcode,           sWriteOpcode;
    PFUN    pWriteAddr,             sWriteAddr;
    PFUN    pWriteCount,            sWriteCount;
    PFUN    pWriteModeBit,          sWriteModeBit;
    PFUN    pWriteDataBit,          sWriteDataBit;
    PFUN    pReadDataBit,           sReadDataBit;
    PFUN    pEnterDP,               sEnterDP;
    PFUN    pExitDP,                sExitDP;
    PFUN    pEnableHold,            sEnableHold;
    PFUN    pDisableHold,           sDisableHold;
    PFUN    pHold,                  sHold;
    PFUN    pFPGARegRd,             sFPGARegRd;
    PFUN    pFPGARegWr,             sFPGARegWr;
    PFUN    pFPGARamRd,             sFPGARamRd;
    PFUN    pFPGAReset,             sFPGAReset;
    PFUN    pFPGAIdle,              sFPGAIdle;
    PFUN    pSetReadCmdMode,        sSetReadCmdMode;
    PFUN    pSetProgCmdMode,        sSetProgCmdMode;
    PFUN    pSetAddrMode,           sSetAddrMode;
    PFUN    pGetReadCmdMode,        sGetReadCmdMode;
    PFUN    pGetProgCmdMode,        sGetProgCmdMode;
    PFUN    pGetAddrMode,           sGetAddrMode;

    //
    // logger data
    struct  logParms parms;
    DWORD   LogIndent;          // level depth
    DWORD   LogState;           // current logging state
    struct  logEntry logf[LOG_DEFAULT]; // fail-safe log
    //
    // additional storage
    //char    vName[VNAME_MAX + 1];
};

/************ Debug macro definition *****************/
//#define VLLD_DEBUG
#define RPC_DRIVER_DEBUG 		0

#endif // #ifndef __SLTAPI_H
