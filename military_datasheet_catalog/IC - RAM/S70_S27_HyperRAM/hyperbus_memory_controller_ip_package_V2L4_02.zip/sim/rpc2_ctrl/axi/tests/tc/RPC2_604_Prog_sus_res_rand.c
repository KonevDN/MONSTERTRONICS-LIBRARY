#ifdef SIMULATION
#include "sltapi_sim.h"
#include "svdpi.h"
#include "dpiheader.h"
#include <math.h>
#include "rpc2_vlld.h"
#include "rpc2_llops.h"
#else
#include <sltapi.h>
#endif
#include "rpc2.h"
#ifdef NCSC
extern int io_printf(const char *fmt, ...);
#define printf io_printf
#endif

//
//----------------------------------------------------------------------------------
//  Script: Program suspend/resume with fixed suspend latency
//----------------------------------------------------------------------------------
/* Test flow
1.  erase sector 0
2.  buffer write 32 words ("bs") to sector 0 with data pattern 0xAA55 ("dp")
3.  delay 30 usec ("sd")
4.  suspend buffer write
5.  delay 30 usec ("TBD")
6.  read status register, should see 0x84h
7.  resume buffer write
8.  random delay (50 % < 30 usec) ("delay")
9.  repeat step 4 to 8 until buffer write completes
10. repeat step 2 to 9 for the whole sector 0
11. repeat step 1 to 10 for other selected sectors
12. repeat step 1 to 11 for 100 times ("cycle")
*/
char Script[] = "604_Prog_sus_res_rand";

//Command line arguments and their defaults
//DWORD susp_delay    = 17;                       // "sd"
DWORD susp_delay    = 1;                       // "sd"
DWORD delay         = 30;                       // "delay"
DWORD max_delay     = 100;                      // "max"
DWORD bwsize        = 32;                       // "bs"
DWORD data_p        = WORDS_ALT_0X55AA_0XAA55;  // "dp"
DWORD PreRead       = YES;                       // "pr"
//DWORD cycle         = 100;                      // "cycle"
DWORD cycle         = 5;                      // "cycle"
DWORD tPSL          = 30;       //usec
//DWORD tPSL          = 1;       //usec
// undocumented command line arguments and their default values
DWORD help_only = NO;       // display help only (NO), execute test (YES)
DWORD diag = NO;

//Global variables
PDEV pDevice;
PTEST pTest = 1;
STS t0, t1;
char s[81];
WORD * pData = (WORD *)NULL;
DWORD bufSize;
DWORD DISP_DATA_PATTERN = 1;
DWORD max_rand_half;
DWORD delay_diff;

DWORD BufferWriteProgram(PDEV pDevice, DWORD tSector, WORD * pData, DWORD *scount);
DWORD EraseSuspendResume(DWORD vSector, DWORD tSector);
DWORD test_exit(DWORD exit_val);
void help(void);
void linespace(DWORD n);
DWORD GetCommandLineArg(void);
DWORD SCRPPrimBufferWriteTimedSusp(PTEST pT, PDEV pDev, WORD *src, DWORD addr, DWORD count, DWORD wait);
DWORD SCRPPrimBufferWriteResSusp(PTEST pT, PDEV pDev, DWORD addr, DWORD wait);

#ifdef SIMULATION
int c_test()
#else
int main(int argc, char* argv[])
#endif
{
    DWORD tBank, tSector, tSecAddr;
    DWORD errCode, totalSectors, largeSecSize;
    DWORD totalBanks;
    DWORD i, loop;
    DWORD susp_count;

    linespace(2);
    printf("Test: %s\n", Script);

#ifndef SIMULATION
    SKIP = GetGlobalVar("SKIP");
#endif
    if (SKIP)
    {
        line_space(2);
        printf("Test is skipped\n");
        return __LINE__;
    }
#ifndef SIMULATION
    GetArgEnum("help", &help_only, "YES_NO");
#endif
    if (help_only == YES)
    {
        help();
        return 0;
    }
#ifdef SIMULATION
    pDevice = NewDeviceObject(0, RPC);
#endif
    pDevice = Find_Device(RPC);
    if (!pDevice)
    {
        printf("Error: NOR device not found.\n");
        return (__LINE__);
    }

    printf("Device: %s\n", SCRPGetFAPIInfo(pDevice, DEVICE_NAME));
    //SCRPCmdResetFlash(pDevice);
    SYS_GetTimestamp(&t0);

    //SCRPASPUnlock(pDevice);
    errCode = EC_NONE;
    totalBanks = SCRPGetFAPIInfo(pDevice, BANK_COUNT);
    bufSize = SCRPGetFAPIInfo(pDevice, WRITE_BUFFER_SIZE);
    largeSecSize = SCRPGetFAPIInfo(pDevice, LARGEST_SECTOR);
    pData = (WORD *)malloc(sizeof(WORD)*largeSecSize);
    if (!pData)
    {
        printf("Error: malloc()\n");
        return test_exit(__LINE__);
    }

    errCode = GetCommandLineArg();
    if (errCode != EC_NONE)
        return test_exit(__LINE__);

    FillBuffer(data_p, pData, largeSecSize);
    if (DISP_DATA_PATTERN)
    {
        linespace(2);
        printf("Data pattern\n");
        // display first 128 words data pattern
        for (i = 0; i < 128; i++)
        {
            if ((i % 8) == 0)
                printf("\n%04X ", i);
            printf("%04X ", pData[i]);
        }
        printf("\n");
        printf("...\n...\n");

        // display last 128 words data pattern
        for (i = largeSecSize-128; i < largeSecSize; i++)
        {
            if ((i % 8) == 0)
                printf("\n%04X ", i);
            printf("%04X ", pData[i]);
        }
        printf("\n");
        linespace(0);
        //return test_exit(__LINE__);
    }

    max_rand_half = (DWORD) GetRAND_MAX() >> 1;
    delay_diff = max_delay - delay;
    for (loop = 1; loop <= cycle; loop++)
    {
        printf("\nLoop = %d, suspend latency %d uSec\n", loop, delay);

        for (tBank = 0; tBank < totalBanks; tBank++)
        {
            printf("\nBank %d\n", tBank);
            if (SYS_CheckUserBreak())
            {
                linespace(2);
                printf("User break\n");
                return test_exit(0);
            }

            // get the first sector number of a bank
            tSecAddr = SCRPGetFAPIGeometry(pDevice, ADDRESS_OF_BANK, tBank);
            tSector = SCRPGetFAPIGeometry(pDevice, SECTOR_FROM_ADDRESS, tSecAddr);

            totalSectors  = SCRPGetFAPIGeometry(pDevice, SECTOR_COUNT_OF_BANK, tBank);
            // Note: do only first and last sectors in a bank
            for (i = 0; i < totalSectors; i = i + totalSectors - 1)
            {
                tSector += i;
                printf("\nTesting sector %d\n", tSector);
                if (SYS_CheckUserBreak())
                {
                    linespace(2);
                    printf("User break\n");
                    return test_exit(0);
                }
                /*
                if (SCRPGetBadSector(pDevice, tSector))
                {
                    printf("Skip Bad Sector: %d\n", tSector);
                    continue;
                }
                */
                printf("Erasing the sector...");
                #ifndef SIMULATION
                ClearDevLog(pDevice);
                #endif
                errCode = SCRPEraseSector(pDevice, tSector, TRUE);
                if (errCode)
                {
                    printf("\nError: %s\n", GetErrorText(errCode));
                    //DumpLog(pDevice, LOG_DISP_NORM);
                    continue;
                }
                else
                    printf("OK\n");

                printf("Buffer write suspend resume testing...");
                susp_count = 0;
                errCode = BufferWriteProgram(pDevice, tSector, pData, &susp_count);
                if (errCode == EC_USERBREAK)
                {
                    printf("line # %d\n", __LINE__);
                    return test_exit(0);
                }
                if (errCode != EC_NONE)
                {
                    printf("\nError: buffer write suspend count = %d\n", susp_count);
                    return test_exit(__LINE__);
                }
                else
                {
                    printf("OK\n");
                    printf("buffer write suspend count = %d\n", susp_count);
                }
            } // for (i = 0; i < totalSectors; i++)

        } // for (tBank = 0; tBank < totalBanks; tBank++)

    } // for (loop = 1; ; loop++)

    printf("Test complete\n");
#ifndef SIMULATION
    if (TASK_DELAY)
        SYS_OSTickDelay(TASK_DELAY);
#endif
    return test_exit(0);
} // main()


DWORD BufferWriteProgram(PDEV pDevice, DWORD tSector, WORD * pData, DWORD *scount)
{
    DWORD i, j;
    DWORD bw_loop;
    DWORD errCode, status;
    DWORD secAddr, secSize;
    WORD data;
    DWORD rand_delay;

    secAddr = SCRPGetFAPIGeometry(pDevice, ADDRESS_OF_SECTOR, tSector);
    secSize = SCRPGetFAPIGeometry(pDevice, WORD_COUNT_OF_SECTOR, tSector);
    bw_loop = secSize / bwsize;
    for (i = 0; i < bw_loop; i++)
    {
        errCode = SYS_CheckUserBreak();
        if (errCode)
        {
            linespace(2);
            printf("User break\n");
            return errCode;
        }

        if (PreRead == YES)
        {
            //blank check
            for(j = 0; j < bwsize; j++)
            {
                data = SCRPRead(pDevice, secAddr + j);
                if(0xFFFF != data)
                {
                    printf("\nError: write-buffer blank check failed\n");
                    printf("Address 0x%08X, data read 0x%04X\n", secAddr + j, data);
                    return EC_READDATA;
                }
            }
        }
        #ifndef SIMULATION
        if (diag == YES) ClearDevLog(pDevice);
        #endif
        errCode = SCRPPrimBufferWriteTimedSusp(pTest, pDevice, pData, secAddr, bwsize, susp_delay);
        SYS_WaitUSec(tPSL);
        #ifndef SIMULATION
        if (diag == YES)
        {
            linespace(2); 
            DumpLog(pDevice, LOG_DISP_NORM);  
        }
        #endif

        if (errCode != EC_NONE)
        {
            printf("\nError: %s\n", GetErrorText(errCode));
            printf("Address 0x%08X (in Sector %d)\n", secAddr, tSector);
            return errCode;
        }

        do
        {
            rand_delay = rand();
            if (rand_delay > max_rand_half)
                rand_delay = delay + (rand_delay % delay_diff);
            else
                rand_delay = rand_delay % delay;

            *scount = *scount + 1;
            #ifndef SIMULATION
            if (diag == YES) ClearDevLog(pDevice);
            #endif
            errCode = SCRPPrimBufferWriteResSusp(pTest, pDevice, secAddr, rand_delay);
            SYS_WaitUSec(tPSL);
            if (errCode != EC_NONE)
            {
                printf("Error: %s\n", GetErrorText(errCode));
                return errCode;
            }
            SCRPDeviceStatus(pDevice, secAddr, 0, &status);
            #ifndef SIMULATION
            if (diag == YES)
            {
                linespace(2);
                DumpLog(pDevice, LOG_DISP_NORM);
                return EC_USERBREAK;
            }
            #endif
        } while ((status & NOR_DS_PGM_SUSPENDED) == NOR_DS_PGM_SUSPENDED);

        pData += bwsize;
        secAddr += bwsize;
    } // for (i = 0; i < bw_loop; i++)

    return EC_NONE;
} // BufferWriteWordProgram()

void help(void)
{
    linespace(2);
    printf("Command line arguments\n");
    printf("sd: suspend delay time in usec after buffer write command is issued, default %d\n", susp_delay);
    printf("delay: suspend delay time in usec after buffer write resume, default %d\n", delay);
    printf("max: max delay time in usec after buffer write resume, default %d\n", max_delay);
    printf("bs: buffer write word length, default %d\n", bwsize);
    printf("dp: data pattern\n");
    printf("pr: pre-read blank check, default ");
    if (PreRead == YES) printf("YES\n");
    else printf("NO\n");
    printf("cycle: test loop count\n");
    printf("example:\n");
    printf("sd=17 delay=30 max=100 bs=32 dp=WORDS_ALT_0X55AA_0XAA55 pr=NO cycle=100\n");
    linespace(0);
} // help()

void linespace(DWORD n)
{
    DWORD i;

    for (i = 0; i < n; i++)
        printf("\n");
    printf("*******************************************\n");
} // linespace()

DWORD GetCommandLineArg(void)
{
    DWORD errCount = 0;
#ifndef SIMULATION
    GetArg("sd", &susp_delay);
    GetArg("delay", &delay);
    GetArg("max", &max_delay);
    GetArg("bs", &bwsize);
    GetArgEnum("dp", &data_p, "FILL_TYPES");
    GetArgEnum("pr", &PreRead, "YES_NO");
    GetArg("cycle", &cycle);
    GetArgEnum("diag", &diag, "YES_NO");
#endif
    printf("sd = %d usec\n", susp_delay);
    printf("delay = %d usec\n", delay);
    printf("max = %d usec\n", max_delay);
    printf("bs = %d\n", bwsize);
    if (PreRead == YES)
        printf("pr = YES\n");
    else
        printf("pr = NO\n");
    printf("cycle = %d", cycle);

    if (delay > max_delay)
    {
        printf("Error: delay is greater than max.\n");
        errCount++;
    }

    if (bwsize > bufSize)
    {
        printf("Error: buffer size (bs) is larger than %d\n", bufSize);
        errCount++;
    }

    if (errCount)
        return EC_PARAMETER;
    else
        return EC_NONE;
} // GetCommandLineArg()

DWORD test_exit(DWORD exit_val)
{
    if (pData) free(pData);

    linespace(2);
    SYS_GetTimestamp(&t1);
    FormatDeltaTime(s, &t0, &t1);
    printf("Test time: %s\n", s);

    if (exit_val)
    {
        SetGlobalVar("SKIP", 1);
	printf("<TC> Test =========================== Fail\n");
    }
    else {
      printf("<TC> Test =========================== Pass\n");
    }

    return (exit_val);

} // test_exit()

DWORD SCRPPrimBufferWriteTimedSusp(PTEST pT, PDEV pDev, WORD *src, DWORD addr, DWORD count, DWORD wait)
{
    DWORD errCode, status;
    if ((errCode = SCRPBufferWrite(pDev, src, addr, count, FALSE)) != EC_NONE) return errCode;
    SYS_WaitUSec(wait);
    errCode = SCRPDeviceStatus(pDev, addr, 0, &status);
    if ((status & NOR_DS_BUSY) != NOR_DS_BUSY) return errCode;
    errCode = SCRPProgSuspend(pDev, addr, FALSE);
    return errCode;
}

DWORD SCRPPrimBufferWriteResSusp(PTEST pT, PDEV pDev, DWORD addr, DWORD wait)
{
    DWORD errCode, status;
    errCode = SCRPDeviceStatus(pDev, addr, 0, &status);
    if ((status & NOR_DS_PGM_SUSPENDED) != NOR_DS_PGM_SUSPENDED) return errCode;
    if ((errCode = SCRPProgResume(pDev, addr)) != EC_NONE) return errCode;
    SYS_WaitUSec(wait);
    errCode = SCRPDeviceStatus(pDev, addr, 0, &status);
    if ((status & NOR_DS_BUSY) != NOR_DS_BUSY) return errCode;
    errCode = SCRPProgSuspend(pDev, addr, FALSE);
    return errCode;
}
