//===========================================================================
//
///  @file rpc2_vlld.h 
//
//   @Wei Huang (wei.huang@spansion.com)
//   @date: 03/28/2013
//
//============================================================================

#define     AXI4_BURST_LEN      256

#define		reg_tcsr_adr		0x00000000
//#define		reg_mbr_adr		0x00000004
#define		reg_mbr_adr		0x00000010
//#define		reg_rwm_adr		0x00000008
#define		reg_rwm_adr		0x00000030
//#define		reg_wpr_adr		0x0000000C
//#define		reg_wpr_adr		0x00000034
#define		reg_wpr_adr		0x00000044
//#define		reg_ien_adr		0x00000010
#define		reg_ien_adr		0x00000004
//#define		reg_tc_adr		0x00000014
//#define		reg_str_adr		0x00000018
//#define		reg_lbr_adr		0x0000001C
//#define		reg_lbr_adr		0x00000038
#define		reg_lbr_adr		0x00000048

#include "svdpi.h"
#include "dpiheader.h"

void wait100us();

void waitUs(unsigned int num_us);

void writeRegData(unsigned int address, 
		  svBitVecVal* wdata, 
		  unsigned int data_len,
		  svBitVecVal* wrRespOut);

void readRegData(unsigned int address, 
		 svBitVecVal* rdata, 
		 unsigned int data_len,
		 svBitVecVal* rdRespOut);

void writeMemData(unsigned int address, 
		  svBitVecVal* wdata, 
		  unsigned int data_len,
		  svBitVecVal* wrRespOut);

void readMemData(unsigned int address, 
		 svBitVecVal* rdata, 
		 unsigned int data_len,
		 svBitVecVal* rdRespOut);

void writeMemData16(unsigned int address, 
		  svBitVecVal* wdata, 
		  unsigned int data_len,
		  svBitVecVal* wrRespOut);

void writeMemBurstData16 (unsigned int btype,
			  unsigned int address,
			  unsigned short int *wdata,
			  unsigned int dataLen,   // data length in 16-bit
			  unsigned int *wrRespOut);

void readMemData16(unsigned int address, 
		   svBitVecVal* rdata, 
		   unsigned int data_len,
		   svBitVecVal* rdRespOut);

///read memory in 32-bit per transfer
///burst type: INCR
///datalength in 8-bit
void readMemDataNormal8Incr(unsigned int address, 
		      svBitVecVal* rdata, 
		      unsigned int data_len,
		      svBitVecVal* rdRespOut);

///read memory in 16-bit per transfer
///burst type: INCR
///datalength in 8-bit
void readMemDataNarrow8Incr(unsigned int address, 
			    svBitVecVal* rdata, 
			    unsigned int data_len,
			    svBitVecVal* rdRespOut);

void writeMemData16Wrap(unsigned int address, 
			svBitVecVal* wdata, 
			unsigned int data_len,
			svBitVecVal* wrRespOut);

void readMemData16Wrap(unsigned int address, 
		       svBitVecVal* rdata, 
		       unsigned int data_len,
		       svBitVecVal* rdRespOut);

void writeMemData8Wrap(unsigned int address, 
		       svBitVecVal* wdata, 
		       unsigned int data_len,
		       svBitVecVal* wrRespOut);

///read memory in 32-bit per transfer
///burst type: WRAP
///datalength in 8-bit
void readMemDataNormal8Wrap(unsigned int address, 
			    svBitVecVal* rdata, 
			    unsigned int data_len,
			    svBitVecVal* rdRespOut);

///read memory in 16-bit per transfer
///burst type: WRAP
///datalength in 8-bit
void readMemDataNarrow8Wrap(unsigned int address, 
			    svBitVecVal* rdata, 
			    unsigned int data_len,
			    svBitVecVal* rdRespOut);

void wrRPC2_REG(unsigned int addr, unsigned int *val);
void rdRPC2_REG(unsigned int addr, unsigned int *val);
void wrRPC2_MEM(unsigned int addr, unsigned short *val, unsigned int len);
void rdRPC2_MEM(unsigned int addr, unsigned short *val, unsigned int len);
void resetRPCreg(void);
void resetRPCmem(void);
