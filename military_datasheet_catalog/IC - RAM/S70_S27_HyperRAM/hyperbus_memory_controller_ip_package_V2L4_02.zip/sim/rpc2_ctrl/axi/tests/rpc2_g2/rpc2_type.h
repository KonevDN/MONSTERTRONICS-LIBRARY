//===========================================================================
//
//  rpc2_type.h
//
//   @author  Yuichi Ise (yuichi.ise@spansion.com)
//   @version 0.1
//   @since   06/21/2013
//
//===========================================================================
#ifndef __RPC2_TYPE_H__
#define __RPC2_TYPE_H__

//=============================================================================
//  TYPEDEFS
//=============================================================================
typedef unsigned char BYTE;
typedef unsigned short int WORD;
typedef unsigned int DWORD;

#endif //__RPC2_TYPE_H__
