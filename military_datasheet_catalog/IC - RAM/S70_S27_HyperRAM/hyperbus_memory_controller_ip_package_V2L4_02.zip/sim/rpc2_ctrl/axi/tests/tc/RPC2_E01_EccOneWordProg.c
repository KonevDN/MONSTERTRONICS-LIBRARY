#ifdef SIMULATION
#include "sltapi_sim.h"
#include "svdpi.h"
#include "dpiheader.h"
#include <math.h>
#include "rpc2_vlld.h"
#include "rpc2_llops.h"
#else
#include <sltapi.h>
#endif
#include "rpc2.h"
#ifdef NCSC
extern int io_printf(const char *fmt, ...);
#define printf io_printf
#endif

char Script[] = "E01_EccOneWordProg";
char TestTitle[] = "Check ECC status in one word programming";

STS t0, t1;
char s[81];
DWORD ECCUNITSIZE = 16; // bytes, will be moved to global var
PDEV pDevice;

DWORD CheckSectorEccSts(DWORD tSector);
DWORD GetECCStatusReg(PDEV pDevice, DWORD EccUnitAddr, WORD *EccReg);
DWORD CheckUnitEccSts(DWORD UnitNo, DWORD UnitAddr);
void DispEccReg(WORD reg);
DWORD test_exit(DWORD exit_val);

#ifdef SIMULATION
int c_test()
#else
int main(int argc, char* argv[])
#endif
{
    DWORD loop;
    DWORD tSector;
    DWORD errCode;

    printf("Test: %s\n", Script);
    printf("%s\n", TestTitle);
#ifndef SIMULATION
    SKIP = GetGlobalVar("SKIP");
#endif
    if (SKIP)
    {
        line_space(2);
        printf("Test is skipped\n");
        return __LINE__;
    }

#ifdef SIMULATION
    pDevice = NewDeviceObject(0, RPC);
#endif
	pDevice = Find_Device(RPC);

    if (!pDevice)
    {
        line_space(2);
        printf("Error: RPC device not found\n");
        return __LINE__;
    }
    printf("Device: %s\n", (char *) SCRPGetFAPIInfo(pDevice, DEVICE_NAME));

    SYS_GetTimestamp(&t0);
#ifndef SIMULATION
    // ================================
    LOOP_COUNT      = GetGlobalVar("LOOP_COUNT");
    SOE             = GetGlobalVar("SOE");
    BEGINSECTOR     = GetGlobalVar("BEGINSECTOR");
    ENDSECTOR       = GetGlobalVar("ENDSECTOR");
#else
    LOOP_COUNT      = 1;
    SOE             = SOE_SETTING;
    BEGINSECTOR     = 0;
    ENDSECTOR       = 1;
#endif
    for (loop = 1; loop <= LOOP_COUNT; loop++)
    {
        printf("loop = %lu\n", loop);
        for (tSector = BEGINSECTOR; tSector <= ENDSECTOR; tSector++)
        {
            printf("Sector %lu\n", tSector);
            if ((errCode = SYS_CheckUserBreak()))
            {
                return test_exit(0);
            }

            errCode = CheckSectorEccSts(tSector);
            if ((errCode != EC_NONE) && SOE)
            {
                return test_exit(__LINE__);
            }
            else
                printf("Sector %lu ECC test .... PASS\n", tSector);
        } // for (tSector = BEGINSECTOR; tSector <= ENDSECTOR; tSector++)
    } //     for (loop = 1; loop <= LOOP_COUNT; loop++)

    // ================================

    line_space(2);
    printf("Test complete\n");
    return test_exit(0);

} //main

DWORD CheckSectorEccSts(DWORD sector)
{
    DWORD EccUnit, EccUnitAddr;
    DWORD SecAddr;
    DWORD SecSize, EccUnitTot;
    DWORD errCode;

    SecAddr = SCRPGetFAPIGeometry(pDevice, ADDRESS_OF_SECTOR, sector);
    SecSize = SCRPGetFAPIGeometry(pDevice, BYTE_COUNT_OF_SECTOR, sector);
    EccUnitTot = SecSize / ECCUNITSIZE;
    for (EccUnit = 0; EccUnit < EccUnitTot; EccUnit++)
    {
        EccUnitAddr = SecAddr + EccUnit * ECCUNITSIZE;
        errCode = CheckUnitEccSts(EccUnit, EccUnitAddr);
        EccUnit += 100;
        //if ((errCode == EC_35) || (errCode == EC_36))
        //    continue;

        if ((errCode != EC_NONE) && SOE)
            return errCode;
    }

    return EC_NONE;
} // CheckSectorEccSts()

DWORD CheckUnitEccSts(DWORD UnitNo, DWORD UnitAddr)
{
    BYTE data;
    int i;
    DWORD errCode;
    WORD EccReg;
    DWORD addr;

    data = 1;
    addr = UnitAddr;
    errCode = EC_NONE;

    errCode = SCRPBufferWrite(pDevice, &data, addr, 1, TRUE);
    if (errCode != EC_NONE)
    {
        printf("Error: 1-byte page program failed, addr 0x%08lX\n", addr);
        #ifndef SIMULATION
        OutputLog(pDevice, LOG_DISP_NORM, 0, -50);
        #endif
        return errCode;
    }

    GetECCStatusReg(pDevice, UnitAddr, &EccReg);
    if (EccReg & 0x01)   // if ECC is disabled
    {
        printf("Error: ECC should not be disabled (ECC unit %lu, addr 0x%08lX (byte %d)\n", UnitNo, UnitAddr, i);
        printf("ECC status register = 0x%04X\n", EccReg);
        line_space(0);
        DispEccReg(EccReg);
        line_space(0);
        return EC_36;       // EC_36 = ECC is disabled
    }


    for (i = 1; i < 3; i++)
    {
        addr++;
        data++;
        errCode = SCRPBufferWrite(pDevice, &data, addr, 1, TRUE);
        if (errCode != EC_NONE)
        {
            printf("Error: 1-byte page program failed\n");
            #ifndef SIMULATION
            OutputLog(pDevice, LOG_DISP_NORM, 0, -50);
            #endif
            return errCode;
        }

        errCode = GetECCStatusReg(pDevice, UnitAddr, &EccReg);
        if (errCode != EC_NONE)
        {
            #ifndef SIMULATION
            OutputLog(pDevice, LOG_DISP_NORM, 0, -50);
            #endif
            return EC_DEVICEERROR;
        }

        if (!(EccReg & 0x01))   // if ECC is not disabled
        {
            printf("Error: ECC is not disabled (ECC unit %lu, addr 0x%08lX (byte %d)\n", UnitNo, UnitAddr, i);
            printf("ECC status register = 0x%04X\n", EccReg);
            line_space(0);
            DispEccReg(EccReg);
            line_space(0);
            return EC_35;       // EC_35 = ECC is not disabled
        }

    } // for (i = 0; i < ECCUNITSIZE; i++)

    return errCode;
} // CheckUnitEccSts();

DWORD GetECCStatusReg(PDEV pDevice, DWORD EccUnitAddr, WORD *EccReg)
{
    DWORD addr;
    WORD EccStsArray[32];

    addr = EccUnitAddr & ~0x1F;
    SCRPCmd(pDevice, 0x555, 0xAA);
    SCRPCmd(pDevice, 0x2AA, 0x55);
    SCRPCmd(pDevice, 0x555, 0x75);
    SCRPCmd(pDevice, 0x555, 0xAA);
    *EccReg = SCRPRead(pDevice, addr);
    SCRPCmd(pDevice, 0x0, 0xF0);

    return EC_NONE;
} // GetECCStatusReg()

void DispEccReg(WORD reg)
{
    printf("Bit 15-8 (RFU)                         = %04X\n", (reg & 0xFF00));
    printf("Bit 7 (RFU)                            = %d\n", (reg & 0x0080) ? 1 : 0);
    printf("Bit 6 (RFU)                            = %d\n", (reg & 0x0040) ? 1 : 0);
    printf("Bit 5 (RFU)                            = %d\n", (reg & 0x0020) ? 1 : 0);
    printf("Bit 4 (2BD - 2b ECC Detection)         = %d\n", (reg & 0x0010) ? 1 : 0);
    printf("Bit 3 (CB - 1b ECC Correction)         = %d\n", (reg & 0x0008) ? 1 : 0);
    printf("Bit 2 (EECC - Error in ECC)            = %d\n", (reg & 0x0004) ? 1 : 0);
    printf("Bit 1 (EECCD - Error in ECC unit data) = %d\n", (reg & 0x0002) ? 1 : 0);
    printf("Bit 0 (ECCDI - ECC disabled)           = %d\n", (reg & 0x0001) ? 1 : 0);

    printf("\n");
    printf("RFU : reserved for future use\n");
    printf("2BD : 1 = 2b ECC detection occurred since last ECCSR read\n");
    printf("      0 = No 2b ECC detection occurred since last ECCSR read\n");
    printf("CB  : 1 = ECC correction performed since last ECCSR read\n");
    printf("      0 = No ECC correction performed since last ECCSR read\n");
    printf("EECC: 1 = single bit error found in the ECC unit error correct code\n");
    printf("      0 = no error\n");
    printf("EECCD 1 = single bit error corrrected in ECC unit data\n");
    printf("      0 = no error\n");
    printf("ECCDI 1 = ECC is disabled in the selected ECC unit\n");
    printf("      0 = ECC is enabled in the selected ECC unit\n");

} // DispEccReg();

DWORD test_exit(DWORD exit_val)
{

    SYS_GetTimestamp(&t1);
    FormatDeltaTime(s, &t0, &t1);
    printf("Test time: %s\n", s);

    if (exit_val)
    {
        SetGlobalVar("SKIP", 1);
	printf("<TC> Test =========================== Fail\n");
    }
    else {
      printf("<TC> Test =========================== Pass\n");
    }

    return(exit_val);
} // test_exit()


