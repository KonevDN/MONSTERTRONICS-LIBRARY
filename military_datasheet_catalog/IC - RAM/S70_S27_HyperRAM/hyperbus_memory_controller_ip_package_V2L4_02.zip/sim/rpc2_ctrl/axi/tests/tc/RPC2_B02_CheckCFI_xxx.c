#ifdef SIMULATION
#include "sltapi_sim.h"
#include "svdpi.h"
#include "dpiheader.h"
#include <math.h>
#include "rpc2_vlld.h"
#include "rpc2_llops.h"

#else
#include <sltapi.h>
#endif
#include "rpc2.h"

#ifdef NCSC
extern int io_printf(const char *fmt, ...);
#define printf io_printf
#endif
//
//----------------------------------------------------------------------------------
//  Script: Continuous Read Status Register test
//----------------------------------------------------------------------------------
char Script[] = "B02_CheckCFI_xxx";
char TestTitle[] = "Read CFI Data Test";

PDEV pDevice;

WORD CFI[256];

// Global variables
STS t0, t1;
char s[81];
WORD *pDestData = (WORD *)NULL;

// Functions prototyping
DWORD test_exit(DWORD exit_val);
DWORD CheckCFI(WORD *readCFI, WORD *expectCFI);

void SetCorrectCfiData(void)
{
    memset(CFI, 0xFFFF, MAX_CFI);
    CFI[0x00] = 0x0001;   // Manufacturer ID
    CFI[0x01] = 0x007E;   // Device ID byte 1
    CFI[0x0C] = 0x0001;   // Lower Software Bits
    CFI[0x0E] = 0x0070;   // Device ID
    CFI[0x0F] = 0x0000;   // Device ID

    CFI[0x10] = 0x0051;   // "Q"
    CFI[0x11] = 0x0052;   // "R"
    CFI[0x12] = 0x0059;   // "Y"

    CFI[0x13] = 0x0002;   // Primary OEM command set
    CFI[0x14] = 0x0000;   // Primary OEM command set
    CFI[0x15] = 0x0040;   // Address for primary extended table
    CFI[0x16] = 0x0000;   // Address for primary extended table
    CFI[0x17] = 0x0000;   // Alternate OEM command set
    CFI[0x18] = 0x0000;   // Alternate OEM command set
    CFI[0x19] = 0x0000;   // Address for alternate OEM extended table
    CFI[0x1A] = 0x0000;   // Address for alternate OEM extended table

    CFI[0x1B] = 0x0027;   // Vcc Min
    CFI[0x1C] = 0x0036;   // Vcc Max
    CFI[0x1D] = 0x0000;   // Vpp Min
    CFI[0x1E] = 0x0000;   // Vpp Max
    CFI[0x1F] = 0x0006;   // Typical timeout per single byte program
    CFI[0x20] = 0x0008;   // Typical timeout for min. size page program
    CFI[0x21] = 0x0008;   // Typical timeout per individual sector erase
    CFI[0x22] = 0x0013;   // Typical timeout for full chip erase
    CFI[0x23] = 0x0002;   // Max timeout for byte program
    CFI[0x24] = 0x0002;   // Max timeout for page program
    CFI[0x25] = 0x0002;   // Max timeout per individual sector erase
    CFI[0x26] = 0x0002;   // Max timeout for full chip erase

    CFI[0x27] = 0x001C;   // Device size

    CFI[0x28] = 0x0001;   // Flash device interface description
    CFI[0x29] = 0x0000;   //

    CFI[0x2A] = 0x0009;   // Max number of byte in multi-byte write
    CFI[0x2B] = 0x0000;   //

    CFI[0x2C] = 0x0001;   // Number of erase block regions

    CFI[0x2D] = 0x00FF;   // Erase block region 1 information
    CFI[0x2E] = 0x0007;   //
    CFI[0x2F] = 0x0000;   //
    CFI[0x30] = 0x0002;   //

    CFI[0x31] = 0x0000;   // Erase block region 2 information
    CFI[0x32] = 0x0000;   //
    CFI[0x33] = 0x0000;   //
    CFI[0x34] = 0x0000;   //

    CFI[0x35] = 0x0000;   // Erase block region 3 information
    CFI[0x36] = 0x0000;   //
    CFI[0x37] = 0x0000;   //
    CFI[0x38] = 0x0000;   //

    CFI[0x39] = 0x0000;   // Erase block region 4 information
    CFI[0x3A] = 0x0000;   //
    CFI[0x3B] = 0x0000;   //
    CFI[0x3C] = 0x0000;   //

    CFI[0x40] = 0x0050;   // "P"
    CFI[0x41] = 0x0052;   // "R"
    CFI[0x42] = 0x0049;   // "I"

    CFI[0x43] = 0x0031;   // Major version number
    CFI[0x44] = 0x0033;   // Minor version number

    CFI[0x45] = 0x001C;   // Address sensitive unlock and process technology
    CFI[0x46] = 0x0002;   // Support for erase suspend
    CFI[0x47] = 0x0001;   // Sector protect
    CFI[0x48] = 0x0000;   // Temporary sector unprotect

    CFI[0x49] = 0x0008;   // Sector protect/unprotect scheme
    CFI[0x4A] = 0x0000;   // Simultaneous operation
    CFI[0x4B] = 0x0000;   // Burst mode
    CFI[0x4C] = 0x0003;   // Page mode type

    CFI[0x4D] = 0x0000;   // ACC supply min.
    CFI[0x4E] = 0x0000;   // ACC supply max.
    CFI[0x4F] = 0x0007;   // WP# protection
    CFI[0x50] = 0x0001;   // Program suspend

    CFI[0x51] = 0x0000;   // Unlock Bypass
    CFI[0x52] = 0x000A;   // SecSi Sector
    CFI[0x53] = 0x0007;   // Software Features
    CFI[0x54] = 0x0005;   // Page Size
    CFI[0x55] = 0x0006;   // Erase Suspen Timeout Maximum
    CFI[0x56] = 0x0006;   // Program Suspen Timeout Maximum

    CFI[0x78] = 0x0005;   // Embedded Hardware Reset Timeout Maximum
    CFI[0x79] = 0x0009;   // Embedded Hardware Reset Maximum
}

//----------------------------------------------------------------------------------
//RPC2 Flash Test script begin
//----------------------------------------------------------------------------------
#ifdef SIMULATION
int c_test()
#else
int main(int argc, char* argv[])
#endif
{
    
    DWORD nMhz;
    DWORD i;
    WORD *WORDCFI;

    line_space(2);
    printf("Test: %s\n", Script);
    printf("%s\n", TestTitle);
    
#ifndef SIMULATION
	SKIP = GetGlobalVar("SKIP");
#endif

	if (SKIP)
	{
		line_space(2);
		printf("Test is skipped\n");
		return __LINE__;
	}
    
#ifdef SIMULATION

   pDevice = NewDeviceObject(0, RPC);
#endif
    
    pDevice = Find_Device(RPC);
    if (!pDevice)
    {
        line_space(2);
        printf("Error: RPC device not found\n");
        return __LINE__;
    }
    
    #ifndef SIMULATION
    SYS_GetTimestamp(&t0);
    #endif
    
    pDestData = (WORD *) malloc(MAX_CFI * sizeof(WORD));
    if (!pDestData)
    {
        line_space(2);
        printf("Error: malloc()!\n");
        return test_exit(__LINE__);
    }

    SetCorrectCfiData();
    memset(pDestData, 0xFF, MAX_CFI * sizeof(WORD));
    SCRPCFIRead(pDevice, 0, pDestData);
    for (i = 0; i < MAX_CFI; i++)
    {
        printf("%3X: %04X\n", i, pDestData[i]);
    }

    if(EC_NONE!=CheckCFI(pDestData, CFI))
        return test_exit(__LINE__);

    line_space(2);
    printf("Test complete\n");

    #ifndef SIMULATION
    if (TASK_DELAY)
        SYS_OSTickDelay(TASK_DELAY);
    #endif
    
    return test_exit(0);
} // main()

DWORD test_exit(DWORD exit_val)
{
    if (pDestData) free(pDestData);

    SYS_GetTimestamp(&t1);
    FormatDeltaTime(s, &t0, &t1);
    printf("Test time: %s\n", s);

	if (exit_val)
	{
		SetGlobalVar("SKIP", 1);
	printf("<TC> Test =========================== Fail\n");
    }
    else {
      printf("<TC> Test =========================== Pass\n");
    }
    return exit_val;
} // test_exit()

DWORD CheckCFI(WORD *readCFI, WORD *expectCFI)
{
    DWORD i;

    i = 0;
    printf("Manufacturer ID (%02X)                        = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Device ID (%02X)                              = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i=0xC;
    printf("Lower Software Bits (%02X)                    = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i = 0xE;
    printf("Extended Device ID (%02X)                     = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Extended Device ID (%02X)                     = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

/*
    i = 0x10;
    printf("Q (%02X)                                      = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("R (%02X)                                      = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Y (%02X)                                      = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Primary OEM command set (%02X)                = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Primary OEM command set (%02X)                = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Addr for primary extended table (%02X)        = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Addr for primary extended table (%02X)        = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Alternate OEM command set (%02X)              = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Alternate OEM command set (%02X)              = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Addr for alternate OEM extended table (%02X)  = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Addr for alternate OEM extended table (%02X)  = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i = 0x1B;
    printf("Vcc Min (%02X)                                = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Vcc Max (%02X)                                = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Vpp Min (%02X)                                = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Vpp Max (%02X)                                = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Typ timeout per single byte program (%02X)    = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Typ timeout for min. size page program (%02X) = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Typ timeout per sector erase (%02X)           = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Typical timeout for full chip erase (%02X)    = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Max timeout for byte program (%02X)           = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Max timeout for page program (%02X)           = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Max timeout per sector erase (%02X)           = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Max timeout for full chip erase (%02X)        = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Device size (%02X)                            = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Flash device interface description (%02X)     = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Flash device interface description (%02X)     = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Max number of byte in multi-byte write (%02X) = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Max number of byte in multi-byte write (%02X) = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Number of erase block regions (%02X)          = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Number of erase block regions (%02X)          = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Erase block region 1 information (%02X)       = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Erase block region 1 information (%02X)       = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Erase block region 1 information (%02X)       = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Erase block region 1 information (%02X)       = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Erase block region 2 information (%02X)       = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Erase block region 2 information (%02X)       = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Erase block region 2 information (%02X)       = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Erase block region 2 information (%02X)       = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i = 0x40;
    printf("P (%02X)                                      = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("R (%02X)                                      = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("I (%02X)                                      = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Major version number (%02X)                   = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Minor version number (%02X)                   = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Addr sensitive unlock and process tech (%02X) = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Support for erase suspend (%02X)              = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Sector protect (%02X)                         = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Temporary sector unprotect (%02X)             = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Sector protect/unprotect scheme (%02X)        = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Simultaneous operation (%02X)                 = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Burst mode (%02X)                             = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Page mode type (%02X)                         = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("ACC supply min. (%02X)                        = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("ACC supply max. (%02X)                        = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("WP# protection (%02X)                         = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Program suspend (%02X)                        = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Unlock Bypass (%02X)                          = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("SecSi Sector (%02X)                           = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Software Features (%02X)                      = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Page Size (%02X)                              = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Erase Suspend Timeout Maximum (%02X)          = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Program Suspend Timeout Maximum(%02X)         = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i=0x78;
    printf("Embedded Hardware Reset Timeout Maximum (%02X) = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");

    i++;
    printf("Non-Embedded Hardware Reset Timeout Maximum(%02X) = %04X ........", i, readCFI[i]);
    if (readCFI[i] != expectCFI[i])
        printf("Error: expect %04X\n", expectCFI[i]);
    else
        printf("OK\n");*/

    if(i==0x0F) 
        return EC_NONE;
    else
        return EC_CFIMATCH;
} // CheckCFI()
