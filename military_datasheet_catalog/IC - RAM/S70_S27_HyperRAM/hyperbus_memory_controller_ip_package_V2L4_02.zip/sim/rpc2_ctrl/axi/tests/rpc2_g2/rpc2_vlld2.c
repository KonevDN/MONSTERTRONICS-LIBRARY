//===========================================================================
//
///  rpc2_vlld2.c
//
//   @author  Yuichi Ise (yuichi.ise@spansion.com)
//   @version 0.1
//   @since   08/07/2013
//
//===========================================================================
#include "dpiheader.h"

#ifndef MAX_LEN
#define MAX_LEN  256
#endif

//===================================
// FUNCTIONS
//===================================
void waitUs(unsigned int num_us)
{
  DPI_waitUs(num_us);
}

///////////////////////////
//
void writeData(unsigned int address,
	       unsigned int dataLen8,
	       unsigned int burst,
	       unsigned int size,
	       unsigned char* wrData8,
	       unsigned int* wrResp)
{
  int i;
  unsigned int len;
  unsigned int addr;
  unsigned int burstLen;
  unsigned int xferSize;
  unsigned int inPtr;
  unsigned char response;

  xferSize = 1 << size;
  burstLen = ((address%xferSize)+dataLen8+(xferSize-1))/xferSize;

  while (burstLen != 0) {
    inPtr = 0;
    addr = address;
    if (burstLen > MAX_LEN) {
      len = MAX_LEN;
    }
    else {
      len = burstLen;
    }
    for (i = addr%xferSize; i < (len*xferSize); i++) {
      if (dataLen8 == 0) {
	break;
      }
      DPI_inputData(inPtr++, *wrData8++);
      address++;
      dataLen8--;
    }
    DPI_writeBurst(addr, len-1, burst, size);
    DPI_getWriteResp(&response);
    *wrResp |= response;
    burstLen -= len;
  }
}

void readData(unsigned int address,
	      unsigned int dataLen8,
	      unsigned int burst,
	      unsigned int size,
	      unsigned char* rdData8, 
	      unsigned int* rdResp)
{
  int i;
  unsigned int len;
  unsigned int addr;
  unsigned int burstLen;
  unsigned int xferSize;
  unsigned int outPtr;
  unsigned char response;

  xferSize = 1 << size;
  burstLen = ((address%xferSize)+dataLen8+(xferSize-1))/xferSize;

  while (burstLen != 0) {
    outPtr = 0;
    addr = address;
    if (burstLen > MAX_LEN) {
      len = MAX_LEN;
    }
    else {
      len = burstLen;
    }
    DPI_readBurst(addr, len-1, burst, size);
    DPI_getReadData();
    for (i = addr%xferSize; i < (len*xferSize); i++) {
      if (dataLen8 == 0) {
	break;
      }
      DPI_outputData(outPtr++, rdData8++);
      address++;
      dataLen8--;
    }
    for (i = 0; i < len; i++) {
      DPI_outputRdResp(i, &response);
      *rdResp |= response;
    }
    burstLen -= len;
  }
}

//////////////////////////////////////
//
void wrRPC2_REG(unsigned int addr, unsigned int *val)
{
  unsigned int wrRespOut = 0;
  unsigned char* wdata8 = (unsigned char*)val;

  DPI_selectTarget(1);
  writeData(addr, 4, 0, 2, wdata8, &wrRespOut);
}

void rdRPC2_REG(unsigned int addr, unsigned int *val)
{
  unsigned int rdRespOut = 0;
  unsigned char* rdata8 = (unsigned char*)val;

  DPI_selectTarget(1);
  readData(addr, 4, 0, 2, rdata8, &rdRespOut);
}

void wrRPC2_MEM(unsigned int addr, unsigned short *val, unsigned int len)
{
#ifndef RPC2_BURSTWRITE
  int i;
#endif
  unsigned int address;
  unsigned int wrRespOut = 0;
  unsigned char* wdata8 = (unsigned char*)val;

  address = addr << 1;
  DPI_selectTarget(0);
#ifndef RPC2_BURSTWRITE
  for (i = 0; i < len; i++) {
    writeData(address+i*2, 2, 1, 1, &wdata8[i*2], &wrRespOut);
  }
#else
  writeData(address, 2*len, 1, 1, &wdata8[0], &wrRespOut);
#endif
}

void rdRPC2_MEM(unsigned int addr, unsigned short *val, unsigned int len)
{
  unsigned int address;
  unsigned int rdRespOut = 0;
  unsigned char* rdata8 = (unsigned char*)val;

  address = addr << 1;
  DPI_selectTarget(0);
  readData(address, len*2, 1, 1, rdata8, &rdRespOut);
}

void resetRPCreg()
{
  DPI_resetReg();
}

void resetRPCmem()
{
  DPI_resetMem();
}
