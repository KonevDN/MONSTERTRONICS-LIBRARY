#ifdef SIMULATION
#include "sltapi_sim.h"
#include "svdpi.h"
#include "dpiheader.h"
#include <math.h>
#include "rpc2_vlld.h"
#include "rpc2_llops.h"
#else
#include <sltapi.h>
#endif
#include "rpc2.h"
#ifdef NCSC
extern int io_printf(const char *fmt, ...);
#define printf io_printf
#endif

char Script[] = "C01_ReadOtp 1";
char TestTitle[] = "dump contents of OTP";

PDEV pDevice;
BYTE *pDestData = (BYTE *)NULL;
STS t0, t1;
char s[81];

void Disp_Reg0(struct OTP_REG0 * reg);
void print_buf(DWORD base, BYTE * buff, DWORD count);
DWORD test_exit(DWORD exit_val);

#ifdef SIMULATION
int c_test()
#else
int main(int argc, char* argv[])
#endif
{

    struct OTP_REG0 * reg0;
    int i, baseaddr;
    unsigned long otp_lock;

    printf("Test: %s\n", Script);
    printf("%s\n", TestTitle);
#ifndef SIMULATION
    LOOP_COUNT      = GetGlobalVar("LOOP_COUNT");
    SOE             = GetGlobalVar("SOE");
    SKIP            = GetGlobalVar("SKIP");
    TOTALSECTORS    = GetGlobalVar("TOTALSECTORS");
    BUFSIZE         = GetGlobalVar("BUFSIZE"); 
    LARGESECSIZE    = GetGlobalVar("LARGESECSIZE"); 
#else
    LOOP_COUNT      = 1;
    SOE             = SOE_SETTING;
    SKIP            = 0;
    TOTALSECTORS    = 2;
    BUFSIZE         = 256; 
    LARGESECSIZE    = 256; 
#endif
    if (SKIP)
    {
        line_space(2);
        printf("Test is skipped\n");
        return __LINE__;
    }

#ifdef SIMULATION
    pDevice = NewDeviceObject(0, RPC);
#endif
	pDevice = Find_Device(RPC);

    if (!pDevice)
    {
        line_space(2);
        printf("Error: RPC device not found\n");
        return __LINE__;
    }
    printf("Device: %s\n", (char *) SCRPGetFAPIInfo(pDevice, DEVICE_NAME));

    SYS_GetTimestamp(&t0);
    pDestData = (BYTE *) malloc(OTP_SIZE);
    if (!pDestData)
    {
        printf("Error: Malloc error\n");
        return test_exit(__LINE__);
    }

    SCRPQSPIReadOTP(pDevice, (WORD *) pDestData, 0, OTP_SIZE);

    reg0 = (struct OTP_REG0 *)pDestData;
    Disp_Reg0(reg0);

    // display rest of the regions
    otp_lock = * (unsigned long *) reg0->otp_reglock;
    for (i = 1; i < OTP_REG_CNT; i++)
    {
        line_space(2);
        //printf("REGION %d\n", i);
        printf("REGION %2d..... %s\n", i, (otp_lock & (1 << i)) ? "not locked" : "locked");
        baseaddr = OTP_REG_SIZE * i;
        print_buf(baseaddr , pDestData + baseaddr, OTP_REG_SIZE);
    }

    line_space(2);
    printf("Test complete\n");
#ifndef SIMULATION
    if (TASK_DELAY)
        SYS_OSTickDelay(TASK_DELAY);
#endif
    return test_exit(0);
} // main()

void Disp_Reg0(struct OTP_REG0 * reg)
{
    int i;
    unsigned long * region_lock;

    line_space(2);
    printf("REGION 0\n");

    printf("(1) Spansion progammable area (16 bytes)\n");
    print_buf(0, reg->otp_matecode, 16);

    region_lock = (unsigned long *)reg->otp_reglock;
    printf("\n(2) Region lock status = 0x%08X\n", (unsigned int)*region_lock);
    for (i = 0; i < OTP_REG_CNT; i++)
    {
          printf("REGION %2d..... %s\n", i, (*region_lock & (1 << i)) ? "not locked" : "locked");
    }

    printf("\n(3) reserved area (12 bytes)\n");
    print_buf(20, reg->otp_rsv, 12);

    return;

}

void print_buf(DWORD base, BYTE * buff, DWORD count)
{
    unsigned int i;

    for (i = 0; i < count; i++)
    {
        if ((i % 8) == 0)
        {
            printf("\n0x%08X ", (unsigned int)(i + base));
            #ifndef SIMULATION
            SYS_WaitUSec(1000);
            #endif
        }
        printf("%02X ", buff[i]);
    }
    printf("\n");
} // printf_buf()

DWORD test_exit(DWORD exit_val)
{

    if (pDestData)
        free(pDestData);

    SYS_GetTimestamp(&t1);
    FormatDeltaTime(s, &t0, &t1);
    printf("Test time: %s\n", s);

    if (exit_val)
    {
        SetGlobalVar("SKIP", 1);
	printf("<TC> Test =========================== Fail\n");
    }
    else {
      printf("<TC> Test =========================== Pass\n");
    }

    return(exit_val);
} // test_exit()


