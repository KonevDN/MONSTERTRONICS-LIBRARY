/*******************************************************************************
 *
 *  Filename:       rpc2_llops.c
 *
 *                  implement APIs of rpc driver 
 *
 *  Created:        Wei Huang (3/15/2012)
 *
 *  Modified:       $Author:
 *
 *******************************************************************************
 *  Copyright (C) 2012, Spansion Inc. All Rights Reserved.
 ******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#ifdef SIMULATION
#include "sltapi_sim.h"
#include "rpc2_llops.h"
#include "rpc2_vlld.h"
#else
#include "slttypes.h"
#include "slterr.h"
#include "sltfapi.h"
#include "sltapi.h"
#include "sysio.h"
#include "rpc2_llops.h"
#endif

// ***************************************************************************
//  Macro
// ***************************************************************************
#define PRINT_INTERVAL	1000
#define LLOPS_PRINT(fmt, args ...) {printf("<LLOPS>"); printf("          "); printf(fmt, ## args);}

// ***************************************************************************
//  Global RPC controller mode Variables
// ***************************************************************************
//extern int direct_mode;
//extern int slt_mode;
//extern int loopbk_mode;
//extern int burst_mode;
extern PDEV pDevice;
extern DWORD rpc_reg_baseaddr;

/*******************************************************************************
 * module varibles
 ******************************************************************************/
unsigned int m_freq_mhz = 66;
rpc_ctrl_reg_t rpc_ctrl;
rpc_ctrl_reg_t *pRPC_CTRL;

DWORD rpc_llops_Timeout = 50 * 1000; //50ms
 #if 0
#ifndef SIMULATION
extern DWORD SYS_FastReadNOR(WORD*, WORD*, DWORD);
/*************************************************************
 * memory opertaion
 *
 *************************************************************/

 void gpmc_write16(DWORD address, WORD data)
{
    *((volatile unsigned short *)address) = data;
}

void gpmc_read16(DWORD address, WORD* data)
{
    *data = *((volatile unsigned short *)address);
}

BOOL GPMC_Write(DWORD address, WORD* pData, DWORD write_count)
{
    int i;
    DWORD write_address = address;
    WORD* pSrc_data = pData;
    
    for(i=0;i<write_count;i++, pSrc_data++, write_address+=2)
    {
        //gpmc_write16(write_address, *pSrc_data);
    }

    return TRUE;
}

void gpmc_write_reg(DWORD addr, WORD val)
{
    //gpmc_write16(rpc_reg_baseaddr | addr, val);
}
void gpmc_read_reg(DWORD addr, WORD *val)
{
    //gpmc_read16(rpc_reg_baseaddr | addr, val);
}

BOOL GPMC_Read(DWORD address, WORD* pData, DWORD read_count)
{
    DWORD count = read_count;

    // check dword alignment
    if ((DWORD)pData & 0x3) {
        //gpmc_read16(address, pData);
        count--;
        if (count != 0)
            SYS_FastReadNOR(pData+1,(WORD *)(address+2),count);
    } else {        
        SYS_FastReadNOR(pData, (WORD *)address, read_count);
    }
    return TRUE;
}
#else
void gpmc_write_reg(DWORD addr, WORD val)
{
	//GPMC_Write(rpc_reg_baseaddr | addr, &val,1);
}

void gpmc_read_reg(DWORD addr, WORD *val)
{
    //GPMC_Read(rpc_reg_baseaddr | addr, val,1);
}
BOOL GPMC_Read(DWORD address, WORD* pData, DWORD read_count)
{


    return TRUE;
}
BOOL GPMC_Write(DWORD address, WORD* pData, DWORD write_count)
{


    return TRUE;
}    
#endif
#endif
/*******************************************************************************
 * APIs - flash command
 ******************************************************************************/
#if 0
BOOL rpc_get_flash_info(fdev_info_t *pFDevIF)
{
	pFDevIF->rd_addr_algn = 16;

	pFDevIF->sz_page = 1<<9;
	pFDevIF->nr_page = 1<<9;
	pFDevIF->sz_sec  = pFDevIF->sz_page * pFDevIF->nr_page;
	pFDevIF->nr_sec  = 128;

	pFDevIF->total_size = pFDevIF->sz_sec * pFDevIF->nr_sec;

	pFDevIF->tmout_wrr_us   = 10*1875*1000;
	pFDevIF->tmout_wrcfg_us = 10*1875*1000;
	pFDevIF->tmout_pp_us    = 10*750;
	pFDevIF->tmout_se_ms    = 10*1875;
	pFDevIF->tmout_be_ms    = 10*330*1000;
	return TRUE;
}

void RPC_write_DPRam(DWORD addr, WORD data)
{
    //gpmc_write16((rpc_reg_baseaddr | WRDPRAM_BASE_ADDR | (addr<<1)), &data);
    //GPMC_Write((rpc_reg_baseaddr | WRDPRAM_BASE_ADDR | (addr<<1)), &data, 1);
}
#endif
void HIAR_process(DWORD *address)
{
    DWORD fl_address = (*address)<<1;
    DWORD mem_base_addr_reg;
    if(fl_address > 0x00FFFFFF) {
        #if RPC_DRIVER_DEBUG
        printf("Original addr: %08x, ", fl_address);
        #endif
        mem_base_addr_reg = fl_address & 0xFF000000;
        wrRPC2_REG(reg_mbr_adr,&mem_base_addr_reg);
        fl_address &= 0x00FFFFFF;
        #if RPC_DRIVER_DEBUG
        printf("Processed addr: %08x\n", fl_address);
        #endif
        }
    else wrRPC2_REG(reg_mbr_adr,&fl_address);
    *address = fl_address>>1;
}

BOOL RPC_Read_Data(DWORD read_address, DWORD read_length, WORD* pData)
{
	BOOL ret = TRUE;

	//WORD pBuf;

	rdRPC2_MEM(read_address, pData, read_length);

	return ret;	
}

BOOL RPC_Read_Reg(DWORD reg_type, WORD* pReg)
{
	BOOL ret = TRUE;
	DWORD rpc_addr;
	WORD rpc_data;
	DWORD polling_nr;
	
	#ifndef SIMULATION
	DWORD timeout = rpc_llops_Timeout;
    DWORD cpuStat;
	cpuStat = SYS_EnterCritical();

    if (timeout) SYS_StartTimeout(timeout);
	#endif
	
	WORD nReg[256];

	polling_nr = 0;
	
	
	switch(reg_type) {
		case RPC_RD_SR: {
            // 3 --- Write RPC_RD_SR to 555
            rpc_addr = 0x555;
            rpc_data = RPC_RD_SR;
            wrRPC2_MEM(rpc_addr, &rpc_data, 1);
            
            rpc_addr = 0;
            rdRPC2_MEM(rpc_addr, &nReg[0], 1);
			*pReg = nReg[0];
			break;
		}
		case RPC_RD_VCR: {
	        // 1 --- Write AA to 555
            rpc_addr = 0x555;
            rpc_data = 0xAA;
            wrRPC2_MEM(rpc_addr, &rpc_data, 1);
            // 2 --- Write 55 to 2AA
            rpc_addr = 0x2AA;
            rpc_data = 0x55;
            wrRPC2_MEM(rpc_addr, &rpc_data, 1);
            // 3 --- Write RPC_RD_VCR to 555
            rpc_addr = 0x555;
            rpc_data = RPC_RD_VCR;
            wrRPC2_MEM(rpc_addr, &rpc_data, 1);
            // 4 --- Read VCR
            rdRPC2_MEM(rpc_addr, &nReg[0], 1);
			*pReg = nReg[0];
			break;
		}
		case RPC_RD_NVCR: {
            // 1 --- Write AA to 555
            rpc_addr = 0x555;
            rpc_data = 0xAA;
            wrRPC2_MEM(rpc_addr, &rpc_data, 1);
            // 2 --- Write 55 to 2AA
            rpc_addr = 0x2AA;
            rpc_data = 0x55;
            wrRPC2_MEM(rpc_addr, &rpc_data, 1);
            // 3 --- Write RPC_RD_NVCR to 555
            rpc_addr = 0x555;
            rpc_data = RPC_RD_NVCR;
            wrRPC2_MEM(rpc_addr, &rpc_data, 1);
            // 4 --- Read VCR
            rdRPC2_MEM(rpc_addr, &nReg[0], 1);
			*pReg = nReg[0];
			break;
		}
        case RPC_RD_PORTR: {
            // 1 --- Write AA to 555
            rpc_addr = 0x555;
            rpc_data = 0xAA;
            wrRPC2_MEM(rpc_addr, &rpc_data, 1);
            // 2 --- Write 55 to 2AA
            rpc_addr = 0x2AA;
            rpc_data = 0x55;
            wrRPC2_MEM(rpc_addr, &rpc_data, 1);
            // 3 --- Write RPC_RD_PORTR to 555
            rpc_addr = 0x555;
            rpc_data = RPC_RD_PORTR;
            wrRPC2_MEM(rpc_addr, &rpc_data, 1);
            // 4 --- Read PORTR
            rdRPC2_MEM(rpc_addr, &nReg[0], 1);
			*pReg = nReg[0];
			break;
		}
        case RPC_RD_ICR: {
            // 1 --- Write AA to 555
            rpc_addr = 0x555;
            rpc_data = 0xAA;
            wrRPC2_MEM(rpc_addr, &rpc_data, 1);
            // 2 --- Write 55 to 2AA
            rpc_addr = 0x2AA;
            rpc_data = 0x55;
            wrRPC2_MEM(rpc_addr, &rpc_data, 1);
            // 3 --- Write RPC_RD_ICR to 555
            rpc_addr = 0x555;
            rpc_data = RPC_RD_ICR;
            wrRPC2_MEM(rpc_addr, &rpc_data, 1);
            // 4 --- Read ICR
            rdRPC2_MEM(rpc_addr, &nReg[0], 1);
			*pReg = nReg[0];
			break;
		}
        case RPC_RD_ISR: {
            // 1 --- Write AA to 555
            rpc_addr = 0x555;
            rpc_data = 0xAA;
            wrRPC2_MEM(rpc_addr, &rpc_data, 1);
            // 2 --- Write 55 to 2AA
            rpc_addr = 0x2AA;
            rpc_data = 0x55;
            wrRPC2_MEM(rpc_addr, &rpc_data, 1);
            // 3 --- Write RPC_RD_ISR to 555
            rpc_addr = 0x555;
            rpc_data = RPC_RD_ISR;
            wrRPC2_MEM(rpc_addr, &rpc_data, 1);
            // 4 --- Read ISR
            rdRPC2_MEM(rpc_addr, &nReg[0], 1);
			*pReg = nReg[0];
			break;
		}
		default:{ret = FALSE; break;}
	}
	#ifndef SIMULATION
	SYS_ExitCritical(cpuStat);
	#endif
	return ret;
}

BOOL RPC_Prog_Reg(DWORD reg_type, WORD* pReg)
{
	BOOL ret = TRUE;
    rpc_sr_t rpc_sr;
	DWORD rpc_addr;
	WORD rpc_data;
	DWORD polling_nr = 0;
	WORD nReg[256];

	nReg[0] = *pReg;

	#ifndef SIMULATION
	//DWORD timeout = rpc_llops_Timeout;
	DWORD timeout = pDevice->ProgWordTimeout;
    DWORD cpuStat;
	cpuStat = SYS_EnterCritical();

    if (timeout) SYS_StartTimeout(timeout);
	#endif
	
	switch(reg_type) {
        case RPC_LD_VCR:
        case RPC_LD_ICR:
        case RPC_LD_ISR: {
          	// 1 --- Write AA to 555
            rpc_addr = 0x555;
            rpc_data = 0xAA;
            wrRPC2_MEM(rpc_addr, &rpc_data, 1);
            // 2 --- Write 55 to 2AA
            rpc_addr = 0x2AA;
            rpc_data = 0x55;
            wrRPC2_MEM(rpc_addr, &rpc_data, 1);
            // 3 --- Write RPC_LD_VCR,ICR,ISR to 555
            rpc_addr = 0x555;
            rpc_data = reg_type;
            wrRPC2_MEM(rpc_addr, &rpc_data, 1);
            // 4 --- Write data to VCR,ICR,ISR
            rpc_addr = 0;
            rpc_data = nReg[0];
            wrRPC2_MEM(rpc_addr, &rpc_data, 1);
			
			break;
		}
        case RPC_PROG_NVCR:
		case RPC_PROG_PORTR: {
            // 1 --- Write AA to 555
            rpc_addr = 0x555;
            rpc_data = 0xAA;
            wrRPC2_MEM(rpc_addr, &rpc_data, 1);
            // 2 --- Write 55 to 2AA
            rpc_addr = 0x2AA;
            rpc_data = 0x55;
            wrRPC2_MEM(rpc_addr, &rpc_data, 1);
            // 3 --- Write RPC_PROG_NVCR,PORTR to 555
            rpc_addr = 0x555;
            rpc_data = reg_type;
            wrRPC2_MEM(rpc_addr, &rpc_data, 1);
            // 4 --- Write data to NVCR,PORTR
            rpc_addr = 0;
            rpc_data = nReg[0];
            wrRPC2_MEM(rpc_addr, &rpc_data, 1);

            polling_nr = 0;
	        //Polling status until prog done
	        #if RPC_DRIVER_DEBUG
	        LLOPS_PRINT("Send prog reg cmd complete.\n");
	        LLOPS_PRINT("Polling for DRB = 1, PSB = 0\n");	
	        #endif
	        while(1)
	        {
		        rpc_addr = 0x00000555;
		        rpc_data = RPC_RD_SR;
		        wrRPC2_MEM(rpc_addr, &rpc_data, 1);
		        rpc_addr = 0;
		        rdRPC2_MEM(rpc_addr, &rpc_sr.val, 1);
				
		        if(rpc_sr.DRB==1) 
		        {
			        if(rpc_sr.PSB==0) {ret = TRUE; break;}
			        if(rpc_sr.PSB==1) {ret = FALSE; break;}
		        }
		        polling_nr++;
		        #if RPC_DRIVER_DEBUG
		        if(polling_nr%PRINT_INTERVAL==0)
			        LLOPS_PRINT("Polling %d times, DRB = %d, PSB = %d, SR = 0x%04X\n",polling_nr,rpc_sr.DRB,rpc_sr.PSB,rpc_sr.val);
		        #endif
		        #ifndef SIMULATION
		        if (SYS_CheckTimeout())
                {
                    ret = FALSE;
			        LLOPS_PRINT("Timeout.\n");
			        SYS_ExitCritical(cpuStat);
                    break;
		        }
		        #else
		        if(polling_nr==MAX_POLLING_NUM) 
                {
			        LLOPS_PRINT("Timeout. Polling %d times, DRB = %d, PSB = %d, SR = 0x%04X\n",polling_nr,rpc_sr.DRB,rpc_sr.PSB,rpc_sr.val);
			        ret = FALSE;	break;
		        }
                //waitUs(1);    //wait 1us in SV simulator
		        #endif
	        }
	        #if RPC_DRIVER_DEBUG
	        LLOPS_PRINT("Polling %d times, DRB = %d, PSB = %d, SR = 0x%04X\n",polling_nr,rpc_sr.DRB,rpc_sr.PSB,rpc_sr.val);
	        #endif
			break;
		}
		default:{ret = FALSE; break;}
	}
	#ifndef SIMULATION
	SYS_ExitCritical(cpuStat);
	#endif
	return ret;
}

BOOL RPC_Prog_Data(DWORD prog_address, DWORD prog_length, WORD* pData)
{
	BOOL ret = TRUE;
//    rpc_sr_t rpc_sr;
    DWORD rpc_addr;
	WORD rpc_data;
	WORD *pBuf;
//	DWORD polling_nr = 0;
	DWORD i;
//	WORD nReg[4];

	pBuf = pData;


	#ifndef SIMULATION
	//DWORD timeout = rpc_llops_Timeout;
	DWORD timeout = pDevice->ProgBufferTimeout;
    DWORD cpuStat;
	cpuStat = SYS_EnterCritical();


    if (timeout) SYS_StartTimeout(timeout);
#endif
    // 1 --- Write AA to 555
    rpc_addr = 0x555;
    rpc_data = 0xAA;
    wrRPC2_MEM(rpc_addr, &rpc_data, 1);
    // 2 --- Write 55 to 2AA
    rpc_addr = 0x2AA;
    rpc_data = 0x55;
    wrRPC2_MEM(rpc_addr, &rpc_data, 1);
    // 3 --- Write RPC_WR_BUF at (SA)
	//#ifdef SEC_256
	rpc_addr = prog_address & 0xFFFE0000;
	//#else
	//rpc_addr = prog_address & 0xFFFC0000;
	//#endif
	rpc_data = RPC_WR_BUF;
    wrRPC2_MEM(rpc_addr, &rpc_data, 1);
    // 4 --- Write (word_count-1) at (SA)
	//#ifdef SEC_256
	rpc_addr = prog_address & 0xFFFE0000;
	//#else
	//rpc_addr = prog_address & 0xFFFC0000;
	//#endif
	rpc_data = prog_length - 1;
    wrRPC2_MEM(rpc_addr, &rpc_data, 1);
    	
	//5 --- Write data to buffer
	rpc_addr = prog_address;
    //wrRPC2_MEM(rpc_addr, pBuf, prog_length);
#ifndef RPC2_BURSTWRITE  
    for(i=0;i<prog_length;i++)
    {
        wrRPC2_MEM(rpc_addr, pBuf, 1);
		if(i!=(prog_length-1)) {rpc_addr++; pBuf++;}
	}
#else
    wrRPC2_MEM(rpc_addr, pBuf, prog_length);
#endif
    
    //6 --- Program buffer to flash
	//#ifdef SEC_256
	rpc_addr = prog_address & 0xFFFE0000;
	//#else
	//rpc_addr = prog_address & 0xFFFC0000;
	//#endif
	rpc_data = RPC_PROG_BUF;
    wrRPC2_MEM(rpc_addr, &rpc_data, 1);
#if 0
    polling_nr = 0;
	//Polling status until prog done
	#if RPC_DRIVER_DEBUG
	LLOPS_PRINT("Send word prog cmd complete.\n");
	LLOPS_PRINT("Polling for DRB = 1, PSB = 0\n");	
	#endif
	while(1)
	{
		rpc_addr = 0x00000555;
		rpc_data = RPC_RD_SR;
		wrRPC2_MEM(rpc_addr, &rpc_data, 1);
		rpc_addr = 0;
		rdRPC2_MEM(rpc_addr, &rpc_sr.val, 1);
				
		if(rpc_sr.DRB==1) 
		{
			if(rpc_sr.PSB==0) {ret = TRUE; break;}
			if(rpc_sr.PSB==1) {ret = FALSE; break;}
		}
		polling_nr++;
		#if RPC_DRIVER_DEBUG
		if(polling_nr%PRINT_INTERVAL==0)
			LLOPS_PRINT("Polling %d times, DRB = %d, PSB = %d, SR = 0x%04X\n",polling_nr,rpc_sr.DRB,rpc_sr.PSB,rpc_sr.val);
		#endif
		#ifndef SIMULATION
		if (SYS_CheckTimeout())
        {
            ret = FALSE;
			LLOPS_PRINT("Timeout.\n");
			SYS_ExitCritical(cpuStat);
            break;
		}
		#else
		if(polling_nr==MAX_POLLING_NUM) 
        {
			LLOPS_PRINT("Timeout. Polling %d times, DRB = %d, PSB = %d, SR = 0x%04X\n",polling_nr,rpc_sr.DRB,rpc_sr.PSB,rpc_sr.val);
			ret = FALSE;	break;
		}
        //waitUs(1);    //wait 1us in SV simulator
		#endif
	}
	#if RPC_DRIVER_DEBUG
	LLOPS_PRINT("Polling %d times, DRB = %d, PSB = %d, SR = 0x%04X\n",polling_nr,rpc_sr.DRB,rpc_sr.PSB,rpc_sr.val);
	#endif
#endif    
	#ifndef SIMULATION
	SYS_ExitCritical(cpuStat);
	#endif
	return ret;
}

BOOL RPC_Buffer_Write_Load(DWORD prog_address, DWORD prog_length)
{
	BOOL ret = TRUE;
	DWORD rpc_addr;
	WORD rpc_data;
//	DWORD polling_nr = 0;


	#ifndef SIMULATION
	DWORD timeout = rpc_llops_Timeout;
    DWORD cpuStat;
	cpuStat = SYS_EnterCritical();

    if (timeout) SYS_StartTimeout(timeout);
#endif
    // 1 --- Write AA to 555
    rpc_addr = 0x555;
    rpc_data = 0xAA;
    wrRPC2_MEM(rpc_addr, &rpc_data, 1);
    // 2 --- Write 55 to 2AA
    rpc_addr = 0x2AA;
    rpc_data = 0x55;
    wrRPC2_MEM(rpc_addr, &rpc_data, 1);
    // 3 --- Write RPC_WR_BUF at (SA)
	//#ifdef SEC_256
	rpc_addr = prog_address & 0xFFFE0000;
	//#else
	//rpc_addr = prog_address & 0xFFFC0000;
	//#endif
	rpc_data = RPC_WR_BUF;
    wrRPC2_MEM(rpc_addr, &rpc_data, 1);
    // 4 --- Write (word_count-1) at (SA)
	//#ifdef SEC_256
	rpc_addr = prog_address & 0xFFFE0000;
	//#else
	//rpc_addr = prog_address & 0xFFFC0000;
	//#endif
	rpc_data = prog_length - 1;
    wrRPC2_MEM(rpc_addr, &rpc_data, 1);
    
	#ifndef SIMULATION
	SYS_ExitCritical(cpuStat);
	#endif
	return ret;
}

BOOL RPC_Buffer_Write_Store(DWORD prog_address, DWORD prog_length, WORD* pData)
{
	BOOL ret = TRUE;
	DWORD rpc_addr;
//	WORD rpc_data;
	DWORD i;
	WORD *pBuf;
//	DWORD polling_nr = 0;

	pBuf = pData;
		
	#ifndef SIMULATION
	DWORD timeout = rpc_llops_Timeout;
    DWORD cpuStat;
	cpuStat = SYS_EnterCritical();

    if (timeout) SYS_StartTimeout(timeout);
    #endif

	//HIAR_process(&prog_address);
	rpc_addr = prog_address;
	//5 --- Write data to buffer
	for(i=0;i<prog_length;i++)
    {
        wrRPC2_MEM(rpc_addr, pBuf, 1);
		if(i!=(prog_length-1)) {rpc_addr++; pBuf++;}
	}

	#ifndef SIMULATION
	SYS_ExitCritical(cpuStat);
	#endif
	return ret;
}

BOOL RPC_Buffer_Write_Commit(DWORD prog_address)
{
	BOOL ret = TRUE;
	rpc_sr_t rpc_sr;
	DWORD rpc_addr;
	WORD rpc_data;
//	WORD nReg[32],i;

	DWORD polling_nr = 0;


	#ifndef SIMULATION
	//DWORD timeout = rpc_llops_Timeout;
	DWORD timeout = pDevice->ProgBufferTimeout;
    DWORD cpuStat;
	cpuStat = SYS_EnterCritical();

    if (timeout) SYS_StartTimeout(timeout);
#endif
	

	//HIAR_process(&prog_address);
	//6 --- Program buffer to flash
	//#ifdef SEC_256
	rpc_addr = prog_address & 0xFFFE0000;
	//#else
	//rpc_addr = prog_address & 0xFFFC0000;
	//#endif
	rpc_data = RPC_PROG_BUF;
    wrRPC2_MEM(rpc_addr, &rpc_data, 1);


    polling_nr = 0;
	//Polling status until prog done
	#if RPC_DRIVER_DEBUG
	LLOPS_PRINT("Send buffer write commit cmd complete.\n");
	LLOPS_PRINT("Polling for DRB = 1, PSB = 0\n");	
	#endif
	while(1)
	{
		rpc_addr = 0x00000555;
		rpc_data = RPC_RD_SR;
		wrRPC2_MEM(rpc_addr, &rpc_data, 1);
		rpc_addr = 0;
		rdRPC2_MEM(rpc_addr, &rpc_sr.val, 1);
				
		if(rpc_sr.DRB==1) 
		{
			if(rpc_sr.PSB==0) {ret = TRUE; break;}
			if(rpc_sr.PSB==1) {ret = FALSE; break;}
		}
		polling_nr++;
		#if RPC_DRIVER_DEBUG
		if(polling_nr%PRINT_INTERVAL==0)
			LLOPS_PRINT("Polling %d times, DRB = %d, PSB = %d, SR = 0x%04X\n",polling_nr,rpc_sr.DRB,rpc_sr.PSB,rpc_sr.val);
		#endif
		#ifndef SIMULATION
		if (SYS_CheckTimeout())
        {
            ret = FALSE;
			LLOPS_PRINT("Timeout.\n");
			SYS_ExitCritical(cpuStat);
            break;
		}
		#else
		if(polling_nr==MAX_POLLING_NUM) 
        {
			LLOPS_PRINT("Timeout. Polling %d times, DRB = %d, PSB = %d, SR = 0x%04X\n",polling_nr,rpc_sr.DRB,rpc_sr.PSB,rpc_sr.val);
			ret = FALSE;	break;
		}
        //waitUs(1);    //wait 1us in SV simulator
		#endif
	}
	#if RPC_DRIVER_DEBUG
	LLOPS_PRINT("Polling %d times, DRB = %d, PSB = %d, SR = 0x%04X\n",polling_nr,rpc_sr.DRB,rpc_sr.PSB,rpc_sr.val);
	#endif
			    
		
	#ifndef SIMULATION
	SYS_ExitCritical(cpuStat);
	#endif
	return ret;
}

BOOL RPC_Erase(DWORD sector_address)
{
	BOOL ret = TRUE;
//	rpc_sr_t rpc_sr;
	DWORD rpc_addr;
	WORD rpc_data;
//	WORD i;
//	DWORD polling_nr = 0;
//	WORD nReg[4];
	

	#ifndef SIMULATION
	//DWORD timeout = rpc_llops_Timeout;
	DWORD timeout = pDevice->SecEraseTimeout;
    DWORD cpuStat;
	cpuStat = SYS_EnterCritical();

    if (timeout) SYS_StartTimeout(timeout);
    #endif

    // 1 --- Write AA to 555
    rpc_addr = 0x555;
    rpc_data = 0xAA;
    wrRPC2_MEM(rpc_addr, &rpc_data, 1);
    // 2 --- Write 55 to 2AA
    rpc_addr = 0x2AA;
    rpc_data = 0x55;
    wrRPC2_MEM(rpc_addr, &rpc_data, 1);
    // 3 --- Write RPC_ERASE_SECTOR at 555
	rpc_addr = 0x555;
	rpc_data = RPC_ERASE_SECTOR;
    wrRPC2_MEM(rpc_addr, &rpc_data, 1);
    // 4 --- Write AA at 555
	rpc_addr = 0x555;
	rpc_data = 0x00AA;
    wrRPC2_MEM(rpc_addr, &rpc_data, 1);
    //5 --- Write 55 at 2AA
	rpc_addr = 0x2AA;
	rpc_data = 0x0055;
    wrRPC2_MEM(rpc_addr, &rpc_data, 1);
    //6 --- Write 0x30 at (SA)0
	rpc_addr = sector_address;
	rpc_data = 0x0030;
    wrRPC2_MEM(rpc_addr, &rpc_data, 1);

#if 0
    polling_nr = 0;
	//Polling status until prog done
	#if RPC_DRIVER_DEBUG
	LLOPS_PRINT("Send sector erase cmd complete.\n");
	LLOPS_PRINT("Polling for DRB = 1, ESB = 0\n");	
	#endif
	while(1)
	{
		rpc_addr = 0x00000555;
		rpc_data = RPC_RD_SR;
		wrRPC2_MEM(rpc_addr, &rpc_data, 1);
		rpc_addr = 0;
		rdRPC2_MEM(rpc_addr, &rpc_sr.val, 1);
				
		if(rpc_sr.DRB==1) 
		{
			if(rpc_sr.ESB==0) {ret = TRUE; break;}
			if(rpc_sr.ESB==1) {ret = FALSE; break;}
		}
		polling_nr++;
		#if RPC_DRIVER_DEBUG
		if(polling_nr%PRINT_INTERVAL==0)
			LLOPS_PRINT("Polling %d times, DRB = %d, ESB = %d, SR = 0x%04X\n",polling_nr,rpc_sr.DRB,rpc_sr.ESB,rpc_sr.val);
		#endif
		#ifndef SIMULATION
		if (SYS_CheckTimeout())
        {
            ret = FALSE;
			LLOPS_PRINT("Timeout.\n");
			SYS_ExitCritical(cpuStat);
            break;
		}
		#else
		if(polling_nr==MAX_POLLING_NUM) 
        {
			LLOPS_PRINT("Timeout. Polling %d times, DRB = %d, ESB = %d, SR = 0x%04X\n",polling_nr,rpc_sr.DRB,rpc_sr.ESB,rpc_sr.val);
			ret = FALSE;	break;
		}
        waitUs(100);    //wait 100us in SV simulator
		#endif
	}
	#if RPC_DRIVER_DEBUG
	LLOPS_PRINT("Polling %d times, DRB = %d, ESB = %d, SR = 0x%04X\n",polling_nr,rpc_sr.DRB,rpc_sr.ESB,rpc_sr.val);
	#endif
#endif

	#ifndef SIMULATION
	SYS_ExitCritical(cpuStat);
	#endif
	return ret;
}

BOOL RPC_Clear_SR(void)
{
	BOOL ret = TRUE;
	DWORD rpc_addr;
	WORD rpc_data;
    WORD rpc_data2[2];



	#ifndef SIMULATION
	DWORD timeout = rpc_llops_Timeout;
    DWORD cpuStat;
	cpuStat = SYS_EnterCritical();

    if (timeout) SYS_StartTimeout(timeout);
    #endif
    
    // 1 --- Write RPC_CLR_SR at 555
    rpc_addr = 0x555;
    rpc_data = RPC_CLR_SR;
    rpc_data2[1] = RPC_CLR_SR;
    wrRPC2_MEM(rpc_addr, &rpc_data, 1);

	#ifndef SIMULATION
	SYS_ExitCritical(cpuStat);
	#endif
	return ret;		
}

BOOL RPC_ID_ASO_Entry(void)
{
	BOOL ret = TRUE;
	DWORD rpc_addr;
	WORD rpc_data;
    WORD rpc_data2[2];
//	DWORD polling_nr = 0;

	
	#ifndef SIMULATION
	DWORD timeout = rpc_llops_Timeout;
    DWORD cpuStat;
	cpuStat = SYS_EnterCritical();

    if (timeout) SYS_StartTimeout(timeout);
    #endif

	// 1 --- Write AA to 555
    rpc_addr = 0x555;
    rpc_data = 0xAA;
    rpc_data2[1] = 0xAA;
    wrRPC2_MEM(rpc_addr, &rpc_data, 1);
    // 2 --- Write 55 to 2AA
    rpc_addr = 0x2AA;
    rpc_data = 0x55;
    rpc_data2[1] = 0x55;
    wrRPC2_MEM(rpc_addr, &rpc_data, 1);
    // 3 --- Write RPC_ID_ENTRY at 555
    rpc_addr = 0x555;
    rpc_data = RPC_ID_ENTRY;
    rpc_data2[1] = RPC_ID_ENTRY;
    wrRPC2_MEM(rpc_addr, &rpc_data, 1);

	#ifndef SIMULATION
	SYS_ExitCritical(cpuStat);
	#endif
	return ret;	
	
}

BOOL RPC_ID_Read(WORD *pCFI)
{
	BOOL ret = TRUE;
	DWORD rpc_addr;
	WORD cfi[256];

    // 1 --- Write CFI at XXX
    rpc_addr = 0;
    rdRPC2_MEM(rpc_addr, cfi, 16);

	memcpy(pCFI, cfi, sizeof(WORD)*16);

	//pCFI = cfi;
	return ret;		
}

BOOL RPC_ID_ASO_Exit(void)
{
	BOOL ret = TRUE;
	DWORD rpc_addr;
	WORD rpc_data;
    WORD rpc_data2[2];

    //ID ASO Exit
	// 1 --- Write RPC_SW_RESET at XXX
	rpc_addr = 0;
    rpc_data = RPC_SW_RESET;
    rpc_data2[1] = RPC_SW_RESET;
    wrRPC2_MEM(rpc_addr, &rpc_data, 1);
    
	return ret;		
}

BOOL RPC_Read_CFI(WORD *pCFI)
{
	BOOL ret = TRUE;
	#if RPC_DRIVER_DEBUG
	printf(" RPC_ID_ASO_Entry\n");
	#endif
	if(RPC_ID_ASO_Entry()==FALSE) ret = FALSE;

	#if RPC_DRIVER_DEBUG
	printf(" RPC_ID_Read\n");
	#endif
	if(RPC_ID_Read(pCFI)==FALSE) ret = FALSE;
	#if RPC_DRIVER_DEBUG
	printf(" RPC_ID_ASO_Exit\n");
	#endif
	if(RPC_ID_ASO_Exit()==FALSE) ret = FALSE;
	#if RPC_DRIVER_DEBUG
	printf(" return from RPC_Read_CFI\n");
	#endif

	return ret;	
}

BOOL RPC_Blank_Check(DWORD sector)
{
	BOOL ret = TRUE;
	DWORD rpc_addr;
	DWORD polling_nr = 0;
//	WORD nReg[4];
	rpc_sr_t rpc_sr;
	WORD rpc_data;
	

	#ifndef SIMULATION
	DWORD timeout = rpc_llops_Timeout;
    DWORD cpuStat;
	cpuStat = SYS_EnterCritical();

    if (timeout) SYS_StartTimeout(timeout);
    #endif

    // 1 --- Write RPC_BLANK_CHECK at XXX
	rpc_addr = (sector | 0x00000555);
	rpc_data = RPC_BLANK_CHECK;
    wrRPC2_MEM(rpc_addr, &rpc_data, 1);


    polling_nr = 0;
	//Polling status until prog done
	#if RPC_DRIVER_DEBUG
	LLOPS_PRINT("Send blank check cmd complete.\n");
	LLOPS_PRINT("Polling for DRB = 1, ESB = 0\n");	
	#endif
	while(1)
	{
		rpc_addr = 0x00000555;
		rpc_data = RPC_RD_SR;
		wrRPC2_MEM(rpc_addr, &rpc_data, 1);
		rpc_addr = 0;
		rdRPC2_MEM(rpc_addr, &rpc_sr.val, 1);
				
		if(rpc_sr.DRB==1) 
		{
			if(rpc_sr.ESB==0) {ret = TRUE; break;}
			if(rpc_sr.ESB==1) {ret = FALSE; break;}
		}
		polling_nr++;
		#if RPC_DRIVER_DEBUG
		if(polling_nr%PRINT_INTERVAL==0)
			LLOPS_PRINT("Polling %d times, DRB = %d, ESB = %d, SR = 0x%04X\n",polling_nr,rpc_sr.DRB,rpc_sr.ESB,rpc_sr.val);
		#endif
		#ifndef SIMULATION
		if (SYS_CheckTimeout())
        {
            ret = FALSE;
			LLOPS_PRINT("Timeout.\n");
			SYS_ExitCritical(cpuStat);
            break;
		}
		#else
		if(polling_nr==MAX_POLLING_NUM) 
        {
			LLOPS_PRINT("Timeout. Polling %d times, DRB = %d, ESB = %d, SR = 0x%04X\n",polling_nr,rpc_sr.DRB,rpc_sr.ESB,rpc_sr.val);
			ret = FALSE;	break;
		}
        waitUs(100);    //wait 100us in SV simulator
		#endif
	}
	#if RPC_DRIVER_DEBUG
	LLOPS_PRINT("Polling %d times, DRB = %d, ESB = %d, SR = 0x%04X\n",polling_nr,rpc_sr.DRB,rpc_sr.ESB,rpc_sr.val);
	#endif

    
	#ifndef SIMULATION
	SYS_ExitCritical(cpuStat);
	#endif
	return ret;		
}

BOOL RPC_Read(DWORD read_address, WORD* data, DWORD length)
{
    BOOL ret = TRUE;
    
    rdRPC2_MEM(read_address, data, length);

	return ret;		
}

BOOL RPC_Write(DWORD write_address, WORD* data, DWORD length)
{
	BOOL ret = TRUE;
	
	wrRPC2_MEM(write_address, data, length);
	return ret;

}
	
BOOL RPC_CTRL_Reg_Read(DWORD read_address, DWORD* data)
{
    BOOL ret = TRUE;
    
    rdRPC2_REG(read_address, data);

	return ret;		
}

BOOL RPC_CTRL_Reg_Write(DWORD write_address, DWORD* data)
{
	BOOL ret = TRUE;
	
	wrRPC2_REG(write_address, data);
	return ret;

}

/*******************************************************************************
 * APIs - directly execute
 ******************************************************************************/



/*******************************************************************************
 * APIs - system command
 ******************************************************************************/
#if 0
void sys_get_time_stamp(unsigned long long *p_time_ns)
{
//	*p_time_ns = apu_get_sc_time_stamp();
	*p_time_ns = 0;
}
void sys_delay(unsigned long long delay_ns)
{
	//APU_ADD_DELAY((unsigned int)delay_ns);
}
void sys_set_rpc_freq(unsigned int freq_mhz)
{
	rpc_ctrl.reg.CLKSR.CLK_FREQ = (UINT8)freq_mhz;
	rpc_ctrl.reg.CLKSR.RPC_CLK_MULT = 1;
	//GPMC_WRITE(RPC_CLKSR, &rpc_ctrl.reg.CLKSR.val, 1);
	//m_freq_mhz = freq_mhz;
}
unsigned int sys_get_rpc_freq(void)
{
	//GPMC_READ(RPC_CLKSR, &rpc_ctrl.reg.CLKSR.val, 1);
	return rpc_ctrl.reg.CLKSR.CLK_FREQ;
}
#endif
/*******************************************************************************
 * initialize and exit
 ******************************************************************************/
 #ifndef SIMULATION
 DWORD rpc_ctrl_init(DWORD type)
{
    BOOL ret = TRUE;
    return ret;
}
#endif


