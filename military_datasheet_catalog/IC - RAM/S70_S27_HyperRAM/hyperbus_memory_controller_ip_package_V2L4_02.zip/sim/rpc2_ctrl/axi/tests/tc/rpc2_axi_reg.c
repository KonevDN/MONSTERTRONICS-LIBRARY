//===========================================================================
//
//  rpc2_axi_reg.c
//
//   @author  Yuichi Ise (yuichi.ise@spansion.com)
//   @version 0.1
//   @since   01/31/2014
//
//===========================================================================
#include <stdlib.h>
#include "rpc2_common.h"

//=============================================================================
//  DEFINITIONS
//=============================================================================
#define CT_MSG(fmt, args ...)     printf("[REG]"); printf(fmt, ## args)
#define CT_ERR_MSG(fmt, args ...) printf("[REG]<ERR>"); printf(fmt, ## args)

//=============================================================================
//  STRUCTS
//=============================================================================
typedef struct {
  DWORD sig;
  int (*func)(void);
  const char* title;
} TTestCaseReg;

//=============================================================================
//  FUNCTIONS
//=============================================================================
static DWORD ibase_addr = 0x0;

static void setBaseAddress (DWORD addr)
{
  ibase_addr = addr;
}

static DWORD getBaseAddress (void)
{
  return ibase_addr;
}

static int wr_rd_reg(DWORD addr, DWORD burst, DWORD size, DWORD *wbuf, DWORD* validData)
{
  int ret = NO_ERROR;

  DWORD len = 1;
  BYTE* rbuf;
  BYTE rresp;
  BYTE wresp;

  int wxferByte;

  DWORD expData;
  DWORD len8;

  int cnt, cntLoop = RPC2_REG_SIZE;

  wxferByte = 1 << size;
  len8 = (wxferByte*len);

  rbuf = (BYTE*)malloc(len8);
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_wr_rd;
  }

  for (cnt = 0; cnt < cntLoop; cnt++) {
    CT_MSG("Write : addr=0x%08X len=0x%03X burst=%1d size=%1d\n", addr+cnt, len, burst, size);
    writeBurst(REG, addr+cnt, len, burst, size, (BYTE*)wbuf);
    getWriteResp(REG, &wresp);
    if (wresp) {
      CT_ERR_MSG("Write Response 0x%x\n", wresp);
      ret = RESP_ERROR;
      goto end_wr_rd;
    }

    CT_MSG("Read  : addr=0x%08X len=0x%03X burst=%1d size=%1d\n", addr+cnt, len, burst, size);
    readBurst(REG, addr+cnt, len, burst, size);
    getReadDataResp(REG, len, size, rbuf, &rresp);
    if (rresp) {
      CT_ERR_MSG("Read Response: 0x%x\n", rresp);
      ret = RESP_ERROR;
      goto end_wr_rd;
    }

    wrapMemCopy8((BYTE*)&expData, (BYTE*)validData, RPC2_REG_SIZE, cnt);
    expData &= *wbuf;
    if (verifyData8(rbuf, (BYTE*)&expData, len8-(cnt%wxferByte))) {
      ret = VERIFY_ERROR;
      CT_ERR_MSG("VerifyData8\n");
      goto end_wr_rd;
    }
  }
 end_wr_rd:
  if (rbuf) {
    free(rbuf);
  }
  return ret;
}

static int wr_rd(int target, DWORD addr, DWORD burst, DWORD wlen, 
		 DWORD wsize, BYTE* wbuf, DWORD rsize)
{
  int i;
  int ret = NO_ERROR;

  DWORD rlen;
  BYTE* rbuf;
  BYTE rresp[MAX_LEN];

  DWORD waddr;
  BYTE wresp;

  int wxferByte;
  int rxferByte;

  DWORD raddr;
  DWORD len8;
  DWORD burstLen;
  DWORD bufPtr;

  wxferByte = 1 << wsize;
  rxferByte = 1 << rsize;

  rlen = ((wxferByte*wlen)+(rxferByte-1)) / rxferByte;
  len8 = (wxferByte*wlen) - addr%wxferByte;

  rbuf = (BYTE*)malloc(len8*sizeof(BYTE));
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_wr_rd;
  }

  waddr = addr;
  bufPtr = 0;
  CT_MSG("Write: addr=0x%08X len=0x%03X burst=%1d size=%1d\n", waddr, wlen, burst, wsize);
  while (wlen) {
    if (wlen > MAX_LEN) {
      burstLen = MAX_LEN;
    }
    else {
      burstLen = wlen;
    }
    writeBurst(target, waddr, burstLen, burst, wsize, &wbuf[bufPtr]);
    getWriteResp(target, &wresp);
    if (wresp) {
      CT_ERR_MSG("Write Response 0x%x\n", wresp);
      ret = RESP_ERROR;
      goto end_wr_rd;
    }
    wlen -= burstLen;
    waddr += (wxferByte*burstLen);
    bufPtr += (wxferByte*burstLen);
  }

  raddr = addr;
  bufPtr = 0;
  CT_MSG("Read : addr=0x%08X len=0x%03X burst=%1d size=%1d\n", raddr, rlen, burst, rsize);
  while (rlen) {
    if (rlen > MAX_LEN) {
      burstLen = MAX_LEN;
    }
    else {
      burstLen = rlen;
    }
    readBurst(target, raddr, burstLen, burst, rsize);
    getReadDataResp(target, burstLen, rsize, &rbuf[bufPtr], rresp);
    for (i = 0; i < burstLen; i++) {
      if (rresp[i]) {
	CT_ERR_MSG("Read Response %d: 0x%x\n", i, rresp[i]);
	ret = RESP_ERROR;
	goto end_wr_rd;
      }
    }
    rlen -= burstLen;
    raddr += (rxferByte*burstLen);
    bufPtr += (rxferByte*burstLen);
  }

  if (verifyData8(rbuf, wbuf, len8)) {
    ret = VERIFY_ERROR;
    CT_ERR_MSG("VerifyData8\n");
    goto end_wr_rd;
  }

 end_wr_rd:
  if (rbuf) {
    free(rbuf);
  }
  return ret;
}


static int rd_slave_error(int target, DWORD addr, DWORD rlen, DWORD rburst,
			  DWORD rsize, WORD* rbuf)
{
  int i;
  int ret = NO_ERROR;
  BYTE rresp[MAX_LEN];

  CT_MSG("Read : addr=0x%08X len=0x%03x burst=%1d size=%1d\n", addr, rlen, rburst, rsize);
  readBurst(target, addr, rlen, rburst, rsize);
  getReadDataResp(target, rlen, rsize, rbuf, rresp);
  for (i = 0; i < rlen; i++) {
    if (rresp[i] != SLVERR) {
      ret = RESP_ERROR;
      CT_ERR_MSG("Unexpected Read response %d\n", rresp[i]);
      break;
    }
  }
  return ret;
}

static int wr_slave_error(int target, DWORD addr, DWORD wlen, DWORD wburst,
			  DWORD wsize, WORD* wbuf)
{
  int ret = NO_ERROR;
  BYTE wresp;

  CT_MSG("Write: addr=0x%08X len=0x%03x burst=%1d size=%1d\n", addr, wlen, wburst, wsize);
  writeBurst(target, addr, wlen, wburst, wsize, wbuf);
  getWriteResp(target, &wresp);
  if (wresp != SLVERR) {
    ret = RESP_ERROR;
    CT_ERR_MSG("Unexpected Write response %d\n", wresp);
  }
  return ret;
}

static int rd_decode_error(int target, DWORD addr, DWORD rlen, DWORD rburst,
			  DWORD rsize, WORD* rbuf)
{
  int i;
  int ret = NO_ERROR;
  BYTE rresp[MAX_LEN];

  CT_MSG("Read : addr=0x%08X len=0x%03x burst=%1d size=%1d\n", addr, rlen, rburst, rsize);
  readBurst(target, addr, rlen, rburst, rsize);
  getReadDataResp(target, rlen, rsize, rbuf, rresp);
  for (i = 0; i < rlen; i++) {
    if (rresp[i] != DECERR) {
      ret = RESP_ERROR;
      CT_ERR_MSG("Unexpected Read response %d\n", rresp[i]);
      break;
    }
  }
  return ret;
}

static int wr_decode_error(int target, DWORD addr, DWORD wlen, DWORD wburst,
			   DWORD wsize, WORD* wbuf)
{
  int ret = NO_ERROR;
  BYTE wresp;

  CT_MSG("Write: addr=0x%08X len=0x%03x burst=%1d size=%1d\n", addr, wlen, wburst, wsize);
  writeBurst(target, addr, wlen, wburst, wsize, wbuf);
  getWriteResp(target, &wresp);
  if (wresp != DECERR) {
    ret = RESP_ERROR;
    CT_ERR_MSG("Unexpected Write response %d\n", wresp);
  }
  return ret;
}

static int sub_concurrent_wr_rd (int target, DWORD addr, DWORD wlen, DWORD wburst,
				 DWORD wsize, WORD* wbuf, DWORD rburst, DWORD rsize)
{
  int i;
  int ret = NO_ERROR;

  DWORD rlen;
  WORD* rbuf;
  BYTE rresp[MAX_LEN];

  DWORD len8;
  BYTE wresp;

  int wXferByte;
  int rXferByte;
  wXferByte = 1 << wsize;
  rXferByte = 1 << rsize;

  if (wlen > MAX_LEN) {
    CT_ERR_MSG("Can't support the burst length 0x%X\n", wlen);
    ret = NOT_SUPPORT;
    goto end_wr_rd;
  }

  rlen = ((wXferByte*wlen)+(rXferByte-1))/rXferByte;
  len8 = (wXferByte*wlen)-addr%wXferByte;

  rbuf = (WORD*)malloc(rXferByte*rlen);
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_wr_rd;
  }

  CT_MSG("Concurrent Write: addr=0x%08X len=0x%03X burst=%1d size=%1d\n", addr, wlen, wburst, wsize);
  CT_MSG("           Read : addr=0x%08X len=0x%03X burst=%1d size=%1d\n", addr, rlen, rburst, rsize);
  writeBurst(target, addr, wlen, wburst, wsize, wbuf);
  readBurst(target, addr, rlen, rburst, rsize);

  getWriteResp(target, &wresp);
  getReadDataResp(target, rlen, rsize, rbuf, rresp);
  if (wresp) {
    CT_ERR_MSG("Write Response 0x%x\n", wresp);
    ret = RESP_ERROR;
    goto end_wr_rd;
  }
  for (i = 0; i < rlen; i++) {
    if (rresp[i]) {
      CT_ERR_MSG("Read Response %d: 0x%x\n", i, rresp[i]);
      ret = RESP_ERROR;
      goto end_wr_rd;
    }
  }
  if (verifyData8((BYTE*)rbuf, (BYTE*)wbuf, len8)) {
    ret = VERIFY_ERROR;
    CT_ERR_MSG("VerifyData\n");
  }
 end_wr_rd:
  if (rbuf) {
    free(rbuf);
  }
  return ret;
}

//=============================================================================
//  REGISTER
//=============================================================================
int axi_reg_wr_rd_1B (void)
{
  int ret = NO_ERROR;

  DWORD addr = getBaseAddress()+REG_MCR0_ADDR;
  DWORD burst;
  DWORD size  = BYTE_1;

  DWORD wbuf;
  DWORD validData = REG_MCR_RW_BIT;

  CT_MSG(">> AXI REG WRITE/READ 1B\n");
  // random data
  fillBuffer(RANDOM, (WORD*)&wbuf, 1);
  CT_MSG("Data Pattern");
  printBuffer((WORD*)&wbuf, 1);

  burst = INCR;
  ret = wr_rd_reg(addr, burst, size, &wbuf, &validData);
  if (ret != NO_ERROR) {
    goto end_test;
  }

  // 00 data
  genFixData((WORD*)&wbuf, 0x0, 1);
  CT_MSG("Data Pattern");
  printBuffer((WORD*)&wbuf, 1);

  burst = FIXED;
  ret = wr_rd_reg(addr, burst, size, &wbuf, &validData);

  // FF data
  genFixData((WORD*)&wbuf, 0xFFFF, 1);
  CT_MSG("Data Pattern");
  printBuffer((WORD*)&wbuf, 1);

  burst = INCR;
  ret = wr_rd_reg(addr, burst, size, &wbuf, &validData);

 end_test:
  CT_MSG("<< AXI REG WRITE/READ 1B");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_reg_wr_rd_2B (void)
{
  int ret = NO_ERROR;

  DWORD addr = getBaseAddress()+REG_MCR0_ADDR;
  DWORD burst;
  DWORD size  = BYTE_2;

  DWORD wbuf;
  DWORD validData = REG_MCR_RW_BIT;

  CT_MSG(">> AXI REG WRITE/READ 2B\n");
  // random data
  fillBuffer(RANDOM, (WORD*)&wbuf, 1);
  CT_MSG("Data Pattern");
  printBuffer((WORD*)&wbuf, 1);

  burst = INCR;
  ret = wr_rd_reg(addr, burst, size, &wbuf, &validData);
  if (ret != NO_ERROR) {
    goto end_test;
  }

  // 00 data
  genFixData((WORD*)&wbuf, 0x0, 1);
  CT_MSG("Data Pattern");
  printBuffer((WORD*)&wbuf, 1);

  burst = FIXED;
  ret = wr_rd_reg(addr, burst, size, &wbuf, &validData);

  // FF data
  genFixData((WORD*)&wbuf, 0xFFFF, 1);
  CT_MSG("Data Pattern");
  printBuffer((WORD*)&wbuf, 1);

  burst = INCR;
  ret = wr_rd_reg(addr, burst, size, &wbuf, &validData);

 end_test:
  CT_MSG("<< AXI REG WRITE/READ 2B");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_reg_wr_rd_4B (void)
{
  int ret = NO_ERROR;

  DWORD addr = getBaseAddress()+REG_MCR0_ADDR;
  DWORD burst;
  DWORD size  = BYTE_4;

  DWORD wbuf;
  DWORD validData = REG_MCR_RW_BIT;

  CT_MSG(">> AXI REG WRITE/READ 4B\n");
  // random data
  fillBuffer(RANDOM, (WORD*)&wbuf, 2);
  CT_MSG("Data Pattern");
  printBuffer((WORD*)&wbuf, 2);

  burst = INCR;
  ret = wr_rd_reg(addr, burst, size, &wbuf, &validData);
  if (ret != NO_ERROR) {
    goto end_test;
  }

  // 00 data
  genFixData((WORD*)&wbuf, 0x0, 2);
  CT_MSG("Data Pattern");
  printBuffer((WORD*)&wbuf, 2);

  burst = FIXED;
  ret = wr_rd_reg(addr, burst, size, &wbuf, &validData);

  // FF data
  genFixData((WORD*)&wbuf, 0xFFFF, 2);
  CT_MSG("Data Pattern");
  printBuffer((WORD*)&wbuf, 2);

  burst = FIXED;
  ret = wr_rd_reg(addr, burst, size, &wbuf, &validData);

 end_test:
  CT_MSG("<< AXI REG WRITE/READ 4B");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_reg_incr_wr_rd_1B (void)
{
  int ret;
  int i;

  DWORD wlen = 4;
  DWORD wsize = BYTE_1;
  DWORD rsize = BYTE_1;
  DWORD addr = getBaseAddress()+REG_MCR0_ADDR;
  DWORD burst = INCR;

  DWORD pattern;
  DWORD len16;
  WORD* rbuf;
  WORD* wbuf;
  BYTE* wbuf8;
  int wxferByte;

  CT_MSG(">> AXI INCR WRITE/READ 1B\n");
  wxferByte = 1 << wsize;
  len16 = (wxferByte*wlen)/sizeof(WORD);

  wbuf = (WORD*)malloc(wxferByte*wlen);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    return ALLOC_ERROR;
  }
  rbuf = (WORD*)malloc(wxferByte*wlen);
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    return ALLOC_ERROR;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  // mask
  wbuf[0] &= REG_MCR_RW_BIT;
  wbuf[1] &= (REG_MCR_RW_BIT>>16);
  printBuffer(wbuf, len16);

  wbuf8 = (BYTE*)wbuf;

  CT_MSG("INCR BURST --------------------------------------------------\n");
  for (i = 0; i < 4; i++) {
    ret = wr_rd(REG, addr+i, burst, wlen-i, wsize, &wbuf8[i], rsize);
    if (ret != NO_ERROR) {
      break;
    }
  }

  CT_MSG("SLVERR out of 32-bit address boundary ------------------------\n");
  // SLVERR because of exceeding 32-bit address boundary
  for (i = 1; i < 4; i++) {
    ret = wr_slave_error(REG, addr+i, wlen, burst, wsize, wbuf);
    if (ret != NO_ERROR) {
      break;
    }
    ret = rd_slave_error(REG, addr+i, wlen, burst, wsize, rbuf);
    if (ret != NO_ERROR) {
      break;
    }
  }

  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
  CT_MSG(">> AXI INCR WRITE/READ 1B");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_reg_incr_wr_rd_2B (void)
{
  int ret;
  int i;

  DWORD wlen = 2;
  DWORD wsize = BYTE_2;
  DWORD rsize = BYTE_2;
  DWORD addr = getBaseAddress()+REG_MCR0_ADDR;
  DWORD burst = INCR;

  DWORD pattern;
  DWORD len16;
  WORD* rbuf;
  WORD* wbuf;
  BYTE* wbuf8;
  int wxferByte;

  CT_MSG(">> AXI INCR WRITE/READ 2B\n");
  wxferByte = 1 << wsize;
  len16 = (wxferByte*wlen)/sizeof(WORD);

  wbuf = (WORD*)malloc(wxferByte*wlen);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    return ALLOC_ERROR;
  }
  rbuf = (WORD*)malloc(wxferByte*wlen);
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    return ALLOC_ERROR;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  // mask
  wbuf[0] &= REG_MCR_RW_BIT;
  wbuf[1] &= (REG_MCR_RW_BIT>>16);
  printBuffer(wbuf, len16);

  wbuf8 = (BYTE*)wbuf;

  CT_MSG("INCR BURST --------------------------------------------------\n");
  for (i = 0; i < 2; i++) {
    ret = wr_rd(REG, addr+i, burst, wlen, wsize, &wbuf8[i], rsize);
    if (ret != NO_ERROR) {
      break;
    }
  }

  CT_MSG("SLVERR out of 32-bit address boundary ------------------------\n");
  // SLVERR because of exceeding 32-bit address boundary
  for (i = 2; i < 4; i++) {
    ret = wr_slave_error(REG, addr+i, wlen, burst, wsize, wbuf);
    if (ret != NO_ERROR) {
      break;
    }
    ret = rd_slave_error(REG, addr+i, wlen, burst, wsize, rbuf);
    if (ret != NO_ERROR) {
      break;
    }
  }

  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
  CT_MSG(">> AXI INCR WRITE/READ 2B");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_reg_slave_error (void)
{
  int ret = NO_ERROR;

  DWORD addr;
  DWORD wlen = 3;
  DWORD wburst;
  DWORD wsize  = BYTE_4;
  DWORD rlen = wlen;
  DWORD rburst;
  DWORD rsize  = BYTE_4;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  WORD* rbuf;
  int wXferByte;
  int rXferByte;

  CT_MSG(">> AXI REG ERROR WRITE/READ\n");
  wXferByte = 1 << wsize;
  rXferByte = 1 << rsize;

  len16 = (wXferByte*wlen)/sizeof(WORD);

  wbuf = (WORD*)malloc(wXferByte*wlen);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    return ALLOC_ERROR;
  }

  rbuf = (WORD*)malloc(rXferByte*rlen);
  if (!rbuf) {
    CT_ERR_MSG("Can't allocate memory for read data\n");
    ret = ALLOC_ERROR;
    goto end_test;
  }

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

#if 0
  addr = REG_MBR0_ADDR+getBaseAddress();
  rlen = 2;
  wlen = 2;
  rburst = WRAP;
  wburst = WRAP;
  rsize  = BYTE_4;
  wsize  = BYTE_4;
  ret = rd_slave_error(REG, addr, rlen, rburst, rsize, rbuf); if (ret != NO_ERROR) goto end_test;
  ret = wr_slave_error(REG, addr, wlen, wburst, wsize, wbuf); if (ret != NO_ERROR) goto end_test;
  
  rlen = 3;
  wlen = 3;
  rburst = INCR;
  wburst = INCR;
  rsize  = BYTE_4;
  wsize  = BYTE_4;
  ret = rd_slave_error(REG, addr, rlen, rburst, rsize, rbuf); if (ret != NO_ERROR) goto end_test;
  ret = wr_slave_error(REG, addr, wlen, wburst, wsize, wbuf); if (ret != NO_ERROR) goto end_test;
#endif

  CT_MSG("Hoge1");
  if (getBaseAddress()) {
    CT_MSG("Hoge2");
    // address is lower than base address
    addr = getBaseAddress() - 4;
    rlen = 1;
    wlen = 1;
    rburst = INCR;
    wburst = INCR;
    rsize  = BYTE_4;
    wsize  = BYTE_4;
    ret = rd_decode_error(REG, addr, rlen, rburst, rsize, rbuf); if (ret != NO_ERROR) goto end_test;
    ret = wr_decode_error(REG, addr, wlen, wburst, wsize, wbuf); if (ret != NO_ERROR) goto end_test;
  }

 end_test:
  if (rbuf) {
    free(rbuf);
  }
  if (wbuf) {
    free(wbuf);
  }
  CT_MSG("<< AXI REG ERROR WRITE/READ");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_reg_concurrent_wr_rd (void)
{
  int ret;

  DWORD addr;
  DWORD wlen = 256;
  DWORD wburst;
  DWORD wsize  = BYTE_4;
  DWORD rburst;
  DWORD rsize  = BYTE_4;

  DWORD pattern;
  DWORD len16;
  WORD* wbuf;
  int wXferByte;

  CT_MSG(">> AXI REG CONCURRENT WRITE/READ\n");
  wXferByte = 1 << wsize;
  len16 = (wXferByte*wlen)/sizeof(WORD);

  wbuf = (WORD*)malloc(wXferByte*wlen);
  if (!wbuf) {
    CT_ERR_MSG("Can't allocate memory for write data\n");
    return ALLOC_ERROR;
  }

  wlen = 1;
  len16 = (wXferByte*wlen)/sizeof(WORD);

  wbuf[0] = 0x0000;
  wbuf[1] = 0xA500;
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  addr = REG_MBR0_ADDR+getBaseAddress();
  wburst = INCR;
  rburst = INCR;
  CT_MSG("INCR -----------------------------------------------------\n");
  ret = sub_concurrent_wr_rd(REG, addr, wlen, wburst, wsize, wbuf, rburst, rsize);
  if (ret != NO_ERROR) goto end_test;

  wbuf[1] = 0x5A00;
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  wburst = FIXED;
  rburst = FIXED;
  CT_MSG("FIXED ----------------------------------------------------\n");
  ret = sub_concurrent_wr_rd(REG, addr, wlen, wburst, wsize, wbuf, rburst, rsize);
  if (ret != NO_ERROR) goto end_test;

  ///------
  addr = 0xFFFFFFFF;
  wburst = INCR;
  rburst = INCR;
  CT_MSG("INCR ADDR=0x%08X--------------------------------------\n", addr);
  ret = sub_concurrent_wr_rd(REG, addr, wlen, wburst, wsize, wbuf, rburst, rsize);
  if (ret != RESP_ERROR) {
    ret = RESP_ERROR;
    goto end_test;
  }
  ret = NO_ERROR;

  wlen = 2;
  len16 = (wXferByte*wlen)/sizeof(WORD);

  wbuf[0] = 0x0003;
  wbuf[1] = 0x0030;
  wbuf[2] = 0x0002;
  wbuf[3] = 0x0022;
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  wlen = len16;
  addr = REG_MCR0_ADDR+getBaseAddress();
  wburst = WRAP;
  rburst = WRAP;
  wsize = BYTE_2;
  rsize = BYTE_2;
  CT_MSG("WRAP LEN=0x%03X SIZE=%1d-------------------------------------\n", wlen, wsize);
  ret = sub_concurrent_wr_rd(REG, addr, wlen, wburst, wsize, wbuf, rburst, rsize);
  if (ret != RESP_ERROR) {
    ret = RESP_ERROR;
    goto end_test;
  }
  ret = NO_ERROR;

  wlen = MAX_LEN;
  len16 = (wXferByte*wlen)/sizeof(WORD);

  getDataPattern(&pattern);
  fillBuffer(pattern, wbuf, len16);
  CT_MSG("Data Pattern");
  printBuffer(wbuf, len16);

  addr = REG_WPR_ADDR+getBaseAddress();
  wburst = INCR;
  rburst = INCR;
  wsize = BYTE_4;
  rsize = BYTE_4;
  CT_MSG("INCR LEN=0x%03X-------------------------------------------\n", wlen, wsize);
  ret = sub_concurrent_wr_rd(REG, addr, wlen, wburst, wsize, wbuf, rburst, rsize);
  if (ret != RESP_ERROR) {
    ret = RESP_ERROR;
    goto end_test;
  }

    ret = NO_ERROR;

  ///------

  // initialize
  genFixData(wbuf, 0x0, len16);
  wlen = 1;
  addr = REG_MBR0_ADDR+getBaseAddress();
  wburst = INCR;
  rburst = INCR;
  wsize = BYTE_4;
  rsize = BYTE_4;
  ret = sub_concurrent_wr_rd(REG, addr, wlen, wburst, wsize, wbuf, rburst, rsize);

 end_test:
  if (wbuf) {
    free(wbuf);
  }
  CT_MSG("<< AXI REG CONCURRENT WRITE/READ");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

int axi_reg_wr_id_max_inc (void)
{
  int i;
  int ret;
  DWORD wlen = 1;
  DWORD wsize = BYTE_4;
  DWORD rsize = BYTE_4;
  DWORD addr = getBaseAddress()+REG_MCR0_ADDR;
  DWORD burst = FIXED;
  DWORD wbuf;

  int idCnt = AXI_ID_WIDTH;
  DWORD transNum = 0;

  CT_MSG(">> AXI REG MAX ID COUNT WRITE/READ\n");
  // random data
  fillBuffer(RANDOM, (WORD*)&wbuf, 2);
  // mask
  wbuf &= REG_MCR_RW_BIT;
  CT_MSG("Data Pattern");
  printBuffer((WORD*)&wbuf, 2);

  for (i = 0; i < idCnt; i++) {
    transNum |= (BIT0 << i);
  }
  CT_MSG("Supported ID Count = 0x%08X\n", transNum);

  CT_MSG("FIXED BURST -------------------------------------------------\n");
  for (i=0; i<transNum+1; i++) {
    ret = wr_rd(REG, addr, burst, wlen, wsize, (BYTE*)(&wbuf), rsize);
    if (ret != NO_ERROR) {
      break;
    }
  }

  CT_MSG("<< AXI REG MAX ID COUNT WRITE/READ");
  if (ret == NO_ERROR) MSG_PASS;
  else MSG_FAIL;
  return ret;
}

//=============================================================================
//  MAIN
//=============================================================================
#define IT_WR_1B_REG         0x00000001
#define IT_WR_2B_REG         0x00000002
#define IT_WR_4B_REG         0x00000004
#define IT_WR_INCR_1B_REG    0x00000008
#define IT_WR_INCR_2B_REG    0x00000010
#define IT_WR_SLVERR_REG     0x00000020
#define IT_WR_CONCURRENT_REG 0x00000040
#define IT_WR_ID_MAX_INC_REG 0x00000080
#define IT_DEBUG             0x80000000

TTestCaseReg IT[] = {
  {IT_WR_1B_REG,          axi_reg_wr_rd_1B,          "1B W/R to REG"},
  {IT_WR_2B_REG,          axi_reg_wr_rd_2B,          "2B W/R to REG"},
  {IT_WR_4B_REG,          axi_reg_wr_rd_4B,          "4B W/R to REG"},
  {IT_WR_INCR_1B_REG,     axi_reg_incr_wr_rd_1B,     "1B Incr W/R to REG"},
  {IT_WR_INCR_2B_REG,     axi_reg_incr_wr_rd_2B,     "2B Incr W/R to REG"},
  {IT_WR_SLVERR_REG,      axi_reg_slave_error,       "Slave Error REG"},
  {IT_WR_CONCURRENT_REG,  axi_reg_concurrent_wr_rd,  "Concurrent W/R to REG"},
  {IT_WR_ID_MAX_INC_REG,  axi_reg_wr_id_max_inc,     "AXI ID Count MAX W/R to REG"},
  {IT_DEBUG,              (void*)0,                  "For debug"}
};

#define NUM_IT (sizeof(IT)/sizeof(IT[0]))

static int initialization (DWORD pattern, DWORD addr)
{
  // Set data pattern
  setDataPattern(pattern);

  // Set base address
  setBaseAddress(addr);

  return NO_ERROR;
}

int c_test()
{
  int ret;

  int i;
  int itResult[NUM_IT];
  char *itStr[] = {"UNDO", "PASS", "FAIL"};
  DWORD ctFlag;
  DWORD pattern;
  DWORD base_addr = 0x0;

  MSG("RPC2 AXI REGISTER Test\n");

#ifdef PATTERN
  pattern = PATTERN;
#else
  pattern = RANDOM;
#endif

#if defined CTFLAG
  ctFlag = CTFLAG;
#else
  ctFlag = 0xFF;
#endif

#ifdef AXI_REG_BASEADDR
  base_addr = AXI_REG_BASEADDR;
#endif

  for (i = 0; i < NUM_IT; i++) {
    itResult[i] = UNDO;
  }
  ret = initialization(pattern, base_addr);

  while (ctFlag && (ret == NO_ERROR)) {
    for (i = 0; i < NUM_IT; i++) {
      if (ctFlag & IT[i].sig) {
	ctFlag &= ~IT[i].sig;
	if (IT[i].func) {
	  ret = IT[i].func();
	  if (ret != NO_ERROR) itResult[i] = FAIL;
	  else itResult[i] = PASS;
	}
      }
      if (ret != NO_ERROR) {
	break;
      }
    }
    if (ctFlag) {
      break;
    }
  }
  MSG("\nTest Report ---------------------------------------------\n");
  for (i = 0; i < NUM_IT; i++) {
    MSG("  %2d: %-40s -- %s\n", i, IT[i].title, itStr[itResult[i]]);
  }
  MSG("---------------------------------------------------------\n");
  return 0;
}
