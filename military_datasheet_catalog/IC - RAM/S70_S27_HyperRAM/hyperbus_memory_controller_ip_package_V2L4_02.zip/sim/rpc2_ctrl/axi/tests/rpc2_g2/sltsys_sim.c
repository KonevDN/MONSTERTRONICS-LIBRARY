#include "sltapi_sim.h"
//#include "omap24xx.h"
#include "rpc2_llops.h"


// general coniguration
LTE csTable [] =
{
    {"wrap", WRAP_BURST},
    {"rdmult", READ_MULTIPLE},
    {"rdtype", READ_TYPE},
    {"wrtype", WRITE_TYPE},
    {"clockst", CLOCK_START},
    {"pglength", DEV_PAGE_LENGTH},
    {"rdhndshk", HANDSHAKE_READ},
    {"wrhndshk", HANDSHAKE_WRITE},
    {"hndshktim", HANDSHAKE_TIMING},
    {"cswtpin", CS_WAIT_PIN},
    {"intftype", INTF_TYPE},
    {"timescale", TIME_SCALE},
    {"clockdiv", CS_CLOCK_DIVISOR},
    {"cswroff", CS_OFF_WRITE},
    {"csrdoff", CS_OFF_READ},
    {"csdelay", CS_DELAY_HALF},
    {"cson", CS_ON},
    {"advwroff", ADV_OFF_WRITE},
    {"advrdoff", ADV_OFF_READ},
    {"advdelay", ADV_DELAY_HALF},
    {"advon", ADV_ON},
    {"weoff", WE_OFF},
    {"wedelay", WE_DELAY_HALF},
    {"weon", WE_ON},
    {"oeoff", OE_OFF},
    {"oedelay", OE_DELAY_HALF},
    {"oeon", OE_ON},
    {"pgbstdelay", PAGE_BURST_DELAY},
    {"readws", READ_WAIT_STATES},
    {"wtcyctime", WRITE_CYCLE_TIME},
    {"rdcyctime", READ_CYCLE_TIME},
    {"idlecs", IDLE_CS_HIGH},
    {"idlesame", IDLE_CS_SAME},
    {"idlediff", IDLE_CS_DIFF},
    {"turnaround", BUS_TURN_AROUND},
    {"waitpol", CS_WAIT_POLARITY},
    {"wprot", WRITE_PROTECT},
    {"", 0},
};


// convert timestamp value to nanoseconds
float CvtTsToNSec(DWORD lower, WORD upper)
{
    float uTime = 0xFFFFFFFF;
    float fTime = lower;
    uTime += 1;
    uTime *= upper;
    fTime += uTime;
    fTime *= 1000;
    return fTime / 12;  // use with 12MHz
}

float CvtDeltaTsToNSec(DWORD lTime1, WORD uTime1, DWORD lTime2, WORD uTime2)
{
    DWORD lDiff = lTime1 - lTime2;
    WORD uDiff = uTime1 - uTime2;
    if (lTime2 > lTime1) uDiff--;
    return CvtTsToNSec(lDiff, uDiff);
}

char *mag[] =
{
    "nS",
    "uS",
    "mS",
    "S ",
    "KS",
    "MS"
};

// compute and format delta time with scaled output
// subtract time 2 from time 1
void SYS_FormatDeltaTime(char *s, DWORD lTime1, WORD uTime1, DWORD lTime2, WORD uTime2)
{
    BYTE scale = 0;
    float fTime = CvtDeltaTsToNSec(lTime1, uTime1, lTime2, uTime2);
    int iTime;
    while (1)
    {
        if (fTime < 1000.0) break;
        fTime /= 1000.0;
        ++scale;
        if (5 == scale) break;
    }
    iTime = (int)(fTime*1000);
    // use local version of sprintf
    sprintf(s, " %7d.%03d%s", iTime/1000, iTime%1000, mag[scale]);
}

/****************************************************************************/
/*  Write data to WRDPRAM memory.                                           */
/****************************************************************************/
void SYS_WriteMem(DWORD addr, WORD value, DWORD size)
{
	//WORD val;
	//val = (WORD)value;
	if(2 == size){
//		GPMC_Write(addr, &value, 1);
	}
}

/****************************************************************************/
/*  Read data from RDDPRAM memory.                                          */
/****************************************************************************/
void SYS_ReadMem(DWORD addr, WORD *value, DWORD size)
{
	if(2 == size){
//		GPMC_Read(addr, value, 1);
	}
}

/****************************************************************************/
/*  Write data to WRDPRAM memory.                                           */
/****************************************************************************/
void SYS_WriteDPRAM(DWORD addr, WORD value, DWORD size)
{
	//WORD val;
	//val = (WORD)value;
	if(2 == size){
		//GPMC_Write((CS1_BASE_ADDR | WRDPRAM_BASE_ADDR | (addr<<1)), &value, 1);
	}
}

/****************************************************************************/
/*  Read data from RDDPRAM memory.                                          */
/****************************************************************************/
void SYS_ReadDPRAM(DWORD addr, WORD *value, DWORD size)
{
	if(2 == size){
		//GPMC_Read((CS1_BASE_ADDR | RDDPRAM_BASE_ADDR | (addr<<1)), value, 1);
	}
}

/****************************************************************************/
/*  Burst Read data from RDDPRAM memory.                                    */
/*                                                                          */
/****************************************************************************/
void SYS_Burst_ReadMem(DWORD addr, WORD *value, DWORD count)
{

	//GPMC_Read((CS1_BASE_ADDR | RDDPRAM_BASE_ADDR | (addr<<1)), value, count);
	//GPMC_Read((CS1_BASE_ADDR | (addr<<1)), value, count);                      //fixed bug @ 20120917

}


/** GetControl **************************************************************/
/*                                                                          */
/****************************************************************************/

DWORD GetControl(volatile unsigned int reg, DWORD mask, DWORD offset)
{
    //return *reg >> offset & mask;
	DWORD reg_data = 0;
	//gpmc_read32(reg,&reg_data);
	return(reg_data >> offset & mask);
}

/** SetControl **************************************************************/
/*                                                                          */
/****************************************************************************/

BOOL SetControl(volatile unsigned int reg, DWORD mask, DWORD offset, DWORD value)
{
    // For now do mode set this way in case some bits cannot be read.
    // Otherwise read the register, clear/set locally then write it
    // so that no accidental mode zero set occurs.
    DWORD reg_data = 0;
    if (value > mask) return FALSE;
    //*reg &= ~(mask << offset);  // clear current mode
    //*reg |= value << offset;    // set new mode
    //gpmc_read32(reg,&reg_data);
	reg_data &= ~(mask << offset);  // clear current mode
	//gpmc_write32(reg, &reg_data);
	reg_data |= value << offset;    // set new mode
	//gpmc_write32(reg, &reg_data);
    return TRUE;
}

/** SYS_GetCSControl ********************************************************/
/*                                                                          */
/****************************************************************************/

DWORD SYS_GetCSControl(DWORD type)
{
//    DWORD val;
/*
    switch (type)
    {
    case WRAP_BURST:        return GetControl(OMAP24XX_GPMC_CONFIG1_1, 0x01, 31);
    case READ_MULTIPLE:     return GetControl(OMAP24XX_GPMC_CONFIG1_1, 0x01, 30);
    case READ_TYPE:         return GetControl(OMAP24XX_GPMC_CONFIG1_1, 0x01, 29);
    case WRITE_TYPE:        return GetControl(OMAP24XX_GPMC_CONFIG1_1, 0x01, 27);
    case CLOCK_START:       return GetControl(OMAP24XX_GPMC_CONFIG1_1, 0x03, 25);
    // *** should do page length logically ***
    case DEV_PAGE_LENGTH:   return GetControl(OMAP24XX_GPMC_CONFIG1_1, 0x03, 23);
    case HANDSHAKE_READ:    return GetControl(OMAP24XX_GPMC_CONFIG1_1, 0x01, 22);
    case HANDSHAKE_WRITE:   return GetControl(OMAP24XX_GPMC_CONFIG1_1, 0x01, 21);
    case HANDSHAKE_TIMING:  return GetControl(OMAP24XX_GPMC_CONFIG1_1, 0x03, 18);
    case CS_WAIT_PIN:       return GetControl(OMAP24XX_GPMC_CONFIG1_1, 0x03, 16);
    // do bus width as 8, 16
    case BUS_WIDTH:         return GetControl(OMAP24XX_GPMC_CONFIG1_1, 0x01, 12) ? 16 : 8;
    case INTF_TYPE:         return GetControl(OMAP24XX_GPMC_CONFIG1_1, 0x03, 10);
    case MULTIPLEX_STATE:   return GetControl(OMAP24XX_GPMC_CONFIG1_1, 0x01,  9);
    case TIME_SCALE:        return GetControl(OMAP24XX_GPMC_CONFIG1_1, 0x01,  4);
    // do divisor logically
    case CS_CLOCK_DIVISOR:  return GetControl(OMAP24XX_GPMC_CONFIG1_1, 0x03,  0) + 1;
    case CS_OFF_WRITE:      return GetControl(OMAP24XX_GPMC_CONFIG2_1, 0x1F, 16);
    case CS_OFF_READ:       return GetControl(OMAP24XX_GPMC_CONFIG2_1, 0x1F,  8);
    case CS_DELAY_HALF:     return GetControl(OMAP24XX_GPMC_CONFIG2_1, 0x01,  7);
    case CS_ON:             return GetControl(OMAP24XX_GPMC_CONFIG2_1, 0x0F,  0);
    case ADV_OFF_WRITE:     return GetControl(OMAP24XX_GPMC_CONFIG3_1, 0x1F, 16);
    case ADV_OFF_READ:      return GetControl(OMAP24XX_GPMC_CONFIG3_1, 0x1F,  8);
    case ADV_DELAY_HALF:    return GetControl(OMAP24XX_GPMC_CONFIG3_1, 0x01,  7);
    case ADV_ON:            return GetControl(OMAP24XX_GPMC_CONFIG3_1, 0x0F,  0);
    case WE_OFF:            return GetControl(OMAP24XX_GPMC_CONFIG4_1, 0x1F, 24);
    case WE_DELAY_HALF:     return GetControl(OMAP24XX_GPMC_CONFIG4_1, 0x01, 23);
    case WE_ON:             return GetControl(OMAP24XX_GPMC_CONFIG4_1, 0x0F, 16);
    case OE_OFF:            return GetControl(OMAP24XX_GPMC_CONFIG4_1, 0x1F,  8);
    case OE_DELAY_HALF:     return GetControl(OMAP24XX_GPMC_CONFIG4_1, 0x01,  7);
    case OE_ON:             return GetControl(OMAP24XX_GPMC_CONFIG4_1, 0x0F,  0);
    case PAGE_BURST_DELAY:  return GetControl(OMAP24XX_GPMC_CONFIG5_1, 0x0F, 24);
    case READ_WAIT_STATES:  return GetControl(OMAP24XX_GPMC_CONFIG5_1, 0x1F, 16);
    case WRITE_CYCLE_TIME:  return GetControl(OMAP24XX_GPMC_CONFIG5_1, 0x1F,  8);
    case READ_CYCLE_TIME:   return GetControl(OMAP24XX_GPMC_CONFIG5_1, 0x1F,  0);
    case IDLE_CS_HIGH:      return GetControl(OMAP24XX_GPMC_CONFIG6_1, 0x0F,  8);
    case IDLE_CS_SAME:      return GetControl(OMAP24XX_GPMC_CONFIG6_1, 0x01,  7);
    case IDLE_CS_DIFF:      return GetControl(OMAP24XX_GPMC_CONFIG6_1, 0x01,  6);
    case BUS_TURN_AROUND:   return GetControl(OMAP24XX_GPMC_CONFIG6_1, 0x0F,  0);
    // do size logically
    case CS_SIZE:
        switch (GetControl(OMAP24XX_GPMC_CONFIG7_1, 0x0F, 8))
        {
        case 0x08: return 0x08000000;
        case 0x0C: return 0x04000000;
        case 0x0E: return 0x02000000;
        case 0x0F: return 0x01000000;
        default: return 0;
        }
    case CS_VALID:          return GetControl(OMAP24XX_GPMC_CONFIG7_1, 0x01,  6);
    // do base logically
    case CS_BASE:           return GetControl(OMAP24XX_GPMC_CONFIG7_1, 0x3F,  0) << 24;
    case CS_WAIT_POLARITY:
        val = GetControl(OMAP24XX_GPMC_CONFIG1_1, 0x03, 16);  // get this wait pin
        return GetControl(OMAP24XX_GPMC_CONFIG, 0x01, 8 + val);  // get this polaritiy
    case WRITE_PROTECT:     return GetControl(OMAP24XX_GPMC_CONFIG, 0x01, 4);
    case WAIT_PIN_COUNT:    return 4;
    default:                return 0;
    }
    */
    return TRUE;
}

/** SYS_SetCSControl ********************************************************/
/*                                                                          */
/****************************************************************************/

BOOL SYS_SetCSControl(DWORD type, DWORD value)
{
//    DWORD val1, val2;
/*
    // handle general configuration
    switch (type)
    {
    case WRAP_BURST:        return SetControl(OMAP24XX_GPMC_CONFIG1_1, 0x01, 31, value);
    case READ_MULTIPLE:     return SetControl(OMAP24XX_GPMC_CONFIG1_1, 0x01, 30, value);
    case READ_TYPE:         return SetControl(OMAP24XX_GPMC_CONFIG1_1, 0x01, 29, value);
    case WRITE_TYPE:        return SetControl(OMAP24XX_GPMC_CONFIG1_1, 0x01, 27, value);
    case CLOCK_START:       return SetControl(OMAP24XX_GPMC_CONFIG1_1, 0x03, 25, value);
    // *** should do page length logically ***
    case DEV_PAGE_LENGTH:   return SetControl(OMAP24XX_GPMC_CONFIG1_1, 0x03, 23, value);
    case HANDSHAKE_READ:    return SetControl(OMAP24XX_GPMC_CONFIG1_1, 0x01, 22, value);
    case HANDSHAKE_WRITE:   return SetControl(OMAP24XX_GPMC_CONFIG1_1, 0x01, 21, value);
    case HANDSHAKE_TIMING:  return SetControl(OMAP24XX_GPMC_CONFIG1_1, 0x03, 18, value);
    case CS_WAIT_PIN:       return SetControl(OMAP24XX_GPMC_CONFIG1_1, 0x03, 16, value);
    case TIME_SCALE:        return SetControl(OMAP24XX_GPMC_CONFIG1_1, 0x01,  4, value);
    // do divisor logically
    case CS_CLOCK_DIVISOR:
        if (0 == value || 4 < value) return FALSE;
        return SetControl(OMAP24XX_GPMC_CONFIG1_1, 0x03,  0, value - 1);
    case CS_OFF_WRITE:      return SetControl(OMAP24XX_GPMC_CONFIG2_1, 0x1F, 16, value);
    case CS_OFF_READ:       return SetControl(OMAP24XX_GPMC_CONFIG2_1, 0x1F,  8, value);
    case CS_DELAY_HALF:     return SetControl(OMAP24XX_GPMC_CONFIG2_1, 0x01,  7, value);
    case CS_ON:             return SetControl(OMAP24XX_GPMC_CONFIG2_1, 0x0F,  0, value);
    case ADV_OFF_WRITE:     return SetControl(OMAP24XX_GPMC_CONFIG3_1, 0x1F, 16, value);
    case ADV_OFF_READ:      return SetControl(OMAP24XX_GPMC_CONFIG3_1, 0x1F,  8, value);
    case ADV_DELAY_HALF:    return SetControl(OMAP24XX_GPMC_CONFIG3_1, 0x01,  7, value);
    case ADV_ON:            return SetControl(OMAP24XX_GPMC_CONFIG3_1, 0x0F,  0, value);
    case WE_OFF:            return SetControl(OMAP24XX_GPMC_CONFIG4_1, 0x1F, 24, value);
    case WE_DELAY_HALF:     return SetControl(OMAP24XX_GPMC_CONFIG4_1, 0x01, 23, value);
    case WE_ON:             return SetControl(OMAP24XX_GPMC_CONFIG4_1, 0x0F, 16, value);
    case OE_OFF:            return SetControl(OMAP24XX_GPMC_CONFIG4_1, 0x1F,  8, value);
    case OE_DELAY_HALF:     return SetControl(OMAP24XX_GPMC_CONFIG4_1, 0x01,  7, value);
    case OE_ON:             return SetControl(OMAP24XX_GPMC_CONFIG4_1, 0x0F,  0, value);
    case PAGE_BURST_DELAY:  return SetControl(OMAP24XX_GPMC_CONFIG5_1, 0x0F, 24, value);
    case READ_WAIT_STATES:  return SetControl(OMAP24XX_GPMC_CONFIG5_1, 0x1F, 16, value);
    case WRITE_CYCLE_TIME:  return SetControl(OMAP24XX_GPMC_CONFIG5_1, 0x1F,  8, value);
    case READ_CYCLE_TIME:   return SetControl(OMAP24XX_GPMC_CONFIG5_1, 0x1F,  0, value);
    case IDLE_CS_HIGH:      return SetControl(OMAP24XX_GPMC_CONFIG6_1, 0x0F,  8, value);
    case IDLE_CS_SAME:      return SetControl(OMAP24XX_GPMC_CONFIG6_1, 0x01,  7, value);
    case IDLE_CS_DIFF:      return SetControl(OMAP24XX_GPMC_CONFIG6_1, 0x01,  6, value);
    case BUS_TURN_AROUND:   return SetControl(OMAP24XX_GPMC_CONFIG6_1, 0x0F,  0, value);
    case CS_WAIT_POLARITY:
        if (1 < value) return FALSE;
        val1 = GetControl(OMAP24XX_GPMC_CONFIG1_1, 0x03, 16); // get this wait pin
        val2 = GetControl(OMAP24XX_GPMC_CONFIG, 0x01, 8 + val1);
        if (val2 == value) return TRUE; // don't glitch pin
        return SetControl(OMAP24XX_GPMC_CONFIG, 0x01, 8 + val1, value);
    case WRITE_PROTECT:     return SetControl(OMAP24XX_GPMC_CONFIG, 0x01, 4, value);

    // handle config time only configuration
    default:
        // do not allow changes to reserved or boot regions
        switch (type)
        {
        case MULTIPLEX_STATE:   return SetControl(OMAP24XX_GPMC_CONFIG1_1, 0x01,  9, value);
        case INTF_TYPE:
            if (INTF_NOR == value || INTF_NAND == value)
                return SetControl(OMAP24XX_GPMC_CONFIG1_1, 0x03, 10, value);
            else return FALSE;
        // do bus width as 8, 16
        case BUS_WIDTH:
            switch (value)
            {
            case 8: value = 0; break;
            case 16: value = 1; break;
            default: return FALSE;
            }
            return SetControl(OMAP24XX_GPMC_CONFIG1_1, 0x01, 12, value);
        // do size logically
        case CS_SIZE:
            switch (value)
            {
            case 0x08000000: value = 0x08; break;
            case 0x04000000: value = 0x0C; break;
            case 0x02000000: value = 0x0E; break;
            case 0x01000000: value = 0x0F; break;
            default: return 0;
            }
            return SetControl(OMAP24XX_GPMC_CONFIG7_1, 0x0F, 8, value);
        case CS_VALID:
            if (SetControl(OMAP24XX_GPMC_CONFIG7_1, 0x01,  6, value))
                return TRUE;
            return FALSE;
        // do base logically *** should confirm no overlaps first ***
        case CS_BASE:           return SetControl(OMAP24XX_GPMC_CONFIG7_1, 0x3F,  0, value >> 24);
        default:                return FALSE;
        }
    }
    */
    return TRUE;
}

