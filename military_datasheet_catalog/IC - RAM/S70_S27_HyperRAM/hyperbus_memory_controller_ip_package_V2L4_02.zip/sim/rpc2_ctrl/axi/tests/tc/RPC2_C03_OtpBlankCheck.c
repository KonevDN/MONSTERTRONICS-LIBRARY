#ifdef SIMULATION
#include "sltapi_sim.h"
#include "svdpi.h"
#include "dpiheader.h"
#include <math.h>
#include "rpc2_vlld.h"
#include "rpc2_llops.h"
#else
#include <sltapi.h>
#endif
#include "rpc2.h"
#ifdef NCSC
extern int io_printf(const char *fmt, ...);
#define printf io_printf
#endif

char Script[] = "C03_OtpBlankCheck 1";
char TestTitle[] = "Test initial contents of OTP";

DWORD R_V_LOOP = 1;   // "rv"

PDEV pDevice;
BYTE *pSrcData = (BYTE *)NULL;
BYTE *pDestData = (BYTE *)NULL;
STS t0, t1;
char s[81];

void Disp_Reg0(struct OTP_REG0 * reg);
void print_buf(DWORD base, BYTE * buff, DWORD count);
DWORD test_exit(DWORD exit_val);

#ifdef SIMULATION
int c_test()
#else
int main(int argc, char* argv[])
#endif
{

    int i, loop, errcnt;

    printf("Test: %s\n", Script);
    printf("%s\n", TestTitle);

#ifndef SIMULATION
    LOOP_COUNT      = GetGlobalVar("LOOP_COUNT");
    SOE             = GetGlobalVar("SOE");
    SKIP            = GetGlobalVar("SKIP");
    TOTALSECTORS    = GetGlobalVar("TOTALSECTORS");
    BUFSIZE         = GetGlobalVar("BUFSIZE"); 
    LARGESECSIZE    = GetGlobalVar("LARGESECSIZE"); 
#else
    LOOP_COUNT      = 1;
    SOE             = SOE_SETTING;
    SKIP            = 0;
    TOTALSECTORS    = 2;
    BUFSIZE         = 256; 
    LARGESECSIZE    = 256; 
#endif

    if (SKIP)
    {
        line_space(2);
        printf("Test is skipped\n");
        return __LINE__;
    }

#ifdef SIMULATION
    pDevice = NewDeviceObject(0, RPC);
#endif
	pDevice = Find_Device(RPC);

    if (!pDevice)
    {
        line_space(2);
        printf("Error: RPC device not found\n");
        return __LINE__;
    }
    printf("Device: %s\n", (char *) SCRPGetFAPIInfo(pDevice, DEVICE_NAME));

//    GetArg("rv", &R_V_LOOP);
    SYS_GetTimestamp(&t0);
    pSrcData = (BYTE *) malloc(OTP_SIZE);
    pDestData = (BYTE *) malloc(OTP_SIZE);
    if (!pSrcData || !pDestData)
    {
        printf("Error: Malloc error\n");
        return test_exit(__LINE__);
    }

    FillBuffer(BYTES_ARE_0XFF, pSrcData, OTP_SIZE);
    printf("OTPSIZE=%d, CNT=%d\n",OTP_SIZE,OTP_REG_CNT);
    // read OTP area and check if it is blank
    for (loop = 1; loop <= R_V_LOOP; loop++)
    {
        line_space(2);
        printf("loop = %d\n", loop);
        errcnt = 0;
        SCRPQSPIReadOTP(pDevice, (WORD *) pDestData, 0, OTP_SIZE);
        if (memcmp(pSrcData, pDestData, OTP_SIZE))
        {
            for (i = 16; i < OTP_SIZE; i++)     // skip the first 16-byte
            {
                if (pDestData[i] != pSrcData[i])
                {
                    printf("Error: addr 0x%08X read 0x%02X expect 0x%02X\n", i, pDestData[i], pSrcData[i]);
                    errcnt++;
                }
            }
        }
        if (errcnt)
        {
            printf("Error: OTP blank check at loop %d.... FAIL\n", loop);
            if (SOE)
                return test_exit(__LINE__);
        }
        else
        {
            #ifndef SIMULATION
            SYS_WaitUSec(5000);
            #endif
            printf("OTP blank check at loop %d.... PASS\n", loop);
        }
    }

    line_space(2);
    printf("Test complete\n");
    #ifndef SIMULATION
    if (TASK_DELAY)
        SYS_OSTickDelay(TASK_DELAY);
    #endif
    return test_exit(0);
} // main()

DWORD test_exit(DWORD exit_val)
{

    if (pSrcData)
        free(pSrcData);

    if (pDestData)
        free(pDestData);

    SYS_GetTimestamp(&t1);
    FormatDeltaTime(s, &t0, &t1);
    printf("Test time: %s\n", s);

    if (exit_val)
    {
        SetGlobalVar("SKIP", 1);
	printf("<TC> Test =========================== Fail\n");
    }
    else {
      printf("<TC> Test =========================== Pass\n");
    }

    return(exit_val);
} // test_exit()


