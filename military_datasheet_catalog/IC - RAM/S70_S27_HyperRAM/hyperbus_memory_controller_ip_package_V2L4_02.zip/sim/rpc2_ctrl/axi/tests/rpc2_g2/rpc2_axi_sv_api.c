//===========================================================================
//
//  rpc2_api_sv_api.c
//
//   @author  Yuichi Ise (yuichi.ise@spansion.com)
//   @version 0.1
//   @since   06/21/2013
//
//===========================================================================
#include "dpiheader.h"
#include "rpc2_common.h"

//===========================================================
// DEFINITIONS
//===========================================================
//#define AXI_MSG(fmt, args ...)    printf("[AXI]"); printf(fmt, ## args)
#define AXI_MSG(fmt, args ...)


//===========================================================
//  C to/from SV APIs
//===========================================================
void waitNs(DWORD num_ns)
{
  DPI_waitNs(num_ns);
}

void waitUs(DWORD num_us)
{
  DPI_waitUs(num_us);
}

DWORD genRndAddr (void)
{
  DWORD addr;

  DPI_genRndAddr(&addr);
  return addr;
}

DWORD genRndAddr4 (void)
{
  DWORD addr;

  DPI_genRndAddr(&addr);
  addr -= addr%4;
  return addr;
}

// len8: data length in 8-bit
void genRndData (void* genData,
		 DWORD len8)
{
  DWORD i;
  BYTE* data8 = (BYTE*)genData;

  DPI_genRndData(len8);
  for (i = 0; i < len8; i++) {
    DPI_outputData(i, &data8[i]);
  }
}

DWORD genRndLen (void)
{
  DWORD data;
  genRndData(&data, 4);
  data = data % MAX_LEN;
  if (data == 0) {
    data = MAX_LEN;
  }
  return data;
}

DWORD genRndDataLimit(DWORD maxData)
{
  DWORD data;
  genRndData(&data, 4);
  data = data % (maxData+1);
  return data;
}

void getRpcClkPeriod(DWORD* rpc_clk)
{
  DPI_getRpcClkPeriod(rpc_clk);
}

void getAxiClkPeriod(DWORD* axi_clk)
{
  DPI_getAxiClkPeriod(axi_clk);
}

void setRndDelay(int target, int maxBurst, int maxWait)
{
  DPI_setRndDelay(target, maxBurst, maxWait);
}

void startCScnt(int cs)
{
  DPI_startCScnt(cs);
}

void endCScnt(int cs)
{
  DPI_endCScnt(cs);
}

void getCScnt(int cs, DWORD* cs_neg_cnt)
{
  DPI_getCScnt(cs, cs_neg_cnt);
}

void start2CScntArbitration(int cs)
{
  DPI_start2CScntArbitration(cs);
}

void end2CScntArbitration(void)
{
  DPI_end2CScntArbitration();
}

void get2CScntArbitration(int arbitration, DWORD* cs_neg_cnt_write, DWORD* cs_neg_cnt_read)
{
  int i;
  for (i=0; i<arbitration; i++) {
    DPI_get2CScntArbitration(i, &cs_neg_cnt_write[i], &cs_neg_cnt_read[i]);
  }
}

////////////////////////////////////
// Reset
////////////////////////////////////
void AXIREG_reset(void)
{
  DPI_resetReg();
}

void AXIMEM_reset(void)
{
  DPI_resetMem();
}


////////////////////////////////////
// Write Data
////////////////////////////////////
#ifdef STRESS_TEST
static void writeDataStress(int target,
                            DWORD address,
		            DWORD dataLen8,
		            DWORD burst,
		            DWORD size,
		            BYTE* wrData8,
		            BYTE* wrResp)
{
  int i;
  DWORD len;
  DWORD addr;
  DWORD burstLen;
  DWORD xferSize;
  DWORD inPtr;
  BYTE response;

  xferSize = 1 << size;
  //burstLen = ((address%xferSize)+dataLen8+(xferSize-1))/xferSize;
  burstLen = (dataLen8+(xferSize-1))/xferSize;
  *wrResp = 0;
  while (burstLen != 0) {
    inPtr = 0;
    addr = address;
    if (burstLen > MAX_LEN) {
      len = MAX_LEN;
    }
    else {
      len = burstLen;
    }
    for (i = addr%xferSize; i < (len*xferSize); i++) {
      if (dataLen8 == 0) {
	break;
      }
      DPI_inputData(inPtr++, *wrData8++);
      if (burst != 0) {
	address++;
      }
      dataLen8--;
    }
    DPI_writeBurstStress(target, addr, len-1, burst, size);
    DPI_getWriteRespStress(target, &response);
    *wrResp |= response;
    burstLen -= len;
  }
}
#else
static void writeData(DWORD address,
		      DWORD dataLen8,
		      DWORD burst,
		      DWORD size,
		      BYTE* wrData8,
		      BYTE* wrResp)
{
  int i;
  DWORD len;
  DWORD addr;
  DWORD burstLen;
  DWORD xferSize;
  DWORD inPtr;
  BYTE response;

  xferSize = 1 << size;
  //burstLen = ((address%xferSize)+dataLen8+(xferSize-1))/xferSize;
  burstLen = (dataLen8+(xferSize-1))/xferSize;
  *wrResp = 0;
  while (burstLen != 0) {
    inPtr = 0;
    addr = address;
    if (burstLen > MAX_LEN) {
      len = MAX_LEN;
    }
    else {
      len = burstLen;
    }
    for (i = addr%xferSize; i < (len*xferSize); i++) {
      if (dataLen8 == 0) {
	break;
      }
      DPI_inputData(inPtr++, *wrData8++);
      if (burst != 0) {
	address++;
      }
      dataLen8--;
    }
    DPI_writeBurst(addr, len-1, burst, size);
    DPI_getWriteResp(&response);
    *wrResp |= response;
    burstLen -= len;
  }
}
#endif

int AXIREG_writeData(DWORD address,
		     DWORD* wdata)
{
  int ret = NO_ERROR;
  BYTE resp;

  AXI_MSG("AXIREG_writeData: addr 0x%08X\n", address);
#if (RPC2_CTRL_IP_VER < 200)
  while (address%4) {
    address--;
  }
#endif
  DPI_selectTarget(REG);
#ifdef STRESS_TEST
  writeDataStress(REG, address, 4, INCR, BYTE_4, (BYTE*)wdata, &resp);
#else
  writeData(address, 4, INCR, BYTE_4, (BYTE*)wdata, &resp);
#endif
  if (resp != 0) {
    ret = RESP_ERROR;
    MSG("AXIREG_writeData: Resp 0x%0X\n", resp);
  }
  return ret;
}

int AXIREG_writeData16(DWORD address,
		       WORD* wdata)
{
  int ret = NO_ERROR;
  BYTE resp;

  AXI_MSG("AXIREG_writeData16: addr 0x%08X\n", address);
  DPI_selectTarget(REG);
#ifdef STRESS_TEST
  writeDataStress(REG, address, 2, INCR, BYTE_2, (BYTE*)wdata, &resp);
#else
  writeData(address, 2, INCR, BYTE_2, (BYTE*)wdata, &resp);
#endif
  if (resp != 0) {
    ret = RESP_ERROR;
    MSG("AXIREG_writeData16: Resp 0x%0X\n", resp);
  }
  return ret;
}

int AXIREG_writeData8(DWORD address,
		      BYTE* wdata)
{
  int ret = NO_ERROR;
  BYTE resp;

  AXI_MSG("AXIREG_writeData8: addr 0x%08X\n", address);
  DPI_selectTarget(REG);
#ifdef STRESS_TEST
  writeDataStress(REG, address, 1, INCR, BYTE_1, wdata, &resp);
#else
  writeData(address, 1, INCR, BYTE_1, wdata, &resp);
#endif
  if (resp != 0) {
    ret = RESP_ERROR;
    MSG("AXIREG_writeData8: Resp 0x%0X\n", resp);
  }
  return ret;
}

int AXIMEM_writeData32(DWORD address,
		       DWORD len,
		       DWORD* wdata)
{
  int ret = NO_ERROR;
  BYTE resp;

  AXI_MSG("AXIMEM_writeData32: addr 0x%08X, len 0x%05X\n", address, len);
  DPI_selectTarget(MEM);
#ifdef STRESS_TEST
  writeDataStress(MEM, address, len*4, INCR, BYTE_4, (BYTE*)wdata, &resp);
#else
  writeData(address, len*4, INCR, BYTE_4, (BYTE*)wdata, &resp);
#endif
  if (resp != 0) {
    ret = RESP_ERROR;
    MSG("AXIMEM_writeData32: Resp 0x%0X\n", resp);
  }
  return ret;
}

int AXIMEM_writeData16(DWORD address,
		       DWORD len16,
		       WORD* wdata)
{
  int ret = NO_ERROR;
  BYTE resp;

  AXI_MSG("AXIMEM_writeData16: addr 0x%08X, len 0x%05X\n", address, len16);
#if (RPC2_CTRL_IP_VER < 200)
  while (address%2) {
    address--;
  }
#endif
  DPI_selectTarget(MEM);
#ifdef STRESS_TEST
  writeDataStress(MEM, address, len16*2, INCR, BYTE_2, (BYTE*)wdata, &resp);
#else
  writeData(address, len16*2, INCR, BYTE_2, (BYTE*)wdata, &resp);
#endif
  if (resp != 0) {
    ret = RESP_ERROR;
    MSG("AXIMEM_writeData16: Resp 0x%0X\n", resp);
  }
  return ret;
}

int AXIMEM_writeData8(DWORD address,
		      DWORD len8,
		      BYTE* wdata)
{
  int ret = NO_ERROR;
  BYTE resp;

  AXI_MSG("AXIMEM_writeData8: addr 0x%08X, len 0x%05X\n", address, len8);
  DPI_selectTarget(MEM);
#ifdef STRESS_TEST
  writeDataStress(MEM, address, len8, INCR, BYTE_1, wdata, &resp);
#else
  writeData(address, len8, INCR, BYTE_1, wdata, &resp);
#endif
  if (resp != 0) {
    ret = RESP_ERROR;
    MSG("AXIMEM_writeData8: Resp 0x%0X\n", resp);
  }
  return ret;
}

////////////////////////////////////
// Read Data
////////////////////////////////////
#ifdef STRESS_TEST
static void readDataStress(int target,
                           DWORD address,
		           DWORD dataLen8,
		           DWORD burst,
		           DWORD size,
		           BYTE* rdData8, 
		           BYTE* rdResp)
{
  int i;
  DWORD len;
  DWORD addr;
  DWORD burstLen;
  DWORD xferSize;
  //  DWORD addrHold;
  //  DWORD burstLenHold;
  DWORD outPtr;
  BYTE response;


  xferSize = 1 << size;
  //burstLen = ((address%xferSize)+dataLen8+(xferSize-1))/xferSize;
  burstLen = (dataLen8+(xferSize-1))/xferSize;
  *rdResp = 0;
  /*
  burstLenHold = burstLen;
  addrHold = address;
  while (burstLen != 0) {
    addr = address;
    if (burstLen > MAX_LEN) {
      len = MAX_LEN;
    }
    else {
      len = burstLen;
    }
    DPI_readBurst(addr, len-1, burst, size);
    for (i = addr%xferSize; i < (len*xferSize); i++) {
      if (burst != FIXED) {
	address++;
      }
    }
    burstLen -= len;
  }
  burstLen = burstLenHold;
  address = addrHold;
  while (burstLen != 0) {
    outPtr = 0;
    addr = address;
    if (burstLen > MAX_LEN) {
      len = MAX_LEN;
    }
    else {
      len = burstLen;
    }
    DPI_getReadData();
    for (i = addr%xferSize; i < (len*xferSize); i++) {
      if (dataLen8 == 0) {
	break;
      }
      DPI_outputData(outPtr++, rdData8++);
      if (burst != 0) {
	address++;
      }
      dataLen8--;
    }
    for (i = 0; i < len; i++) {
      DPI_outputRdResp(i, &response);
      *rdResp |= response;
    }
    burstLen -= len;
  }
*/

  while (burstLen != 0) {
    outPtr = 0;
    addr = address;
    if (burstLen > MAX_LEN) {
      len = MAX_LEN;
    }
    else {
      len = burstLen;
    }
    DPI_readBurstStress(target, addr, len-1, burst, size);
    DPI_getReadDataStress(target, addr);
    for (i = addr%xferSize; i < (len*xferSize); i++) {
      if (dataLen8 == 0) {
	break;
      }
//      DPI_outputData(outPtr++, rdData8++);
      DPI_outputDataStress(target, outPtr++, rdData8++);
      if (burst != 0) {
	address++;
      }
      dataLen8--;
    }
    for (i = 0; i < len; i++) {
//      DPI_outputRdResp(i, &response);
      DPI_outputRdRespStress(target, i, &response);
      *rdResp |= response;
    }
    burstLen -= len;
  }
}
#else
static void readData(DWORD address,
		     DWORD dataLen8,
		     DWORD burst,
		     DWORD size,
		     BYTE* rdData8, 
		     BYTE* rdResp)
{
  int i;
  DWORD len;
  DWORD addr;
  DWORD burstLen;
  DWORD xferSize;
  //  DWORD addrHold;
  //  DWORD burstLenHold;
  DWORD outPtr;
  BYTE response;


  xferSize = 1 << size;
  //burstLen = ((address%xferSize)+dataLen8+(xferSize-1))/xferSize;
  burstLen = (dataLen8+(xferSize-1))/xferSize;
  *rdResp = 0;
  /*
  burstLenHold = burstLen;
  addrHold = address;
  while (burstLen != 0) {
    addr = address;
    if (burstLen > MAX_LEN) {
      len = MAX_LEN;
    }
    else {
      len = burstLen;
    }
    DPI_readBurst(addr, len-1, burst, size);
    for (i = addr%xferSize; i < (len*xferSize); i++) {
      if (burst != FIXED) {
	address++;
      }
    }
    burstLen -= len;
  }
  burstLen = burstLenHold;
  address = addrHold;
  while (burstLen != 0) {
    outPtr = 0;
    addr = address;
    if (burstLen > MAX_LEN) {
      len = MAX_LEN;
    }
    else {
      len = burstLen;
    }
    DPI_getReadData();
    for (i = addr%xferSize; i < (len*xferSize); i++) {
      if (dataLen8 == 0) {
	break;
      }
      DPI_outputData(outPtr++, rdData8++);
      if (burst != 0) {
	address++;
      }
      dataLen8--;
    }
    for (i = 0; i < len; i++) {
      DPI_outputRdResp(i, &response);
      *rdResp |= response;
    }
    burstLen -= len;
  }
*/

  while (burstLen != 0) {
    outPtr = 0;
    addr = address;
    if (burstLen > MAX_LEN) {
      len = MAX_LEN;
    }
    else {
      len = burstLen;
    }
    DPI_readBurst(addr, len-1, burst, size);
//#ifdef STRESS_TEST
//    DPI_getReadDataStress(addr);
//#else
    DPI_getReadData();
//#endif
    for (i = addr%xferSize; i < (len*xferSize); i++) {
      if (dataLen8 == 0) {
	break;
      }
      DPI_outputData(outPtr++, rdData8++);
      if (burst != 0) {
	address++;
      }
      dataLen8--;
    }
    for (i = 0; i < len; i++) {
      DPI_outputRdResp(i, &response);
      *rdResp |= response;
    }
    burstLen -= len;
  }
}
#endif

int AXIREG_readData(DWORD address,
		    DWORD* rdata)
{
  int ret = NO_ERROR;
  BYTE resp;

  AXI_MSG("AXIREG_readData: addr 0x%08X\n", address);
#if (RPC2_CTRL_IP_VER < 200)
  while (address%4) {
    address--;
  }
#endif
  DPI_selectTarget(REG);
#ifdef STRESS_TEST
  readDataStress(REG, address, 4, INCR, BYTE_4, (BYTE*)rdata, &resp);
#else
  readData(address, 4, INCR, BYTE_4, (BYTE*)rdata, &resp);
#endif
  if (resp != 0) {
    ret = RESP_ERROR;
    MSG("AXIREG_readData: Resp 0x%0X\n", resp);
  }
  return ret;
}

int AXIREG_readData16(DWORD address,
		      WORD* rdata)
{
  int ret = NO_ERROR;
  BYTE resp;

  AXI_MSG("AXIREG_readData16: addr 0x%08X\n", address);
  DPI_selectTarget(REG);
#ifdef STRESS_TEST
  readDataStress(REG, address, 2, INCR, BYTE_2, (BYTE*)rdata, &resp);
#else
  readData(address, 2, INCR, BYTE_2, (BYTE*)rdata, &resp);
#endif
  if (resp != 0) {
    ret = RESP_ERROR;
    MSG("AXIREG_readData16: Resp 0x%0X\n", resp);
  }
  return ret;
}

int AXIREG_readData8(DWORD address,
		     BYTE* rdata)
{
  int ret = NO_ERROR;
  BYTE resp;

  AXI_MSG("AXIREG_readData8: addr 0x%08X\n", address);
  DPI_selectTarget(REG);
#ifdef STRESS_TEST
  readDataStress(REG, address, 1, INCR, BYTE_1, rdata, &resp);
#else
  readData(address, 1, INCR, BYTE_1, rdata, &resp);
#endif
  if (resp != 0) {
    ret = RESP_ERROR;
    MSG("AXIREG_readData8: Resp 0x%0X\n", resp);
  }
  return ret;
}

int AXIMEM_readData(DWORD address,
		    DWORD len,
		    DWORD* rdata)
{
  int ret = NO_ERROR;
  BYTE resp;

  AXI_MSG("AXIMEM_readData: addr 0x%08X, len 0x%05X\n", address, len);
#if (RPC2_CTRL_IP_VER < 200)
  while (address%2) {
    address--;
  }
#endif
  DPI_selectTarget(MEM);
#ifdef STRESS_TEST
  readDataStress(MEM, address, len*4, INCR, BYTE_4, (BYTE*)rdata, &resp);
#else
  readData(address, len*4, INCR, BYTE_4, (BYTE*)rdata, &resp);
#endif
  if (resp != 0) {
    ret = RESP_ERROR;
    MSG("AXIMEM_readData: Resp 0x%0X\n", resp);
  }
  return ret;
}

int AXIMEM_readData16(DWORD address,
		      DWORD len16,
		      WORD* rdata)
{
  int ret = NO_ERROR;
  BYTE resp;

  AXI_MSG("AXIMEM_readData16: addr 0x%08X, len 0x%05X\n", address, len16);
#if (RPC2_CTRL_IP_VER < 200)
  while (address%2) {
    address--;
  }
#endif
  DPI_selectTarget(MEM);
#ifdef STRESS_TEST
  readDataStress(MEM, address, len16*2, INCR, BYTE_2, (BYTE*)rdata, &resp);
#else
  readData(address, len16*2, INCR, BYTE_2, (BYTE*)rdata, &resp);
#endif
  if (resp != 0) {
    ret = RESP_ERROR;
    MSG("AXIMEM_readData16: Resp 0x%0X\n", resp);
  }
  return ret;
}

int AXIMEM_readData8(DWORD address,
		     DWORD len8,
		     BYTE* rdata)
{
  int ret = NO_ERROR;
  BYTE resp;

  AXI_MSG("AXIMEM_readData8: addr 0x%08X, len 0x%05X\n", address, len8);
  DPI_selectTarget(MEM);
#ifdef STRESS_TEST
  readDataStress(MEM, address, len8, INCR, BYTE_1, rdata, &resp);
#else
  readData(address, len8, INCR, BYTE_1, rdata, &resp);
#endif
  if (resp != 0) {
    ret = RESP_ERROR;
    MSG("AXIMEM_readData8: Resp 0x%0X\n", resp);
  }
  return ret;
}

////////////////////////////////////
// Write Burst
////////////////////////////////////
// @param burstLen  burst length (1 - 256)
void writeBurst (int target,
		 unsigned int addr,
		 unsigned int burstLen,
		 unsigned int burstType,
		 unsigned int burstSize,
		 void* buf)
{
  unsigned int i;
  unsigned char* buf8;
  unsigned dataLen8;

  AXI_MSG("writeBurst: addr 0x%08X, len 0x%03X, type %d, size %d\n",
	  addr, burstLen, burstType, burstSize);
  buf8 = (unsigned char*)buf;
  dataLen8 = burstLen * (1 << burstSize);

  DPI_selectTarget(target);
  for (i = 0; i < dataLen8; i++) {
    DPI_inputData(i, buf8[i]);
  }
#ifdef STRESS_TEST
  DPI_writeBurstStress(target, addr, burstLen-1, burstType, burstSize);
#else
  DPI_writeBurst(addr, burstLen-1, burstType, burstSize);
#endif
}

void AXIMEM_writeBurst16(DWORD address,
		         DWORD burstLen,
		         WORD* wdata)
{
  writeBurst(MEM, address, burstLen, INCR, BYTE_2, wdata);
}

void AXIMEM_writeBurst8(DWORD address,
		        DWORD burstLen,
		        BYTE* wdata)
{
  writeBurst(MEM, address, burstLen, INCR, BYTE_1, wdata);
}

void AXIMEM_writeBurst32(DWORD address,
		         DWORD burstLen,
		         DWORD* wdata)
{
  writeBurst(MEM, address, burstLen, INCR, BYTE_4, wdata);
}

void getWriteResp (int target,
		   unsigned char* resp)
{
  AXI_MSG("getWriteResp\n");
  DPI_selectTarget(target);
#ifdef STRESS_TEST
  DPI_getWriteRespStress(target, resp);
#else
  DPI_getWriteResp(resp);
#endif
}

int AXIMEM_getWriteResp(void)
{
  int ret = NO_ERROR;
  BYTE resp;
  getWriteResp(MEM, &resp);
  if (resp) {
    ret = RESP_ERROR;
  }
  return ret;
}

void getWriteRespIndex(int target,
		       unsigned char* resp,
                       unsigned int wrPtr)
{
  AXI_MSG("getWriteRespIndex\n");
  DPI_selectTarget(target);
#if (MAX_LEN==16)
#ifdef STRESS_TEST
  DPI_getWriteRespIndexStress(target, resp, wrPtr);
#else
  DPI_getWriteRespIndex(resp, wrPtr);
#endif
#endif
}

int AXIMEM_getWriteRespIndex(unsigned int wrPtr)
{
  int ret = NO_ERROR;
  BYTE resp;
  getWriteRespIndex(MEM, &resp, wrPtr);
  if (resp) {
    ret = RESP_ERROR;
  }
  return ret;
}

void writeBurstStrobe(int target,
        unsigned int addr,
        unsigned int burstLen,
        unsigned int burstType,
        unsigned int burstSize,
        void* buf,
        void* strb)
{
    unsigned int i;
    unsigned char* buf8;
    unsigned dataLen8;

    AXI_MSG("writeBurstStrobe: addr 0x%08X, len 0x%03X, type %d, size %d\n",
        addr, burstLen, burstType, burstSize);

    DPI_selectTarget(target);

    buf8 = (unsigned char*)buf;
    dataLen8 = burstLen * (1 << BYTE_4);
    for (i = 0; i < dataLen8; i++) {
        DPI_inputData(i, buf8[i]);
    }

    buf8 = (unsigned char*)strb;
    for(i = 0; i < burstLen; i++) {
        if(i % 2) {
            DPI_inputStrobe(i, buf8[(i-1)/2]);
        } else {
            DPI_inputStrobe(i, buf8[i/2] >> 4);
        }
    }
#ifdef STRESS_TEST
    DPI_writeBurstStrobeStress(target, addr, burstLen-1, burstType, burstSize);
#else
    DPI_writeBurstStrobe(addr, burstLen-1, burstType, burstSize);
#endif
}

////////////////////////////////////
// Write Address/Burst Data
////////////////////////////////////
// @param burstLen  burst length (1 - 256)
void writeAddress (int target,
                   unsigned int wrid,
		   unsigned int addr,
		   unsigned int burstLen,
		   unsigned int burstType,
		   unsigned int burstSize,
                   unsigned int *wrPtr)
{
  AXI_MSG("writeAddress: addr 0x%08X, len 0x%03X, type %d, size %d, wrid %d\n",
	  addr, burstLen, burstType, burstSize, wrid);

  DPI_selectTarget(target);
#if (MAX_LEN==16)
#ifdef STRESS_TEST
  DPI_writeAddressStress(target, wrid, addr, burstLen-1, burstType, burstSize, wrPtr);
#else
  DPI_writeAddress(wrid, addr, burstLen-1, burstType, burstSize, wrPtr);
#endif
#endif
}

void writeBurstData (int target,
                     unsigned int wrid,
                     unsigned int addr,
                     unsigned int burstLen,
                     unsigned int burstType,
                     unsigned int burstSize,
                     void* buf,
                     unsigned int wrPtr)
{
    unsigned int i;
    unsigned char* buf8;
    unsigned dataLen8;

    AXI_MSG("writeBurstData: addr 0x%08X, len 0x%03X, type %d, size %d, wrid %d\n",
            addr, burstLen, burstType, burstSize, wrid);

    DPI_selectTarget(target);

    buf8 = (unsigned char*)buf;
    dataLen8 = burstLen * (1 << BYTE_4);
    for (i = 0; i < dataLen8; i++) {
        DPI_inputData(i, buf8[i]);
    }
#if (MAX_LEN==16)
#ifdef STRESS_TEST
    DPI_writeBurstDataStress(target, wrid, addr, burstLen-1, burstType, burstSize, wrPtr);
#else
    DPI_writeBurstData(wrid, addr, burstLen-1, burstType, burstSize, wrPtr);
#endif
#endif
}

void AXIMEM_writeAddress8(DWORD address,
		          DWORD burstLen,
                          DWORD wrid,
                          DWORD *wrPtr)
{
  writeAddress(MEM, wrid, address, burstLen, INCR, BYTE_1, wrPtr);
}

void AXIMEM_writeAddress16(DWORD address,
		           DWORD burstLen,
                           DWORD wrid,
                           DWORD *wrPtr)
{
  writeAddress(MEM, wrid, address, burstLen, INCR, BYTE_2, wrPtr);
}

void AXIMEM_writeAddress32(DWORD address,
		           DWORD burstLen,
                           DWORD wrid,
                           DWORD *wrPtr)
{
  writeAddress(MEM, wrid, address, burstLen, INCR, BYTE_4, wrPtr);
}

void AXIMEM_writeBurstData8(DWORD address,
		            DWORD burstLen,
                            DWORD wrid,
		            BYTE* wdata,
                            DWORD wrPtr)
{
  writeBurstData(MEM, wrid, address, burstLen, INCR, BYTE_1, wdata, wrPtr);
}

void AXIMEM_writeBurstData16(DWORD address,
		             DWORD burstLen,
                             DWORD wrid,
		             WORD* wdata,
                             DWORD wrPtr)
{
  writeBurstData(MEM, wrid, address, burstLen, INCR, BYTE_2, wdata, wrPtr);
}

void AXIMEM_writeBurstData32(DWORD address,
		             DWORD burstLen,
                             DWORD wrid,
		             DWORD* wdata,
                             DWORD wrPtr)
{
  writeBurstData(MEM, wrid, address, burstLen, INCR, BYTE_4, wdata, wrPtr);
}

////////////////////////////////////
// Read Burst
////////////////////////////////////
// @param burstLen  burst length (1 - 256)
void readBurst (int target,
		unsigned int addr,
		unsigned int burstLen,
		unsigned int burstType,
		unsigned int burstSize)
{
  AXI_MSG("readBurst: addr 0x%08X, len 0x%03X, type %d, size %d\n",
	  addr, burstLen, burstType, burstSize);
  DPI_selectTarget(target);
#ifdef STRESS_TEST
  DPI_readBurstStress(target, addr, burstLen-1, burstType, burstSize);
#else
  DPI_readBurst(addr, burstLen-1, burstType, burstSize);
#endif
}

#ifdef STRESS_TEST
void getReadDataRespStress(int target,
             unsigned int addr,
		     unsigned int burstLen,
		     unsigned int burstSize,
		     void* buf,
		     unsigned char resp[])
{
  unsigned int i;
  unsigned char* buf8;
  unsigned dataLen8;

  AXI_MSG("getReadDataResp: len 0x%03X, size %d\n", burstLen, burstSize);
  buf8 = (unsigned char*)buf;
  dataLen8 = burstLen * (1 << burstSize);

  DPI_selectTarget(target);
  DPI_getReadDataStress(target, addr);
  for (i = 0; i < dataLen8; i++) {
//    DPI_outputData(i, &buf8[i]);
    DPI_outputDataStress(target, i, &buf8[i]);
  }
//  MSG("buf8[0]: 0x%08X\n", buf8[0]);
//  MSG("buf8[1]: 0x%08X\n", buf8[1]);
  for (i = 0; i < burstLen; i++) {
//    DPI_outputRdResp(i, &resp[i]);
    DPI_outputRdRespStress(target, i, &resp[i]);
  }
}
#else		
void getReadDataResp(int target,
		     unsigned int burstLen,
		     unsigned int burstSize,
		     void* buf,
		     unsigned char resp[])
{
  unsigned int i;
  unsigned char* buf8;
  unsigned dataLen8;

  AXI_MSG("getReadDataResp: len 0x%03X, size %d\n", burstLen, burstSize);
  buf8 = (unsigned char*)buf;
  dataLen8 = burstLen * (1 << burstSize);

  DPI_selectTarget(target);
  DPI_getReadData();
  for (i = 0; i < dataLen8; i++) {
    DPI_outputData(i, &buf8[i]);
  }
  for (i = 0; i < burstLen; i++) {
    DPI_outputRdResp(i, &resp[i]);
  }
}
#endif

void AXIMEM_readBurst(DWORD address,
		      DWORD burstLen,
		      DWORD burstType)
{
  if (burstType == WRAP) {
    readBurst(MEM, address, burstLen, burstType, BYTE_2);
  }
  else {
    readBurst(MEM, address, burstLen, burstType, BYTE_2);
  }
}

void AXIMEM_readBurst8(DWORD address,
		       DWORD burstLen,
		       DWORD burstType)
{
  if (burstType == WRAP) {
    readBurst(MEM, address, burstLen, burstType, BYTE_1);
  }
  else {
    readBurst(MEM, address, burstLen, burstType, BYTE_1);
  }
}

void AXIMEM_readBurst32(DWORD address,
		        DWORD burstLen,
		        DWORD burstType)
{
  readBurst(MEM, address, burstLen, burstType, BYTE_4);
}

#ifdef STRESS_TEST
int AXIMEM_getDataStress(DWORD address,
                         DWORD burstLen,
                         WORD* buf)
{
  int ret = NO_ERROR;
  DWORD i;
  BYTE resp[MAX_LEN];
  getReadDataRespStress(MEM, address, burstLen, BYTE_2, buf, resp);
  for (i = 0; i < burstLen; i++) {
    if (resp[i]) {
      ret = RESP_ERROR;
    }
  }
  return ret;
}

int AXIMEM_getDataStress8(DWORD address,
                          DWORD burstLen,
                          WORD* buf)
{
  int ret = NO_ERROR;
  DWORD i;
  BYTE resp[MAX_LEN];
  getReadDataRespStress(MEM, address, burstLen, BYTE_1, buf, resp);
  for (i = 0; i < burstLen; i++) {
    if (resp[i]) {
      ret = RESP_ERROR;
    }
  }
  return ret;
}

int AXIMEM_getDataStress32(DWORD address,
                           DWORD burstLen,
                           WORD* buf)
{
  int ret = NO_ERROR;
  DWORD i;
  BYTE resp[MAX_LEN];
  getReadDataRespStress(MEM, address, burstLen, BYTE_4, buf, resp);
  for (i = 0; i < burstLen; i++) {
    if (resp[i]) {
      ret = RESP_ERROR;
    }
  }
  return ret;
}
#else
int AXIMEM_getData(DWORD burstLen, WORD* buf)
{
  int ret = NO_ERROR;
  DWORD i;
  BYTE resp[MAX_LEN];
  getReadDataResp(MEM, burstLen, BYTE_2, buf, resp);
  for (i = 0; i < burstLen; i++) {
    if (resp[i]) {
      ret = RESP_ERROR;
    }
  }
  return ret;
}

int AXIMEM_getData8(DWORD burstLen, BYTE* buf)
{
  int ret = NO_ERROR;
  DWORD i;
  BYTE resp[MAX_LEN];
  getReadDataResp(MEM, burstLen, BYTE_1, buf, resp);
  for (i = 0; i < burstLen; i++) {
    if (resp[i]) {
      ret = RESP_ERROR;
    }
  }
  return ret;
}

int AXIMEM_getData32(DWORD burstLen, DWORD* buf)
{
  int ret = NO_ERROR;
  DWORD i;
  BYTE resp[MAX_LEN];
  getReadDataResp(MEM, burstLen, BYTE_4, buf, resp);
  for (i = 0; i < burstLen; i++) {
    if (resp[i]) {
      ret = RESP_ERROR;
    }
  }
  return ret;
}
#endif

////////////////////////////////////
// Delay
////////////////////////////////////
void waitRndDelayAW(int target)
{
  DPI_selectTarget(target);
  DPI_waitRndDelayAW();
}

void waitRndDelayAR(int target)
{
  DPI_selectTarget(target);
  DPI_waitRndDelayAR();
}

void AXIMEM_idleReadDataUs(DWORD us)
{
  DPI_selectTarget(MEM);
  DPI_idleRdDataChannel(us);
}

////////////////////////////////////
// Overlapped & Parallel
////////////////////////////////////
void overlappedParallelWriteRead (unsigned int rdAddr[], unsigned int* rdData[],
				  unsigned int rdLen[], unsigned int rdResp[],
				  unsigned int wrAddr[], unsigned int* wrData[],
				  unsigned int wrLen[], unsigned int wrResp[])
{
  int i, j;
  unsigned char response;
  unsigned char respArray[256];

  int wrBurstSize = 1;
  int rdBurstSize = 1;

  for (i = 0; i < MAX_OUTSTANDING_TRANS; i++) {
    if (wrLen[i] != 0) {
      waitRndDelayAW(0);
      writeBurst(0, wrAddr[i], wrLen[i]>>wrBurstSize, 1, wrBurstSize, wrData[i]);
    }
    if (rdLen[i] != 0) {
      waitRndDelayAR(0);
      readBurst(0, rdAddr[i], rdLen[i]>>rdBurstSize, 1, rdBurstSize);
    }
  }
  for (i = 0; i < MAX_OUTSTANDING_TRANS; i++) {
    if (wrLen[i] != 0) {
      getWriteResp(0, &response);
      wrResp[i] = (unsigned int)response;
    }
    if (rdLen[i] != 0) {
#ifdef STRESS_TEST
      getReadDataRespStress(0, rdAddr[i], rdLen[i]>>rdBurstSize, rdBurstSize, rdData[i], respArray);
#else
      getReadDataResp(0, rdLen[i]>>rdBurstSize, rdBurstSize, rdData[i], respArray);
#endif
      response = 0;
      for (j = 0; j < (rdLen[i]>>rdBurstSize); j++) {
	response |= respArray[j];
      }
      rdResp[i] = (unsigned int)response;
    }
  }
}
