//===========================================================================
//
//  rpc2_common.h
//
//   @author  Yuichi Ise (yuichi.ise@spansion.com)
//   @version 0.1
//   @since   06/21/2013
//
//===========================================================================
#ifndef __RPC2_COMMON_H__
#define __RPC2_COMMON_H__

#include "rpc2_type.h"

//=============================================================================
//  DEFINITIONS
//=============================================================================
#ifndef RPC2_CTRL_IP_VER
#define RPC2_CTRL_IP_MAJOR_VER     2
//#define RPC2_CTRL_IP_MINOR_VER     2
//#define RPC2_CTRL_IP_REVISION_VER  1
//#define RPC2_CTRL_IP_MINOR_VER     3
#define RPC2_CTRL_IP_MINOR_VER     4
#define RPC2_CTRL_IP_REVISION_VER  0
#define RPC2_CTRL_IP_VER           ((RPC2_CTRL_IP_MAJOR_VER*100) + (RPC2_CTRL_IP_MINOR_VER*10) + RPC2_CTRL_IP_REVISION_VER)
#endif

#ifdef NCSC
extern int io_printf(const char *fmt, ...);
#define printf io_printf
#endif

// Message
#define MSG                        printf
#define ERR_MSG(fmt, args ...)     printf("[ERR]"); printf(fmt, ## args)
#define MSG_PASS                   MSG(" -- PASS.\n")
#define MSG_FAIL                   MSG(" -- FAIL.\n")
#define STR_OK                     "OK"
#define STR_NG                     "NG"

#define NO_ERROR         0
#define ERROR           -1
#define RESP_ERROR      -2
#define ALLOC_ERROR     -3
#define VERIFY_ERROR    -4
#define NOT_SUPPORT     -5
#define RESP_NO_ERROR   -6

#include "rpc2_axi_sv_api.h"
#define RPC2_REG_SIZE   (4)
#define RPC2_RESET_REG  AXIREG_reset
#define RPC2_WRITE_REG  AXIREG_writeData
#define RPC2_READ_REG   AXIREG_readData

#define RPC2_RESET      AXIMEM_reset
#define RPC2_WRITE8     AXIMEM_writeData8
#define RPC2_WRITE      AXIMEM_writeData16
#define RPC2_WRITE32    AXIMEM_writeData32
#define RPC_WRITE_BURST AXIMEM_writeBurst16
#define RPC_WRITE_BURST8 AXIMEM_writeBurst8
#define RPC_WRITE_BURST32 AXIMEM_writeBurst32
#define RPC_GET_WRESP   AXIMEM_getWriteResp
#define RPC2_READ8      AXIMEM_readData8
#define RPC2_READ       AXIMEM_readData16
#define RPC2_READ32     AXIMEM_readData
#define RPC_READ_BURST(address, burstLen)      AXIMEM_readBurst(address, burstLen, INCR)
#define RPC_READ_BURST8(address, burstLen)     AXIMEM_readBurst8(address, burstLen, INCR)
#define RPC_READ_BURST32(address, burstLen)     AXIMEM_readBurst32(address, burstLen, INCR)
#define RPC_READ_WRAP_BURST(address, burstLen) AXIMEM_readBurst(address, burstLen, WRAP)
#define RPC_READ_WRAP_BURST8(address, burstLen) AXIMEM_readBurst8(address, burstLen, WRAP)
#define RPC_READ_WRAP_BURST32(address, burstLen) AXIMEM_readBurst32(address, burstLen, WRAP)
#ifdef STRESS_TEST
#define RPC2_GET_DATA        AXIMEM_getDataStress
#define RPC2_GET_DATA8       AXIMEM_getDataStress8
#define RPC2_GET_DATA32      AXIMEM_getDataStress32
#else
#define RPC2_GET_DATA        AXIMEM_getData
#define RPC2_GET_DATA8       AXIMEM_getData8
#define RPC2_GET_DATA32      AXIMEM_getData32
#endif
#define RPC2_IDLE_READ_DATA  AXIMEM_idleReadDataUs

#define CS0_SEL                  0
#define CS1_SEL                  1

#ifndef CS0_MEM_BASE
#define CS0_MEM_BASE    0x00000000
#endif
#ifndef CS1_MEM_BASE
#define CS1_MEM_BASE    0x01000000
#endif
#ifndef OFFSET
#define OFFSET          0x00000000
#endif

#if (RPC2_CTRL_IP_VER >= 200)
#define REG_CSR_ADDR    0x00000000
#define REG_IEN_ADDR    0x00000004
#define REG_ISR_ADDR    0x00000008
#define REG_ICR_ADDR    0x0000000C
#define REG_MBR0_ADDR   0x00000010
#define REG_MBR1_ADDR   0x00000014
#define REG_MBR2_ADDR   0x00000018
#define REG_MBR3_ADDR   0x0000001C
#define REG_MCR0_ADDR   0x00000020
#define REG_MCR1_ADDR   0x00000024
#define REG_MCR2_ADDR   0x00000028
#define REG_MCR3_ADDR   0x0000002C
#define REG_RWM_ADDR    0x00000030
#if (RPC2_CTRL_IP_VER >= 210)
#define REG_MTR0_ADDR   0x00000030
#define REG_MTR1_ADDR   0x00000034
#define REG_GPOR_ADDR   0x00000040
#define REG_WPR_ADDR    0x00000044
#define REG_LBR_ADDR    0x00000048
#if (RPC2_CTRL_IP_VER >= 240)
#define REG_TAR_ADDR    0x0000004C
#define REG_TOTAL_SIZE  0x00000050
#else
#define REG_TOTAL_SIZE  0x0000004C
#endif
#else
#define REG_WPR_ADDR    0x00000034
#define REG_LBR_ADDR    0x00000038
#define REG_TOTAL_SIZE  0x0000003C
#endif

#define REG_TCSR_ADDR   REG_CSR_ADDR
#define REG_MBR_ADDR    REG_MBR0_ADDR
#define REG_TIR_ADDR    REG_MCR0_ADDR

#define MAX_SUPPORTED_CS_NUM     (2)
#else
// Control Register
#define REG_TCSR_ADDR   0x00000000
#define REG_MBR_ADDR    0x00000004
#define REG_RWM_ADDR    0x00000008
#define REG_WPR_ADDR    0x0000000C
#define REG_IEN_ADDR    0x00000010
#define REG_ISR_ADDR    0x00000014
#define REG_TIR_ADDR    0x00000018
#define REG_LBR_ADDR    0x0000001C

#define REG_TOTAL_SIZE  0x00000020

#define MAX_SUPPORTED_CS_NUM     (1)
#endif

#if (RPC2_CTRL_IP_VER >= 220)
#define WRSTOERR_BIT    0x04000000
#define WTRSERR_BIT     0x02000000
#define WDECERR_BIT     0x01000000
#define WACT_BIT        0x00010000
#define RDSSTALL_BIT    0x00000800
#define RRSTOERR_BIT    0x00000400
#define RTRSERR_BIT     0x00000200
#define RDECERR_BIT     0x00000100
#define RACT_BIT        0x00000001
#else
#define WTQ_BIT         0x01FF0000
#define RTQ_BIT         0x0000001F
#endif
#define INTP_BIT        0x80000000
#define RPCINTE_BIT     0x00000001
#define RPCINTS_BIT     0x00000001
#define A_BIT           0xFF000000
#if (RPC2_CTRL_IP_VER >= 230)
#define MAXEN_BIT       0x80000000
#define MAXLEN_BIT      0x07FC0000
#endif
#define TCMO_BIT        0x00020000
#define ACS_BIT         0x00010000
#define CRT_BIT         0x00000020
#define DEVTYPE_BIT     0x00000010
#define WRAPSIZE_BIT    0x00000003
#define RCSHI_BIT       0xF0000000
#define WCSHI_BIT       0x0F000000
#define RCSS_BIT        0x00F00000
#define WCSS_BIT        0x000F0000
#define RCSH_BIT        0x0000F000
#define WCSH_BIT        0x00000F00
#define LTCY_BIT        0x0000000F
#define GPO_BIT         0x00000003
#define WM_BIT          0x00000003
#define WP_BIT          0x00000001
#define LOOPBACK_BIT    0x00000001
#if (RPC2_CTRL_IP_VER >= 240)
#define RTA_BIT         0x00000030
#define WTA_BIT         0x00000003
#endif

#if (RPC2_CTRL_IP_VER >= 220)
#define REG_CSR_RO_BIT  (WRSTOERR_BIT | \
                         WTRSERR_BIT  | \
                         WDECERR_BIT  | \
                         WACT_BIT     | \
                         RDSSTALL_BIT | \
                         RRSTOERR_BIT | \
                         RTRSERR_BIT  | \
                         RDECERR_BIT  | \
                         RACT_BIT)
#else
#define REG_CSR_RO_BIT  (WTQ_BIT | RTQ_BIT)
#endif
#define REG_IEN_RW_BIT  (INTP_BIT | RPCINTE_BIT)
#define REG_ISR_RO_BIT  RPCINTS_BIT
#define REG_ICR_RW_BIT  0x00000000
#define REG_MBR_RW_BIT  (A_BIT)
#if (RPC2_CTRL_IP_VER >= 230)
#define REG_MCR_RW_BIT  (MAXEN_BIT    | \
                         MAXLEN_BIT   | \
                         TCMO_BIT     | \
                         ACS_BIT      | \
                         CRT_BIT      | \
                         DEVTYPE_BIT  | \
                         WRAPSIZE_BIT)
#else
#define REG_MCR_RW_BIT  (TCMO_BIT     | \
                         ACS_BIT      | \
                         CRT_BIT      | \
                         DEVTYPE_BIT  | \
                         WRAPSIZE_BIT)
#endif
#define REG_MTR_RW_BIT  (RCSHI_BIT | WCSHI_BIT | RCSS_BIT | WCSS_BIT | RCSH_BIT | WCSH_BIT | LTCY_BIT)
#define REG_GPOR_RW_BIT (GPO_BIT)
#define REG_RWM_RW_BIT  (WM_BIT)
#define REG_WPR_RW_BIT  (WP_BIT)
#define REG_LBR_RW_BIT  (LOOPBACK_BIT)
#if (RPC2_CTRL_IP_VER >= 240)
#define REG_TAR_RW_BIT  (RTA_BIT | WTA_BIT)
#endif

#define BIT0            0x00000001
#define BIT1            (BIT0 << 1)

#if (RPC2_CTRL_IP_VER >= 240)
#define SET_RTA(value)           ((value << 4) & RTA_BIT)
#define CLR_RTA(value)           (value & ~RTA_BIT)
#define GET_RTA(value)           ((value & RTA_BIT) >> 4)

#define SET_WTA(value)           (value & WTA_BIT)
#define CLR_WTA(value)           (value & ~WTA_BIT)
#define GET_WTA(value)           (value & WTA_BIT)
#endif

#if (RPC2_CTRL_IP_VER >= 230)
#define MAXEN_DISABLED           (0)
#define MAXEN_ENABLED            (1)

#define SET_MAXEN(value)         ((value & BIT0) << 31)
#define CLR_MAXEN                (~(BIT0 << 31))
#define GET_MAXEN(value)         ((value >> 31) & BIT0)

#define SET_MAXLEN(value)        ((value << 18) & MAXLEN_BIT)
#define CLR_MAXLEN(value)        (value & ~MAXLEN_BIT)
#define GET_MAXLEN(value)        ((value & MAXLEN_BIT) >> 18)
#endif

#if (RPC2_CTRL_IP_VER >= 220)
#define CSR_DEFAULT              (0)

#define GET_WRSTOERR(value)      ((value >> 26) & BIT0)
#define GET_WTRSERR(value)       ((value >> 25) & BIT0)
#define GET_WDECERR(value)       ((value >> 24) & BIT0)
#define GET_WACT(value)          ((value >> 16) & BIT0)
#define GET_RDSSTALL(value)      ((value >> 11) & BIT0)
#define GET_RRSTOERR(value)      ((value >> 10) & BIT0)
#define GET_RTRSERR(value)       ((value >>  9) & BIT0)
#define GET_RDECERR(value)       ((value >>  8) & BIT0)
#define GET_RACT(value)          (value & BIT0)
#endif

#define GET_WP(value)            (value & BIT0)
#define GET_INT_EN(value)        (value & BIT0)
#define GET_INT_POLARITY(value)  (value >> 31)  

#define SET_TC_OPTION(value)     ((value & BIT0) << 17)
#define CLR_TC_OPTION            (~(BIT0 << 17))
#define GET_TC_OPTION(value)     ((value >> 17) & BIT0)

#define SET_WRAP_SIZE(value)     (value & (BIT0|BIT1))
#define CLR_WRAP_SIZE            (~(BIT0|BIT1))
#define GET_WRAP_SIZE(value)     (value & (BIT0|BIT1))

#define WRAPSIZE_16B             (0x2)
#define WRAPSIZE_32B             (0x3)
#define WRAPSIZE_64B             (0x1)

#define FLASH_WRAPSIZE_16B       (WRAPSIZE_16B)
#define FLASH_WRAPSIZE_32B       (WRAPSIZE_32B)
#define FLASH_WRAPSIZE_64B       (WRAPSIZE_64B)

#define PSRAM_WRAPSIZE_16B       (WRAPSIZE_16B)
#define PSRAM_WRAPSIZE_32B       (WRAPSIZE_32B)
#define PSRAM_WRAPSIZE_64B       (0x0)

#define SET_ACACHE(value)        ((value & BIT0) << 16)
#define CLR_ACACHE               (~(BIT0 << 16))
#define GET_ACACHE(value)        ((value >> 16) & BIT0)

#if (RPC2_CTRL_IP_VER >= 200)
#define SET_8BIT_CTRL(value)     ((value & BIT0) <<  4)
#define CLR_8BIT_CTRL            (~(BIT0 <<  4))
#define GET_8BIT_CTRL(value)     ((value >>  4) & BIT0)
#else
#define SET_8BIT_CTRL(value)     ((value & BIT0) << 31)
#define CLR_8BIT_CTRL            (~(BIT0 << 31))
#define GET_8BIT_CTRL(value)     ((value >> 31) & BIT0)
#endif

#define SET_DEVTYPE(value)       ((value & BIT0) <<  4)
#define CLR_DEVTYPE              (~(BIT0 <<  4))
#define GET_DEVTYPE(value)       ((value >>  4) & BIT0)

#define SET_CRT(value)           ((value & BIT0) <<  5)
#define CLR_CRT                  (~(BIT0 <<  5))
#define GET_CRT(value)           ((value >>  5) & BIT0)

#define SET_GPO(value, bit)      ((value & BIT0) << (bit & 31))
#define CLR_GPO(bit)             (~(BIT0 << (bit & 31)))
#define GET_GPO(value, bit)      ((value >> (bit & 31)) & BIT0)

#define SET_RCSHI(value)         ((value << 28) & RCSHI_BIT)
#define SET_WCSHI(value)         ((value << 24) & WCSHI_BIT)
#define SET_RCSS(value)          ((value << 20) & RCSS_BIT)
#define SET_WCSS(value)          ((value << 16) & WCSS_BIT)
#define SET_RCSH(value)          ((value << 12) & RCSH_BIT)
#define SET_WCSH(value)          ((value <<  8) & WCSH_BIT)
#define SET_LTCY(value)          ((value <<  0) & LTCY_BIT)

#define CLR_RCSHI(value)         (value & ~RCSHI_BIT)
#define CLR_WCSHI(value)         (value & ~WCSHI_BIT)
#define CLR_RCSS(value)          (value & ~RCSS_BIT)
#define CLR_WCSS(value)          (value & ~WCSS_BIT)
#define CLR_RCSH(value)          (value & ~RCSH_BIT)
#define CLR_WCSH(value)          (value & ~WCSH_BIT)
#define CLR_LTCY(value)          (value & ~LTCY_BIT)

#define GET_RCSHI(value)         ((value & RCSHI_BIT) >> 28)
#define GET_WCSHI(value)         ((value & WCSHI_BIT) >> 24)
#define GET_RCSS(value)          ((value & RCSS_BIT)  >> 20)
#define GET_WCSS(value)          ((value & WCSS_BIT)  >> 16)
#define GET_RCSH(value)          ((value & RCSH_BIT)  >> 12)
#define GET_WCSH(value)          ((value & WCSH_BIT)  >>  8)
#define GET_LTCY(value)          ((value & LTCY_BIT)  >>  0)

#define LTCY_5                   (0x0)
#define LTCY_6                   (0x1)
#define LTCY_3                   (0xE)
#define LTCY_4                   (0xF)

#define MTR_INIT                 (LTCY_6)

#define FLASH                    (0)
#define PSRAM                    (1)

#ifndef CS0_DEVTYPE
#define CS0_DEVTYPE              FLASH
#endif

#ifndef CS1_DEVTYPE
#define CS1_DEVTYPE              FLASH
#endif

#define FLASH_SIZE               (0)
#define PSRAM_SIZE               (0x800000)

#define LOOPBACK_DISABLED        (0)
#define LOOPBACK_ENABLED         (1)
#define ICR_REG_INVARID          (0)
#define ICR_REG_VARID            (1)

#if (RPC2_CTRL_IP_VER >= 230)
#define MAXLEN_MAX               (0x1FF)
#endif

#if (RPC2_CTRL_IP_VER >= 240)
#define TAR_INIT                 (0)
#define RTA_MAX                  (3)
#define WTA_MAX                  (3)
#endif

#define MAX_AXI_BURST_SIZE       (BYTE_4)

#define MIN_WRAP_SIZE            (WRAP_2B)
#define MAX_WRAP_SIZE            ((1 << MAX_AXI_BURST_SIZE)*WRAP_MAX_LEN)
 
//=============================================================================
//  STRUCTS
//=============================================================================
typedef struct {
  DWORD sig;
//  int (*func)(DWORD mbrReg, DWORD cs);
  int (*func)(DWORD cs);
  const char* title;
} TTestCase;

enum {
  UNDO = 0,
  PASS,
  FAIL
} EResult;

// Data Pattern
enum {
  WORD_ADDRESS = 0x00000000,
  WORD_ADDRESS_PLUS_1,
  RANDOM,
  FIXED_0
} EDataPattern;

//=============================================================================
//  PROTOTYPES
//=============================================================================
void setDataPattern (DWORD pattern);
void getDataPattern (DWORD* pattern);
void genFixData (WORD* genData, WORD initData, DWORD len16);
void fillBuffer (DWORD pattern, WORD* buf, DWORD len16);
void printBuffer (WORD* buf, DWORD len16);
int verifyData (WORD* act, WORD* exp, DWORD len16);
int verifyData8 (BYTE* act, BYTE* exp, DWORD len8);
int verifyData32 (DWORD* act, DWORD* exp, DWORD len);
void wrapMemCopy (WORD *dist, WORD *src, DWORD len16, DWORD start_pos);
void wrapMemCopy8 (BYTE *dist, BYTE *src, DWORD len8, DWORD start_pos);
void wrapMemCopy32 (DWORD *dist, DWORD *src, DWORD len, DWORD start_pos);

int setLoopbackMode (DWORD loopback);
int setMemBaseAddress (DWORD address, DWORD cs);
int getMemBaseAddress (DWORD* address, DWORD cs);
int getCsNum (DWORD address, DWORD* cs);
int setWaterMark (DWORD wm);
int setWriteProtect (DWORD wp);
int setInterruptEnable (DWORD ie);
int getInterruptStatus (DWORD* interrupt);
int setTCOption (DWORD value, DWORD cs);
int setWrapSize (DWORD size, DWORD cs);
int setACacheSupport (DWORD support, DWORD cs);
int getNumTransaction(WORD* numWr, WORD* numRd);
int setByteEnable (DWORD byteCtrl, DWORD cs);
int setDevType (DWORD devType, DWORD cs);
int getDevType (DWORD* devType, DWORD cs);
int setConfigRegTarget(DWORD target, DWORD cs);

#if (RPC2_CTRL_IP_VER >= 230)
int setMAXEN (DWORD maxen, DWORD cs);
int setMAXLEN (DWORD maxlen, DWORD cs);
int getMAXEN (DWORD *maxen, DWORD cs);
int getMAXLEN (DWORD *maxlen, DWORD cs);
#endif

int setRCSHIcycle(DWORD target, DWORD cs);
int setWCSHIcycle(DWORD target, DWORD cs);
int setRCSScycle(DWORD target, DWORD cs);
int setWCSScycle(DWORD target, DWORD cs);
int setRCSHcycle(DWORD target, DWORD cs);
int setWCSHcycle(DWORD target, DWORD cs);
int setLTCYcycle(DWORD target, DWORD cs);
int setGeneralPurposeOutput(DWORD target, DWORD bit);

#if (RPC2_CTRL_IP_VER >= 240)
int setRTA (DWORD rta);
int setWTA (DWORD wta);
int getRTA (DWORD* rta);
int getWTA (DWORD* wta);
#endif
#endif //__RPC2_COMMON_H__
