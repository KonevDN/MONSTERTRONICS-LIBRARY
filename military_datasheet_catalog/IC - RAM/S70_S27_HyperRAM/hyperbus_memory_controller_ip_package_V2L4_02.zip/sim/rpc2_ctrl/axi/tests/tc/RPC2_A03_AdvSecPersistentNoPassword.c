#ifdef SIMULATION
#include "sltapi_sim.h"
#include "svdpi.h"
#include "dpiheader.h"
#include <math.h>
#include "rpc2_vlld.h"
#include "rpc2_llops.h"
#else
#include <sltapi.h>
#endif
#include "rpc2.h"
#ifdef NCSC
extern int io_printf(const char *fmt, ...);
#define printf io_printf
#endif

//----------------------------------------------------------------------------------
// 	Script: Advanced Sector Persistent Protection without password test
//  Before running this script, the Include.scp needs to be downloaded first.
//----------------------------------------------------------------------------------

enum
{
	CLEARDYBL,
	SETDYBL,
	SCRPPAGESIZE = 8,
	PASSVALUE = 0x5555
};

enum
{
	CLEARPPBL,
	SETPPBL
};

PDEV pDevice;

DWORD test_exit(DWORD exit_val)
{
    if (exit_val)
    {
        SetGlobalVar("SKIP", 1);
	printf("<TC> Test =========================== Fail\n");
    }
    else {
      printf("<TC> Test =========================== Pass\n");
    }
    return (exit_val);
}

#ifdef SIMULATION
int c_test()
#else
int main(int argc, char* argv[])
#endif
{
	DWORD errCode, i, Data;
	WORD  password[4];
	WORD  pwdValue[4];
	
#ifndef SIMULATION
    SKIP = GetGlobalVar("SKIP");
#endif
    if (SKIP)
    {
        line_space(2);
        printf("Test is skipped\n");
        return test_exit(__LINE__);
    }

#ifdef SIMULATION
    pDevice = NewDeviceObject(0, RPC);
#endif
	pDevice = Find_Device(RPC);
	
	//if (!(FS_PERSISTENTSECTOR & SCRPSupport(pDevice)))
    if (!(FS_SECTORPROTECT & SCRPSupport(pDevice)))
    {
        printf("Error: Advanced Sector Protection not supported\n");
        return test_exit(__LINE__);
    }
	password[0] = 0x1111;
	password[1] = 0x2222;
	password[2] = 0x3333;
	password[3] = 0x4444;		
	//FTHardwareResetFlash(TRUE);
	errCode = EC_NONE;
    printf("Advanced Sector Persistent Protection Enable Mode and Password Test\n");

    SCRPGetASPFunc(pDevice, ASP_PWD, 0, &Data);
    switch (Data)
    {
        case PROT_NONE:
            printf("No Password and no Persistent Mode setting \n");

            for (i = 0; i < 4; i++)
            {
                errCode = SCRPProgPassword( pDevice, i, (DWORD)password[i] );
                if (errCode != EC_NONE)
                {
                    printf("Error: Program Password: %s\n", GetErrorText(errCode));
                    #ifndef SIMULATION
                    OutputLog(pDevice, LOG_DISP_NORM, 0, -50);
                    #endif
                    return test_exit(__LINE__);
                }
            }

   			SCRPReadPassword( pDevice, pwdValue );
   			for (i = 0; i < 4; i++)
   				printf("read = 0x%04X  expect = 0x%04X\n", pwdValue[i], password[i]);
   			
			for (i = 0; i < 4; i++)
            {
				if (pwdValue[i] != password[i])
				{
                    printf("Error: Verify Programmed Password\n");
                    #ifndef SIMULATION
                    OutputLog(pDevice, LOG_DISP_NORM, 0, -50);
                    #endif
                    return test_exit(__LINE__);
				}
            }

            // Do not program the lock register
            // Attempt to set both PWDE and PWDD at the same time.  Should timeout.
            printf("Try to set PPB and PASSWORD protection mode at the same time\n");
            if (( errCode = SCRPSetASPFunc( pDevice, ASP_PWDED, 0, TRUE )) != EC_PWDETIMEOUT )
            {
                printf("Error: PPB and PASSWORD protection modes can be set at the same time\n");
                #ifndef SIMULATION
                OutputLog(pDevice, LOG_DISP_NORM, 0, -50);
                #endif
                return test_exit(__LINE__);
            }
            else
                printf("PPB and PASSWORD protection mode can not be set at the same time (good)\n");

            //Add to clear failure status in SR, HUANG WEI, 20130619
            SCRPClrDeviceStatus(pDevice, 0);
            
            // Attempt to enable Persistent Protection mode.
            if (( errCode = SCRPSetASPFunc( pDevice, ASP_PWD, 0, PROT_PERSISTENT )) != EC_NONE )
            {
                printf("Error: Set PPB protection mode failed\n");
                #ifndef SIMULATION
                OutputLog(pDevice, LOG_DISP_NORM, 0, -50);
                #endif
                return test_exit(__LINE__);
			}
			else
                printf("Set PPB protection mode ... OK\n");

            // If PWD is not disabled, it's fatal at this point in the test.
			SCRPGetASPFunc( pDevice, ASP_PWD, 0, &Data );
			if (Data == PROT_PASSWORD || Data == PROT_NONE)
   			{
                printf("Error: PASSWORD mode is set or no protection\n");
                #ifndef SIMULATION
                OutputLog(pDevice, LOG_DISP_NORM, 0, -50);
                #endif
                return test_exit(__LINE__);
            }
            else
                printf("Persistent Protection Mode is enabled\n");
            break;
        case PROT_PERSISTENT:
            printf("Persitent Protection Enable Mode is already ON\n");
            break;
        case PROT_PASSWORD:
        default:
            printf("Error: This device has been set to PASSWORD protection mode\n");
            #ifndef SIMULATION
            OutputLog(pDevice, LOG_DISP_NORM, 0, -50);
            #endif
            return test_exit(__LINE__);
	}

    // Attempt to set the PWDE bit to enable password mode. Should FAIL!
    if ( SCRPSetASPFunc( pDevice, ASP_PWD, 0, PROT_PASSWORD ) == EC_NONE)
    {
        printf("Error: PPB mode device can be set to PASSWORD mode\n");
        #ifndef SIMULATION
        OutputLog(pDevice, LOG_DISP_NORM, 0, -50);
        #endif
        return test_exit(__LINE__);
    }
    else
        printf("Password Protection can NOT be enabled... OK\n");

    // Attempt to read and verify password.  Should pass.
    SCRPReadPassword( pDevice, pwdValue );
    for (i = 0; i < 4; i++)
    {
        if (pwdValue[i] != password[i])
        {
            printf("Error: read password from a PPB mode device failed\n");
            #ifndef SIMULATION
            OutputLog(pDevice, LOG_DISP_NORM, 0, -50);
            #endif
            return test_exit(__LINE__);
        }
    }

	printf("Read password from a PPB mode device... OK\n");


	// Attempt to program password registers.  should fail.
	//for (i = 0; i < 4; i++)
	//	if (SCRPProgPassword( pDevice, i, 0 ) == EC_NONE)
	//	{
	//		errCode = EC_PWDPROGSUCCESS;
	//		break;
	//	}

	//if (errCode)
	//{
	//	printf("%s\n", GetErrorText(errCode));
	//	return 0;    	
	//}
	//printf("Password are failed to program. TEST OK\n");

	SCRPGetASPFunc( pDevice, ASP_PPBL, 0, &Data );
   	if ( Data )
   	{
        printf("Error: PPB Lock is enabled on a PPB mode device\n");
        #ifndef SIMULATION
        OutputLog(pDevice, LOG_DISP_NORM, 0, -50);
        #endif
        return test_exit(__LINE__);
    }
    else
        printf("PPB Lock bit is not locked for a PPB mode device... OK\n");

    printf("Test complete\n");
    return test_exit(0);

}

