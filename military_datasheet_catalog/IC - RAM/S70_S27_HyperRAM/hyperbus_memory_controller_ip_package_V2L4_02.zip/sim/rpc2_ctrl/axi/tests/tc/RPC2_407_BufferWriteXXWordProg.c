#ifdef SIMULATION
#include "sltapi_sim.h"
#include "svdpi.h"
#include "dpiheader.h"
#include <math.h>
#include "rpc2_vlld.h"
#include "rpc2_llops.h"

#else
#include <sltapi.h>
#endif

#include "rpc2.h"

#ifdef NCSC
extern int io_printf(const char *fmt, ...);
#define printf io_printf
#endif

//
//----------------------------------------------------------------------------------
//  Script: Buffer Write with XX Word Program test
//----------------------------------------------------------------------------------
char Script[] = "407_BufferWriteXXWordProg";
char TestTitle[] = "Buffer Write with XX Word Program test";

// Command line arguments and their default values
DWORD PreRead   = YES;         // Blank check before buffer write: enabled(YES), disabled(NO)
DWORD help_only = NO;          // display help only (NO), execute test (YES)
DWORD bw_rv     = YES;         // buffer write read verify
DWORD sect_rv   = YES;          // sector read verify
DWORD bwsize    = 0;           // buffer write size, 0=use max buffer size

PDEV pDevice;

// Test Configuration
SKIP            = 0;
LOOP_COUNT = 1;
SOE = SOE_SETTING;     //Stop on Error: enable(1), disable(0)


// Global variables
WORD *pSrcData = (WORD *)NULL;
WORD *pDestData = (WORD *)NULL;
STS t0, t1;
char s[81];



// Functions prototyping
DWORD BufferWriteProgram(PDEV, DWORD, DWORD, WORD *, DWORD);
DWORD test_exit(DWORD exit_val);
DWORD GetDataPattern(DWORD * dpvar);
DWORD EraseSector(PDEV dev, DWORD sector);
void linespace(DWORD n);
void disp_arg(void);

//----------------------------------------------------------------------------------
//NOR Test script begin
//----------------------------------------------------------------------------------
#ifdef SIMULATION
int c_test()
#else
int main(int argc, char* argv[])
#endif
{
    DWORD tSector, tSecAddr, tSecSize;
    DWORD /*logStat,*/ errCode;
    DWORD totalSectors, bufSize, largeSecSize;
    DWORD i;
    DWORD loop;
//    int voltage, temperature;
    DWORD data_p;
    

    printf("Test: %s\n", Script);
    printf("%s\n", TestTitle);

#ifndef SIMULATION
    SKIP = GetGlobalVar("SKIP");
#endif
    if (SKIP)
    {
        line_space(2);
        printf("Test is skipped\n");
        return __LINE__;
    }
    linespace(2);
	
#ifndef SIMULATION
    GetArgEnum("help", &help_only, "YES_NO");
#endif

    if (help_only == YES)
    {
        printf("Command line parameters:\n");
        printf("dp: data pattern\n");
        printf("pr: buffer write pre-read blank check\n");
        printf("bs: buffer-write size\n");
        printf("br: buffer-write read verify\n");
        printf("sr: sector read verify\n");
        printf("example:\n");
        printf(" dp=WORDS_ARE_0X0000 bs=32 pr=YES br=NO sr=YES\n");
        return 0;
    }

#ifdef SIMULATION
    pDevice = NewDeviceObject(0, RPC);
#endif
    pDevice = Find_Device(RPC);
    if (!pDevice)
    {
        printf("Error: device not found\n");
        return __LINE__;
    }

#ifdef SIMULATION
    SCRPQSPISetWP(pDevice, FALSE);
    printf("<TC> Enable write\n");
    SYS_WaitUSec(300);
#endif
	
    SYS_GetTimestamp(&t0);
    //SCRPCmdResetFlash(pDevice);
    //SCRPASPUnlock(pDevice);

    errCode = EC_NONE;
    totalSectors = SCRPGetFAPIInfo(pDevice, SECTOR_COUNT);
    bufSize = SCRPGetFAPIInfo(pDevice, WRITE_BUFFER_SIZE);
    largeSecSize = SCRPGetFAPIInfo(pDevice, LARGEST_SECTOR);
    pSrcData = (WORD *) malloc(sizeof(WORD) * largeSecSize);
    pDestData = (WORD *) malloc(sizeof(WORD) * largeSecSize);
    if (!pSrcData || !pDestData)
    {
        printf("malloc error!\n");
        return test_exit(__LINE__);
    }
#ifndef SIMULATION
    GetArgEnum("pr", &PreRead, "YES_NO");
    GetArgEnum("br", &bw_rv, "YES_NO");
    GetArgEnum("sr", &sect_rv, "YES_NO");
    GetArg("bs", &bwsize);
#endif
    if (bwsize == 0)
        bwsize = bufSize;
#ifdef SIMULATION
    #ifdef DEF_BUFSIZE
    if(DEF_BUFSIZE==0)
        bwsize = bufSize;
    else
    bwsize = DEF_BUFSIZE;
    #endif
#endif

    data_p = WORDS_ARE_RANDOM;
#ifdef SIMULATION
    #ifdef DEF_DATA_PATTERN
    if(DEF_DATA_PATTERN==1)
    data_p = WORDS_ARE_RANDOM;
    else if(DEF_DATA_PATTERN==2)
    data_p = WORDS_ARE_ADDRESS_PLUS_1;
    else if(DEF_DATA_PATTERN==3)
    data_p = WORDS_ALT_0X55AA_0XAA55;
    else
    data_p = WORDS_ARE_RANDOM;    
    #endif
#endif
    if (data_p == WORDS_ARE_RANDOM)
    {
        srand(100);
        printf("<TC> Random Seed = 100\n");
    }
    linespace(2);
    printf("Initializing Buffers %d words\n", largeSecSize);
    GetDataPattern(&data_p);
    FillBuffer(data_p, pSrcData, largeSecSize);
    linespace(1);
    printf("Data pattern\n");
    if (1) // display first 128 words data pattern
    {
        for (i = 0; i < 128; i++)
        {
            if ((i % 8) == 0)
                printf("\n%04X ", i);
            printf("%04X ", pSrcData[i]);
        }
        printf("\n");
        printf("...\n...\n");

        //return test_exit(__LINE__);
    }

    linespace(2);
    printf("Word szie of buffer write = %d words\n", bwsize);
#ifndef SIMULATION
    SYS_GetVoltage(VOLT_3, &voltage);
    SYS_GetTemperature(0, &temperature);
    printf("Temperature = %dC\n", temperature);
    printf("Voltage = %d.%dV\n", voltage/1000, voltage%1000);
#endif
    disp_arg();
    linespace(2);

    for (loop = 0; loop < LOOP_COUNT; loop++)
    {
        printf("loop = %d\n",loop);
		#ifndef SIMULATION
        ClearDevLog(pDevice);
		#endif
        for (tSector = 0; tSector < totalSectors; tSector++)

        {
            tSecAddr  = SCRPGetFAPIGeometry(pDevice, ADDRESS_OF_SECTOR, tSector);
            tSecSize = SCRPGetFAPIGeometry(pDevice, WORD_COUNT_OF_SECTOR, tSector);
            printf("\nErasing Sector %d ... ", tSector);
            if (SYS_CheckUserBreak())
            {
                printf("\n\nUser Break\n");
                return test_exit(0);
            }

            //if (SCRPGetBadSector(pDevice, tSector))
            //    continue;
            errCode = EraseSector(pDevice, tSector);
            if (errCode != EC_NONE)
            {
                if (SOE)
                {
                    printf("\n\nStop on Error\n");
                    return test_exit(__LINE__);
                }
                continue;   // move on to next sector
            }
			#ifndef SIMULATION
            ClearDevLog(pDevice);
            logStat = SaveDevLogState(pDevice);
            SetLogDevice(pDevice, LOG_RW_ALL);
			#endif
            printf("Buffer Write on sector %d\n", tSector);
            errCode = BufferWriteProgram(pDevice, tSecAddr, tSecSize, pSrcData, bwsize);
            if (errCode != EC_NONE)
            {
                printf("Error: %s", GetErrorText(errCode));
                if (SOE)
                {
                    printf("\n\nStop on Error\n");
                    return test_exit(__LINE__);
                }
                continue;   // move on to next sector
            }

            if (sect_rv == YES)
            {
                errCode = EC_NONE;
                memset(pDestData, 0, sizeof(WORD) * tSecSize);
                printf("Read Verify on address 0x%08X with length of %d words\n", tSecAddr, tSecSize);

                errCode = SCRPReadArray(pDevice, pDestData, tSecAddr, tSecSize);
                if (errCode != EC_NONE)
                {
                    printf("Error: %s", GetErrorText(errCode));
                    if (SOE)
                    {
                        printf("\n\nStop on Error\n");
                        return test_exit(__LINE__);
                    }
                    continue;   // move on to next sector
                }
				#ifndef SIMULATION
                RestoreDevLogState(pDevice, logStat);
				#endif
                for (i = 0; i < tSecSize; i++)
                {
                    if (pSrcData[i] != pDestData[i])
                    {
                        printf("Error: expect 0x%04X, read 0x%04X, Offset 0x%08X\n", pSrcData[i], pDestData[i], tSecAddr + i);
                        if (SOE)
                        {
                            printf("\n\nStop on Error\n");
                            return test_exit(__LINE__);
                        }
                        break;
                    }
                }
            } // if (sect_rv == YES)
        } // for (tSector = 0; tSector < totalSectors; tSector++)
    } // for (loop = 0; loop < LOOP_COUNT; loop++)

    printf("Test complete\n");
    if (TASK_DELAY)
        //SYS_OSTickDelay(TASK_DELAY);
        SYS_WaitUSec(TASK_DELAY);
    return test_exit(0);
} // main()

DWORD BufferWriteProgram(PDEV pDevice, DWORD secAddr, DWORD progSize, WORD *pData,
                         DWORD bwsize)
{
    DWORD errCode;
    DWORD i, j, k;
    //DWORD bufSize;
    DWORD bw_loop;

    errCode = EC_NONE;
    //bufSize = SCRPGetFAPIInfo(pDevice, WRITE_BUFFER_SIZE);
    bw_loop = progSize / bwsize;

    j = 0;
    for (i = 0; i < bw_loop; i++)
    {
    	#ifndef SIMULATION
        ClearDevLog(pDevice);
		#endif
        if (PreRead == YES)
            errCode = SCRPBufferWriteBlankCheck(pDevice, &pData[j], secAddr, bwsize, TRUE);
        else
            errCode = SCRPBufferWrite(pDevice, &pData[j], secAddr, bwsize, TRUE);
 
        if (errCode != EC_NONE)
        {
			#ifndef SIMULATION
			OutputLog(pDevice, LOG_DISP_NORM, 0, -30);
			#endif
            return errCode;
        }

        if (bw_rv == YES)
        {
            errCode = SCRPReadArray(pDevice, pDestData, secAddr, bwsize);
            for (k = 0; k < bwsize; k++)
            {
                if (pData[k + j] != pDestData[k])
                {
                    printf("Written: 0x%04X, Read: 0x%04X, Offset: 0x%04X\n", pData[k + j], pDestData[k], k + j);
                    //break;
                }
            }
        } // if (bw_rv == YES)

        j += bwsize;
        secAddr += bwsize;
    }

    return(errCode);
} // BufferWriteProgram()

DWORD test_exit(DWORD exit_val)
{
    if (pSrcData) free(pSrcData);
    if (pDestData) free(pDestData);

    SYS_GetTimestamp(&t1);
    FormatDeltaTime(s, &t0, &t1);
    printf("Test time: %s\n", s);

    if (exit_val)
    {
        SetGlobalVar("SKIP", 1);
	printf("<TC> Test =========================== Fail\n");
    }
    else {
      printf("<TC> Test =========================== Pass\n");
    }
    return exit_val;
} // test_exit()

DWORD GetDataPattern(DWORD * dpvar)
{
//    DWORD adata_p=WORDS_ARE_0X0000;
    DWORD status = TRUE;
	#ifndef SIMULATION
    status = GetArgEnum("dp", &adata_p, "FILL_TYPES");
	
    if (status == TRUE)
        *dpvar = adata_p;
    else
    {
        printf("Warning: dp argument missing or wrong\n");
        printf("Use default data pattern\n");
        *dpvar = WORDS_ARE_0X0000;
    }
    #endif
    if (1)
    {
        printf("data pattern = ");
        switch (*dpvar)
        {
            case BYTES_ARE_0X00:
                printf("BYTES_ARE_0X00\n");
                break;
            case BYTES_ARE_0X55:
                printf("BYTES_ARE_0X55\n");
                break;
            case BYTES_ARE_0XFF:
                printf("BYTES_ARE_0XFF\n");
                break;
            case BYTES_ALT_0X00_0XFF:
                printf("BYTES_ALT_0X00_0XFF\n");
                break;
            case BYTES_ALT_0X55_0XAA:
                printf("BYTES_ALT_0X55_0XAA\n");
                break;
            case BYTES_ARE_ADDRESSES:
                printf("BYTES_ARE_ADDRESSES\n");
                break;
            case BYTES_ARE_RANDOM:
                printf("BYTES_ARE_RANDOM\n");
                break;
            case WORDS_ARE_0X0000:
                printf("WORDS_ARE_0X0000\n");
                break;
            case WORDS_ARE_0X5555:
                printf("WORDS_ARE_0X5555\n");
                break;
            case WORDS_ARE_0XFFFF:
                printf("WORDS_ARE_0XFFFF\n");
                break;
            case WORDS_ALT_0X0000_0XFFFF:
                printf("WORDS_ALT_0X0000_0XFFFF\n");
                break;
            case WORDS_ALT_0X5555_0XAAAA:
                printf("WORDS_ALT_0X5555_0XAAAA\n");
                break;
            case WORDS_ALT_0X55AA_0XAA55:
                printf("WORDS_ALT_0X55AA_0XAA55\n");
                break;
            case WORDS_ARE_ADDRESS_PLUS_1:
                printf("WORDS_ARE_ADDRESS_PLUS_1\n");
                break;
            case WORDS_ARE_CKBD:
                printf("WORDS_ARE_CKBD\n");
                break;
            case WORDS_ALT_4_OF_0X0000_4_OF_0XFFFF:
                printf("WORDS_ALT_4_OF_0X0000_4_OF_0XFFFF\n");
                break;
            case WORDS_ARE_ADDRESSES:
                printf("WORDS_ARE_ADDRESSES\n");
                break;
            case WORDS_ARE_RANDOM:
                printf("WORDS_ARE_RANDOM\n");
                break;
        } // switch
    } // if (0/1)
    return status;
} // GetDataPattern()

DWORD EraseSector(PDEV dev, DWORD sector)
{
    DWORD errCode;
//    DWORD logStat;
    DWORD secSize;
    DWORD secAddr;
    DWORD i;

    secSize = SCRPGetFAPIGeometry(dev, WORD_COUNT_OF_SECTOR, sector);
    secAddr  = SCRPGetFAPIGeometry(dev, ADDRESS_OF_SECTOR, sector);

    errCode = SCRPEraseSector(dev, sector, TRUE);
    if (errCode != EC_NONE)
    {
        printf("Error: %s\n", GetErrorText(errCode));
		#ifndef SIMULATION
        OutputLog(dev, LOG_DISP_NORM, 0, -10);
		#endif
        return errCode;
    }

    errCode = EC_NONE;
    memset(pDestData, 0, sizeof(WORD) * secSize);
	#ifndef SIMULATION
    logStat = SaveDevLogState(dev);
    SetLogDevice(dev, LOG_RW_ALL);
	#endif
    SCRPReadArray(dev, pDestData, secAddr, secSize);
	#ifndef SIMULATION
    RestoreDevLogState(dev, logStat);
	#endif
    for (i = 0; i < secSize; i++)
    {
        if (pDestData[i] != 0xFFFF)
        {
            printf("Error: Blank Check\n");
            return EC_ERASEVERIFY;
        }
    }

    printf("OK\n");
    return EC_NONE;
} // EraseSector()

void linespace(DWORD n)
{
    DWORD i;

    for (i = 0; i < n; i++)
        printf("\n");
    printf("****************************\n");
} // linespace()

void disp_arg(void)
{
    printf("Command line parameters:\n");

    if (PreRead == YES) printf("pr = YES ");
    else printf("pr = NO ");
    printf("(buffer write pre-read blank check)\n");

    if (bw_rv == YES) printf("br = YES ");
    else printf("br = NO ");
    printf("(buffer-write read verify)\n");

    if (sect_rv == YES) printf("sr = YES ");
    else printf("sr = NO ");
    printf("(sector read verify)\n");

    printf("bs = %d words (buffer write size)\n", bwsize);
} // disp_arg()
