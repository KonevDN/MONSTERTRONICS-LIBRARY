
Altera Package kit for Mentor Graphics Expedition program.

Version: 1.6

Disclaimer:
This document is for information and instruction purposes. Mentor Graphics reserves the right to make changes in specifications and other information contained in this publication without prior notice, and the reader should, in all cases, consult Mentor Graphics to determine whether any changes have been made.
The terms and conditions governing the sale and licensing of Mentor Graphics products are set forth in  written agreements between Mentor Graphics and its customers.  No representation or other affirmation of fact contained in this publication shall be deemed to be a warranty or give rise to any liability of Mentor Graphics whatsoever.
MENTOR GRAPHICS MAKES NO WARRANTY OF ANY KIND WITH REGARD TO THIS MATERIAL INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OR MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
MENTOR GRAPHICS SHALL NOT BE LIABLE FOR ANY INCIDENTAL, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES WHATSOEVER (INCLUDING BUT NOT LIMITED TO LOST PROFITS) ARISING OUT OF OR RELATED TO THIS PUBLICATION OR THE INFORMATION CONTAINED IN IT, EVEN IF MENTOR GRAPHICS CORPORATION HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

Description:
These package kit is generated based on the package information from http://www.altera.com/literature/ds/dspkg.pdf. 
"readme.txt" -- this file.
"Altera pakages list.xls" is a list of the cells and their crospondent padstack.
"cells" directory contains all the cells generated.
"padstacks"directory contains all the padstack needed for this package kit.
"Altera" directory is the whole library files master dir.

How to use these kit in Expedition
	1. Run Library Manager
	2. Create a new project
	3. Create patition for cell and padstack
	4. Tool->Library Service->Import ASCII, first import padstacks, then import cells.

How to use "Altera" directory --- the whole library files master dir.
        1. Invoke Library Manager for DxD-Expdition
	2. Open the .lmc file (Browse to the "Altera" directory).

Revision History:
1.0  16 July 2004
     - Initial release.

1.1   23 Aug 2004
     - Modify the cells by adding height parameters.

1.2   13 Oct 2004
     - Add .lmc file & the whole library files master dir.

1.2.1   2 June 2005
     - Add one package drawing to the table Altera pakages list.xls.(line 61)
     - Creat cell FBGA896-1M-31X31 at master.lmc library.
     - Add file FBGA896-1M-31X31.txt to the cells Dir.

1.3   15 Dec 2005
     - Add package drawing :
		BGA1508-1M-40X40
		BGA1152-1M-35X35
		BGA1020-1M-33X33
		BGA896-1M-31X31
		BGA780-1M-29X29
		BGA672-1M-27X27
		BGA484-0_8M-19X19
		BGA484-1M-27X27
		BGA484-1M-23X23
		BGA256-1_27M-27X27
		BGA256-1M-17X17
		SOIC24-1_27M-15_4X7_5
		SOIC16-1_27M-10_3X7_5
		SOIC8-1_27M-4_9X3_9

     - Modify package drawing :
		BGA600-1_27M-45X45.txt
		BGA652-1_27M-45X45.txt
		BGA672-1_27M-35X35.txt
		BGA724-1_27M-35X35.txt
		BGA956-1_27M-40X40.txt

     - Delete package drawing :
		DIP28-100-1370X295.txt
		EBGA256-50-1064X1064.txt
		FBGA256-1M-17X17.txt
		FBGA484-1M-23X23.txt
		FBGA672-1M-27X27.txt
		FBGA780-1M-29X29.txt
		FBGA896-1M-31X31.txt
		FBGA1020-1M-33X33.txt
		FBGA1508-1M-40X40.txt
		SOIC28-50-720X300.txt

1.4   17 Mar 2006
     - Modify package drawing :
		49-Pin Ultra Fineline BGA? (UBGA)-----------------------------BGA49-0_8M-7X7
		68-Pin Ceramic Pin-Grid Array (PGA)---------------------------PGA68-100-1120X1120
		88-Pin Ultra Fineline BGA? (UBGA)-----------------------------BGA88-0_8M-11X8
		100-Pin Fineline BGA? (FBGA)----------------------------------BGA100-1M-11X11
		144-Pin Fineline BGA? (FBGA)----------------------------------BGA144-1M-13X13
		169-Pin Ultra Fineline BGA? (UBGA)---------------------------BGA169-0_8M-11X11
		324-Pin Fineline BGA? (FBGA)----------------------------------BGA324-1M-19X19
		356-Pin Ball-Grid Array (BGA)-----------------------------------BGA356-1_27M-35X35
		400-Pin Fineline BGA? (FBGA)----------------------------------BGA400-1M-21X21
		

1.5   16 May 2006
     - Modify package drawing :
		100-Pin FineLine BGA? (FBGA) - Option 1-----------------------------BGA100-1M-11X11
		100-Pin FineLine BGA? (FBGA) - Option 2-----------------------------BGA100-1M-11X11
		100-Pin Micro FineLine BGA? (MBGA)---------------------------------BGA100-0_5M-6X6
		256-Pin Ultra FineLine BGA? (UBGA)-----------------------------------BGA256-0_8M-14X14
		256-Pin Micro FineLine BGA? (MBGA)---------------------------------BGA256-0_5M-11X11
		

1.6   26 May 2006
     - Modify package drawing
		